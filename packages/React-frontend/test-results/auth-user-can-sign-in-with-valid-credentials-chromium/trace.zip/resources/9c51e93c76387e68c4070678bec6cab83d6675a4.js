import { injectQuery as __vite__injectQuery } from "/@vite/client";import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=987d57e9";
import { A as UINT16_LE, B as require_browser, C as INT32_BE, G as EndOfStreamError, I as UINT64_LE, L as UINT8, N as UINT32_BE, O as StringType, P as UINT32_LE, _ as makeUnexpectedFileContentError, a as getMaxMemoryAllocation, k as UINT16_BE, o as getMaxMetadataEntries, p as InternalParserError, r as defaultMaxMetadataEntries } from "/node_modules/.vite/deps/BasicParser-CAIs-t7m.js?v=987d57e9";
import { a as fromBlob, o as fromBuffer, s as fromWebStream } from "/node_modules/.vite/deps/APEv2Parser-BWD6Dcm_.js?v=987d57e9";
import { n as TokenizerBoundaryError, t as createTokenizerView } from "/node_modules/.vite/deps/TokenizerView-COelGXyl.js?v=987d57e9";
import { f as concatUint8Arrays, n as decodeString, p as getUintBE, u as toRatio } from "/node_modules/.vite/deps/Util-DYMxorDw.js?v=987d57e9";
import { r as LyricsContentType, s as TimestampFormat } from "/node_modules/.vite/deps/ID3v2Token-DBHkmIVj.js?v=987d57e9";
import { n as TrackTypeValueToKeyMap, t as TrackType } from "/node_modules/.vite/deps/type-BPo7WUg5.js?v=987d57e9";
// node_modules/@tokenizer/inflate/lib/GzipHandler.js
var import_browser = /* @__PURE__ */ __toESM(require_browser(), 1);
var GzipHandler = class {
	constructor(tokenizer) {
		this.tokenizer = tokenizer;
	}
	inflate() {
		const tokenizer = this.tokenizer;
		return new ReadableStream({ async pull(controller) {
			const buffer = /* @__PURE__ */ new Uint8Array(1024);
			const size = await tokenizer.readBuffer(buffer, { mayBeLess: true });
			if (size === 0) {
				controller.close();
				return;
			}
			controller.enqueue(buffer.subarray(0, size));
		} }).pipeThrough(new DecompressionStream("gzip"));
	}
};
// node_modules/@tokenizer/inflate/lib/ZipLimitError.js
/** A configured ZIP processing limit was exceeded. */
var ZipLimitError = class extends RangeError {
	constructor(limit, requestedSize, maxSize) {
		super(`ZIP ${limit} exceeded: ${requestedSize} exceeds limit of ${maxSize}`);
		this.limit = limit;
		this.requestedSize = requestedSize;
		this.maxSize = maxSize;
		this.name = "ZipLimitError";
	}
};
// node_modules/@tokenizer/inflate/lib/ZipToken.js
/**
* Ref https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT
*/
var Signature = {
	LocalFileHeader: 67324752,
	DataDescriptor: 134695760,
	CentralFileHeader: 33639248,
	EndOfCentralDirectory: 101010256
};
var DataDescriptor = {
	get(array) {
		return {
			signature: UINT32_LE.get(array, 0),
			compressedSize: UINT32_LE.get(array, 8),
			uncompressedSize: UINT32_LE.get(array, 12)
		};
	},
	len: 16
};
/**
* First part of the ZIP Local File Header
* Offset | Bytes| Description
* -------|------+-------------------------------------------------------------------
*      0 |    4 | Signature (0x04034b50)
*      4 |    2 | Minimum version needed to extract
*      6 |    2 | Bit flag
*      8 |    2 | Compression method
*     10 |    2 | File last modification time (MS-DOS format)
*     12 |    2 | File last modification date (MS-DOS format)
*     14 |    4 | CRC-32 of uncompressed data
*     18 |    4 | Compressed size
*     22 |    4 | Uncompressed size
*     26 |    2 | File name length (n)
*     28 |    2 | Extra field length (m)
*     30 |    n | File name
* 30 + n |    m | Extra field
*/
var LocalFileHeaderToken = {
	get(array) {
		const flags = UINT16_LE.get(array, 6);
		return {
			signature: UINT32_LE.get(array, 0),
			minVersion: UINT16_LE.get(array, 4),
			dataDescriptor: !!(flags & 8),
			compressedMethod: UINT16_LE.get(array, 8),
			compressedSize: UINT32_LE.get(array, 18),
			uncompressedSize: UINT32_LE.get(array, 22),
			filenameLength: UINT16_LE.get(array, 26),
			extraFieldLength: UINT16_LE.get(array, 28),
			filename: null
		};
	},
	len: 30
};
/**
* 4.3.16  End of central directory record:
*  end of central dir signature (0x06064b50)                                      4 bytes
*  number of this disk                                                            2 bytes
*  number of the disk with the start of the central directory                     2 bytes
*  total number of entries in the central directory on this disk                  2 bytes
*  total number of entries in the size of the central directory                   2 bytes
*  sizeOfTheCentralDirectory                                                      4 bytes
*  offset of start of central directory with respect to the starting disk number  4 bytes
*  .ZIP file comment length                                                       2 bytes
*  .ZIP file comment       (variable size)
*/
var EndOfCentralDirectoryRecordToken = {
	get(array) {
		return {
			signature: UINT32_LE.get(array, 0),
			nrOfThisDisk: UINT16_LE.get(array, 4),
			nrOfThisDiskWithTheStart: UINT16_LE.get(array, 6),
			nrOfEntriesOnThisDisk: UINT16_LE.get(array, 8),
			nrOfEntriesOfSize: UINT16_LE.get(array, 10),
			sizeOfCd: UINT32_LE.get(array, 12),
			offsetOfStartOfCd: UINT32_LE.get(array, 16),
			zipFileCommentLength: UINT16_LE.get(array, 20)
		};
	},
	len: 22
};
/**
* File header:
*    central file header signature   4 bytes   0 (0x02014b50)
*    version made by                 2 bytes   4
*    version needed to extract       2 bytes   6
*    general purpose bit flag        2 bytes   8
*    compression method              2 bytes  10
*    last mod file time              2 bytes  12
*    last mod file date              2 bytes  14
*    crc-32                          4 bytes  16
*    compressed size                 4 bytes  20
*    uncompressed size               4 bytes  24
*    file name length                2 bytes  28
*    extra field length              2 bytes  30
*    file comment length             2 bytes  32
*    disk number start               2 bytes  34
*    internal file attributes        2 bytes  36
*    external file attributes        4 bytes  38
*    relative offset of local header 4 bytes  42
*/
var FileHeader = {
	get(array) {
		const flags = UINT16_LE.get(array, 8);
		return {
			signature: UINT32_LE.get(array, 0),
			minVersion: UINT16_LE.get(array, 6),
			dataDescriptor: !!(flags & 8),
			compressedMethod: UINT16_LE.get(array, 10),
			compressedSize: UINT32_LE.get(array, 20),
			uncompressedSize: UINT32_LE.get(array, 24),
			filenameLength: UINT16_LE.get(array, 28),
			extraFieldLength: UINT16_LE.get(array, 30),
			fileCommentLength: UINT16_LE.get(array, 32),
			relativeOffsetOfLocalHeader: UINT32_LE.get(array, 42),
			filename: null
		};
	},
	len: 46
};
// node_modules/@tokenizer/inflate/lib/ZipHandler.js
function signatureToArray(signature) {
	const signatureBytes = new Uint8Array(UINT32_LE.len);
	UINT32_LE.put(signatureBytes, 0, signature);
	return signatureBytes;
}
var debug$1 = (0, import_browser.default)("tokenizer:inflate");
var syncBufferSize = 262144;
var eocdSignatureBytes = signatureToArray(Signature.EndOfCentralDirectory);
var ZipHandler = class {
	constructor(tokenizer, options = {}) {
		this.tokenizer = tokenizer;
		this.syncBuffer = new Uint8Array(syncBufferSize);
		this.scannedBytes = 0;
		this.descriptorScannedBytes = 0;
		this.limits = {
			maxEntryCount: options.maxEntryCount ?? Number.POSITIVE_INFINITY,
			maxTotalScanBytes: options.maxTotalScanBytes ?? Number.POSITIVE_INFINITY,
			maxTotalDataDescriptorScanBytes: options.maxTotalDataDescriptorScanBytes ?? Number.POSITIVE_INFINITY,
			maxSkippedEntrySize: options.maxSkippedEntrySize ?? Number.POSITIVE_INFINITY,
			maxDataDescriptorScanBytes: options.maxDataDescriptorScanBytes ?? Number.POSITIVE_INFINITY,
			maxCompressedSize: options.maxCompressedSize ?? Number.POSITIVE_INFINITY,
			maxUncompressedSize: options.maxUncompressedSize ?? Number.POSITIVE_INFINITY
		};
		this.useCentralDirectory = options.useCentralDirectory ?? true;
		this.allowTruncatedDataDescriptor = options.allowTruncatedDataDescriptor ?? false;
		if (typeof this.useCentralDirectory !== "boolean") throw new TypeError("useCentralDirectory must be a boolean");
		if (typeof this.allowTruncatedDataDescriptor !== "boolean") throw new TypeError("allowTruncatedDataDescriptor must be a boolean");
		for (const [name, limit] of Object.entries(this.limits)) if (limit !== Number.POSITIVE_INFINITY && (!Number.isSafeInteger(limit) || limit <= 0)) throw new RangeError(`${name} must be a positive safe integer or Infinity`);
	}
	/** Reject oversized entries before retaining data or allocating a combined buffer. */
	checkLimit(limit, size) {
		if (size > this.limits[limit]) throw new ZipLimitError(limit, size, this.limits[limit]);
	}
	resetTraversal() {
		this.scannedBytes = 0;
		this.descriptorScannedBytes = 0;
	}
	consumeBytes(length) {
		this.checkLimit("maxTotalScanBytes", this.scannedBytes + length);
		this.scannedBytes += length;
	}
	readToken(token, input = this.tokenizer) {
		this.consumeBytes(token.len);
		return input.readToken(token);
	}
	ignore(length, input = this.tokenizer) {
		this.consumeBytes(length);
		return input.ignore(length);
	}
	readData(length) {
		this.consumeBytes(length);
		const data = new Uint8Array(length);
		return this.tokenizer.readBuffer(data).then(() => data);
	}
	checkEntrySize(header) {
		this.checkLimit("maxCompressedSize", header.compressedSize);
		this.checkLimit("maxUncompressedSize", header.uncompressedSize);
		if (header.compressedMethod === 0) this.checkLimit("maxUncompressedSize", header.compressedSize);
	}
	async isZip() {
		return await this.peekSignature() === Signature.LocalFileHeader;
	}
	peekSignature() {
		return this.tokenizer.peekToken(UINT32_LE);
	}
	async findEndOfCentralDirectoryLocator() {
		const randomReadTokenizer = this.tokenizer;
		const chunkLength = Math.min(16384, randomReadTokenizer.fileInfo.size);
		const buffer = this.syncBuffer.subarray(0, chunkLength);
		this.consumeBytes(chunkLength);
		await this.tokenizer.readBuffer(buffer, { position: randomReadTokenizer.fileInfo.size - chunkLength });
		for (let i = buffer.length - 4; i >= 0; i--) if (buffer[i] === eocdSignatureBytes[0] && buffer[i + 1] === eocdSignatureBytes[1] && buffer[i + 2] === eocdSignatureBytes[2] && buffer[i + 3] === eocdSignatureBytes[3]) return randomReadTokenizer.fileInfo.size - chunkLength + i;
		return -1;
	}
	async readCentralDirectory() {
		this.resetTraversal();
		const entries = await this.centralDirectoryEntries();
		if (!entries) return;
		const files = [];
		for await (const entry of entries) files.push(entry);
		return files;
	}
	async centralDirectoryEntries() {
		if (!this.tokenizer.supportsRandomAccess()) {
			debug$1("Cannot reading central-directory without random-read support");
			return;
		}
		debug$1("Reading central-directory...");
		const pos = this.tokenizer.position;
		try {
			const offset = await this.findEndOfCentralDirectoryLocator();
			if (offset > 0) {
				debug$1("Central-directory 32-bit signature found");
				this.tokenizer.setPosition(offset);
				const eocdHeader = await this.readToken(EndOfCentralDirectoryRecordToken);
				return this.iterateDirectory(eocdHeader.offsetOfStartOfCd, eocdHeader.sizeOfCd, eocdHeader.nrOfEntriesOfSize);
			}
		} finally {
			this.tokenizer.setPosition(pos);
		}
	}
	async *iterateDirectory(offset, size, count) {
		const source = this.tokenizer;
		const pos = source.position;
		let directory;
		let position = 0;
		try {
			source.setPosition(offset);
			directory = createTokenizerView(source, size);
			for (let n = 0; n < count; ++n) {
				this.checkLimit("maxEntryCount", n + 1);
				directory.setPosition(position);
				const entry = await this.readToken(FileHeader, directory);
				if (entry.signature !== Signature.CentralFileHeader) throw new Error("Expected Central-File-Header signature");
				entry.filename = await this.readToken(new StringType(entry.filenameLength, "utf-8"), directory);
				await this.ignore(entry.extraFieldLength, directory);
				await this.ignore(entry.fileCommentLength, directory);
				position = directory.position;
				yield entry;
			}
		} finally {
			try {
				await directory?.close();
			} finally {
				source.setPosition(pos);
			}
		}
	}
	async unzip(fileCb) {
		this.resetTraversal();
		const entries = this.useCentralDirectory ? await this.centralDirectoryEntries() : void 0;
		if (entries) return this.iterateOverCentralDirectory(entries, fileCb);
		let stop = false;
		let entryCount = 0;
		do {
			const zipHeader = await this.readLocalFileHeader();
			if (!zipHeader) break;
			this.checkLimit("maxEntryCount", ++entryCount);
			const next = fileCb(zipHeader);
			stop = !!next.stop;
			let fileData;
			await this.ignore(zipHeader.extraFieldLength);
			if (next.handler) this.checkEntrySize(zipHeader);
			else this.checkLimit("maxSkippedEntrySize", zipHeader.compressedSize);
			if (zipHeader.dataDescriptor && zipHeader.compressedSize === 0) {
				const chunks = [];
				let totalSize = 0;
				const scanLimit = Math.min(this.limits.maxDataDescriptorScanBytes, this.limits.maxTotalDataDescriptorScanBytes - this.descriptorScannedBytes, this.limits.maxTotalScanBytes - this.scannedBytes, next.handler ? Number.POSITIVE_INFINITY : this.limits.maxSkippedEntrySize, next.handler ? this.limits.maxCompressedSize : Number.POSITIVE_INFINITY, next.handler && zipHeader.compressedMethod === 0 ? this.limits.maxUncompressedSize : Number.POSITIVE_INFINITY);
				debug$1("Compressed-file-size unknown, scanning for next data-descriptor-signature....");
				while (true) {
					const peekLength = Math.min(syncBufferSize, scanLimit - totalSize + DataDescriptor.len);
					const len = await this.tokenizer.peekBuffer(this.syncBuffer.subarray(0, peekLength), { mayBeLess: true });
					const allowTruncated = this.allowTruncatedDataDescriptor && len < peekLength;
					const nextHeaderIndex = findDescriptor(this.syncBuffer.subarray(0, len), totalSize, allowTruncated);
					if (nextHeaderIndex < 0 && len < DataDescriptor.len && !allowTruncated) throw new Error("Expected data-descriptor-signature before end of input");
					const size = nextHeaderIndex >= 0 ? nextHeaderIndex : allowTruncated ? len : len - DataDescriptor.len + 1;
					if (size === 0) break;
					this.checkLimit("maxDataDescriptorScanBytes", totalSize + size);
					this.checkLimit("maxTotalDataDescriptorScanBytes", this.descriptorScannedBytes + size);
					if (!next.handler) this.checkLimit("maxSkippedEntrySize", totalSize + size);
					if (next.handler) {
						this.checkLimit("maxCompressedSize", totalSize + size);
						if (zipHeader.compressedMethod === 0) this.checkLimit("maxUncompressedSize", totalSize + size);
						if (size > 0) {
							const data = await this.readData(size);
							chunks.push(data);
						}
					} else await this.ignore(size);
					totalSize += size;
					this.descriptorScannedBytes += size;
					if (nextHeaderIndex >= 0) break;
				}
				debug$1(`Found data-descriptor-signature at pos=${this.tokenizer.position}`);
				if (next.handler) {
					this.checkLimit("maxCompressedSize", totalSize);
					await this.inflate(zipHeader, mergeArrays(chunks), next.handler);
				}
			} else if (next.handler) {
				debug$1(`Reading compressed-file-data: ${zipHeader.compressedSize} bytes`);
				fileData = await this.readData(zipHeader.compressedSize);
				await this.inflate(zipHeader, fileData, next.handler);
			} else {
				debug$1(`Ignoring compressed-file-data: ${zipHeader.compressedSize} bytes`);
				await this.ignore(zipHeader.compressedSize);
			}
			debug$1(`Reading data-descriptor at pos=${this.tokenizer.position}`);
			if (zipHeader.dataDescriptor) {
				if ((await this.readToken(DataDescriptor)).signature !== 134695760) throw new Error(`Expected data-descriptor-signature at position ${this.tokenizer.position - DataDescriptor.len}`);
			}
		} while (!stop);
	}
	async iterateOverCentralDirectory(entries, fileCb) {
		for await (const fileHeader of entries) {
			const next = fileCb(fileHeader);
			if (next.handler) {
				this.tokenizer.setPosition(fileHeader.relativeOffsetOfLocalHeader);
				const zipHeader = await this.readLocalFileHeader();
				if (zipHeader) {
					await this.ignore(zipHeader.extraFieldLength);
					this.checkEntrySize(fileHeader);
					this.checkEntrySize(zipHeader);
					const fileData = await this.readData(fileHeader.compressedSize);
					await this.inflate(zipHeader, fileData, next.handler);
				}
			}
			if (next.stop) break;
		}
	}
	async inflate(zipHeader, fileData, cb) {
		if (zipHeader.compressedMethod === 0) {
			this.checkLimit("maxUncompressedSize", fileData.length);
			return cb(fileData);
		}
		if (zipHeader.compressedMethod !== 8) throw new Error(`Unsupported ZIP compression method: ${zipHeader.compressedMethod}`);
		debug$1(`Decompress filename=${zipHeader.filename}, compressed-size=${fileData.length}`);
		return cb(await this.decompressDeflateRaw(fileData));
	}
	async decompressDeflateRaw(data) {
		const input = new ReadableStream({ start(controller) {
			controller.enqueue(data);
			controller.close();
		} });
		const ds = new DecompressionStream("deflate-raw");
		const reader = input.pipeThrough(ds).getReader();
		const chunks = [];
		let totalSize = 0;
		try {
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				this.checkLimit("maxUncompressedSize", totalSize + value.length);
				totalSize += value.length;
				chunks.push(value);
			}
			this.checkLimit("maxUncompressedSize", totalSize);
			return mergeArrays(chunks);
		} catch (err) {
			await reader.cancel(err).catch(() => {});
			if (err instanceof ZipLimitError) throw err;
			if (err instanceof Error && "code" in err && err.code === "ERR_TRAILING_JUNK_AFTER_STREAM_END") return mergeArrays(chunks);
			const message = err instanceof Error ? `Failed to deflate ZIP entry: ${err.message}` : "Unknown decompression error in ZIP entry";
			throw new TypeError(message);
		} finally {
			reader.releaseLock();
		}
	}
	async readLocalFileHeader() {
		const signature = await this.tokenizer.peekToken(UINT32_LE);
		if (signature === Signature.LocalFileHeader) {
			const header = await this.readToken(LocalFileHeaderToken);
			header.filename = await this.readToken(new StringType(header.filenameLength, "utf-8"));
			return header;
		}
		if (signature === Signature.CentralFileHeader) return false;
		if (signature === 3759263696) throw new Error("Encrypted ZIP");
		throw new Error("Unexpected signature");
	}
};
function findDescriptor(buffer, consumed, allowTruncated) {
	for (let i = 0; i <= buffer.length - (allowTruncated ? 4 : DataDescriptor.len); i++) if (UINT32_LE.get(buffer, i) === Signature.DataDescriptor && (buffer.length - i < 12 || UINT32_LE.get(buffer, i + 8) === consumed + i)) return i;
	return -1;
}
function mergeArrays(chunks) {
	const totalLength = chunks.reduce((acc, curr) => acc + curr.length, 0);
	const mergedArray = new Uint8Array(totalLength);
	let offset = 0;
	for (const chunk of chunks) {
		mergedArray.set(chunk, offset);
		offset += chunk.length;
	}
	return mergedArray;
}
// node_modules/file-type/source/tokens.js
function stringToBytes(string, encoding) {
	if (encoding === "utf-16le") {
		const bytes = [];
		for (let index = 0; index < string.length; index++) {
			const code = string.charCodeAt(index);
			bytes.push(code & 255, code >> 8 & 255);
		}
		return bytes;
	}
	if (encoding === "utf-16be") {
		const bytes = [];
		for (let index = 0; index < string.length; index++) {
			const code = string.charCodeAt(index);
			bytes.push(code >> 8 & 255, code & 255);
		}
		return bytes;
	}
	return [...string].map((character) => character.charCodeAt(0));
}
/**
Checks whether the TAR checksum is valid.

@param {Uint8Array} arrayBuffer - The TAR header `[offset ... offset + 512]`.
@param {number} offset - Position of the TAR header in `arrayBuffer`.
@returns {boolean} `true` if the TAR checksum is valid, otherwise `false`.
*/
function tarHeaderChecksumMatches(arrayBuffer, offset = 0) {
	const readSum = Number.parseInt(new StringType(6).get(arrayBuffer, 148), 8);
	if (Number.isNaN(readSum)) return false;
	let sum = 256;
	for (let index = offset; index < offset + 148; index++) sum += arrayBuffer[index];
	for (let index = offset + 156; index < offset + 512; index++) sum += arrayBuffer[index];
	return readSum === sum;
}
/**
ID3 UINT32 sync-safe tokenizer token.
28 bits (representing up to 256MB) integer, the msb is 0 to avoid "false syncsignals".
*/
var uint32SyncSafeToken = {
	get: (buffer, offset) => buffer[offset + 3] & 127 | (buffer[offset + 2] & 127) << 7 | (buffer[offset + 1] & 127) << 14 | (buffer[offset] & 127) << 21,
	len: 4
};
// node_modules/file-type/source/supported.js
var extensions = [
	"jpg",
	"png",
	"apng",
	"gif",
	"webp",
	"flif",
	"xcf",
	"cr2",
	"cr3",
	"orf",
	"arw",
	"dng",
	"nef",
	"rw2",
	"raf",
	"tif",
	"bmp",
	"icns",
	"jxr",
	"psd",
	"indd",
	"zip",
	"tar",
	"rar",
	"gz",
	"bz2",
	"7z",
	"dmg",
	"mp4",
	"mid",
	"mkv",
	"webm",
	"mov",
	"avi",
	"mpg",
	"mp2",
	"mp3",
	"m4a",
	"oga",
	"ogg",
	"ogv",
	"opus",
	"flac",
	"wav",
	"spx",
	"amr",
	"pdf",
	"epub",
	"elf",
	"macho",
	"exe",
	"swf",
	"rtf",
	"wasm",
	"woff",
	"woff2",
	"eot",
	"ttf",
	"otf",
	"ttc",
	"ico",
	"flv",
	"ps",
	"xz",
	"sqlite",
	"nes",
	"crx",
	"xpi",
	"cab",
	"deb",
	"ar",
	"rpm",
	"Z",
	"lz",
	"cfb",
	"mxf",
	"mts",
	"blend",
	"bpg",
	"docx",
	"pptx",
	"xlsx",
	"3gp",
	"3g2",
	"j2c",
	"jp2",
	"jpm",
	"jpx",
	"mj2",
	"aif",
	"caf",
	"qcp",
	"odt",
	"ods",
	"odp",
	"xml",
	"mobi",
	"heic",
	"cur",
	"ktx",
	"ape",
	"wv",
	"dcm",
	"ics",
	"glb",
	"pcap",
	"dsf",
	"dff",
	"lnk",
	"alias",
	"voc",
	"ac3",
	"m4v",
	"m4p",
	"m4b",
	"f4v",
	"f4p",
	"f4b",
	"f4a",
	"mie",
	"asf",
	"ogm",
	"ogx",
	"mpc",
	"arrow",
	"shp",
	"aac",
	"mp1",
	"it",
	"s3m",
	"xm",
	"skp",
	"avif",
	"eps",
	"lzh",
	"pgp",
	"asar",
	"stl",
	"chm",
	"3mf",
	"zst",
	"jxl",
	"vcf",
	"jls",
	"pst",
	"dwg",
	"parquet",
	"class",
	"arj",
	"cpio",
	"ace",
	"avro",
	"icc",
	"fbx",
	"vsdx",
	"vtt",
	"apk",
	"drc",
	"lz4",
	"potx",
	"xltx",
	"dotx",
	"xltm",
	"ott",
	"ots",
	"otp",
	"odg",
	"otg",
	"xlsm",
	"docm",
	"dotm",
	"potm",
	"pptm",
	"jar",
	"jmp",
	"rm",
	"sav",
	"ppsm",
	"ppsx",
	"tar.gz",
	"reg",
	"dat",
	"key",
	"numbers",
	"pages",
	"iso"
];
var mimeTypes = [
	"image/jpeg",
	"image/png",
	"image/gif",
	"image/webp",
	"image/flif",
	"image/x-xcf",
	"image/x-canon-cr2",
	"image/x-canon-cr3",
	"image/tiff",
	"image/bmp",
	"image/vnd.ms-photo",
	"image/vnd.adobe.photoshop",
	"application/x-indesign",
	"application/epub+zip",
	"application/x-xpinstall",
	"application/vnd.ms-powerpoint.slideshow.macroenabled.12",
	"application/vnd.oasis.opendocument.text",
	"application/vnd.oasis.opendocument.spreadsheet",
	"application/vnd.oasis.opendocument.presentation",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"application/vnd.openxmlformats-officedocument.presentationml.presentation",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	"application/vnd.openxmlformats-officedocument.presentationml.slideshow",
	"application/zip",
	"application/x-tar",
	"application/x-rar-compressed",
	"application/gzip",
	"application/x-bzip2",
	"application/x-7z-compressed",
	"application/x-apple-diskimage",
	"application/vnd.apache.arrow.file",
	"video/mp4",
	"audio/midi",
	"video/matroska",
	"video/webm",
	"video/quicktime",
	"video/vnd.avi",
	"audio/wav",
	"audio/qcelp",
	"audio/x-ms-asf",
	"video/x-ms-asf",
	"application/vnd.ms-asf",
	"video/mpeg",
	"video/3gpp",
	"audio/mpeg",
	"audio/mp4",
	"video/ogg",
	"audio/ogg",
	"audio/ogg; codecs=opus",
	"application/ogg",
	"audio/flac",
	"audio/ape",
	"audio/wavpack",
	"audio/amr",
	"application/pdf",
	"application/x-elf",
	"application/x-mach-binary",
	"application/x-msdownload",
	"application/x-shockwave-flash",
	"application/rtf",
	"application/wasm",
	"font/woff",
	"font/woff2",
	"application/vnd.ms-fontobject",
	"font/ttf",
	"font/otf",
	"font/collection",
	"image/x-icon",
	"video/x-flv",
	"application/postscript",
	"application/eps",
	"application/x-xz",
	"application/x-sqlite3",
	"application/x-nintendo-nes-rom",
	"application/x-google-chrome-extension",
	"application/vnd.ms-cab-compressed",
	"application/x-deb",
	"application/x-unix-archive",
	"application/x-rpm",
	"application/x-compress",
	"application/lzip",
	"application/x-cfb",
	"application/x-mie",
	"application/mxf",
	"video/mp2t",
	"application/x-blender",
	"image/bpg",
	"image/j2c",
	"image/jp2",
	"image/jpx",
	"image/jpm",
	"image/mj2",
	"audio/aiff",
	"audio/x-caf",
	"application/xml",
	"application/x-mobipocket-ebook",
	"image/heif",
	"image/heif-sequence",
	"image/heic",
	"image/heic-sequence",
	"image/icns",
	"image/ktx",
	"application/dicom",
	"audio/x-musepack",
	"text/calendar",
	"text/vcard",
	"text/vtt",
	"model/gltf-binary",
	"application/vnd.tcpdump.pcap",
	"audio/x-dsf",
	"audio/x-dff",
	"application/x-ms-shortcut",
	"application/x-ft-apple.alias",
	"audio/x-voc",
	"audio/vnd.dolby.dd-raw",
	"audio/x-m4a",
	"image/apng",
	"image/x-olympus-orf",
	"image/x-sony-arw",
	"image/x-adobe-dng",
	"image/x-nikon-nef",
	"image/x-panasonic-rw2",
	"image/x-fujifilm-raf",
	"video/x-m4v",
	"video/3gpp2",
	"application/x-esri-shape",
	"audio/aac",
	"audio/x-it",
	"audio/x-s3m",
	"audio/x-xm",
	"video/MP1S",
	"video/MP2P",
	"application/vnd.sketchup.skp",
	"image/avif",
	"application/x-lzh-compressed",
	"application/pgp-encrypted",
	"application/x-asar",
	"model/stl",
	"application/vnd.ms-htmlhelp",
	"model/3mf",
	"image/jxl",
	"application/zstd",
	"image/jls",
	"application/vnd.ms-outlook",
	"image/vnd.dwg",
	"application/vnd.apache.parquet",
	"application/java-vm",
	"application/x-arj",
	"application/x-cpio",
	"application/x-ace-compressed",
	"application/avro",
	"application/vnd.iccprofile",
	"application/x-ft-fbx",
	"application/vnd.visio",
	"application/vnd.android.package-archive",
	"application/x-ft-draco",
	"application/x-lz4",
	"application/vnd.openxmlformats-officedocument.presentationml.template",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.template",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.template",
	"application/vnd.ms-excel.template.macroenabled.12",
	"application/vnd.oasis.opendocument.text-template",
	"application/vnd.oasis.opendocument.spreadsheet-template",
	"application/vnd.oasis.opendocument.presentation-template",
	"application/vnd.oasis.opendocument.graphics",
	"application/vnd.oasis.opendocument.graphics-template",
	"application/vnd.ms-excel.sheet.macroenabled.12",
	"application/vnd.ms-word.document.macroenabled.12",
	"application/vnd.ms-word.template.macroenabled.12",
	"application/vnd.ms-powerpoint.template.macroenabled.12",
	"application/vnd.ms-powerpoint.presentation.macroenabled.12",
	"application/java-archive",
	"application/vnd.rn-realmedia",
	"application/x-spss-sav",
	"application/x-ms-regedit",
	"application/x-ft-windows-registry-hive",
	"application/x-jmp-data",
	"application/vnd.apple.keynote",
	"application/vnd.apple.numbers",
	"application/vnd.apple.pages",
	"application/x-iso9660-image"
];
// node_modules/file-type/source/parser.js
var maximumUntrustedSkipSizeInBytes = 16777216;
var ParserHardLimitError = class extends Error {};
function getSafeBound(value, maximum, reason) {
	if (!Number.isFinite(value) || value < 0 || value > maximum) throw new ParserHardLimitError(`${reason} has invalid size ${value} (maximum ${maximum} bytes)`);
	return value;
}
async function safeIgnore(tokenizer, length, { maximumLength = maximumUntrustedSkipSizeInBytes, reason = "skip" } = {}) {
	const safeLength = getSafeBound(length, maximumLength, reason);
	await tokenizer.ignore(safeLength);
}
async function safeReadBuffer(tokenizer, buffer, options, { maximumLength = buffer.length, reason = "read" } = {}) {
	const safeLength = getSafeBound(options?.length ?? buffer.length, maximumLength, reason);
	return tokenizer.readBuffer(buffer, {
		...options,
		length: safeLength
	});
}
function checkBytes(buffer, headers, options) {
	options = {
		offset: 0,
		...options
	};
	for (const [index, header] of headers.entries()) if (options.mask) {
		if (header !== (options.mask[index] & buffer[index + options.offset])) return false;
	} else if (header !== buffer[index + options.offset]) return false;
	return true;
}
function hasUnknownFileSize(tokenizer) {
	const fileSize = tokenizer.fileInfo.size;
	return !Number.isFinite(fileSize) || fileSize === Number.MAX_SAFE_INTEGER;
}
function hasExceededUnknownSizeScanBudget(tokenizer, startOffset, maximumBytes) {
	return hasUnknownFileSize(tokenizer) && tokenizer.position - startOffset > maximumBytes;
}
// node_modules/file-type/source/detectors/zip.js
var maximumZipEntrySizeInBytes = 1048576;
var maximumZipEntryCount = 1024;
var maximumZipTextEntrySizeInBytes = maximumZipEntrySizeInBytes;
var recoverableZipErrorMessages = /* @__PURE__ */ new Set([
	"Unexpected signature",
	"Encrypted ZIP",
	"Expected Central-File-Header signature"
]);
var recoverableZipErrorMessagePrefixes = ["Unsupported ZIP compression method:", "Expected data-descriptor-signature at position "];
var recoverableZipErrorCodes = /* @__PURE__ */ new Set([
	"Z_BUF_ERROR",
	"Z_DATA_ERROR",
	"ERR_INVALID_STATE"
]);
function isRecoverableZipError(error) {
	if (error instanceof EndOfStreamError) return true;
	if (error instanceof ParserHardLimitError || error instanceof ZipLimitError) return true;
	if (!(error instanceof Error)) return false;
	if (error instanceof TypeError && error.message.startsWith("Failed to deflate ZIP entry:")) return true;
	if (recoverableZipErrorMessages.has(error.message)) return true;
	if (recoverableZipErrorCodes.has(error.code)) return true;
	for (const prefix of recoverableZipErrorMessagePrefixes) if (error.message.startsWith(prefix)) return true;
	return false;
}
function isZipScanLimitError(error) {
	return error instanceof ZipLimitError && [
		"maxTotalScanBytes",
		"maxTotalDataDescriptorScanBytes",
		"maxDataDescriptorScanBytes",
		"maxSkippedEntrySize"
	].includes(error.limit);
}
function canReadZipEntryForDetection(zipHeader, maximumSize = maximumZipEntrySizeInBytes) {
	const sizes = [zipHeader.compressedSize, zipHeader.uncompressedSize];
	for (const size of sizes) if (!Number.isFinite(size) || size < 0 || size > maximumSize) return false;
	return true;
}
function createIWorkZipDetectionState() {
	return {
		hasDocumentEntry: false,
		hasMasterSlideEntry: false,
		hasTablesEntry: false,
		hasCalculationEngineEntry: false
	};
}
function updateIWorkZipDetectionStateFromFilename(iWorkState, filename) {
	if (filename === "Index/Document.iwa") iWorkState.hasDocumentEntry = true;
	if (filename.startsWith("Index/MasterSlide")) iWorkState.hasMasterSlideEntry = true;
	if (filename.startsWith("Index/Tables/")) iWorkState.hasTablesEntry = true;
	if (filename === "Index/CalculationEngine.iwa") iWorkState.hasCalculationEngineEntry = true;
}
function getIWorkFileTypeFromZipEntries(iWorkState) {
	if (!iWorkState.hasDocumentEntry) return;
	if (iWorkState.hasMasterSlideEntry) return {
		ext: "key",
		mime: "application/vnd.apple.keynote"
	};
	if (iWorkState.hasTablesEntry) return {
		ext: "numbers",
		mime: "application/vnd.apple.numbers"
	};
	return {
		ext: "pages",
		mime: "application/vnd.apple.pages"
	};
}
function getFileTypeFromMimeType(mimeType) {
	mimeType = mimeType.toLowerCase();
	switch (mimeType) {
		case "application/epub+zip": return {
			ext: "epub",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.text": return {
			ext: "odt",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.text-template": return {
			ext: "ott",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.spreadsheet": return {
			ext: "ods",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.spreadsheet-template": return {
			ext: "ots",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.presentation": return {
			ext: "odp",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.presentation-template": return {
			ext: "otp",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.graphics": return {
			ext: "odg",
			mime: mimeType
		};
		case "application/vnd.oasis.opendocument.graphics-template": return {
			ext: "otg",
			mime: mimeType
		};
		case "application/vnd.openxmlformats-officedocument.presentationml.slideshow": return {
			ext: "ppsx",
			mime: mimeType
		};
		case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": return {
			ext: "xlsx",
			mime: mimeType
		};
		case "application/vnd.ms-excel.sheet.macroenabled": return {
			ext: "xlsm",
			mime: "application/vnd.ms-excel.sheet.macroenabled.12"
		};
		case "application/vnd.openxmlformats-officedocument.spreadsheetml.template": return {
			ext: "xltx",
			mime: mimeType
		};
		case "application/vnd.ms-excel.template.macroenabled": return {
			ext: "xltm",
			mime: "application/vnd.ms-excel.template.macroenabled.12"
		};
		case "application/vnd.ms-powerpoint.slideshow.macroenabled": return {
			ext: "ppsm",
			mime: "application/vnd.ms-powerpoint.slideshow.macroenabled.12"
		};
		case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": return {
			ext: "docx",
			mime: mimeType
		};
		case "application/vnd.ms-word.document.macroenabled": return {
			ext: "docm",
			mime: "application/vnd.ms-word.document.macroenabled.12"
		};
		case "application/vnd.openxmlformats-officedocument.wordprocessingml.template": return {
			ext: "dotx",
			mime: mimeType
		};
		case "application/vnd.ms-word.template.macroenabledtemplate": return {
			ext: "dotm",
			mime: "application/vnd.ms-word.template.macroenabled.12"
		};
		case "application/vnd.openxmlformats-officedocument.presentationml.template": return {
			ext: "potx",
			mime: mimeType
		};
		case "application/vnd.ms-powerpoint.template.macroenabled": return {
			ext: "potm",
			mime: "application/vnd.ms-powerpoint.template.macroenabled.12"
		};
		case "application/vnd.openxmlformats-officedocument.presentationml.presentation": return {
			ext: "pptx",
			mime: mimeType
		};
		case "application/vnd.ms-powerpoint.presentation.macroenabled": return {
			ext: "pptm",
			mime: "application/vnd.ms-powerpoint.presentation.macroenabled.12"
		};
		case "application/vnd.ms-visio.drawing": return {
			ext: "vsdx",
			mime: "application/vnd.visio"
		};
		case "application/vnd.ms-package.3dmanufacturing-3dmodel+xml": return {
			ext: "3mf",
			mime: "model/3mf"
		};
	}
}
function createOpenXmlZipDetectionState() {
	return {
		hasContentTypesEntry: false,
		hasParsedContentTypesEntry: false,
		isParsingContentTypes: false,
		hasUnparseableContentTypes: false,
		hasWordDirectory: false,
		hasPresentationDirectory: false,
		hasSpreadsheetDirectory: false,
		hasThreeDimensionalModelEntry: false
	};
}
function updateOpenXmlZipDetectionStateFromFilename(openXmlState, filename) {
	if (filename.startsWith("word/")) openXmlState.hasWordDirectory = true;
	if (filename.startsWith("ppt/")) openXmlState.hasPresentationDirectory = true;
	if (filename.startsWith("xl/")) openXmlState.hasSpreadsheetDirectory = true;
	if (filename.startsWith("3D/") && filename.endsWith(".model")) openXmlState.hasThreeDimensionalModelEntry = true;
}
function getOpenXmlFileTypeFromDirectoryNames(openXmlState) {
	if (openXmlState.hasWordDirectory) return {
		ext: "docx",
		mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
	};
	if (openXmlState.hasPresentationDirectory) return {
		ext: "pptx",
		mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
	};
	if (openXmlState.hasSpreadsheetDirectory) return {
		ext: "xlsx",
		mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
	};
	if (openXmlState.hasThreeDimensionalModelEntry) return {
		ext: "3mf",
		mime: "model/3mf"
	};
}
function getOpenXmlFileTypeFromZipEntries(openXmlState) {
	if (!openXmlState.hasContentTypesEntry || openXmlState.hasUnparseableContentTypes || openXmlState.isParsingContentTypes || openXmlState.hasParsedContentTypesEntry) return;
	return getOpenXmlFileTypeFromDirectoryNames(openXmlState);
}
function getOpenXmlMimeTypeFromContentTypesXml(xmlContent) {
	const endPosition = xmlContent.indexOf(".main+xml\"");
	if (endPosition === -1) {
		const mimeType = "application/vnd.ms-package.3dmanufacturing-3dmodel+xml";
		if (xmlContent.includes(`ContentType="${mimeType}"`)) return mimeType;
		return;
	}
	const truncatedContent = xmlContent.slice(0, endPosition);
	const firstQuotePosition = truncatedContent.lastIndexOf("\"");
	return truncatedContent.slice(firstQuotePosition + 1);
}
async function detectZip(tokenizer) {
	let fileType;
	const openXmlState = createOpenXmlZipDetectionState();
	const iWorkState = createIWorkZipDetectionState();
	try {
		await new ZipHandler(tokenizer, {
			useCentralDirectory: false,
			allowTruncatedDataDescriptor: true,
			maxEntryCount: maximumZipEntryCount,
			maxTotalScanBytes: hasUnknownFileSize(tokenizer) ? maximumUntrustedSkipSizeInBytes : Infinity,
			maxTotalDataDescriptorScanBytes: hasUnknownFileSize(tokenizer) ? Infinity : maximumZipEntrySizeInBytes,
			maxSkippedEntrySize: hasUnknownFileSize(tokenizer) ? maximumZipEntrySizeInBytes : Infinity,
			maxDataDescriptorScanBytes: maximumZipEntrySizeInBytes,
			maxCompressedSize: maximumZipTextEntrySizeInBytes,
			maxUncompressedSize: maximumZipTextEntrySizeInBytes
		}).unzip((zipHeader) => {
			updateOpenXmlZipDetectionStateFromFilename(openXmlState, zipHeader.filename);
			updateIWorkZipDetectionStateFromFilename(iWorkState, zipHeader.filename);
			if (iWorkState.hasDocumentEntry && (iWorkState.hasMasterSlideEntry || iWorkState.hasTablesEntry)) {
				fileType = getIWorkFileTypeFromZipEntries(iWorkState);
				return { stop: true };
			}
			const isOpenXmlContentTypesEntry = zipHeader.filename === "[Content_Types].xml";
			const openXmlFileTypeFromEntries = getOpenXmlFileTypeFromZipEntries(openXmlState);
			if (!isOpenXmlContentTypesEntry && openXmlFileTypeFromEntries) {
				fileType = openXmlFileTypeFromEntries;
				return { stop: true };
			}
			switch (zipHeader.filename) {
				case "META-INF/mozilla.rsa":
					fileType = {
						ext: "xpi",
						mime: "application/x-xpinstall"
					};
					return { stop: true };
				case "META-INF/MANIFEST.MF":
					fileType = {
						ext: "jar",
						mime: "application/java-archive"
					};
					return { stop: true };
				case "mimetype":
					if (!canReadZipEntryForDetection(zipHeader, maximumZipTextEntrySizeInBytes)) return {};
					return {
						async handler(fileData) {
							fileType = getFileTypeFromMimeType(new TextDecoder("utf-8").decode(fileData).trim());
						},
						stop: true
					};
				case "[Content_Types].xml":
					openXmlState.hasContentTypesEntry = true;
					if (!canReadZipEntryForDetection(zipHeader, maximumZipTextEntrySizeInBytes)) {
						openXmlState.hasUnparseableContentTypes = true;
						return {};
					}
					openXmlState.isParsingContentTypes = true;
					return {
						async handler(fileData) {
							const mimeType = getOpenXmlMimeTypeFromContentTypesXml(new TextDecoder("utf-8").decode(fileData));
							if (mimeType) fileType = getFileTypeFromMimeType(mimeType);
							openXmlState.hasParsedContentTypesEntry = true;
							openXmlState.isParsingContentTypes = false;
						},
						stop: true
					};
				default:
					if (new RegExp("classes\\d*\\.dex", "v").test(zipHeader.filename)) {
						fileType = {
							ext: "apk",
							mime: "application/vnd.android.package-archive"
						};
						return { stop: true };
					}
					return {};
			}
		});
	} catch (error) {
		if (!isRecoverableZipError(error)) throw error;
		if (openXmlState.isParsingContentTypes) {
			openXmlState.isParsingContentTypes = false;
			openXmlState.hasUnparseableContentTypes = true;
		}
		if (!fileType && (error instanceof EndOfStreamError || error instanceof ParserHardLimitError || isZipScanLimitError(error)) && !openXmlState.hasContentTypesEntry) fileType = getOpenXmlFileTypeFromDirectoryNames(openXmlState);
	}
	const iWorkFileType = hasUnknownFileSize(tokenizer) && iWorkState.hasDocumentEntry && !iWorkState.hasMasterSlideEntry && !iWorkState.hasTablesEntry && !iWorkState.hasCalculationEngineEntry ? void 0 : getIWorkFileTypeFromZipEntries(iWorkState);
	return fileType ?? getOpenXmlFileTypeFromZipEntries(openXmlState) ?? iWorkFileType ?? {
		ext: "zip",
		mime: "application/zip"
	};
}
// node_modules/file-type/source/detectors/ebml.js
var maximumEbmlDocumentTypeSizeInBytes = 64;
var maximumEbmlElementPayloadSizeInBytes = 1048576;
var maximumEbmlElementCount = 256;
async function detectEbml(tokenizer) {
	async function readField(input) {
		const msb = await input.peekNumber(UINT8);
		let mask = 128;
		let ic = 0;
		while (mask !== 0 && (msb & mask) === 0) {
			++ic;
			mask >>= 1;
		}
		const id = new Uint8Array(ic + 1);
		await safeReadBuffer(input, id, void 0, {
			maximumLength: id.length,
			reason: "EBML field"
		});
		return id;
	}
	async function readElement(input) {
		const idField = await readField(input);
		const lengthField = await readField(input);
		lengthField[0] ^= 128 >> lengthField.length - 1;
		const nrLength = Math.min(6, lengthField.length);
		const idView = new DataView(idField.buffer);
		const lengthView = new DataView(lengthField.buffer, lengthField.length - nrLength, nrLength);
		return {
			id: getUintBE(idView),
			len: getUintBE(lengthView)
		};
	}
	const isUnknownFileSize = hasUnknownFileSize(tokenizer);
	async function readChildren(header) {
		let ebmlElementCount = 0;
		while (header.remaining > 0) {
			ebmlElementCount++;
			if (ebmlElementCount > maximumEbmlElementCount) return;
			if (hasExceededUnknownSizeScanBudget(tokenizer, ebmlScanStart, 16777216)) return;
			const previousPosition = tokenizer.position;
			const element = await readElement(header);
			if (element.id === 17026) {
				if (element.len > maximumEbmlDocumentTypeSizeInBytes) return;
				const documentTypeLength = getSafeBound(element.len, maximumEbmlDocumentTypeSizeInBytes, "EBML DocType");
				return (await header.readToken(new StringType(documentTypeLength))).split("\0", 1)[0];
			}
			if (isUnknownFileSize && (!Number.isFinite(element.len) || element.len < 0 || element.len > maximumEbmlElementPayloadSizeInBytes)) return;
			await safeIgnore(header, element.len, {
				maximumLength: isUnknownFileSize ? maximumEbmlElementPayloadSizeInBytes : tokenizer.fileInfo.size,
				reason: "EBML payload"
			});
			if (tokenizer.position <= previousPosition) return;
		}
	}
	const rootElement = await readElement(tokenizer);
	const ebmlScanStart = tokenizer.position;
	const header = createTokenizerView(tokenizer, rootElement.len);
	let documentType;
	try {
		documentType = await readChildren(header);
	} catch (error) {
		if (error instanceof TokenizerBoundaryError) return;
		throw error;
	} finally {
		await header.close();
	}
	switch (documentType) {
		case "webm": return {
			ext: "webm",
			mime: "video/webm"
		};
		case "matroska": return {
			ext: "mkv",
			mime: "video/matroska"
		};
	}
}
// node_modules/file-type/source/detectors/png.js
var maximumPngChunkCount = 512;
var maximumPngStreamScanBudgetInBytes = 16777216;
var maximumPngChunkSizeInBytes = 1048576;
function isPngAncillaryChunk(type) {
	return (type.codePointAt(0) & 32) !== 0;
}
async function detectPng(tokenizer) {
	const pngFileType = {
		ext: "png",
		mime: "image/png"
	};
	const apngFileType = {
		ext: "apng",
		mime: "image/apng"
	};
	await tokenizer.ignore(8);
	async function readChunkHeader() {
		return {
			length: await tokenizer.readToken(INT32_BE),
			type: await tokenizer.readToken(new StringType(4, "latin1"))
		};
	}
	const isUnknownPngStream = hasUnknownFileSize(tokenizer);
	const pngScanStart = tokenizer.position;
	let pngChunkCount = 0;
	let hasSeenImageHeader = false;
	do {
		pngChunkCount++;
		if (pngChunkCount > maximumPngChunkCount) break;
		if (hasExceededUnknownSizeScanBudget(tokenizer, pngScanStart, maximumPngStreamScanBudgetInBytes)) break;
		const previousPosition = tokenizer.position;
		const chunk = await readChunkHeader();
		if (chunk.length < 0) return;
		if (chunk.type === "IHDR") {
			if (chunk.length !== 13) return;
			hasSeenImageHeader = true;
		}
		switch (chunk.type) {
			case "IDAT": return pngFileType;
			case "acTL": return apngFileType;
			default:
				if (!hasSeenImageHeader && chunk.type !== "CgBI") return;
				if (isUnknownPngStream && chunk.length > maximumPngChunkSizeInBytes) return hasSeenImageHeader && isPngAncillaryChunk(chunk.type) ? pngFileType : void 0;
				try {
					await safeIgnore(tokenizer, chunk.length + 4, {
						maximumLength: isUnknownPngStream ? 1048580 : tokenizer.fileInfo.size,
						reason: "PNG chunk payload"
					});
				} catch (error) {
					if (!isUnknownPngStream && (error instanceof ParserHardLimitError || error instanceof EndOfStreamError)) return pngFileType;
					throw error;
				}
		}
		if (tokenizer.position <= previousPosition) break;
	} while (tokenizer.position + 8 < tokenizer.fileInfo.size);
	return pngFileType;
}
// node_modules/file-type/source/detectors/asf.js
var maximumAsfHeaderObjectCount = 512;
var maximumAsfHeaderPayloadSizeInBytes = 1048576;
async function detectAsf(tokenizer) {
	let isMalformedAsf = false;
	try {
		async function readHeader() {
			const guid = /* @__PURE__ */ new Uint8Array(16);
			await safeReadBuffer(tokenizer, guid, void 0, {
				maximumLength: guid.length,
				reason: "ASF header GUID"
			});
			return {
				id: guid,
				size: Number(await tokenizer.readToken(UINT64_LE))
			};
		}
		await safeIgnore(tokenizer, 30, {
			maximumLength: 30,
			reason: "ASF header prelude"
		});
		const isUnknownFileSize = hasUnknownFileSize(tokenizer);
		const asfHeaderScanStart = tokenizer.position;
		let asfHeaderObjectCount = 0;
		while (tokenizer.position + 24 < tokenizer.fileInfo.size) {
			asfHeaderObjectCount++;
			if (asfHeaderObjectCount > maximumAsfHeaderObjectCount) break;
			if (hasExceededUnknownSizeScanBudget(tokenizer, asfHeaderScanStart, 16777216)) break;
			const previousPosition = tokenizer.position;
			const header = await readHeader();
			let payload = header.size - 24;
			if (!Number.isFinite(payload) || payload < 0) {
				isMalformedAsf = true;
				break;
			}
			if (checkBytes(header.id, [
				145,
				7,
				220,
				183,
				183,
				169,
				207,
				17,
				142,
				230,
				0,
				192,
				12,
				32,
				83,
				101
			])) {
				const typeId = /* @__PURE__ */ new Uint8Array(16);
				payload -= await safeReadBuffer(tokenizer, typeId, void 0, {
					maximumLength: typeId.length,
					reason: "ASF stream type GUID"
				});
				if (checkBytes(typeId, [
					64,
					158,
					105,
					248,
					77,
					91,
					207,
					17,
					168,
					253,
					0,
					128,
					95,
					92,
					68,
					43
				])) return {
					ext: "asf",
					mime: "audio/x-ms-asf"
				};
				if (checkBytes(typeId, [
					192,
					239,
					25,
					188,
					77,
					91,
					207,
					17,
					168,
					253,
					0,
					128,
					95,
					92,
					68,
					43
				])) return {
					ext: "asf",
					mime: "video/x-ms-asf"
				};
				break;
			}
			if (isUnknownFileSize && payload > maximumAsfHeaderPayloadSizeInBytes) {
				isMalformedAsf = true;
				break;
			}
			await safeIgnore(tokenizer, payload, {
				maximumLength: isUnknownFileSize ? maximumAsfHeaderPayloadSizeInBytes : tokenizer.fileInfo.size,
				reason: "ASF header payload"
			});
			if (tokenizer.position <= previousPosition) {
				isMalformedAsf = true;
				break;
			}
		}
	} catch (error) {
		if (error instanceof EndOfStreamError || error instanceof ParserHardLimitError) {
			if (hasUnknownFileSize(tokenizer)) isMalformedAsf = true;
		} else throw error;
	}
	if (isMalformedAsf) return;
	return {
		ext: "asf",
		mime: "application/vnd.ms-asf"
	};
}
// node_modules/file-type/source/index.js
/**
Primary entry point, Node.js specific entry point is index.js
*/
var reasonableDetectionSizeInBytes = 4100;
var maximumMpegOffsetTolerance = 4096;
var maximumNestedGzipDetectionSizeInBytes = maximumUntrustedSkipSizeInBytes;
var maximumNestedGzipProbeDepth = 1;
var unknownSizeGzipProbeTimeoutInMilliseconds = 100;
var maximumId3HeaderSizeInBytes = maximumUntrustedSkipSizeInBytes;
var maximumTiffTagCount = 512;
var maximumDetectionReentryCount = 256;
var maximumTiffStreamIfdOffsetInBytes = 1048576;
var maximumTiffIfdOffsetInBytes = maximumUntrustedSkipSizeInBytes;
function normalizeSampleSize(sampleSize) {
	if (!Number.isFinite(sampleSize)) return reasonableDetectionSizeInBytes;
	return Math.max(1, Math.trunc(sampleSize));
}
function normalizeMpegOffsetTolerance(mpegOffsetTolerance) {
	if (!Number.isFinite(mpegOffsetTolerance)) return 0;
	return Math.max(0, Math.min(maximumMpegOffsetTolerance, Math.trunc(mpegOffsetTolerance)));
}
function getKnownFileSizeOrMaximum(fileSize) {
	if (!Number.isFinite(fileSize)) return Number.MAX_SAFE_INTEGER;
	return Math.max(0, fileSize);
}
function importAtRuntime(specifier) {
	return import(
		/* @vite-ignore */
		/* webpackIgnore: true */
		__vite__injectQuery(specifier, 'import')
);
}
function toDefaultStream(stream) {
	return stream.pipeThrough(new TransformStream());
}
function readWithSignal(reader, signal) {
	if (signal === void 0) return reader.read();
	signal.throwIfAborted();
	return Promise.race([reader.read(), new Promise((_resolve, reject) => {
		signal.addEventListener("abort", () => {
			reject(signal.reason);
			reader.cancel(signal.reason).catch(() => {});
		}, { once: true });
	})]);
}
function createByteLimitedReadableStream(stream, maximumBytes) {
	const reader = stream.getReader();
	let emittedBytes = 0;
	let isSourceDone = false;
	let isSourceCanceled = false;
	const cancelSource = async (reason) => {
		if (isSourceDone || isSourceCanceled) return;
		isSourceCanceled = true;
		await reader.cancel(reason);
	};
	return new ReadableStream({
		async pull(controller) {
			if (emittedBytes >= maximumBytes) {
				controller.close();
				await cancelSource();
				return;
			}
			const { done, value } = await reader.read();
			if (done || !value) {
				isSourceDone = true;
				controller.close();
				return;
			}
			const remainingBytes = maximumBytes - emittedBytes;
			if (value.length > remainingBytes) {
				controller.enqueue(value.subarray(0, remainingBytes));
				emittedBytes += remainingBytes;
				controller.close();
				await cancelSource();
				return;
			}
			controller.enqueue(value);
			emittedBytes += value.length;
		},
		async cancel(reason) {
			await cancelSource(reason);
		}
	});
}
async function fileTypeFromBuffer(input, options) {
	return new FileTypeParser(options).fromBuffer(input);
}
var FileTypeParser = class FileTypeParser {
	buffer;
	tokenizer;
	detectionReentryCount;
	constructor(options) {
		const normalizedMpegOffsetTolerance = normalizeMpegOffsetTolerance(options?.mpegOffsetTolerance);
		const maxBufferSize = options?.maxBufferSize ?? Infinity;
		if (maxBufferSize !== Infinity && (!Number.isSafeInteger(maxBufferSize) || maxBufferSize <= 0)) throw new RangeError("maxBufferSize must be a positive safe integer or Infinity");
		this.options = {
			...options,
			mpegOffsetTolerance: normalizedMpegOffsetTolerance
		};
		this.detectors = [
			...this.options.customDetectors ?? [],
			{
				id: "core",
				detect: (tokenizer) => this.detectConfident(tokenizer)
			},
			{
				id: "core.imprecise",
				detect: (tokenizer) => this.detectImprecise(tokenizer)
			}
		];
		this.tokenizerOptions = {
			abortSignal: this.options.signal,
			maxBufferSize
		};
		this.gzipProbeDepth = 0;
	}
	getTokenizerOptions() {
		return { ...this.tokenizerOptions };
	}
	createTokenizerFromWebStream(stream) {
		return fromWebStream(toDefaultStream(stream), this.getTokenizerOptions());
	}
	async parseTokenizer(tokenizer, detectionReentryCount = 0) {
		this.detectionReentryCount = detectionReentryCount;
		const initialPosition = tokenizer.position;
		for (const detector of this.detectors) {
			let fileType;
			try {
				fileType = await detector.detect(tokenizer);
			} catch (error) {
				if (error instanceof EndOfStreamError) return;
				if (error instanceof ParserHardLimitError) return;
				throw error;
			}
			if (fileType) return fileType;
			if (initialPosition !== tokenizer.position) return;
		}
	}
	async fromTokenizer(tokenizer) {
		try {
			return await this.parseTokenizer(tokenizer);
		} finally {
			await tokenizer.close();
		}
	}
	async fromBuffer(input) {
		if (!(input instanceof Uint8Array || input instanceof ArrayBuffer)) throw new TypeError(`Expected the \`input\` argument to be of type \`Uint8Array\` or \`ArrayBuffer\`, got \`${typeof input}\``);
		const buffer = input instanceof Uint8Array ? input : new Uint8Array(input);
		if (!(buffer?.length > 1)) return;
		return this.fromTokenizer(fromBuffer(buffer, this.getTokenizerOptions()));
	}
	async fromBlob(blob) {
		this.options.signal?.throwIfAborted();
		const tokenizer = fromBlob(blob, this.getTokenizerOptions());
		return this.fromTokenizer(tokenizer);
	}
	async fromStream(stream) {
		this.options.signal?.throwIfAborted();
		const tokenizer = this.createTokenizerFromWebStream(stream);
		return this.fromTokenizer(tokenizer);
	}
	async fromFile(path) {
		this.options.signal?.throwIfAborted();
		const { fromFile, NotRegularFileError } = await importAtRuntime("strtok3");
		let tokenizer;
		try {
			tokenizer = await fromFile(path, {
				...this.getTokenizerOptions(),
				regularFileOnly: true
			});
		} catch (error) {
			if (error instanceof NotRegularFileError) return;
			throw error;
		}
		return this.fromTokenizer(tokenizer);
	}
	async toDetectionStream(stream, options) {
		this.options.signal?.throwIfAborted();
		const sampleSize = normalizeSampleSize(options?.sampleSize ?? 4100);
		let detectedFileType;
		let hasStreamEnded = false;
		const reader = stream.getReader();
		const chunks = [];
		let totalSize = 0;
		try {
			while (totalSize < sampleSize) {
				const { value, done } = await readWithSignal(reader, this.options.signal);
				if (done || !value) {
					hasStreamEnded = true;
					break;
				}
				chunks.push(value);
				totalSize += value.length;
			}
			if (!hasStreamEnded && totalSize === sampleSize) {
				const { value, done } = await readWithSignal(reader, this.options.signal);
				if (done || !value) hasStreamEnded = true;
				else {
					chunks.push(value);
					totalSize += value.length;
				}
			}
		} finally {
			reader.releaseLock();
		}
		if (totalSize > 0) {
			const sample = chunks.length === 1 ? chunks[0] : concatUint8Arrays(chunks);
			try {
				detectedFileType = await this.fromBuffer(sample.subarray(0, sampleSize));
			} catch (error) {
				if (!(error instanceof EndOfStreamError)) throw error;
				detectedFileType = void 0;
			}
			if (!hasStreamEnded && detectedFileType?.ext === "pages") detectedFileType = {
				ext: "zip",
				mime: "application/zip"
			};
		}
		const transformStream = new TransformStream({
			start(controller) {
				for (const chunk of chunks) controller.enqueue(chunk);
			},
			transform(chunk, controller) {
				controller.enqueue(chunk);
			}
		});
		const newStream = stream.pipeThrough(transformStream);
		newStream.fileType = detectedFileType;
		return newStream;
	}
	async detectGzip(tokenizer) {
		if (this.gzipProbeDepth >= maximumNestedGzipProbeDepth) return {
			ext: "gz",
			mime: "application/gzip"
		};
		const limitedInflatedStream = createByteLimitedReadableStream(new GzipHandler(tokenizer).inflate(), maximumNestedGzipDetectionSizeInBytes);
		const hasUnknownSize = hasUnknownFileSize(tokenizer);
		let timeout;
		let probeSignal;
		let probeParser;
		let compressedFileType;
		if (hasUnknownSize) {
			const timeoutController = new AbortController();
			timeout = setTimeout(() => {
				timeoutController.abort(new DOMException(`Operation timed out after ${unknownSizeGzipProbeTimeoutInMilliseconds} ms`, "TimeoutError"));
			}, unknownSizeGzipProbeTimeoutInMilliseconds);
			probeSignal = this.options.signal === void 0 ? timeoutController.signal : AbortSignal.any([this.options.signal, timeoutController.signal]);
			probeParser = new FileTypeParser({
				...this.options,
				signal: probeSignal
			});
			probeParser.gzipProbeDepth = this.gzipProbeDepth + 1;
		} else this.gzipProbeDepth++;
		try {
			compressedFileType = await (probeParser ?? this).fromStream(limitedInflatedStream);
		} catch (error) {
			if (error?.name === "AbortError" && probeSignal?.reason?.name !== "TimeoutError") throw error;
		} finally {
			clearTimeout(timeout);
			if (!hasUnknownSize) this.gzipProbeDepth--;
		}
		if (compressedFileType?.ext === "tar") return {
			ext: "tar.gz",
			mime: "application/gzip"
		};
		return {
			ext: "gz",
			mime: "application/gzip"
		};
	}
	check(header, options) {
		return checkBytes(this.buffer, header, options);
	}
	checkString(header, options) {
		return this.check(stringToBytes(header, options?.encoding), options);
	}
	async detectConfident(tokenizer) {
		this.buffer = new Uint8Array(reasonableDetectionSizeInBytes);
		if (tokenizer.fileInfo.size === void 0) tokenizer.fileInfo.size = Number.MAX_SAFE_INTEGER;
		this.tokenizer = tokenizer;
		if (hasUnknownFileSize(tokenizer)) {
			await tokenizer.peekBuffer(this.buffer, {
				length: 3,
				mayBeLess: true
			});
			if (this.check([
				31,
				139,
				8
			])) return this.detectGzip(tokenizer);
		}
		await tokenizer.peekBuffer(this.buffer, {
			length: 32,
			mayBeLess: true
		});
		if (this.check([66, 77])) return {
			ext: "bmp",
			mime: "image/bmp"
		};
		if (this.check([11, 119])) return {
			ext: "ac3",
			mime: "audio/vnd.dolby.dd-raw"
		};
		if (this.check([120, 1])) return {
			ext: "dmg",
			mime: "application/x-apple-diskimage"
		};
		if (this.check([77, 90])) return {
			ext: "exe",
			mime: "application/x-msdownload"
		};
		if (this.check([37, 33])) {
			await tokenizer.peekBuffer(this.buffer, {
				length: 24,
				mayBeLess: true
			});
			if (this.checkString("PS-Adobe-", { offset: 2 }) && this.checkString(" EPSF-", { offset: 14 })) return {
				ext: "eps",
				mime: "application/eps"
			};
			return {
				ext: "ps",
				mime: "application/postscript"
			};
		}
		if (this.check([31, 160]) || this.check([31, 157])) return {
			ext: "Z",
			mime: "application/x-compress"
		};
		if (this.check([199, 113])) return {
			ext: "cpio",
			mime: "application/x-cpio"
		};
		if (this.check([96, 234])) return {
			ext: "arj",
			mime: "application/x-arj"
		};
		if (this.check([
			239,
			187,
			191
		])) {
			if (this.detectionReentryCount >= maximumDetectionReentryCount) return;
			this.detectionReentryCount++;
			await this.tokenizer.ignore(3);
			return this.detectConfident(tokenizer);
		}
		if (this.check([
			71,
			73,
			70
		])) return {
			ext: "gif",
			mime: "image/gif"
		};
		if (this.check([
			73,
			73,
			188
		])) return {
			ext: "jxr",
			mime: "image/vnd.ms-photo"
		};
		if (this.check([
			31,
			139,
			8
		])) return this.detectGzip(tokenizer);
		if (this.check([
			66,
			90,
			104
		])) return {
			ext: "bz2",
			mime: "application/x-bzip2"
		};
		if (this.checkString("ID3")) {
			await safeIgnore(tokenizer, 6, {
				maximumLength: 6,
				reason: "ID3 header prefix"
			});
			const id3HeaderLength = await tokenizer.readToken(uint32SyncSafeToken);
			const isUnknownFileSize = hasUnknownFileSize(tokenizer);
			if (!Number.isFinite(id3HeaderLength) || id3HeaderLength < 0 || isUnknownFileSize && (id3HeaderLength > maximumId3HeaderSizeInBytes || tokenizer.position + id3HeaderLength > maximumId3HeaderSizeInBytes)) return;
			if (tokenizer.position + id3HeaderLength > tokenizer.fileInfo.size) {
				if (isUnknownFileSize) return;
				return {
					ext: "mp3",
					mime: "audio/mpeg"
				};
			}
			try {
				await safeIgnore(tokenizer, id3HeaderLength, {
					maximumLength: isUnknownFileSize ? maximumId3HeaderSizeInBytes : tokenizer.fileInfo.size,
					reason: "ID3 payload"
				});
			} catch (error) {
				if (error instanceof EndOfStreamError) return;
				throw error;
			}
			if (this.detectionReentryCount >= maximumDetectionReentryCount) return;
			this.detectionReentryCount++;
			return this.parseTokenizer(tokenizer, this.detectionReentryCount);
		}
		if (this.checkString("MP+")) return {
			ext: "mpc",
			mime: "audio/x-musepack"
		};
		if ((this.buffer[0] === 67 || this.buffer[0] === 70) && this.check([87, 83], { offset: 1 })) return {
			ext: "swf",
			mime: "application/x-shockwave-flash"
		};
		if (this.check([
			255,
			216,
			255
		])) {
			if (this.check([247], { offset: 3 })) return {
				ext: "jls",
				mime: "image/jls"
			};
			return {
				ext: "jpg",
				mime: "image/jpeg"
			};
		}
		if (this.check([
			79,
			98,
			106,
			1
		])) return {
			ext: "avro",
			mime: "application/avro"
		};
		if (this.checkString("FLIF")) return {
			ext: "flif",
			mime: "image/flif"
		};
		if (this.checkString("8BPS")) return {
			ext: "psd",
			mime: "image/vnd.adobe.photoshop"
		};
		if (this.checkString("MPCK")) return {
			ext: "mpc",
			mime: "audio/x-musepack"
		};
		if (this.checkString("FORM")) return {
			ext: "aif",
			mime: "audio/aiff"
		};
		if (this.checkString("caff") && this.check([0, 1], { offset: 4 }) && this.checkString("desc", { offset: 8 })) return {
			ext: "caf",
			mime: "audio/x-caf"
		};
		if (this.checkString("icns", { offset: 0 })) return {
			ext: "icns",
			mime: "image/icns"
		};
		if (this.check([
			80,
			75,
			3,
			4
		])) return detectZip(tokenizer);
		if (this.checkString("OggS")) {
			await tokenizer.ignore(28);
			const type = /* @__PURE__ */ new Uint8Array(8);
			await tokenizer.readBuffer(type);
			if (checkBytes(type, [
				79,
				112,
				117,
				115,
				72,
				101,
				97,
				100
			])) return {
				ext: "opus",
				mime: "audio/ogg; codecs=opus"
			};
			if (checkBytes(type, [
				128,
				116,
				104,
				101,
				111,
				114,
				97
			])) return {
				ext: "ogv",
				mime: "video/ogg"
			};
			if (checkBytes(type, [
				1,
				118,
				105,
				100,
				101,
				111,
				0
			])) return {
				ext: "ogm",
				mime: "video/ogg"
			};
			if (checkBytes(type, [
				127,
				70,
				76,
				65,
				67
			])) return {
				ext: "oga",
				mime: "audio/ogg"
			};
			if (checkBytes(type, [
				83,
				112,
				101,
				101,
				120,
				32,
				32
			])) return {
				ext: "spx",
				mime: "audio/ogg"
			};
			if (checkBytes(type, [
				1,
				118,
				111,
				114,
				98,
				105,
				115
			])) return {
				ext: "ogg",
				mime: "audio/ogg"
			};
			return {
				ext: "ogx",
				mime: "application/ogg"
			};
		}
		if (this.check([80, 75]) && [
			3,
			5,
			7
		].includes(this.buffer[2]) && [
			4,
			6,
			8
		].includes(this.buffer[3])) return {
			ext: "zip",
			mime: "application/zip"
		};
		if (this.checkString("MThd")) return {
			ext: "mid",
			mime: "audio/midi"
		};
		if (this.checkString("wOFF") && (this.check([
			0,
			1,
			0,
			0
		], { offset: 4 }) || this.checkString("OTTO", { offset: 4 }))) return {
			ext: "woff",
			mime: "font/woff"
		};
		if (this.checkString("wOF2") && (this.check([
			0,
			1,
			0,
			0
		], { offset: 4 }) || this.checkString("OTTO", { offset: 4 }))) return {
			ext: "woff2",
			mime: "font/woff2"
		};
		if (this.check([
			212,
			195,
			178,
			161
		]) || this.check([
			161,
			178,
			195,
			212
		])) return {
			ext: "pcap",
			mime: "application/vnd.tcpdump.pcap"
		};
		if (this.checkString("DSD ")) return {
			ext: "dsf",
			mime: "audio/x-dsf"
		};
		if (this.checkString("LZIP")) return {
			ext: "lz",
			mime: "application/lzip"
		};
		if (this.checkString("fLaC")) return {
			ext: "flac",
			mime: "audio/flac"
		};
		if (this.check([
			66,
			80,
			71,
			251
		])) return {
			ext: "bpg",
			mime: "image/bpg"
		};
		if (this.checkString("wvpk")) return {
			ext: "wv",
			mime: "audio/wavpack"
		};
		if (this.checkString("%PDF")) return {
			ext: "pdf",
			mime: "application/pdf"
		};
		if (this.check([
			0,
			97,
			115,
			109
		])) return {
			ext: "wasm",
			mime: "application/wasm"
		};
		if (this.check([73, 73])) {
			const fileType = await this.readTiffHeader(false);
			if (fileType) return fileType;
		}
		if (this.check([77, 77])) {
			const fileType = await this.readTiffHeader(true);
			if (fileType) return fileType;
		}
		if (this.checkString("MAC ")) return {
			ext: "ape",
			mime: "audio/ape"
		};
		if (this.check([
			26,
			69,
			223,
			163
		])) return detectEbml(tokenizer);
		if (this.checkString("SQLi")) return {
			ext: "sqlite",
			mime: "application/x-sqlite3"
		};
		if (this.check([
			78,
			69,
			83,
			26
		])) return {
			ext: "nes",
			mime: "application/x-nintendo-nes-rom"
		};
		if (this.checkString("Cr24")) return {
			ext: "crx",
			mime: "application/x-google-chrome-extension"
		};
		if (this.checkString("MSCF") || this.checkString("ISc(")) return {
			ext: "cab",
			mime: "application/vnd.ms-cab-compressed"
		};
		if (this.check([
			237,
			171,
			238,
			219
		])) return {
			ext: "rpm",
			mime: "application/x-rpm"
		};
		if (this.check([
			197,
			208,
			211,
			198
		])) return {
			ext: "eps",
			mime: "application/eps"
		};
		if (this.check([
			40,
			181,
			47,
			253
		])) return {
			ext: "zst",
			mime: "application/zstd"
		};
		if (this.check([
			127,
			69,
			76,
			70
		])) return {
			ext: "elf",
			mime: "application/x-elf"
		};
		if (this.check([
			33,
			66,
			68,
			78
		])) return {
			ext: "pst",
			mime: "application/vnd.ms-outlook"
		};
		if (this.checkString("PAR1") || this.checkString("PARE")) return {
			ext: "parquet",
			mime: "application/vnd.apache.parquet"
		};
		if (this.checkString("ttcf")) return {
			ext: "ttc",
			mime: "font/collection"
		};
		if (this.check([
			254,
			237,
			250,
			206
		]) || this.check([
			254,
			237,
			250,
			207
		]) || this.check([
			206,
			250,
			237,
			254
		]) || this.check([
			207,
			250,
			237,
			254
		])) return {
			ext: "macho",
			mime: "application/x-mach-binary"
		};
		if (this.check([
			4,
			34,
			77,
			24
		])) return {
			ext: "lz4",
			mime: "application/x-lz4"
		};
		if (this.checkString("regf")) return {
			ext: "dat",
			mime: "application/x-ft-windows-registry-hive"
		};
		if (this.checkString("$FL2") || this.checkString("$FL3")) return {
			ext: "sav",
			mime: "application/x-spss-sav"
		};
		if (this.check([
			79,
			84,
			84,
			79,
			0
		])) return {
			ext: "otf",
			mime: "font/otf"
		};
		if (this.checkString("#!AMR")) return {
			ext: "amr",
			mime: "audio/amr"
		};
		if (this.checkString(String.raw`{\rtf`)) return {
			ext: "rtf",
			mime: "application/rtf"
		};
		if (this.check([
			70,
			76,
			86,
			1
		])) return {
			ext: "flv",
			mime: "video/x-flv"
		};
		if (this.checkString("IMPM")) return {
			ext: "it",
			mime: "audio/x-it"
		};
		if (this.checkString("-lh0-", { offset: 2 }) || this.checkString("-lh1-", { offset: 2 }) || this.checkString("-lh2-", { offset: 2 }) || this.checkString("-lh3-", { offset: 2 }) || this.checkString("-lh4-", { offset: 2 }) || this.checkString("-lh5-", { offset: 2 }) || this.checkString("-lh6-", { offset: 2 }) || this.checkString("-lh7-", { offset: 2 }) || this.checkString("-lzs-", { offset: 2 }) || this.checkString("-lz4-", { offset: 2 }) || this.checkString("-lz5-", { offset: 2 }) || this.checkString("-lhd-", { offset: 2 })) return {
			ext: "lzh",
			mime: "application/x-lzh-compressed"
		};
		if (this.check([
			0,
			0,
			1,
			186
		])) {
			if (this.check([33], {
				offset: 4,
				mask: [241]
			})) return {
				ext: "mpg",
				mime: "video/MP1S"
			};
			if (this.check([68], {
				offset: 4,
				mask: [196]
			})) return {
				ext: "mpg",
				mime: "video/MP2P"
			};
		}
		if (this.checkString("ITSF")) return {
			ext: "chm",
			mime: "application/vnd.ms-htmlhelp"
		};
		if (this.check([
			202,
			254,
			186,
			190
		])) {
			const machOArchitectureCount = UINT32_BE.get(this.buffer, 4);
			if (machOArchitectureCount > 0 && machOArchitectureCount <= 30) return {
				ext: "macho",
				mime: "application/x-mach-binary"
			};
			if (UINT16_BE.get(this.buffer, 6) > 30) return {
				ext: "class",
				mime: "application/java-vm"
			};
		}
		if (this.checkString(".RMF")) return {
			ext: "rm",
			mime: "application/vnd.rn-realmedia"
		};
		if (this.checkString("DRACO")) return {
			ext: "drc",
			mime: "application/x-ft-draco"
		};
		if (this.check([
			253,
			55,
			122,
			88,
			90,
			0
		])) return {
			ext: "xz",
			mime: "application/x-xz"
		};
		if (this.checkString("<?xml ")) return {
			ext: "xml",
			mime: "application/xml"
		};
		if (this.check([
			55,
			122,
			188,
			175,
			39,
			28
		])) return {
			ext: "7z",
			mime: "application/x-7z-compressed"
		};
		if (this.check([
			82,
			97,
			114,
			33,
			26,
			7
		]) && (this.buffer[6] === 0 || this.buffer[6] === 1)) return {
			ext: "rar",
			mime: "application/x-rar-compressed"
		};
		if (this.checkString("solid ")) return {
			ext: "stl",
			mime: "model/stl"
		};
		if (this.checkString("AC")) {
			const version = new StringType(4, "latin1").get(this.buffer, 2);
			if (new RegExp("^\\d+$", "v").test(version) && version >= 1e3 && version <= 1050) return {
				ext: "dwg",
				mime: "image/vnd.dwg"
			};
		}
		if (this.checkString("070707")) return {
			ext: "cpio",
			mime: "application/x-cpio"
		};
		if (this.checkString("BLENDER")) return {
			ext: "blend",
			mime: "application/x-blender"
		};
		if (this.checkString("!<arch>")) {
			await tokenizer.ignore(8);
			if (await tokenizer.readToken(new StringType(13, "ascii")) === "debian-binary") return {
				ext: "deb",
				mime: "application/x-deb"
			};
			return {
				ext: "ar",
				mime: "application/x-unix-archive"
			};
		}
		if (this.checkString("WEBVTT") && [
			"\n",
			"\r",
			"	",
			" ",
			"\0"
		].some((char7) => this.checkString(char7, { offset: 6 }))) return {
			ext: "vtt",
			mime: "text/vtt"
		};
		if (this.check([
			137,
			80,
			78,
			71,
			13,
			10,
			26,
			10
		])) return detectPng(tokenizer);
		if (this.check([
			65,
			82,
			82,
			79,
			87,
			49,
			0,
			0
		])) return {
			ext: "arrow",
			mime: "application/vnd.apache.arrow.file"
		};
		if (this.check([
			103,
			108,
			84,
			70,
			2,
			0,
			0,
			0
		])) return {
			ext: "glb",
			mime: "model/gltf-binary"
		};
		if (this.check([
			102,
			114,
			101,
			101
		], { offset: 4 }) || this.check([
			109,
			100,
			97,
			116
		], { offset: 4 }) || this.check([
			109,
			111,
			111,
			118
		], { offset: 4 }) || this.check([
			119,
			105,
			100,
			101
		], { offset: 4 })) return {
			ext: "mov",
			mime: "video/quicktime"
		};
		if (this.check([
			73,
			73,
			82,
			79,
			8,
			0,
			0,
			0,
			24
		])) return {
			ext: "orf",
			mime: "image/x-olympus-orf"
		};
		if (this.checkString("gimp xcf ")) return {
			ext: "xcf",
			mime: "image/x-xcf"
		};
		if (this.checkString("ftyp", { offset: 4 }) && (this.buffer[8] & 96) !== 0) {
			const brandMajor = new StringType(4, "latin1").get(this.buffer, 8).replace("\0", " ").trim();
			switch (brandMajor) {
				case "avif":
				case "avis": return {
					ext: "avif",
					mime: "image/avif"
				};
				case "mif1": return {
					ext: "heic",
					mime: "image/heif"
				};
				case "msf1": return {
					ext: "heic",
					mime: "image/heif-sequence"
				};
				case "heic":
				case "heix": return {
					ext: "heic",
					mime: "image/heic"
				};
				case "hevc":
				case "hevx": return {
					ext: "heic",
					mime: "image/heic-sequence"
				};
				case "qt": return {
					ext: "mov",
					mime: "video/quicktime"
				};
				case "M4V":
				case "M4VH":
				case "M4VP": return {
					ext: "m4v",
					mime: "video/x-m4v"
				};
				case "M4P": return {
					ext: "m4p",
					mime: "video/mp4"
				};
				case "M4B": return {
					ext: "m4b",
					mime: "audio/mp4"
				};
				case "M4A": return {
					ext: "m4a",
					mime: "audio/x-m4a"
				};
				case "F4V": return {
					ext: "f4v",
					mime: "video/mp4"
				};
				case "F4P": return {
					ext: "f4p",
					mime: "video/mp4"
				};
				case "F4A": return {
					ext: "f4a",
					mime: "audio/mp4"
				};
				case "F4B": return {
					ext: "f4b",
					mime: "audio/mp4"
				};
				case "crx": return {
					ext: "cr3",
					mime: "image/x-canon-cr3"
				};
				default:
					if (brandMajor.startsWith("3g")) {
						if (brandMajor.startsWith("3g2")) return {
							ext: "3g2",
							mime: "video/3gpp2"
						};
						return {
							ext: "3gp",
							mime: "video/3gpp"
						};
					}
					return {
						ext: "mp4",
						mime: "video/mp4"
					};
			}
		}
		if (this.checkString("REGEDIT4\r\n")) return {
			ext: "reg",
			mime: "application/x-ms-regedit"
		};
		if (this.check([
			82,
			73,
			70,
			70
		])) {
			if (this.checkString("WEBP", { offset: 8 })) return {
				ext: "webp",
				mime: "image/webp"
			};
			if (this.check([
				65,
				86,
				73
			], { offset: 8 })) return {
				ext: "avi",
				mime: "video/vnd.avi"
			};
			if (this.check([
				87,
				65,
				86,
				69
			], { offset: 8 })) return {
				ext: "wav",
				mime: "audio/wav"
			};
			if (this.check([
				81,
				76,
				67,
				77
			], { offset: 8 })) return {
				ext: "qcp",
				mime: "audio/qcelp"
			};
		}
		if (this.check([
			73,
			73,
			85,
			0,
			24,
			0,
			0,
			0,
			136,
			231,
			116,
			216
		])) return {
			ext: "rw2",
			mime: "image/x-panasonic-rw2"
		};
		if (this.check([
			48,
			38,
			178,
			117,
			142,
			102,
			207,
			17,
			166,
			217
		])) return detectAsf(tokenizer);
		if (this.check([
			171,
			75,
			84,
			88,
			32,
			49,
			49,
			187,
			13,
			10,
			26,
			10
		])) return {
			ext: "ktx",
			mime: "image/ktx"
		};
		if ((this.check([
			126,
			16,
			4
		]) || this.check([
			126,
			24,
			4
		])) && this.check([
			48,
			77,
			73,
			69
		], { offset: 4 })) return {
			ext: "mie",
			mime: "application/x-mie"
		};
		if (this.check([
			39,
			10,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		], { offset: 2 })) return {
			ext: "shp",
			mime: "application/x-esri-shape"
		};
		if (this.check([
			255,
			79,
			255,
			81
		])) return {
			ext: "j2c",
			mime: "image/j2c"
		};
		if (this.check([
			0,
			0,
			0,
			12,
			106,
			80,
			32,
			32,
			13,
			10,
			135,
			10
		])) {
			await tokenizer.ignore(20);
			switch (await tokenizer.readToken(new StringType(4, "ascii"))) {
				case "jp2 ": return {
					ext: "jp2",
					mime: "image/jp2"
				};
				case "jpx ": return {
					ext: "jpx",
					mime: "image/jpx"
				};
				case "jpm ": return {
					ext: "jpm",
					mime: "image/jpm"
				};
				case "mjp2": return {
					ext: "mj2",
					mime: "image/mj2"
				};
				default: return;
			}
		}
		if (this.check([255, 10]) || this.check([
			0,
			0,
			0,
			12,
			74,
			88,
			76,
			32,
			13,
			10,
			135,
			10
		])) return {
			ext: "jxl",
			mime: "image/jxl"
		};
		if (this.check([254, 255])) {
			if (this.checkString("<?xml ", {
				offset: 2,
				encoding: "utf-16be"
			})) return {
				ext: "xml",
				mime: "application/xml"
			};
			return;
		}
		if (this.check([
			208,
			207,
			17,
			224,
			161,
			177,
			26,
			225
		])) return {
			ext: "cfb",
			mime: "application/x-cfb"
		};
		if (this.checkString("FRM8") && this.checkString("DSD ", { offset: 12 })) return {
			ext: "dff",
			mime: "audio/x-dff"
		};
		await tokenizer.peekBuffer(this.buffer, {
			length: Math.min(256, tokenizer.fileInfo.size),
			mayBeLess: true
		});
		if (this.check([
			97,
			99,
			115,
			112
		], { offset: 36 })) return {
			ext: "icc",
			mime: "application/vnd.iccprofile"
		};
		if (this.checkString("**ACE", { offset: 7 }) && this.checkString("**", { offset: 12 })) return {
			ext: "ace",
			mime: "application/x-ace-compressed"
		};
		if (this.checkString("BEGIN:")) {
			if (this.checkString("VCARD", { offset: 6 })) return {
				ext: "vcf",
				mime: "text/vcard"
			};
			if (this.checkString("VCALENDAR", { offset: 6 })) return {
				ext: "ics",
				mime: "text/calendar"
			};
		}
		if (this.checkString("FUJIFILMCCD-RAW")) return {
			ext: "raf",
			mime: "image/x-fujifilm-raf"
		};
		if (this.checkString("Extended Module:")) return {
			ext: "xm",
			mime: "audio/x-xm"
		};
		if (this.checkString("Creative Voice File")) return {
			ext: "voc",
			mime: "audio/x-voc"
		};
		if (this.check([
			4,
			0,
			0,
			0
		]) && this.buffer.length >= 16) {
			const jsonSize = new DataView(this.buffer.buffer).getUint32(12, true);
			if (jsonSize > 12 && this.buffer.length >= jsonSize + 16) try {
				const header = new TextDecoder().decode(this.buffer.subarray(16, jsonSize + 16));
				if (JSON.parse(header).files) return {
					ext: "asar",
					mime: "application/x-asar"
				};
			} catch {}
		}
		if (this.check([
			6,
			14,
			43,
			52,
			2,
			5,
			1,
			1,
			13,
			1,
			2,
			1,
			1,
			2
		])) return {
			ext: "mxf",
			mime: "application/mxf"
		};
		if (this.checkString("SCRM", { offset: 44 })) return {
			ext: "s3m",
			mime: "audio/x-s3m"
		};
		if (this.check([71]) && this.check([71], { offset: 188 })) return {
			ext: "mts",
			mime: "video/mp2t"
		};
		if (this.check([71], { offset: 4 }) && this.check([71], { offset: 196 })) return {
			ext: "mts",
			mime: "video/mp2t"
		};
		if (this.check([
			66,
			79,
			79,
			75,
			77,
			79,
			66,
			73
		], { offset: 60 })) return {
			ext: "mobi",
			mime: "application/x-mobipocket-ebook"
		};
		if (this.check([
			68,
			73,
			67,
			77
		], { offset: 128 })) return {
			ext: "dcm",
			mime: "application/dicom"
		};
		if (this.check([
			76,
			0,
			0,
			0,
			1,
			20,
			2,
			0,
			0,
			0,
			0,
			0,
			192,
			0,
			0,
			0,
			0,
			0,
			0,
			70
		])) return {
			ext: "lnk",
			mime: "application/x-ms-shortcut"
		};
		if (this.check([
			98,
			111,
			111,
			107,
			0,
			0,
			0,
			0,
			109,
			97,
			114,
			107,
			0,
			0,
			0,
			0
		])) return {
			ext: "alias",
			mime: "application/x-ft-apple.alias"
		};
		if (this.checkString("Kaydara FBX Binary  \0")) return {
			ext: "fbx",
			mime: "application/x-ft-fbx"
		};
		if (this.check([76, 80], { offset: 34 }) && (this.check([
			0,
			0,
			1
		], { offset: 8 }) || this.check([
			1,
			0,
			2
		], { offset: 8 }) || this.check([
			2,
			0,
			2
		], { offset: 8 }))) return {
			ext: "eot",
			mime: "application/vnd.ms-fontobject"
		};
		if (this.check([
			6,
			6,
			237,
			245,
			216,
			29,
			70,
			229,
			189,
			49,
			239,
			231,
			254,
			116,
			183,
			29
		])) return {
			ext: "indd",
			mime: "application/x-indesign"
		};
		if (this.check([
			255,
			255,
			0,
			0,
			7,
			0,
			0,
			0,
			4,
			0,
			0,
			0,
			1,
			0,
			1,
			0
		]) || this.check([
			0,
			0,
			255,
			255,
			0,
			0,
			0,
			7,
			0,
			0,
			0,
			4,
			0,
			1,
			0,
			1
		])) return {
			ext: "jmp",
			mime: "application/x-jmp-data"
		};
		await tokenizer.peekBuffer(this.buffer, {
			length: Math.min(512, tokenizer.fileInfo.size),
			mayBeLess: true
		});
		if (this.checkString("ustar", { offset: 257 }) && (this.checkString("\0", { offset: 262 }) || this.checkString(" ", { offset: 262 })) || this.check([
			0,
			0,
			0,
			0,
			0,
			0
		], { offset: 257 }) && tarHeaderChecksumMatches(this.buffer)) return {
			ext: "tar",
			mime: "application/x-tar"
		};
		if (this.check([255, 254])) {
			const encoding = "utf-16le";
			if (this.checkString("<?xml ", {
				offset: 2,
				encoding
			})) return {
				ext: "xml",
				mime: "application/xml"
			};
			if (this.check([255, 14], { offset: 2 }) && this.checkString("SketchUp Model", {
				offset: 4,
				encoding
			})) return {
				ext: "skp",
				mime: "application/vnd.sketchup.skp"
			};
			if (this.checkString("Windows Registry Editor Version 5.00\r\n", {
				offset: 2,
				encoding
			})) return {
				ext: "reg",
				mime: "application/x-ms-regedit"
			};
			return;
		}
		if (this.checkString("-----BEGIN PGP MESSAGE-----")) return {
			ext: "pgp",
			mime: "application/pgp-encrypted"
		};
		const isoStandardIdentifierOffset = 32769;
		const isoStandardIdentifierLength = 5;
		if (tokenizer.supportsRandomAccess() && tokenizer.fileInfo.size >= 32774) {
			const isoStandardIdentifier = new Uint8Array(isoStandardIdentifierLength);
			await tokenizer.peekBuffer(isoStandardIdentifier, {
				position: isoStandardIdentifierOffset,
				length: isoStandardIdentifierLength,
				mayBeLess: true
			});
			if (checkBytes(isoStandardIdentifier, stringToBytes("CD001"))) return {
				ext: "iso",
				mime: "application/x-iso9660-image"
			};
		}
	}
	async detectImprecise(tokenizer) {
		this.buffer = new Uint8Array(reasonableDetectionSizeInBytes);
		const fileSize = getKnownFileSizeOrMaximum(tokenizer.fileInfo.size);
		await tokenizer.peekBuffer(this.buffer, {
			length: Math.min(8, fileSize),
			mayBeLess: true
		});
		if (this.check([
			0,
			0,
			1,
			186
		]) || this.check([
			0,
			0,
			1,
			179
		])) return {
			ext: "mpg",
			mime: "video/mpeg"
		};
		if (this.check([
			0,
			1,
			0,
			0,
			0
		])) return {
			ext: "ttf",
			mime: "font/ttf"
		};
		if (this.check([
			0,
			0,
			1,
			0
		])) return {
			ext: "ico",
			mime: "image/x-icon"
		};
		if (this.check([
			0,
			0,
			2,
			0
		])) return {
			ext: "cur",
			mime: "image/x-icon"
		};
		await tokenizer.peekBuffer(this.buffer, {
			length: Math.min(4 + this.options.mpegOffsetTolerance, fileSize),
			mayBeLess: true
		});
		if (this.buffer.length >= 4 + this.options.mpegOffsetTolerance) for (let depth = 0; depth <= this.options.mpegOffsetTolerance; ++depth) {
			const type = this.scanMpeg(depth);
			if (type) return type;
		}
	}
	async readTiffTag(isBigEndian) {
		const tagId = await this.tokenizer.readToken(isBigEndian ? UINT16_BE : UINT16_LE);
		await this.tokenizer.ignore(10);
		switch (tagId) {
			case 50341: return {
				ext: "arw",
				mime: "image/x-sony-arw"
			};
			case 50706: return {
				ext: "dng",
				mime: "image/x-adobe-dng"
			};
		}
	}
	async readTiffIFD(isBigEndian) {
		const numberOfTags = await this.tokenizer.readToken(isBigEndian ? UINT16_BE : UINT16_LE);
		if (numberOfTags > maximumTiffTagCount) return;
		if (hasUnknownFileSize(this.tokenizer) && 2 + numberOfTags * 12 > maximumTiffIfdOffsetInBytes) return;
		for (let n = 0; n < numberOfTags; ++n) {
			const fileType = await this.readTiffTag(isBigEndian);
			if (fileType) return fileType;
		}
	}
	async readTiffHeader(isBigEndian) {
		const tiffFileType = {
			ext: "tif",
			mime: "image/tiff"
		};
		const version = (isBigEndian ? UINT16_BE : UINT16_LE).get(this.buffer, 2);
		const ifdOffset = (isBigEndian ? UINT32_BE : UINT32_LE).get(this.buffer, 4);
		if (version === 42) {
			if (ifdOffset >= 6) {
				if (this.checkString("CR", { offset: 8 })) return {
					ext: "cr2",
					mime: "image/x-canon-cr2"
				};
				if (ifdOffset >= 8) {
					const someId1 = (isBigEndian ? UINT16_BE : UINT16_LE).get(this.buffer, 8);
					const someId2 = (isBigEndian ? UINT16_BE : UINT16_LE).get(this.buffer, 10);
					if (someId1 === 28 && someId2 === 254 || someId1 === 31 && someId2 === 11) return {
						ext: "nef",
						mime: "image/x-nikon-nef"
					};
				}
			}
			if (hasUnknownFileSize(this.tokenizer) && ifdOffset > maximumTiffStreamIfdOffsetInBytes) return tiffFileType;
			const maximumTiffOffset = hasUnknownFileSize(this.tokenizer) ? maximumTiffIfdOffsetInBytes : this.tokenizer.fileInfo.size;
			try {
				await safeIgnore(this.tokenizer, ifdOffset, {
					maximumLength: maximumTiffOffset,
					reason: "TIFF IFD offset"
				});
			} catch (error) {
				if (error instanceof EndOfStreamError) return;
				throw error;
			}
			let fileType;
			try {
				fileType = await this.readTiffIFD(isBigEndian);
			} catch (error) {
				if (error instanceof EndOfStreamError) return;
				throw error;
			}
			return fileType ?? tiffFileType;
		}
		if (version === 43) return tiffFileType;
	}
	/**
	Scan check MPEG 1 or 2 Layer 3 header, or 'layer 0' for ADTS (MPEG sync-word 0xFFE).
	
	@param {number} offset - Offset to scan for sync-preamble.
	@returns {{ext: string, mime: string} | undefined} The detected file type, if any.
	*/
	scanMpeg(offset) {
		if (this.check([255, 224], {
			offset,
			mask: [255, 224]
		})) {
			if (this.check([16], {
				offset: offset + 1,
				mask: [22]
			})) return {
				ext: "aac",
				mime: "audio/aac"
			};
			if (this.check([255, 254], { offset })) return;
			if (this.check([8], {
				offset: offset + 1,
				mask: [24]
			})) return;
			if (this.check([240], {
				offset: offset + 2,
				mask: [240]
			})) return;
			if (this.check([12], {
				offset: offset + 2,
				mask: [12]
			})) return;
			if (this.check([2], {
				offset: offset + 1,
				mask: [6]
			})) return {
				ext: "mp3",
				mime: "audio/mpeg"
			};
			if (this.check([4], {
				offset: offset + 1,
				mask: [6]
			})) return {
				ext: "mp2",
				mime: "audio/mpeg"
			};
			if (this.check([6], {
				offset: offset + 1,
				mask: [6]
			})) return {
				ext: "mp1",
				mime: "audio/mpeg"
			};
		}
	}
};
new Set(extensions);
new Set(mimeTypes);
// node_modules/music-metadata/lib/lrc/LyricsParser.js
var TIMESTAMP_REGEX = /\[(\d{2}):(\d{2})\.(\d{2,3})]/;
var LyricsContentError = class extends makeUnexpectedFileContentError("lyrics") {};
function parseLyrics(input, maxLines = defaultMaxMetadataEntries) {
	if (TIMESTAMP_REGEX.test(input)) return parseLrc(input, maxLines);
	return toUnsyncedLyrics(input);
}
function toUnsyncedLyrics(lyrics) {
	return {
		contentType: LyricsContentType.lyrics,
		timeStampFormat: TimestampFormat.notSynchronized,
		text: lyrics.trim(),
		syncText: []
	};
}
/**
* Parse LRC (Lyrics) formatted text
* Ref: https://en.wikipedia.org/wiki/LRC_(file_format)
* @param lrcString
*/
function parseLrc(lrcString, maxLines = defaultMaxMetadataEntries) {
	let lineCount = 1;
	for (let offset = lrcString.indexOf("\n"); offset >= 0; offset = lrcString.indexOf("\n", offset + 1)) ++lineCount;
	if (lineCount > maxLines) throw new LyricsContentError(`Line count ${lineCount} exceeds entry limit ${maxLines}`);
	const lines = lrcString.split("\n");
	const syncText = [];
	for (const line of lines) {
		const match = line.match(TIMESTAMP_REGEX);
		if (match) {
			const minutes = Number.parseInt(match[1], 10);
			const seconds = Number.parseInt(match[2], 10);
			const ms = match[3].length === 3 ? Number.parseInt(match[3], 10) : Number.parseInt(match[3], 10) * 10;
			const timestamp = (minutes * 60 + seconds) * 1e3 + ms;
			const text = line.replace(TIMESTAMP_REGEX, "").trim();
			syncText.push({
				timestamp,
				text
			});
		}
	}
	return {
		contentType: LyricsContentType.lyrics,
		timeStampFormat: TimestampFormat.milliseconds,
		text: syncText.map((line) => line.text).join("\n"),
		syncText
	};
}
// node_modules/music-metadata/lib/common/GenericTagMapper.js
var CommonTagMapper = class {
	static maxRatingScore = 1;
	static toIntOrNull(str) {
		const cleaned = Number.parseInt(str, 10);
		return Number.isNaN(cleaned) ? null : cleaned;
	}
	static normalizeTrack(origVal) {
		const split = origVal.toString().split("/", 2);
		return {
			no: Number.parseInt(split[0], 10) || null,
			of: Number.parseInt(split[1], 10) || null
		};
	}
	tagTypes;
	tagMap;
	constructor(tagTypes, tagMap) {
		this.tagTypes = tagTypes;
		this.tagMap = tagMap;
	}
	/**
	* Process and set common tags
	* write common tags to
	* @param tag Native tag
	* @param warnings Register warnings
	* @return common name
	*/
	mapGenericTag(tag, warnings) {
		tag = {
			id: tag.id,
			value: tag.value
		};
		this.postMap(tag, warnings);
		const id = this.getCommonName(tag.id);
		return id ? {
			id,
			value: tag.value
		} : null;
	}
	/**
	* Convert native tag key to common tag key
	* @param tag Native header tag
	* @return common tag name (alias)
	*/
	getCommonName(tag) {
		return Object.hasOwn(this.tagMap, tag) ? this.tagMap[tag] : void 0;
	}
	/**
	* Handle post mapping exceptions / correction
	* @param tag Tag e.g. {"©alb", "Buena Vista Social Club")
	* @param warnings Used to register warnings
	*/
	postMap(_tag, _warnings) {}
};
// node_modules/music-metadata/lib/aiff/AiffTagMap.js
/**
* ID3v1 tag mappings
*/
var tagMap = {
	NAME: "title",
	AUTH: "artist",
	"(c) ": "copyright",
	ANNO: "comment"
};
var AiffTagMapper = class extends CommonTagMapper {
	constructor() {
		super(["AIFF"], tagMap);
	}
};
// node_modules/music-metadata/lib/common/CaseInsensitiveTagMap.js
var CaseInsensitiveTagMap = class extends CommonTagMapper {
	constructor(tagTypes, tagMap) {
		const upperCaseMap = {};
		for (const [tag, commonName] of Object.entries(tagMap)) upperCaseMap[tag.toUpperCase()] = commonName;
		super(tagTypes, upperCaseMap);
	}
	/**
	* @tag  Native header tag
	* @return common tag name (alias)
	*/
	getCommonName(tag) {
		return super.getCommonName(tag.toUpperCase());
	}
};
// node_modules/music-metadata/lib/apev2/APEv2TagMapper.js
/**
* ID3v2.2 tag mappings
*/
var apev2TagMap = {
	Title: "title",
	Artist: "artist",
	Artists: "artists",
	"Album Artist": "albumartist",
	Album: "album",
	Year: "date",
	Date: "date",
	Originalyear: "originalyear",
	Originaldate: "originaldate",
	Releasedate: "releasedate",
	Comment: "comment",
	Track: "track",
	Disc: "disk",
	DISCNUMBER: "disk",
	Genre: "genre",
	"Cover Art (Front)": "picture",
	"Cover Art (Back)": "picture",
	Composer: "composer",
	Lyrics: "lyrics",
	ALBUMSORT: "albumsort",
	TITLESORT: "titlesort",
	WORK: "work",
	ARTISTSORT: "artistsort",
	ALBUMARTISTSORT: "albumartistsort",
	COMPOSERSORT: "composersort",
	Lyricist: "lyricist",
	Writer: "writer",
	Conductor: "conductor",
	MixArtist: "remixer",
	Arranger: "arranger",
	Engineer: "engineer",
	Producer: "producer",
	DJMixer: "djmixer",
	Mixer: "mixer",
	Label: "label",
	Grouping: "grouping",
	Subtitle: "subtitle",
	DiscSubtitle: "discsubtitle",
	Compilation: "compilation",
	BPM: "bpm",
	Mood: "mood",
	Media: "media",
	CatalogNumber: "catalognumber",
	MUSICBRAINZ_ALBUMSTATUS: "releasestatus",
	MUSICBRAINZ_ALBUMTYPE: "releasetype",
	RELEASECOUNTRY: "releasecountry",
	Script: "script",
	Language: "language",
	Copyright: "copyright",
	LICENSE: "license",
	EncodedBy: "encodedby",
	EncoderSettings: "encodersettings",
	Barcode: "barcode",
	ISRC: "isrc",
	ASIN: "asin",
	musicbrainz_trackid: "musicbrainz_recordingid",
	musicbrainz_releasetrackid: "musicbrainz_trackid",
	MUSICBRAINZ_ALBUMID: "musicbrainz_albumid",
	MUSICBRAINZ_ARTISTID: "musicbrainz_artistid",
	MUSICBRAINZ_ALBUMARTISTID: "musicbrainz_albumartistid",
	MUSICBRAINZ_RELEASEGROUPID: "musicbrainz_releasegroupid",
	MUSICBRAINZ_WORKID: "musicbrainz_workid",
	MUSICBRAINZ_TRMID: "musicbrainz_trmid",
	MUSICBRAINZ_DISCID: "musicbrainz_discid",
	Acoustid_Id: "acoustid_id",
	ACOUSTID_FINGERPRINT: "acoustid_fingerprint",
	MUSICIP_PUID: "musicip_puid",
	Weblink: "website",
	REPLAYGAIN_TRACK_GAIN: "replaygain_track_gain",
	REPLAYGAIN_TRACK_PEAK: "replaygain_track_peak",
	MP3GAIN_MINMAX: "replaygain_track_minmax",
	MP3GAIN_UNDO: "replaygain_undo"
};
var APEv2TagMapper = class extends CaseInsensitiveTagMap {
	constructor() {
		super(["APEv2"], apev2TagMap);
	}
};
// node_modules/music-metadata/lib/asf/AsfTagMapper.js
/**
* ASF Metadata tag mappings.
* See http://msdn.microsoft.com/en-us/library/ms867702.aspx
*/
var asfTagMap = {
	Title: "title",
	Author: "artist",
	"WM/AlbumArtist": "albumartist",
	"WM/AlbumTitle": "album",
	"WM/Year": "date",
	"WM/OriginalReleaseTime": "originaldate",
	"WM/OriginalReleaseYear": "originalyear",
	Description: "comment",
	"WM/TrackNumber": "track",
	TotalTracks: "totaltracks",
	"WM/PartOfSet": "disk",
	"WM/Genre": "genre",
	"WM/Composer": "composer",
	"WM/Lyrics": "lyrics",
	"WM/AlbumSortOrder": "albumsort",
	"WM/TitleSortOrder": "titlesort",
	"WM/ArtistSortOrder": "artistsort",
	"WM/AlbumArtistSortOrder": "albumartistsort",
	"WM/ComposerSortOrder": "composersort",
	"WM/Writer": "lyricist",
	"WM/Conductor": "conductor",
	"WM/ModifiedBy": "remixer",
	"WM/Engineer": "engineer",
	"WM/Producer": "producer",
	"WM/DJMixer": "djmixer",
	"WM/Mixer": "mixer",
	"WM/Publisher": "label",
	"WM/ContentGroupDescription": "grouping",
	"WM/SubTitle": "subtitle",
	"WM/SetSubTitle": "discsubtitle",
	REPLAYGAIN_TRACK_GAIN: "replaygain_track_gain",
	REPLAYGAIN_TRACK_PEAK: "replaygain_track_peak",
	REPLAYGAIN_ALBUM_GAIN: "replaygain_album_gain",
	REPLAYGAIN_ALBUM_PEAK: "replaygain_album_peak",
	replaygain_track_gain: "replaygain_track_gain",
	replaygain_track_peak: "replaygain_track_peak",
	replaygain_album_gain: "replaygain_album_gain",
	replaygain_album_peak: "replaygain_album_peak",
	"WM/IsCompilation": "compilation",
	"WM/SharedUserRating": "rating",
	POPULARIMETER: "rating",
	"WM/BeatsPerMinute": "bpm",
	"WM/Mood": "mood",
	"WM/Media": "media",
	"WM/CatalogNo": "catalognumber",
	"MusicBrainz/Album Status": "releasestatus",
	"MusicBrainz/Album Type": "releasetype",
	"MusicBrainz/Album Release Country": "releasecountry",
	"WM/Script": "script",
	"WM/Language": "language",
	Copyright: "copyright",
	LICENSE: "license",
	"WM/EncodedBy": "encodedby",
	"WM/EncodingSettings": "encodersettings",
	"WM/Barcode": "barcode",
	"WM/ISRC": "isrc",
	"MusicBrainz/Track Id": "musicbrainz_recordingid",
	"MusicBrainz/Release Track Id": "musicbrainz_trackid",
	"MusicBrainz/Album Id": "musicbrainz_albumid",
	"MusicBrainz/Artist Id": "musicbrainz_artistid",
	"MusicBrainz/Album Artist Id": "musicbrainz_albumartistid",
	"MusicBrainz/Release Group Id": "musicbrainz_releasegroupid",
	"MusicBrainz/Work Id": "musicbrainz_workid",
	"MusicBrainz/TRM Id": "musicbrainz_trmid",
	"MusicBrainz/Disc Id": "musicbrainz_discid",
	"Acoustid/Id": "acoustid_id",
	"Acoustid/Fingerprint": "acoustid_fingerprint",
	"MusicIP/PUID": "musicip_puid",
	"WM/ARTISTS": "artists",
	"WM/InitialKey": "key",
	ASIN: "asin",
	"WM/Work": "work",
	"WM/AuthorURL": "website",
	"WM/Picture": "picture"
};
var AsfTagMapper = class AsfTagMapper extends CommonTagMapper {
	static toRating(rating) {
		const value = typeof rating === "number" ? rating : Number.parseFloat(rating);
		if (!Number.isFinite(value) || value <= 0) return { rating: void 0 };
		return { rating: value / 99 };
	}
	constructor() {
		super(["asf"], asfTagMap);
	}
	postMap(tag, warnings) {
		if (this.getCommonName(tag.id)?.startsWith("replaygain_")) {
			const value = typeof tag.value === "string" ? tag.value.trim().match(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)\s*(dB)?$/i) : null;
			const normalized = value ? `${value[1]}${value[2] ? " dB" : ""}` : void 0;
			const ratio = normalized ? toRatio(normalized) : void 0;
			if (!ratio || !Number.isFinite(ratio.ratio) || Number.isNaN(ratio.dB)) {
				warnings.addWarning(`Invalid ASF ReplayGain value for ${tag.id}`);
				tag.id = "";
			} else tag.value = normalized;
		}
		switch (tag.id) {
			case "POPULARIMETER": {
				const [email, rating] = tag.value.split("|", 2);
				const value = Number(rating);
				const valid = /^\d+$/.test(rating) && Number.isInteger(value) && value >= 0 && value <= 255;
				if (!valid) warnings.addWarning(`Invalid ASF POPULARIMETER rating: ${rating}`);
				tag.value = {
					source: email,
					rating: valid && value > 0 ? (value - 1) / 254 * CommonTagMapper.maxRatingScore : void 0
				};
				break;
			}
			case "WM/SharedUserRating": {
				const keys = tag.id.split(":", 2);
				tag.value = AsfTagMapper.toRating(tag.value);
				tag.id = keys[0];
				break;
			}
		}
	}
};
// node_modules/music-metadata/lib/caf/CafTagMap.js
var infoTagMap = {
	tempo: "bpm",
	"key signature": "key",
	artist: "artist",
	album: "album",
	"track number": "track",
	year: "year",
	composer: "composer",
	lyricist: "lyricist",
	genre: "genre",
	title: "title",
	"recorded date": "date",
	comments: "comment",
	copyright: "copyright",
	"source encoder": "encodersettings",
	"encoding application": "encodedby"
};
var commaSeparatedKeys = /* @__PURE__ */ new Set([
	"artist",
	"composer",
	"lyricist",
	"genre"
]);
var CafTagMapper = class extends CommonTagMapper {
	constructor() {
		super(["CAF"], infoTagMap);
	}
	mapGenericTag(tag, warnings) {
		if (commaSeparatedKeys.has(tag.id) && typeof tag.value === "string") tag = {
			id: tag.id,
			value: tag.value.split(",").map((value) => value.trim()).filter((value) => value.length > 0)
		};
		return super.mapGenericTag(tag, warnings);
	}
};
// node_modules/music-metadata/lib/id3v1/ID3v1TagMap.js
/**
* ID3v1 tag mappings
*/
var id3v1TagMap = {
	title: "title",
	artist: "artist",
	album: "album",
	year: "year",
	comment: "comment",
	track: "track",
	genre: "genre"
};
var ID3v1TagMapper = class extends CommonTagMapper {
	constructor() {
		super(["ID3v1"], id3v1TagMap);
	}
};
// node_modules/music-metadata/lib/id3v2/ID3v22TagMapper.js
/**
* ID3v2.2 tag mappings
*/
var id3v22TagMap = {
	TT2: "title",
	TP1: "artist",
	TP2: "albumartist",
	TAL: "album",
	TYE: "year",
	COM: "comment",
	ULT: "lyrics",
	"IPL:arranger": "arranger",
	"IPL:engineer": "engineer",
	"IPL:producer": "producer",
	"IPL:DJ-mix": "djmixer",
	"IPL:mix": "mixer",
	TRK: "track",
	TPA: "disk",
	TCO: "genre",
	PIC: "picture",
	TCM: "composer",
	TOR: "originaldate",
	TOT: "originalalbum",
	TXT: "lyricist",
	TP3: "conductor",
	TPB: "label",
	TT1: "grouping",
	TT3: "subtitle",
	TLA: "language",
	TCR: "copyright",
	WCP: "license",
	TEN: "encodedby",
	TSS: "encodersettings",
	WAR: "website",
	PCS: "podcast",
	TCP: "compilation",
	TDR: "date",
	TS2: "albumartistsort",
	TSA: "albumsort",
	TSC: "composersort",
	TSP: "artistsort",
	TST: "titlesort",
	WFD: "podcasturl",
	TBP: "bpm",
	GP1: "grouping"
};
var ID3v22TagMapper = class extends CaseInsensitiveTagMap {
	constructor() {
		super(["ID3v2.2"], id3v22TagMap);
	}
};
// node_modules/music-metadata/lib/id3v2/ID3v24TagMapper.js
/**
* ID3v2.3/ID3v2.4 tag mappings
*/
var id3v24TagMap = {
	TIT2: "title",
	TPE1: "artist",
	"TXXX:Artists": "artists",
	TPE2: "albumartist",
	TALB: "album",
	TDRV: "date",
	/**
	* Original release year
	*/
	TORY: "originalyear",
	TPOS: "disk",
	TCON: "genre",
	APIC: "picture",
	TCOM: "composer",
	USLT: "lyrics",
	TSOA: "albumsort",
	TSOT: "titlesort",
	TOAL: "originalalbum",
	TSOP: "artistsort",
	TSO2: "albumartistsort",
	TSOC: "composersort",
	TEXT: "lyricist",
	"TXXX:Writer": "writer",
	TPE3: "conductor",
	TPE4: "remixer",
	"IPLS:arranger": "arranger",
	"IPLS:engineer": "engineer",
	"IPLS:producer": "producer",
	"IPLS:DJ-mix": "djmixer",
	"IPLS:mix": "mixer",
	TPUB: "label",
	TIT1: "grouping",
	TIT3: "subtitle",
	TRCK: "track",
	TCMP: "compilation",
	POPM: "rating",
	TBPM: "bpm",
	TMED: "media",
	"TXXX:CATALOGNUMBER": "catalognumber",
	"TXXX:MusicBrainz Album Status": "releasestatus",
	"TXXX:MusicBrainz Album Type": "releasetype",
	/**
	* Release country as documented: https://picard.musicbrainz.org/docs/mappings/#cite_note-0
	*/
	"TXXX:MusicBrainz Album Release Country": "releasecountry",
	/**
	* Release country as implemented // ToDo: report
	*/
	"TXXX:RELEASECOUNTRY": "releasecountry",
	"TXXX:SCRIPT": "script",
	TLAN: "language",
	TCOP: "copyright",
	WCOP: "license",
	TENC: "encodedby",
	TSSE: "encodersettings",
	"TXXX:BARCODE": "barcode",
	"TXXX:ISRC": "isrc",
	TSRC: "isrc",
	"TXXX:ASIN": "asin",
	"TXXX:originalyear": "originalyear",
	"UFID:http://musicbrainz.org": "musicbrainz_recordingid",
	"TXXX:MusicBrainz Release Track Id": "musicbrainz_trackid",
	"TXXX:MusicBrainz Album Id": "musicbrainz_albumid",
	"TXXX:MusicBrainz Artist Id": "musicbrainz_artistid",
	"TXXX:MusicBrainz Album Artist Id": "musicbrainz_albumartistid",
	"TXXX:MusicBrainz Release Group Id": "musicbrainz_releasegroupid",
	"TXXX:MusicBrainz Work Id": "musicbrainz_workid",
	"TXXX:MusicBrainz TRM Id": "musicbrainz_trmid",
	"TXXX:MusicBrainz Disc Id": "musicbrainz_discid",
	"TXXX:ACOUSTID_ID": "acoustid_id",
	"TXXX:Acoustid Id": "acoustid_id",
	"TXXX:Acoustid Fingerprint": "acoustid_fingerprint",
	"TXXX:MusicIP PUID": "musicip_puid",
	"TXXX:MusicMagic Fingerprint": "musicip_fingerprint",
	WOAR: "website",
	TDRC: "date",
	TYER: "year",
	TDOR: "originaldate",
	"TIPL:arranger": "arranger",
	"TIPL:engineer": "engineer",
	"TIPL:producer": "producer",
	"TIPL:DJ-mix": "djmixer",
	"TIPL:mix": "mixer",
	TMOO: "mood",
	SYLT: "lyrics",
	TSST: "discsubtitle",
	TKEY: "key",
	COMM: "comment",
	TOPE: "originalartist",
	"PRIV:AverageLevel": "averageLevel",
	"PRIV:PeakValue": "peakLevel",
	"PRIV:PeakLevel": "peakLevel",
	"TXXX:DISCOGS_ARTIST_ID": "discogs_artist_id",
	"TXXX:DISCOGS_ARTISTS": "artists",
	"TXXX:DISCOGS_ARTIST_NAME": "artists",
	"TXXX:DISCOGS_ALBUM_ARTISTS": "albumartists",
	"TXXX:DISCOGS_CATALOG": "catalognumber",
	"TXXX:DISCOGS_COUNTRY": "releasecountry",
	"TXXX:DISCOGS_DATE": "originaldate",
	"TXXX:DISCOGS_LABEL": "label",
	"TXXX:DISCOGS_LABEL_ID": "discogs_label_id",
	"TXXX:DISCOGS_MASTER_RELEASE_ID": "discogs_master_release_id",
	"TXXX:DISCOGS_RATING": "discogs_rating",
	"TXXX:DISCOGS_RELEASED": "date",
	"TXXX:DISCOGS_RELEASE_ID": "discogs_release_id",
	"TXXX:DISCOGS_VOTES": "discogs_votes",
	"TXXX:CATALOGID": "catalognumber",
	"TXXX:STYLE": "genre",
	"TXXX:REPLAYGAIN_TRACK_PEAK": "replaygain_track_peak",
	"TXXX:REPLAYGAIN_TRACK_GAIN": "replaygain_track_gain",
	"TXXX:REPLAYGAIN_ALBUM_PEAK": "replaygain_album_peak",
	"TXXX:REPLAYGAIN_ALBUM_GAIN": "replaygain_album_gain",
	"TXXX:MP3GAIN_MINMAX": "replaygain_track_minmax",
	"TXXX:MP3GAIN_ALBUM_MINMAX": "replaygain_album_minmax",
	"TXXX:MP3GAIN_UNDO": "replaygain_undo",
	MVNM: "movement",
	MVIN: "movementIndex",
	PCST: "podcast",
	TCAT: "category",
	TDES: "description",
	TDRL: "releasedate",
	TGID: "podcastId",
	TKWD: "keywords",
	WFED: "podcasturl",
	GRP1: "grouping",
	PCNT: "playCounter"
};
var ID3v24TagMapper = class ID3v24TagMapper extends CaseInsensitiveTagMap {
	static toRating(popm) {
		return {
			source: popm.email,
			rating: popm.rating > 0 ? (popm.rating - 1) / 254 * CommonTagMapper.maxRatingScore : void 0
		};
	}
	constructor() {
		super(["ID3v2.3", "ID3v2.4"], id3v24TagMap);
	}
	/**
	* Handle post mapping exceptions / correction
	* @param tag to post map
	* @param warnings Wil be used to register (collect) warnings
	*/
	postMap(tag, warnings) {
		switch (tag.id) {
			case "UFID":
				{
					const idTag = tag.value;
					if (idTag.owner_identifier === "http://musicbrainz.org") {
						tag.id += `:${idTag.owner_identifier}`;
						tag.value = decodeString(idTag.identifier, "latin1");
					}
				}
				break;
			case "PRIV":
				{
					const customTag = tag.value;
					switch (customTag.owner_identifier) {
						case "AverageLevel":
						case "PeakValue":
						case "PeakLevel":
							tag.id += `:${customTag.owner_identifier}`;
							tag.value = customTag.data.length === 4 ? UINT32_LE.get(customTag.data, 0) : null;
							if (tag.value === null) warnings.addWarning(`Failed to parse PRIV:${customTag.owner_identifier}`);
							break;
						default: warnings.addWarning(`Unknown PRIV owner-identifier: ${customTag.owner_identifier.slice(0, 128)}`);
					}
				}
				break;
			case "POPM": tag.value = ID3v24TagMapper.toRating(tag.value);
		}
	}
};
// node_modules/music-metadata/lib/matroska/MatroskaTagMapper.js
/**
* EBML Tag map
*/
var ebmlTagMap = {
	"segment:title": "title",
	"album:ARTIST": "albumartist",
	"album:ARTISTSORT": "albumartistsort",
	"album:TITLE": "album",
	"album:DATE_RECORDED": "originaldate",
	"album:DATE_RELEASED": "releasedate",
	"album:PART_NUMBER": "disk",
	"album:TOTAL_PARTS": "totaltracks",
	"track:ARTIST": "artist",
	"track:ARTISTSORT": "artistsort",
	"track:TITLE": "title",
	"track:PART_NUMBER": "track",
	"track:MUSICBRAINZ_TRACKID": "musicbrainz_recordingid",
	"track:MUSICBRAINZ_ALBUMID": "musicbrainz_albumid",
	"track:MUSICBRAINZ_ARTISTID": "musicbrainz_artistid",
	"track:PUBLISHER": "label",
	"track:GENRE": "genre",
	"track:ENCODER": "encodedby",
	"track:ENCODER_OPTIONS": "encodersettings",
	"edition:TOTAL_PARTS": "totaldiscs",
	picture: "picture"
};
var MatroskaTagMapper = class extends CaseInsensitiveTagMap {
	constructor() {
		super(["matroska"], ebmlTagMap);
	}
};
// node_modules/music-metadata/lib/mp4/MP4TagMapper.js
/**
* Ref: https://github.com/sergiomb2/libmp4v2/wiki/iTunesMetadata
*/
var mp4TagMap = {
	"mdta:title": "title",
	"mdta:album": "album",
	"mdta:artist": "artist",
	"mdta:album_artist": "albumartist",
	"mdta:albumartist": "albumartist",
	"mdta:composer": "composer",
	"mdta:date": "date",
	"mdta:comment": "comment",
	"mdta:description": "description",
	"mdta:synopsis": "longDescription",
	"mdta:genre": "genre",
	"mdta:track": "track",
	"mdta:disc": "disk",
	"mdta:publisher": "label",
	"mdta:subtitle": "subtitle",
	"mdta:language": "language",
	"mdta:copyright": "copyright",
	"mdta:encoder": "encodedby",
	"mdta:asin": "asin",
	"mdta:com.apple.quicktime.title": "title",
	"mdta:com.apple.quicktime.album": "album",
	"mdta:com.apple.quicktime.artist": "artist",
	"mdta:com.apple.quicktime.creationdate": "date",
	"mdta:com.apple.quicktime.comment": "comment",
	"mdta:com.apple.quicktime.description": "description",
	"mdta:com.apple.quicktime.genre": "genre",
	"mdta:com.apple.quicktime.copyright": "copyright",
	"©nam": "title",
	"©ART": "artist",
	aART: "albumartist",
	/**
	* ToDo: Album artist seems to be stored here while Picard documentation says: aART
	*/
	"----:com.apple.iTunes:Band": "albumartist",
	"©alb": "album",
	"©day": "date",
	"©cmt": "comment",
	"©com": "comment",
	trkn: "track",
	disk: "disk",
	"©gen": "genre",
	covr: "picture",
	"©wrt": "composer",
	"©lyr": "lyrics",
	soal: "albumsort",
	sonm: "titlesort",
	soar: "artistsort",
	soaa: "albumartistsort",
	soco: "composersort",
	"----:com.apple.iTunes:LYRICIST": "lyricist",
	"----:com.apple.iTunes:CONDUCTOR": "conductor",
	"----:com.apple.iTunes:REMIXER": "remixer",
	"----:com.apple.iTunes:ENGINEER": "engineer",
	"----:com.apple.iTunes:PRODUCER": "producer",
	"----:com.apple.iTunes:DJMIXER": "djmixer",
	"----:com.apple.iTunes:MIXER": "mixer",
	"----:com.apple.iTunes:LABEL": "label",
	"©grp": "grouping",
	"----:com.apple.iTunes:SUBTITLE": "subtitle",
	"----:com.apple.iTunes:DISCSUBTITLE": "discsubtitle",
	cpil: "compilation",
	tmpo: "bpm",
	"----:com.apple.iTunes:MOOD": "mood",
	"----:com.apple.iTunes:MEDIA": "media",
	"----:com.apple.iTunes:CATALOGNUMBER": "catalognumber",
	tvsh: "tvShow",
	tvsn: "tvSeason",
	tves: "tvEpisode",
	sosn: "tvShowSort",
	tven: "tvEpisodeId",
	tvnn: "tvNetwork",
	pcst: "podcast",
	purl: "podcasturl",
	"----:com.apple.iTunes:MusicBrainz Album Status": "releasestatus",
	"----:com.apple.iTunes:MusicBrainz Album Type": "releasetype",
	"----:com.apple.iTunes:MusicBrainz Album Release Country": "releasecountry",
	"----:com.apple.iTunes:SCRIPT": "script",
	"----:com.apple.iTunes:LANGUAGE": "language",
	cprt: "copyright",
	"©cpy": "copyright",
	"----:com.apple.iTunes:LICENSE": "license",
	"©too": "encodedby",
	pgap: "gapless",
	"----:com.apple.iTunes:BARCODE": "barcode",
	"----:com.apple.iTunes:ISRC": "isrc",
	"----:com.apple.iTunes:ASIN": "asin",
	"----:com.apple.iTunes:NOTES": "comment",
	"----:com.apple.iTunes:MusicBrainz Track Id": "musicbrainz_recordingid",
	"----:com.apple.iTunes:MusicBrainz Release Track Id": "musicbrainz_trackid",
	"----:com.apple.iTunes:MusicBrainz Album Id": "musicbrainz_albumid",
	"----:com.apple.iTunes:MusicBrainz Artist Id": "musicbrainz_artistid",
	"----:com.apple.iTunes:MusicBrainz Album Artist Id": "musicbrainz_albumartistid",
	"----:com.apple.iTunes:MusicBrainz Release Group Id": "musicbrainz_releasegroupid",
	"----:com.apple.iTunes:MusicBrainz Work Id": "musicbrainz_workid",
	"----:com.apple.iTunes:MusicBrainz TRM Id": "musicbrainz_trmid",
	"----:com.apple.iTunes:MusicBrainz Disc Id": "musicbrainz_discid",
	"----:com.apple.iTunes:Acoustid Id": "acoustid_id",
	"----:com.apple.iTunes:Acoustid Fingerprint": "acoustid_fingerprint",
	"----:com.apple.iTunes:MusicIP PUID": "musicip_puid",
	"----:com.apple.iTunes:fingerprint": "musicip_fingerprint",
	"----:com.apple.iTunes:replaygain_track_gain": "replaygain_track_gain",
	"----:com.apple.iTunes:replaygain_track_peak": "replaygain_track_peak",
	"----:com.apple.iTunes:replaygain_album_gain": "replaygain_album_gain",
	"----:com.apple.iTunes:replaygain_album_peak": "replaygain_album_peak",
	"----:com.apple.iTunes:replaygain_track_minmax": "replaygain_track_minmax",
	"----:com.apple.iTunes:replaygain_album_minmax": "replaygain_album_minmax",
	"----:com.apple.iTunes:replaygain_undo": "replaygain_undo",
	"----:com.apple.iTunes:Movement Name": "movement",
	"----:com.apple.iTunes:Movement": "movementIndex",
	"----:com.apple.iTunes:Movement Total": "movementTotal",
	gnre: "genre",
	"----:com.apple.iTunes:ALBUMARTISTSORT": "albumartistsort",
	"----:com.apple.iTunes:ARTISTS": "artists",
	"----:com.apple.iTunes:ORIGINALDATE": "originaldate",
	"----:com.apple.iTunes:ORIGINALYEAR": "originalyear",
	"----:com.apple.iTunes:RELEASEDATE": "releasedate",
	desc: "description",
	ldes: "longDescription",
	"©mvn": "movement",
	"©mvi": "movementIndex",
	"©mvc": "movementTotal",
	"©wrk": "work",
	catg: "category",
	egid: "podcastId",
	hdvd: "hdVideo",
	keyw: "keywords",
	shwm: "showMovement",
	stik: "stik",
	rate: "rating"
};
var tagType = "iTunes";
var MP4TagMapper = class extends CaseInsensitiveTagMap {
	constructor() {
		super([tagType], mp4TagMap);
	}
	postMap(tag, _warnings) {
		switch (tag.id) {
			case "rate": tag.value = {
				source: void 0,
				rating: Number.parseFloat(tag.value) / 100
			};
		}
	}
};
// node_modules/music-metadata/lib/ogg/vorbis/VorbisTagMapper.js
/**
* Vorbis tag mappings
*
* Mapping from native header format to one or possibly more 'common' entries
* The common entries aim to read the same information from different media files
* independent of the underlying format
*/
var vorbisTagMap = {
	TITLE: "title",
	ARTIST: "artist",
	ARTISTS: "artists",
	ALBUMARTIST: "albumartist",
	"ALBUM ARTIST": "albumartist",
	ALBUM: "album",
	DATE: "date",
	ORIGINALDATE: "originaldate",
	ORIGINALYEAR: "originalyear",
	RELEASEDATE: "releasedate",
	COMMENT: "comment",
	DESCRIPTION: "comment",
	TRACKNUMBER: "track",
	DISCNUMBER: "disk",
	GENRE: "genre",
	METADATA_BLOCK_PICTURE: "picture",
	COMPOSER: "composer",
	LYRICS: "lyrics",
	UNSYNCEDLYRICS: "lyrics",
	ALBUMSORT: "albumsort",
	TITLESORT: "titlesort",
	WORK: "work",
	ARTISTSORT: "artistsort",
	ALBUMARTISTSORT: "albumartistsort",
	COMPOSERSORT: "composersort",
	LYRICIST: "lyricist",
	WRITER: "writer",
	CONDUCTOR: "conductor",
	REMIXER: "remixer",
	ARRANGER: "arranger",
	ENGINEER: "engineer",
	PRODUCER: "producer",
	DJMIXER: "djmixer",
	MIXER: "mixer",
	LABEL: "label",
	ORGANIZATION: "label",
	PUBLISHER: "label",
	GROUPING: "grouping",
	SUBTITLE: "subtitle",
	DISCSUBTITLE: "discsubtitle",
	TRACKTOTAL: "totaltracks",
	DISCTOTAL: "totaldiscs",
	COMPILATION: "compilation",
	RATING: "rating",
	BPM: "bpm",
	KEY: "key",
	MOOD: "mood",
	MEDIA: "media",
	CATALOGNUMBER: "catalognumber",
	RELEASESTATUS: "releasestatus",
	RELEASETYPE: "releasetype",
	RELEASECOUNTRY: "releasecountry",
	SCRIPT: "script",
	LANGUAGE: "language",
	COPYRIGHT: "copyright",
	LICENSE: "license",
	ENCODEDBY: "encodedby",
	ENCODERSETTINGS: "encodersettings",
	BARCODE: "barcode",
	ISRC: "isrc",
	ASIN: "asin",
	MUSICBRAINZ_TRACKID: "musicbrainz_recordingid",
	MUSICBRAINZ_RELEASETRACKID: "musicbrainz_trackid",
	MUSICBRAINZ_ALBUMID: "musicbrainz_albumid",
	MUSICBRAINZ_ARTISTID: "musicbrainz_artistid",
	MUSICBRAINZ_ALBUMARTISTID: "musicbrainz_albumartistid",
	MUSICBRAINZ_RELEASEGROUPID: "musicbrainz_releasegroupid",
	MUSICBRAINZ_WORKID: "musicbrainz_workid",
	MUSICBRAINZ_TRMID: "musicbrainz_trmid",
	MUSICBRAINZ_DISCID: "musicbrainz_discid",
	ACOUSTID_ID: "acoustid_id",
	ACOUSTID_ID_FINGERPRINT: "acoustid_fingerprint",
	MUSICIP_PUID: "musicip_puid",
	WEBSITE: "website",
	NOTES: "notes",
	TOTALTRACKS: "totaltracks",
	TOTALDISCS: "totaldiscs",
	DISCOGS_ARTIST_ID: "discogs_artist_id",
	DISCOGS_ARTISTS: "artists",
	DISCOGS_ARTIST_NAME: "artists",
	DISCOGS_ALBUM_ARTISTS: "albumartists",
	DISCOGS_CATALOG: "catalognumber",
	DISCOGS_COUNTRY: "releasecountry",
	DISCOGS_DATE: "originaldate",
	DISCOGS_LABEL: "label",
	DISCOGS_LABEL_ID: "discogs_label_id",
	DISCOGS_MASTER_RELEASE_ID: "discogs_master_release_id",
	DISCOGS_RATING: "discogs_rating",
	DISCOGS_RELEASED: "date",
	DISCOGS_RELEASE_ID: "discogs_release_id",
	DISCOGS_VOTES: "discogs_votes",
	CATALOGID: "catalognumber",
	STYLE: "genre",
	REPLAYGAIN_TRACK_GAIN: "replaygain_track_gain",
	REPLAYGAIN_TRACK_PEAK: "replaygain_track_peak",
	REPLAYGAIN_ALBUM_GAIN: "replaygain_album_gain",
	REPLAYGAIN_ALBUM_PEAK: "replaygain_album_peak",
	REPLAYGAIN_MINMAX: "replaygain_track_minmax",
	REPLAYGAIN_ALBUM_MINMAX: "replaygain_album_minmax",
	REPLAYGAIN_UNDO: "replaygain_undo"
};
var VorbisTagMapper = class VorbisTagMapper extends CommonTagMapper {
	hasStandardDate = false;
	static toRating(email, rating, maxScore) {
		return {
			source: email ? email.toLowerCase() : void 0,
			rating: Number.parseFloat(rating) / maxScore * CommonTagMapper.maxRatingScore
		};
	}
	constructor() {
		super(["vorbis"], vorbisTagMap);
	}
	mapGenericTag(tag, warnings) {
		if (tag.id === "DATE") {
			if (typeof tag.value !== "string" || tag.value.trim().length === 0) return null;
			this.hasStandardDate = true;
		} else if (tag.id === "DISCOGS_RELEASED" && this.hasStandardDate) return null;
		return super.mapGenericTag(tag, warnings);
	}
	postMap(tag) {
		if (tag.id === "RATING") tag.value = VorbisTagMapper.toRating(void 0, tag.value, 100);
		else if (tag.id.indexOf("RATING:") === 0) {
			const keys = tag.id.split(":", 2);
			tag.value = VorbisTagMapper.toRating(keys[1], tag.value, 1);
			tag.id = keys[0];
		}
	}
};
// node_modules/music-metadata/lib/riff/RiffInfoTagMap.js
/**
* RIFF Info Tags; part of the EXIF 2.3
* Ref: http://owl.phy.queensu.ca/~phil/exiftool/TagNames/RIFF.html#Info
*/
var riffInfoTagMap = {
	IART: "artist",
	ICRD: "date",
	INAM: "title",
	TITL: "title",
	IPRD: "album",
	ITRK: "track",
	IPRT: "track",
	COMM: "comment",
	ICMT: "comment",
	ICOP: "copyright",
	ICNT: "releasecountry",
	GNRE: "genre",
	IWRI: "writer",
	RATE: "rating",
	YEAR: "year",
	ISFT: "encodedby",
	CODE: "encodedby",
	TURL: "website",
	IGNR: "genre",
	IENG: "engineer",
	ITCH: "technician",
	IMED: "media",
	IRPD: "album"
};
var RiffInfoTagMapper = class extends CommonTagMapper {
	constructor() {
		super(["exif"], riffInfoTagMap);
	}
};
// node_modules/music-metadata/lib/common/CombinedTagMapper.js
var CombinedTagMapper = class {
	tagMappers = {};
	constructor() {
		[
			new ID3v1TagMapper(),
			new ID3v22TagMapper(),
			new ID3v24TagMapper(),
			new MP4TagMapper(),
			new VorbisTagMapper(),
			new APEv2TagMapper(),
			new AsfTagMapper(),
			new RiffInfoTagMapper(),
			new MatroskaTagMapper(),
			new AiffTagMapper(),
			new CafTagMapper()
		].forEach((mapper) => {
			this.registerTagMapper(mapper);
		});
	}
	/**
	* Convert native to generic (common) tags
	* @param tagType Originating tag format
	* @param tag     Native tag to map to a generic tag id
	* @param warnings
	* @return Generic tag result (output of this function)
	*/
	mapTag(tagType, tag, warnings) {
		if (this.tagMappers[tagType]) return this.tagMappers[tagType].mapGenericTag(tag, warnings);
		throw new InternalParserError(`No generic tag mapper defined for tag-format: ${tagType}`);
	}
	registerTagMapper(genericTagMapper) {
		for (const tagType of genericTagMapper.tagTypes) this.tagMappers[tagType] = genericTagMapper;
	}
};
// node_modules/music-metadata/lib/common/GenericTagTypes.js
var defaultTagInfo = { multiple: false };
var commonTags = {
	year: defaultTagInfo,
	track: defaultTagInfo,
	disk: defaultTagInfo,
	title: defaultTagInfo,
	artist: defaultTagInfo,
	artists: {
		multiple: true,
		unique: true
	},
	albumartist: defaultTagInfo,
	albumartists: {
		multiple: true,
		unique: true
	},
	album: defaultTagInfo,
	date: defaultTagInfo,
	originaldate: defaultTagInfo,
	originalyear: defaultTagInfo,
	releasedate: defaultTagInfo,
	comment: {
		multiple: true,
		unique: false
	},
	genre: {
		multiple: true,
		unique: true
	},
	picture: {
		multiple: true,
		unique: true
	},
	composer: {
		multiple: true,
		unique: true
	},
	lyrics: {
		multiple: true,
		unique: false
	},
	albumsort: {
		multiple: false,
		unique: true
	},
	titlesort: {
		multiple: false,
		unique: true
	},
	work: {
		multiple: false,
		unique: true
	},
	artistsort: {
		multiple: false,
		unique: true
	},
	albumartistsort: {
		multiple: false,
		unique: true
	},
	composersort: {
		multiple: false,
		unique: true
	},
	lyricist: {
		multiple: true,
		unique: true
	},
	writer: {
		multiple: true,
		unique: true
	},
	conductor: {
		multiple: true,
		unique: true
	},
	remixer: {
		multiple: true,
		unique: true
	},
	arranger: {
		multiple: true,
		unique: true
	},
	engineer: {
		multiple: true,
		unique: true
	},
	producer: {
		multiple: true,
		unique: true
	},
	technician: {
		multiple: true,
		unique: true
	},
	djmixer: {
		multiple: true,
		unique: true
	},
	mixer: {
		multiple: true,
		unique: true
	},
	label: {
		multiple: true,
		unique: true
	},
	grouping: defaultTagInfo,
	subtitle: { multiple: true },
	discsubtitle: defaultTagInfo,
	totaltracks: defaultTagInfo,
	totaldiscs: defaultTagInfo,
	compilation: defaultTagInfo,
	rating: { multiple: true },
	bpm: defaultTagInfo,
	mood: defaultTagInfo,
	media: defaultTagInfo,
	catalognumber: {
		multiple: true,
		unique: true
	},
	tvShow: defaultTagInfo,
	tvShowSort: defaultTagInfo,
	tvSeason: defaultTagInfo,
	tvEpisode: defaultTagInfo,
	tvEpisodeId: defaultTagInfo,
	tvNetwork: defaultTagInfo,
	podcast: defaultTagInfo,
	podcasturl: defaultTagInfo,
	releasestatus: defaultTagInfo,
	releasetype: { multiple: true },
	releasecountry: defaultTagInfo,
	script: defaultTagInfo,
	language: defaultTagInfo,
	copyright: defaultTagInfo,
	license: defaultTagInfo,
	encodedby: defaultTagInfo,
	encodersettings: defaultTagInfo,
	gapless: defaultTagInfo,
	barcode: defaultTagInfo,
	isrc: { multiple: true },
	asin: defaultTagInfo,
	musicbrainz_recordingid: defaultTagInfo,
	musicbrainz_trackid: defaultTagInfo,
	musicbrainz_albumid: defaultTagInfo,
	musicbrainz_artistid: { multiple: true },
	musicbrainz_albumartistid: { multiple: true },
	musicbrainz_releasegroupid: defaultTagInfo,
	musicbrainz_workid: defaultTagInfo,
	musicbrainz_trmid: defaultTagInfo,
	musicbrainz_discid: defaultTagInfo,
	acoustid_id: defaultTagInfo,
	acoustid_fingerprint: defaultTagInfo,
	musicip_puid: defaultTagInfo,
	musicip_fingerprint: defaultTagInfo,
	website: defaultTagInfo,
	"performer:instrument": {
		multiple: true,
		unique: true
	},
	averageLevel: defaultTagInfo,
	peakLevel: defaultTagInfo,
	notes: {
		multiple: true,
		unique: false
	},
	key: defaultTagInfo,
	originalalbum: defaultTagInfo,
	originalartist: defaultTagInfo,
	discogs_artist_id: {
		multiple: true,
		unique: true
	},
	discogs_release_id: defaultTagInfo,
	discogs_label_id: defaultTagInfo,
	discogs_master_release_id: defaultTagInfo,
	discogs_votes: defaultTagInfo,
	discogs_rating: defaultTagInfo,
	replaygain_track_peak: defaultTagInfo,
	replaygain_track_gain: defaultTagInfo,
	replaygain_album_peak: defaultTagInfo,
	replaygain_album_gain: defaultTagInfo,
	replaygain_track_minmax: defaultTagInfo,
	replaygain_album_minmax: defaultTagInfo,
	replaygain_undo: defaultTagInfo,
	description: { multiple: true },
	longDescription: defaultTagInfo,
	category: { multiple: true },
	hdVideo: defaultTagInfo,
	keywords: { multiple: true },
	movement: defaultTagInfo,
	movementIndex: defaultTagInfo,
	movementTotal: defaultTagInfo,
	podcastId: defaultTagInfo,
	showMovement: defaultTagInfo,
	stik: defaultTagInfo,
	playCounter: defaultTagInfo
};
/**
* @param alias Name of common tag
* @returns {boolean|*} true if given alias is mapped as a singleton', otherwise false
*/
function isSingleton(alias) {
	return commonTags[alias] && !commonTags[alias].multiple;
}
/**
* @param alias Common (generic) tag
* @returns {boolean|*} true if given alias is a singleton or explicitly marked as unique
*/
function isUnique(alias) {
	return !commonTags[alias].multiple || commonTags[alias].unique || false;
}
// node_modules/music-metadata/lib/common/TrackInfo.js
/** Return a bitrate only when it conveys a finite, positive value. */
function normalizeBitrate(bitrate) {
	return bitrate !== void 0 && Number.isFinite(bitrate) && bitrate > 0 ? bitrate : void 0;
}
/** Map the format of a single audio stream to the shared track abstraction. */
function createAudioTrackInfo(format) {
	const audio = {};
	const track = {
		type: TrackType.audio,
		audio
	};
	if (format.codec !== void 0) track.codecName = format.codec;
	if (format.codecProfile !== void 0) track.codecProfile = format.codecProfile;
	if (format.duration !== void 0) track.duration = format.duration;
	const bitrate = normalizeBitrate(format.bitrate);
	if (bitrate !== void 0) track.bitrate = bitrate;
	if (format.lossless !== void 0) track.lossless = format.lossless;
	if (format.sampleRate !== void 0) audio.samplingFrequency = format.sampleRate;
	if (format.numberOfChannels !== void 0) audio.channels = format.numberOfChannels;
	if (format.bitsPerSample !== void 0) audio.bitDepth = format.bitsPerSample;
	if (format.numberOfSamples !== void 0) audio.numberOfSamples = format.numberOfSamples;
	return track;
}
/** Derive whole-file statistics without treating an audio bitrate as a video bitrate. */
function finalizeContainerInfo(metadata, fileSize) {
	const { format } = metadata;
	let duration = format.containerDuration;
	if (duration === void 0) {
		const durations = format.trackInfo.filter((track) => track.type === TrackType.audio || track.type === TrackType.video).map((track) => track.duration);
		if (durations.length > 0 && durations.every((duration) => duration !== void 0 && duration > 0 && Number.isFinite(duration))) duration = durations.reduce((maximum, trackDuration) => Math.max(maximum, trackDuration), 0);
		else if (!format.hasVideo) duration = format.duration;
	}
	if (duration !== void 0 && Number.isFinite(duration) && duration > 0) {
		metadata.setFormat("containerDuration", duration);
		if (format.duration === void 0) metadata.setFormat("duration", duration);
		if (fileSize !== void 0 && Number.isSafeInteger(fileSize) && fileSize > 0) {
			const bitrate = 8 * fileSize / duration;
			if (Number.isFinite(bitrate)) metadata.setFormat("overallBitrate", bitrate);
		}
	}
}
// node_modules/music-metadata/lib/common/MetadataCollector.js
var debug = (0, import_browser.default)("music-metadata:collector");
var TagPriority = [
	"matroska",
	"APEv2",
	"vorbis",
	"ID3v2.4",
	"ID3v2.3",
	"ID3v2.2",
	"exif",
	"asf",
	"iTunes",
	"AIFF",
	"CAF",
	"ID3v1"
];
/**
* Provided to the parser to update the metadata result.
* Responsible for notifying observers synchronously after updates.
*/
var MetadataCollector = class {
	format = {
		tagTypes: [],
		trackInfo: []
	};
	native = {};
	common = {
		track: {
			no: null,
			of: null
		},
		disk: {
			no: null,
			of: null
		},
		movementIndex: {
			no: null,
			of: null
		}
	};
	quality = { warnings: [] };
	/**
	* Keeps track of origin priority for each mapped id
	*/
	commonOrigin = {};
	/**
	* Maps a tag type to a priority
	*/
	originPriority = {};
	tagMapper = new CombinedTagMapper();
	opts;
	constructor(opts) {
		this.opts = opts;
		let priority = 1;
		for (const tagType of TagPriority) this.originPriority[tagType] = priority++;
		this.originPriority.artificial = 500;
		this.originPriority.id3v1 = 600;
	}
	/**
	* @returns {boolean} true if one or more tags have been found
	*/
	hasAny() {
		return Object.keys(this.native).length > 0;
	}
	addStreamInfo(streamInfo) {
		debug(`streamInfo: type=${streamInfo.type ? TrackTypeValueToKeyMap[streamInfo.type] : "?"}, codec=${streamInfo.codecName}`);
		if (normalizeBitrate(streamInfo.bitrate) === void 0) delete streamInfo.bitrate;
		this.format.trackInfo.push(streamInfo);
	}
	setFormat(key, value) {
		if ((value === null || typeof value !== "object") && Object.is(this.format[key], value)) return;
		debug(`format: ${key} = ${value}`);
		this.format[key] = value;
		if (this.opts?.observer) this.opts.observer({
			metadata: this,
			tag: {
				type: "format",
				id: key,
				value
			}
		});
	}
	setAudioOnly() {
		this.setFormat("hasAudio", true);
		this.setFormat("hasVideo", false);
	}
	registerTagType(tagType) {
		if (!this.format.tagTypes.includes(tagType)) this.format.tagTypes.push(tagType);
	}
	async addTag(tagType, tagId, value) {
		debug("tag %s.%s = %o", tagType, tagId, value);
		if (!this.native[tagType]) {
			this.registerTagType(tagType);
			this.native[tagType] = [];
		}
		this.native[tagType].push({
			id: tagId,
			value
		});
		await this.toCommon(tagType, tagId, value);
	}
	addWarning(warning) {
		this.quality.warnings.push({ message: warning });
	}
	async postMap(tagType, tag) {
		switch (tag.id) {
			case "artist": return this.handleSingularArtistTag(tagType, tag, "artist", "artists");
			case "albumartist": return this.handleSingularArtistTag(tagType, tag, "albumartist", "albumartists");
			case "artists": return this.handlePluralArtistTag(tagType, tag, "artist", "artists");
			case "albumartists": return this.handlePluralArtistTag(tagType, tag, "albumartist", "albumartists");
			case "picture": return this.postFixPicture(tag.value).then((picture) => {
				if (picture !== null) {
					tag.value = picture;
					this.setGenericTag(tagType, tag);
				}
			});
			case "totaltracks":
				this.common.track.of = CommonTagMapper.toIntOrNull(tag.value);
				this.notifyCommonTag({
					id: "track",
					value: { ...this.common.track }
				});
				return;
			case "totaldiscs":
				this.common.disk.of = CommonTagMapper.toIntOrNull(tag.value);
				this.notifyCommonTag({
					id: "disk",
					value: { ...this.common.disk }
				});
				return;
			case "movementTotal":
				this.common.movementIndex.of = CommonTagMapper.toIntOrNull(tag.value);
				this.notifyCommonTag({
					id: "movementIndex",
					value: { ...this.common.movementIndex }
				});
				return;
			case "track":
			case "disk":
			case "movementIndex": {
				const of = this.common[tag.id].of;
				this.common[tag.id] = CommonTagMapper.normalizeTrack(tag.value);
				this.common[tag.id].of = of != null ? of : this.common[tag.id].of;
				this.notifyCommonTag({
					id: tag.id,
					value: { ...this.common[tag.id] }
				});
				return;
			}
			case "bpm":
			case "year":
			case "originalyear":
				tag.value = Number.parseInt(tag.value, 10);
				break;
			case "date": {
				const year = Number.parseInt(tag.value.substr(0, 4), 10);
				if (!Number.isNaN(year)) this.common.year = year;
				break;
			}
			case "discogs_label_id":
			case "discogs_release_id":
			case "discogs_master_release_id":
			case "discogs_artist_id":
			case "discogs_votes":
				tag.value = typeof tag.value === "string" ? Number.parseInt(tag.value, 10) : tag.value;
				break;
			case "replaygain_track_gain":
			case "replaygain_track_peak":
			case "replaygain_album_gain":
			case "replaygain_album_peak":
				tag.value = toRatio(tag.value);
				break;
			case "replaygain_track_minmax":
				tag.value = tag.value.split(",", 2).map((v) => Number.parseInt(v, 10));
				break;
			case "replaygain_undo": {
				const minMix = tag.value.split(",", 2).map((v) => Number.parseInt(v, 10));
				tag.value = {
					leftChannel: minMix[0],
					rightChannel: minMix[1]
				};
				break;
			}
			case "gapless":
			case "compilation":
			case "podcast":
			case "showMovement":
				tag.value = tag.value === "1" || tag.value === 1 || tag.value === true;
				break;
			case "isrc": {
				const commonTag = this.common[tag.id];
				if (commonTag && commonTag.indexOf(tag.value) !== -1) return;
				break;
			}
			case "comment":
				if (typeof tag.value === "string") tag.value = { text: tag.value };
				if (tag.value.descriptor === "iTunPGAP") this.setGenericTag(tagType, {
					id: "gapless",
					value: tag.value.text === "1"
				});
				break;
			case "lyrics": if (typeof tag.value === "string") tag.value = parseLyrics(tag.value, getMaxMetadataEntries(this.opts ?? {}));
		}
		if (tag.value !== null) this.setGenericTag(tagType, tag);
	}
	/**
	* Convert native tags to common tags
	* @returns {IAudioMetadata} Native + common tags
	*/
	toCommonMetadata() {
		return {
			format: this.format,
			native: this.native,
			quality: this.quality,
			common: this.common
		};
	}
	/**
	* Handle singular artist tags (artist, albumartist) and cross-populate to plural form
	*/
	handleSingularArtistTag(tagType, tag, singularId, pluralId) {
		if (this.commonOrigin[singularId] === this.originPriority[tagType]) return this.postMap("artificial", {
			id: pluralId,
			value: tag.value
		});
		if (!this.common[pluralId]) this.setGenericTag("artificial", {
			id: pluralId,
			value: tag.value
		});
		this.setGenericTag(tagType, tag);
	}
	/**
	* Handle plural artist tags (artists, albumartists) and cross-populate to singular form
	*/
	handlePluralArtistTag(tagType, tag, singularId, pluralId) {
		if (!this.common[singularId] || this.commonOrigin[singularId] === this.originPriority.artificial) {
			if (!this.common[pluralId] || this.common[pluralId].indexOf(tag.value) === -1) {
				const value = joinArtists((this.common[pluralId] || []).concat([tag.value]));
				this.setGenericTag("artificial", {
					id: singularId,
					value
				});
			}
		}
		this.setGenericTag(tagType, tag);
	}
	/**
	* Fix some common issues with picture object
	* @param picture Picture
	*/
	async postFixPicture(picture) {
		if (picture.data && picture.data.length > 0) {
			if (!picture.format) {
				const fileType = await fileTypeFromBuffer(Uint8Array.from(picture.data), { maxBufferSize: getMaxMemoryAllocation(this.opts ?? {}) });
				if (fileType) picture.format = fileType.mime;
				else return null;
			}
			picture.format = picture.format.toLocaleLowerCase();
			switch (picture.format) {
				case "image/jpg": picture.format = "image/jpeg";
			}
			return picture;
		}
		this.addWarning("Empty picture tag found");
		return null;
	}
	/**
	* Convert native tag to common tags
	*/
	async toCommon(tagType, tagId, value) {
		if ((tagType === "ID3v2.2" && tagId === "IPL" || tagType === "ID3v2.3" && tagId === "IPLS" || tagType === "ID3v2.4" && tagId === "TIPL") && value !== null && typeof value === "object") {
			for (const [role, people] of Object.entries(value)) if (Array.isArray(people)) {
				for (const person of people) if (typeof person === "string" && person.length > 0) await this.toCommon(tagType, `${tagId}:${role}`, person);
			}
			return;
		}
		const tag = {
			id: tagId,
			value
		};
		const genericTag = this.tagMapper.mapTag(tagType, tag, this);
		if (genericTag) {
			if (Array.isArray(genericTag.value)) for (const value of genericTag.value) await this.postMap(tagType, {
				id: genericTag.id,
				value
			});
			else await this.postMap(tagType, genericTag);
		}
	}
	/**
	* Set generic tag
	*/
	setGenericTag(tagType, tag) {
		debug(`common.${tag.id} = ${tag.value}`);
		const prio0 = this.commonOrigin[tag.id] || 1e3;
		const prio1 = this.originPriority[tagType];
		if (isSingleton(tag.id)) {
			if (prio1 <= prio0) {
				this.common[tag.id] = tag.value;
				this.commonOrigin[tag.id] = prio1;
			} else return debug(`Ignore native tag (singleton): ${tagType}.${tag.id} = ${tag.value}`);
		} else if (prio1 === prio0) {
			if (!isUnique(tag.id) || this.common[tag.id].indexOf(tag.value) === -1) this.common[tag.id].push(tag.value);
			else return debug(`Ignore duplicate value: ${tagType}.${tag.id} = ${tag.value}`);
		} else if (prio1 < prio0) {
			this.common[tag.id] = [tag.value];
			this.commonOrigin[tag.id] = prio1;
		} else return debug(`Ignore native tag (list): ${tagType}.${tag.id} = ${tag.value}`);
		this.notifyCommonTag(tag);
	}
	notifyCommonTag(tag) {
		if (this.opts?.observer) this.opts.observer({
			metadata: this,
			tag: {
				type: "common",
				id: tag.id,
				value: tag.value
			}
		});
	}
};
function joinArtists(artists) {
	if (artists.length > 2) return `${artists.slice(0, artists.length - 1).join(", ")} & ${artists[artists.length - 1]}`;
	return artists.join(" & ");
}
export { fileTypeFromBuffer as i, createAudioTrackInfo as n, finalizeContainerInfo as r, MetadataCollector as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWV0YWRhdGFDb2xsZWN0b3ItQklzd1FGTHQuanMiLCJuYW1lcyI6WyJkZWJ1ZyIsImluaXREZWJ1ZyIsInN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvciIsIlRva2VuLlVJTlQ4IiwiVG9rZW4uU3RyaW5nVHlwZSIsIlRva2VuLklOVDMyX0JFIiwiVG9rZW4uU3RyaW5nVHlwZSIsInN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvciIsIlRva2VuLlVJTlQ2NF9MRSIsInN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvciIsInN0cnRvazMuZnJvbVdlYlN0cmVhbSIsInN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvciIsInN0cnRvazMuZnJvbUJ1ZmZlciIsInN0cnRvazMuZnJvbUJsb2IiLCJUb2tlbi5TdHJpbmdUeXBlIiwiVG9rZW4uVUlOVDE2X0JFIiwiVG9rZW4uVUlOVDE2X0xFIiwiVG9rZW4uVUlOVDMyX0JFIiwiVG9rZW4uVUlOVDMyX0xFIiwiaW5pdERlYnVnIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRva2VuaXplci9pbmZsYXRlL2xpYi9HemlwSGFuZGxlci5qcyIsIi4uLy4uL0B0b2tlbml6ZXIvaW5mbGF0ZS9saWIvWmlwTGltaXRFcnJvci5qcyIsIi4uLy4uL0B0b2tlbml6ZXIvaW5mbGF0ZS9saWIvWmlwVG9rZW4uanMiLCIuLi8uLi9AdG9rZW5pemVyL2luZmxhdGUvbGliL1ppcEhhbmRsZXIuanMiLCIuLi8uLi9maWxlLXR5cGUvc291cmNlL3Rva2Vucy5qcyIsIi4uLy4uL2ZpbGUtdHlwZS9zb3VyY2Uvc3VwcG9ydGVkLmpzIiwiLi4vLi4vZmlsZS10eXBlL3NvdXJjZS9wYXJzZXIuanMiLCIuLi8uLi9maWxlLXR5cGUvc291cmNlL2RldGVjdG9ycy96aXAuanMiLCIuLi8uLi9maWxlLXR5cGUvc291cmNlL2RldGVjdG9ycy9lYm1sLmpzIiwiLi4vLi4vZmlsZS10eXBlL3NvdXJjZS9kZXRlY3RvcnMvcG5nLmpzIiwiLi4vLi4vZmlsZS10eXBlL3NvdXJjZS9kZXRlY3RvcnMvYXNmLmpzIiwiLi4vLi4vZmlsZS10eXBlL3NvdXJjZS9pbmRleC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9scmMvTHlyaWNzUGFyc2VyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2NvbW1vbi9HZW5lcmljVGFnTWFwcGVyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2FpZmYvQWlmZlRhZ01hcC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb21tb24vQ2FzZUluc2Vuc2l0aXZlVGFnTWFwLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2FwZXYyL0FQRXYyVGFnTWFwcGVyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2FzZi9Bc2ZUYWdNYXBwZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvY2FmL0NhZlRhZ01hcC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9pZDN2MS9JRDN2MVRhZ01hcC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9pZDN2Mi9JRDN2MjJUYWdNYXBwZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvaWQzdjIvSUQzdjI0VGFnTWFwcGVyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL21hdHJvc2thL01hdHJvc2thVGFnTWFwcGVyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL21wNC9NUDRUYWdNYXBwZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvb2dnL3ZvcmJpcy9Wb3JiaXNUYWdNYXBwZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvcmlmZi9SaWZmSW5mb1RhZ01hcC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb21tb24vQ29tYmluZWRUYWdNYXBwZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvY29tbW9uL0dlbmVyaWNUYWdUeXBlcy5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb21tb24vVHJhY2tJbmZvLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2NvbW1vbi9NZXRhZGF0YUNvbGxlY3Rvci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgR3ppcEhhbmRsZXIge1xuICAgIGNvbnN0cnVjdG9yKHRva2VuaXplcikge1xuICAgICAgICB0aGlzLnRva2VuaXplciA9IHRva2VuaXplcjtcbiAgICB9XG4gICAgaW5mbGF0ZSgpIHtcbiAgICAgICAgY29uc3QgdG9rZW5pemVyID0gdGhpcy50b2tlbml6ZXI7XG4gICAgICAgIHJldHVybiBuZXcgUmVhZGFibGVTdHJlYW0oe1xuICAgICAgICAgICAgYXN5bmMgcHVsbChjb250cm9sbGVyKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoMTAyNCk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2l6ZSA9IGF3YWl0IHRva2VuaXplci5yZWFkQnVmZmVyKGJ1ZmZlciwgeyBtYXlCZUxlc3M6IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgaWYgKHNpemUgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlci5jbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShidWZmZXIuc3ViYXJyYXkoMCwgc2l6ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KS5waXBlVGhyb3VnaChuZXcgRGVjb21wcmVzc2lvblN0cmVhbSgnZ3ppcCcpKTtcbiAgICB9XG59XG4iLCIvKiogQSBjb25maWd1cmVkIFpJUCBwcm9jZXNzaW5nIGxpbWl0IHdhcyBleGNlZWRlZC4gKi9cbmV4cG9ydCBjbGFzcyBaaXBMaW1pdEVycm9yIGV4dGVuZHMgUmFuZ2VFcnJvciB7XG4gICAgY29uc3RydWN0b3IobGltaXQsIHJlcXVlc3RlZFNpemUsIG1heFNpemUpIHtcbiAgICAgICAgc3VwZXIoYFpJUCAke2xpbWl0fSBleGNlZWRlZDogJHtyZXF1ZXN0ZWRTaXplfSBleGNlZWRzIGxpbWl0IG9mICR7bWF4U2l6ZX1gKTtcbiAgICAgICAgdGhpcy5saW1pdCA9IGxpbWl0O1xuICAgICAgICB0aGlzLnJlcXVlc3RlZFNpemUgPSByZXF1ZXN0ZWRTaXplO1xuICAgICAgICB0aGlzLm1heFNpemUgPSBtYXhTaXplO1xuICAgICAgICB0aGlzLm5hbWUgPSAnWmlwTGltaXRFcnJvcic7XG4gICAgfVxufVxuIiwiLyoqXG4gKiBSZWYgaHR0cHM6Ly9wa3dhcmUuY2FjaGVmbHkubmV0L3dlYmRvY3MvY2FzZXN0dWRpZXMvQVBQTk9URS5UWFRcbiAqL1xuaW1wb3J0IHsgVUlOVDE2X0xFLCBVSU5UMzJfTEUgfSBmcm9tICd0b2tlbi10eXBlcyc7XG5leHBvcnQgY29uc3QgU2lnbmF0dXJlID0ge1xuICAgIExvY2FsRmlsZUhlYWRlcjogMHgwNDAzNGI1MCxcbiAgICBEYXRhRGVzY3JpcHRvcjogMHgwODA3NGI1MCxcbiAgICBDZW50cmFsRmlsZUhlYWRlcjogMHgwMjAxNGI1MCxcbiAgICBFbmRPZkNlbnRyYWxEaXJlY3Rvcnk6IDB4MDYwNTRiNTBcbn07XG5leHBvcnQgY29uc3QgRGF0YURlc2NyaXB0b3IgPSB7XG4gICAgZ2V0KGFycmF5KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzaWduYXR1cmU6IFVJTlQzMl9MRS5nZXQoYXJyYXksIDApLFxuICAgICAgICAgICAgY29tcHJlc3NlZFNpemU6IFVJTlQzMl9MRS5nZXQoYXJyYXksIDgpLFxuICAgICAgICAgICAgdW5jb21wcmVzc2VkU2l6ZTogVUlOVDMyX0xFLmdldChhcnJheSwgMTIpXG4gICAgICAgIH07XG4gICAgfSxcbiAgICBsZW46IDE2XG59O1xuLyoqXG4gKiBGaXJzdCBwYXJ0IG9mIHRoZSBaSVAgTG9jYWwgRmlsZSBIZWFkZXJcbiAqIE9mZnNldCB8IEJ5dGVzfCBEZXNjcmlwdGlvblxuICogLS0tLS0tLXwtLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogICAgICAwIHwgICAgNCB8IFNpZ25hdHVyZSAoMHgwNDAzNGI1MClcbiAqICAgICAgNCB8ICAgIDIgfCBNaW5pbXVtIHZlcnNpb24gbmVlZGVkIHRvIGV4dHJhY3RcbiAqICAgICAgNiB8ICAgIDIgfCBCaXQgZmxhZ1xuICogICAgICA4IHwgICAgMiB8IENvbXByZXNzaW9uIG1ldGhvZFxuICogICAgIDEwIHwgICAgMiB8IEZpbGUgbGFzdCBtb2RpZmljYXRpb24gdGltZSAoTVMtRE9TIGZvcm1hdClcbiAqICAgICAxMiB8ICAgIDIgfCBGaWxlIGxhc3QgbW9kaWZpY2F0aW9uIGRhdGUgKE1TLURPUyBmb3JtYXQpXG4gKiAgICAgMTQgfCAgICA0IHwgQ1JDLTMyIG9mIHVuY29tcHJlc3NlZCBkYXRhXG4gKiAgICAgMTggfCAgICA0IHwgQ29tcHJlc3NlZCBzaXplXG4gKiAgICAgMjIgfCAgICA0IHwgVW5jb21wcmVzc2VkIHNpemVcbiAqICAgICAyNiB8ICAgIDIgfCBGaWxlIG5hbWUgbGVuZ3RoIChuKVxuICogICAgIDI4IHwgICAgMiB8IEV4dHJhIGZpZWxkIGxlbmd0aCAobSlcbiAqICAgICAzMCB8ICAgIG4gfCBGaWxlIG5hbWVcbiAqIDMwICsgbiB8ICAgIG0gfCBFeHRyYSBmaWVsZFxuICovXG5leHBvcnQgY29uc3QgTG9jYWxGaWxlSGVhZGVyVG9rZW4gPSB7XG4gICAgZ2V0KGFycmF5KSB7XG4gICAgICAgIGNvbnN0IGZsYWdzID0gVUlOVDE2X0xFLmdldChhcnJheSwgNik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzaWduYXR1cmU6IFVJTlQzMl9MRS5nZXQoYXJyYXksIDApLFxuICAgICAgICAgICAgbWluVmVyc2lvbjogVUlOVDE2X0xFLmdldChhcnJheSwgNCksXG4gICAgICAgICAgICBkYXRhRGVzY3JpcHRvcjogISEoZmxhZ3MgJiAweDAwMDgpLFxuICAgICAgICAgICAgY29tcHJlc3NlZE1ldGhvZDogVUlOVDE2X0xFLmdldChhcnJheSwgOCksXG4gICAgICAgICAgICBjb21wcmVzc2VkU2l6ZTogVUlOVDMyX0xFLmdldChhcnJheSwgMTgpLFxuICAgICAgICAgICAgdW5jb21wcmVzc2VkU2l6ZTogVUlOVDMyX0xFLmdldChhcnJheSwgMjIpLFxuICAgICAgICAgICAgZmlsZW5hbWVMZW5ndGg6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDI2KSxcbiAgICAgICAgICAgIGV4dHJhRmllbGRMZW5ndGg6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDI4KSxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBudWxsXG4gICAgICAgIH07XG4gICAgfSxcbiAgICBsZW46IDMwXG59O1xuLyoqXG4gKiA0LjMuMTYgIEVuZCBvZiBjZW50cmFsIGRpcmVjdG9yeSByZWNvcmQ6XG4gKiAgZW5kIG9mIGNlbnRyYWwgZGlyIHNpZ25hdHVyZSAoMHgwNjA2NGI1MCkgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDQgYnl0ZXNcbiAqICBudW1iZXIgb2YgdGhpcyBkaXNrICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMiBieXRlc1xuICogIG51bWJlciBvZiB0aGUgZGlzayB3aXRoIHRoZSBzdGFydCBvZiB0aGUgY2VudHJhbCBkaXJlY3RvcnkgICAgICAgICAgICAgICAgICAgICAyIGJ5dGVzXG4gKiAgdG90YWwgbnVtYmVyIG9mIGVudHJpZXMgaW4gdGhlIGNlbnRyYWwgZGlyZWN0b3J5IG9uIHRoaXMgZGlzayAgICAgICAgICAgICAgICAgIDIgYnl0ZXNcbiAqICB0b3RhbCBudW1iZXIgb2YgZW50cmllcyBpbiB0aGUgc2l6ZSBvZiB0aGUgY2VudHJhbCBkaXJlY3RvcnkgICAgICAgICAgICAgICAgICAgMiBieXRlc1xuICogIHNpemVPZlRoZUNlbnRyYWxEaXJlY3RvcnkgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA0IGJ5dGVzXG4gKiAgb2Zmc2V0IG9mIHN0YXJ0IG9mIGNlbnRyYWwgZGlyZWN0b3J5IHdpdGggcmVzcGVjdCB0byB0aGUgc3RhcnRpbmcgZGlzayBudW1iZXIgIDQgYnl0ZXNcbiAqICAuWklQIGZpbGUgY29tbWVudCBsZW5ndGggICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMiBieXRlc1xuICogIC5aSVAgZmlsZSBjb21tZW50ICAgICAgICh2YXJpYWJsZSBzaXplKVxuICovXG5leHBvcnQgY29uc3QgRW5kT2ZDZW50cmFsRGlyZWN0b3J5UmVjb3JkVG9rZW4gPSB7XG4gICAgZ2V0KGFycmF5KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzaWduYXR1cmU6IFVJTlQzMl9MRS5nZXQoYXJyYXksIDApLFxuICAgICAgICAgICAgbnJPZlRoaXNEaXNrOiBVSU5UMTZfTEUuZ2V0KGFycmF5LCA0KSxcbiAgICAgICAgICAgIG5yT2ZUaGlzRGlza1dpdGhUaGVTdGFydDogVUlOVDE2X0xFLmdldChhcnJheSwgNiksXG4gICAgICAgICAgICBuck9mRW50cmllc09uVGhpc0Rpc2s6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDgpLFxuICAgICAgICAgICAgbnJPZkVudHJpZXNPZlNpemU6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDEwKSxcbiAgICAgICAgICAgIHNpemVPZkNkOiBVSU5UMzJfTEUuZ2V0KGFycmF5LCAxMiksXG4gICAgICAgICAgICBvZmZzZXRPZlN0YXJ0T2ZDZDogVUlOVDMyX0xFLmdldChhcnJheSwgMTYpLFxuICAgICAgICAgICAgemlwRmlsZUNvbW1lbnRMZW5ndGg6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDIwKVxuICAgICAgICB9O1xuICAgIH0sXG4gICAgbGVuOiAyMlxufTtcbi8qKlxuICogRmlsZSBoZWFkZXI6XG4gKiAgICBjZW50cmFsIGZpbGUgaGVhZGVyIHNpZ25hdHVyZSAgIDQgYnl0ZXMgICAwICgweDAyMDE0YjUwKVxuICogICAgdmVyc2lvbiBtYWRlIGJ5ICAgICAgICAgICAgICAgICAyIGJ5dGVzICAgNFxuICogICAgdmVyc2lvbiBuZWVkZWQgdG8gZXh0cmFjdCAgICAgICAyIGJ5dGVzICAgNlxuICogICAgZ2VuZXJhbCBwdXJwb3NlIGJpdCBmbGFnICAgICAgICAyIGJ5dGVzICAgOFxuICogICAgY29tcHJlc3Npb24gbWV0aG9kICAgICAgICAgICAgICAyIGJ5dGVzICAxMFxuICogICAgbGFzdCBtb2QgZmlsZSB0aW1lICAgICAgICAgICAgICAyIGJ5dGVzICAxMlxuICogICAgbGFzdCBtb2QgZmlsZSBkYXRlICAgICAgICAgICAgICAyIGJ5dGVzICAxNFxuICogICAgY3JjLTMyICAgICAgICAgICAgICAgICAgICAgICAgICA0IGJ5dGVzICAxNlxuICogICAgY29tcHJlc3NlZCBzaXplICAgICAgICAgICAgICAgICA0IGJ5dGVzICAyMFxuICogICAgdW5jb21wcmVzc2VkIHNpemUgICAgICAgICAgICAgICA0IGJ5dGVzICAyNFxuICogICAgZmlsZSBuYW1lIGxlbmd0aCAgICAgICAgICAgICAgICAyIGJ5dGVzICAyOFxuICogICAgZXh0cmEgZmllbGQgbGVuZ3RoICAgICAgICAgICAgICAyIGJ5dGVzICAzMFxuICogICAgZmlsZSBjb21tZW50IGxlbmd0aCAgICAgICAgICAgICAyIGJ5dGVzICAzMlxuICogICAgZGlzayBudW1iZXIgc3RhcnQgICAgICAgICAgICAgICAyIGJ5dGVzICAzNFxuICogICAgaW50ZXJuYWwgZmlsZSBhdHRyaWJ1dGVzICAgICAgICAyIGJ5dGVzICAzNlxuICogICAgZXh0ZXJuYWwgZmlsZSBhdHRyaWJ1dGVzICAgICAgICA0IGJ5dGVzICAzOFxuICogICAgcmVsYXRpdmUgb2Zmc2V0IG9mIGxvY2FsIGhlYWRlciA0IGJ5dGVzICA0MlxuICovXG5leHBvcnQgY29uc3QgRmlsZUhlYWRlciA9IHtcbiAgICBnZXQoYXJyYXkpIHtcbiAgICAgICAgY29uc3QgZmxhZ3MgPSBVSU5UMTZfTEUuZ2V0KGFycmF5LCA4KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNpZ25hdHVyZTogVUlOVDMyX0xFLmdldChhcnJheSwgMCksXG4gICAgICAgICAgICBtaW5WZXJzaW9uOiBVSU5UMTZfTEUuZ2V0KGFycmF5LCA2KSxcbiAgICAgICAgICAgIGRhdGFEZXNjcmlwdG9yOiAhIShmbGFncyAmIDB4MDAwOCksXG4gICAgICAgICAgICBjb21wcmVzc2VkTWV0aG9kOiBVSU5UMTZfTEUuZ2V0KGFycmF5LCAxMCksXG4gICAgICAgICAgICBjb21wcmVzc2VkU2l6ZTogVUlOVDMyX0xFLmdldChhcnJheSwgMjApLFxuICAgICAgICAgICAgdW5jb21wcmVzc2VkU2l6ZTogVUlOVDMyX0xFLmdldChhcnJheSwgMjQpLFxuICAgICAgICAgICAgZmlsZW5hbWVMZW5ndGg6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDI4KSxcbiAgICAgICAgICAgIGV4dHJhRmllbGRMZW5ndGg6IFVJTlQxNl9MRS5nZXQoYXJyYXksIDMwKSxcbiAgICAgICAgICAgIGZpbGVDb21tZW50TGVuZ3RoOiBVSU5UMTZfTEUuZ2V0KGFycmF5LCAzMiksXG4gICAgICAgICAgICByZWxhdGl2ZU9mZnNldE9mTG9jYWxIZWFkZXI6IFVJTlQzMl9MRS5nZXQoYXJyYXksIDQyKSxcbiAgICAgICAgICAgIGZpbGVuYW1lOiBudWxsXG4gICAgICAgIH07XG4gICAgfSxcbiAgICBsZW46IDQ2XG59O1xuIiwiaW1wb3J0IGluaXREZWJ1ZyBmcm9tICdkZWJ1Zyc7XG5pbXBvcnQgeyBjcmVhdGVUb2tlbml6ZXJWaWV3IH0gZnJvbSAnc3RydG9rMy9jb3JlJztcbmltcG9ydCB7IFN0cmluZ1R5cGUsIFVJTlQzMl9MRSB9IGZyb20gJ3Rva2VuLXR5cGVzJztcbmltcG9ydCB7IFppcExpbWl0RXJyb3IgfSBmcm9tICcuL1ppcExpbWl0RXJyb3IuanMnO1xuaW1wb3J0IHsgRGF0YURlc2NyaXB0b3IsIEVuZE9mQ2VudHJhbERpcmVjdG9yeVJlY29yZFRva2VuLCBGaWxlSGVhZGVyLCBMb2NhbEZpbGVIZWFkZXJUb2tlbiwgU2lnbmF0dXJlIH0gZnJvbSAnLi9aaXBUb2tlbi5qcyc7XG5mdW5jdGlvbiBzaWduYXR1cmVUb0FycmF5KHNpZ25hdHVyZSkge1xuICAgIGNvbnN0IHNpZ25hdHVyZUJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoVUlOVDMyX0xFLmxlbik7XG4gICAgVUlOVDMyX0xFLnB1dChzaWduYXR1cmVCeXRlcywgMCwgc2lnbmF0dXJlKTtcbiAgICByZXR1cm4gc2lnbmF0dXJlQnl0ZXM7XG59XG5jb25zdCBkZWJ1ZyA9IGluaXREZWJ1ZygndG9rZW5pemVyOmluZmxhdGUnKTtcbmNvbnN0IHN5bmNCdWZmZXJTaXplID0gMjU2ICogMTAyNDtcbmNvbnN0IGVvY2RTaWduYXR1cmVCeXRlcyA9IHNpZ25hdHVyZVRvQXJyYXkoU2lnbmF0dXJlLkVuZE9mQ2VudHJhbERpcmVjdG9yeSk7XG5leHBvcnQgY2xhc3MgWmlwSGFuZGxlciB7XG4gICAgY29uc3RydWN0b3IodG9rZW5pemVyLCBvcHRpb25zID0ge30pIHtcbiAgICAgICAgdGhpcy50b2tlbml6ZXIgPSB0b2tlbml6ZXI7XG4gICAgICAgIHRoaXMuc3luY0J1ZmZlciA9IG5ldyBVaW50OEFycmF5KHN5bmNCdWZmZXJTaXplKTtcbiAgICAgICAgdGhpcy5zY2FubmVkQnl0ZXMgPSAwO1xuICAgICAgICB0aGlzLmRlc2NyaXB0b3JTY2FubmVkQnl0ZXMgPSAwO1xuICAgICAgICB0aGlzLmxpbWl0cyA9IHtcbiAgICAgICAgICAgIG1heEVudHJ5Q291bnQ6IG9wdGlvbnMubWF4RW50cnlDb3VudCA/PyBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG4gICAgICAgICAgICBtYXhUb3RhbFNjYW5CeXRlczogb3B0aW9ucy5tYXhUb3RhbFNjYW5CeXRlcyA/PyBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG4gICAgICAgICAgICBtYXhUb3RhbERhdGFEZXNjcmlwdG9yU2NhbkJ5dGVzOiBvcHRpb25zLm1heFRvdGFsRGF0YURlc2NyaXB0b3JTY2FuQnl0ZXMgPz8gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZLFxuICAgICAgICAgICAgbWF4U2tpcHBlZEVudHJ5U2l6ZTogb3B0aW9ucy5tYXhTa2lwcGVkRW50cnlTaXplID8/IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICAgICAgICAgIG1heERhdGFEZXNjcmlwdG9yU2NhbkJ5dGVzOiBvcHRpb25zLm1heERhdGFEZXNjcmlwdG9yU2NhbkJ5dGVzID8/IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICAgICAgICAgIG1heENvbXByZXNzZWRTaXplOiBvcHRpb25zLm1heENvbXByZXNzZWRTaXplID8/IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICAgICAgICAgIG1heFVuY29tcHJlc3NlZFNpemU6IG9wdGlvbnMubWF4VW5jb21wcmVzc2VkU2l6ZSA/PyBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFlcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy51c2VDZW50cmFsRGlyZWN0b3J5ID0gb3B0aW9ucy51c2VDZW50cmFsRGlyZWN0b3J5ID8/IHRydWU7XG4gICAgICAgIHRoaXMuYWxsb3dUcnVuY2F0ZWREYXRhRGVzY3JpcHRvciA9IG9wdGlvbnMuYWxsb3dUcnVuY2F0ZWREYXRhRGVzY3JpcHRvciA/PyBmYWxzZTtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnVzZUNlbnRyYWxEaXJlY3RvcnkgIT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigndXNlQ2VudHJhbERpcmVjdG9yeSBtdXN0IGJlIGEgYm9vbGVhbicpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hbGxvd1RydW5jYXRlZERhdGFEZXNjcmlwdG9yICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2FsbG93VHJ1bmNhdGVkRGF0YURlc2NyaXB0b3IgbXVzdCBiZSBhIGJvb2xlYW4nKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IFtuYW1lLCBsaW1pdF0gb2YgT2JqZWN0LmVudHJpZXModGhpcy5saW1pdHMpKSB7XG4gICAgICAgICAgICBpZiAobGltaXQgIT09IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSAmJiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKGxpbWl0KSB8fCBsaW1pdCA8PSAwKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGAke25hbWV9IG11c3QgYmUgYSBwb3NpdGl2ZSBzYWZlIGludGVnZXIgb3IgSW5maW5pdHlgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAvKiogUmVqZWN0IG92ZXJzaXplZCBlbnRyaWVzIGJlZm9yZSByZXRhaW5pbmcgZGF0YSBvciBhbGxvY2F0aW5nIGEgY29tYmluZWQgYnVmZmVyLiAqL1xuICAgIGNoZWNrTGltaXQobGltaXQsIHNpemUpIHtcbiAgICAgICAgaWYgKHNpemUgPiB0aGlzLmxpbWl0c1tsaW1pdF0pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBaaXBMaW1pdEVycm9yKGxpbWl0LCBzaXplLCB0aGlzLmxpbWl0c1tsaW1pdF0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJlc2V0VHJhdmVyc2FsKCkge1xuICAgICAgICB0aGlzLnNjYW5uZWRCeXRlcyA9IDA7XG4gICAgICAgIHRoaXMuZGVzY3JpcHRvclNjYW5uZWRCeXRlcyA9IDA7XG4gICAgfVxuICAgIGNvbnN1bWVCeXRlcyhsZW5ndGgpIHtcbiAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhUb3RhbFNjYW5CeXRlcycsIHRoaXMuc2Nhbm5lZEJ5dGVzICsgbGVuZ3RoKTtcbiAgICAgICAgdGhpcy5zY2FubmVkQnl0ZXMgKz0gbGVuZ3RoO1xuICAgIH1cbiAgICByZWFkVG9rZW4odG9rZW4sIGlucHV0ID0gdGhpcy50b2tlbml6ZXIpIHtcbiAgICAgICAgdGhpcy5jb25zdW1lQnl0ZXModG9rZW4ubGVuKTtcbiAgICAgICAgcmV0dXJuIGlucHV0LnJlYWRUb2tlbih0b2tlbik7XG4gICAgfVxuICAgIGlnbm9yZShsZW5ndGgsIGlucHV0ID0gdGhpcy50b2tlbml6ZXIpIHtcbiAgICAgICAgdGhpcy5jb25zdW1lQnl0ZXMobGVuZ3RoKTtcbiAgICAgICAgcmV0dXJuIGlucHV0Lmlnbm9yZShsZW5ndGgpO1xuICAgIH1cbiAgICByZWFkRGF0YShsZW5ndGgpIHtcbiAgICAgICAgdGhpcy5jb25zdW1lQnl0ZXMobGVuZ3RoKTtcbiAgICAgICAgY29uc3QgZGF0YSA9IG5ldyBVaW50OEFycmF5KGxlbmd0aCk7XG4gICAgICAgIHJldHVybiB0aGlzLnRva2VuaXplci5yZWFkQnVmZmVyKGRhdGEpLnRoZW4oKCkgPT4gZGF0YSk7XG4gICAgfVxuICAgIGNoZWNrRW50cnlTaXplKGhlYWRlcikge1xuICAgICAgICB0aGlzLmNoZWNrTGltaXQoJ21heENvbXByZXNzZWRTaXplJywgaGVhZGVyLmNvbXByZXNzZWRTaXplKTtcbiAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhVbmNvbXByZXNzZWRTaXplJywgaGVhZGVyLnVuY29tcHJlc3NlZFNpemUpO1xuICAgICAgICBpZiAoaGVhZGVyLmNvbXByZXNzZWRNZXRob2QgPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tMaW1pdCgnbWF4VW5jb21wcmVzc2VkU2l6ZScsIGhlYWRlci5jb21wcmVzc2VkU2l6ZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgaXNaaXAoKSB7XG4gICAgICAgIHJldHVybiAoYXdhaXQgdGhpcy5wZWVrU2lnbmF0dXJlKCkpID09PSBTaWduYXR1cmUuTG9jYWxGaWxlSGVhZGVyO1xuICAgIH1cbiAgICBwZWVrU2lnbmF0dXJlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy50b2tlbml6ZXIucGVla1Rva2VuKFVJTlQzMl9MRSk7XG4gICAgfVxuICAgIGFzeW5jIGZpbmRFbmRPZkNlbnRyYWxEaXJlY3RvcnlMb2NhdG9yKCkge1xuICAgICAgICBjb25zdCByYW5kb21SZWFkVG9rZW5pemVyID0gdGhpcy50b2tlbml6ZXI7XG4gICAgICAgIGNvbnN0IGNodW5rTGVuZ3RoID0gTWF0aC5taW4oMTYgKiAxMDI0LCByYW5kb21SZWFkVG9rZW5pemVyLmZpbGVJbmZvLnNpemUpO1xuICAgICAgICBjb25zdCBidWZmZXIgPSB0aGlzLnN5bmNCdWZmZXIuc3ViYXJyYXkoMCwgY2h1bmtMZW5ndGgpO1xuICAgICAgICB0aGlzLmNvbnN1bWVCeXRlcyhjaHVua0xlbmd0aCk7XG4gICAgICAgIGF3YWl0IHRoaXMudG9rZW5pemVyLnJlYWRCdWZmZXIoYnVmZmVyLCB7IHBvc2l0aW9uOiByYW5kb21SZWFkVG9rZW5pemVyLmZpbGVJbmZvLnNpemUgLSBjaHVua0xlbmd0aCB9KTtcbiAgICAgICAgLy8gU2VhcmNoIHRoZSBidWZmZXIgZnJvbSBlbmQgdG8gYmVnaW5uaW5nIGZvciBFT0NEIHNpZ25hdHVyZVxuICAgICAgICAvLyBjb25zdCBzaWduYXR1cmUgPSAweDA2MDU0YjUwO1xuICAgICAgICBmb3IgKGxldCBpID0gYnVmZmVyLmxlbmd0aCAtIDQ7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICAvLyBDb21wYXJlIDQgYnl0ZXMgZGlyZWN0bHkgd2l0aG91dCBjYWxsaW5nIHJlYWRVSW50MzJMRVxuICAgICAgICAgICAgaWYgKGJ1ZmZlcltpXSA9PT0gZW9jZFNpZ25hdHVyZUJ5dGVzWzBdICYmXG4gICAgICAgICAgICAgICAgYnVmZmVyW2kgKyAxXSA9PT0gZW9jZFNpZ25hdHVyZUJ5dGVzWzFdICYmXG4gICAgICAgICAgICAgICAgYnVmZmVyW2kgKyAyXSA9PT0gZW9jZFNpZ25hdHVyZUJ5dGVzWzJdICYmXG4gICAgICAgICAgICAgICAgYnVmZmVyW2kgKyAzXSA9PT0gZW9jZFNpZ25hdHVyZUJ5dGVzWzNdKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJhbmRvbVJlYWRUb2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAtIGNodW5rTGVuZ3RoICsgaTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gLTE7XG4gICAgfVxuICAgIGFzeW5jIHJlYWRDZW50cmFsRGlyZWN0b3J5KCkge1xuICAgICAgICB0aGlzLnJlc2V0VHJhdmVyc2FsKCk7XG4gICAgICAgIGNvbnN0IGVudHJpZXMgPSBhd2FpdCB0aGlzLmNlbnRyYWxEaXJlY3RvcnlFbnRyaWVzKCk7XG4gICAgICAgIGlmICghZW50cmllcykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpbGVzID0gW107XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICAgICAgZmlsZXMucHVzaChlbnRyeSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZpbGVzO1xuICAgIH1cbiAgICBhc3luYyBjZW50cmFsRGlyZWN0b3J5RW50cmllcygpIHtcbiAgICAgICAgaWYgKCF0aGlzLnRva2VuaXplci5zdXBwb3J0c1JhbmRvbUFjY2VzcygpKSB7XG4gICAgICAgICAgICBkZWJ1ZygnQ2Fubm90IHJlYWRpbmcgY2VudHJhbC1kaXJlY3Rvcnkgd2l0aG91dCByYW5kb20tcmVhZCBzdXBwb3J0Jyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZGVidWcoJ1JlYWRpbmcgY2VudHJhbC1kaXJlY3RvcnkuLi4nKTtcbiAgICAgICAgY29uc3QgcG9zID0gdGhpcy50b2tlbml6ZXIucG9zaXRpb247XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBvZmZzZXQgPSBhd2FpdCB0aGlzLmZpbmRFbmRPZkNlbnRyYWxEaXJlY3RvcnlMb2NhdG9yKCk7XG4gICAgICAgICAgICBpZiAob2Zmc2V0ID4gMCkge1xuICAgICAgICAgICAgICAgIGRlYnVnKCdDZW50cmFsLWRpcmVjdG9yeSAzMi1iaXQgc2lnbmF0dXJlIGZvdW5kJyk7XG4gICAgICAgICAgICAgICAgdGhpcy50b2tlbml6ZXIuc2V0UG9zaXRpb24ob2Zmc2V0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBlb2NkSGVhZGVyID0gYXdhaXQgdGhpcy5yZWFkVG9rZW4oRW5kT2ZDZW50cmFsRGlyZWN0b3J5UmVjb3JkVG9rZW4pO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLml0ZXJhdGVEaXJlY3RvcnkoZW9jZEhlYWRlci5vZmZzZXRPZlN0YXJ0T2ZDZCwgZW9jZEhlYWRlci5zaXplT2ZDZCwgZW9jZEhlYWRlci5uck9mRW50cmllc09mU2l6ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICB0aGlzLnRva2VuaXplci5zZXRQb3NpdGlvbihwb3MpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jICppdGVyYXRlRGlyZWN0b3J5KG9mZnNldCwgc2l6ZSwgY291bnQpIHtcbiAgICAgICAgY29uc3Qgc291cmNlID0gdGhpcy50b2tlbml6ZXI7XG4gICAgICAgIGNvbnN0IHBvcyA9IHNvdXJjZS5wb3NpdGlvbjtcbiAgICAgICAgbGV0IGRpcmVjdG9yeTtcbiAgICAgICAgbGV0IHBvc2l0aW9uID0gMDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHNvdXJjZS5zZXRQb3NpdGlvbihvZmZzZXQpO1xuICAgICAgICAgICAgZGlyZWN0b3J5ID0gY3JlYXRlVG9rZW5pemVyVmlldyhzb3VyY2UsIHNpemUpO1xuICAgICAgICAgICAgZm9yIChsZXQgbiA9IDA7IG4gPCBjb3VudDsgKytuKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhFbnRyeUNvdW50JywgbiArIDEpO1xuICAgICAgICAgICAgICAgIC8vIEV4dHJhY3Rpb24gYmV0d2VlbiB5aWVsZHMgY2FuIG1vdmUgdGhlIHNvdXJjZSB0byBhIGxvY2FsIGhlYWRlci5cbiAgICAgICAgICAgICAgICBkaXJlY3Rvcnkuc2V0UG9zaXRpb24ocG9zaXRpb24pO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVudHJ5ID0gYXdhaXQgdGhpcy5yZWFkVG9rZW4oRmlsZUhlYWRlciwgZGlyZWN0b3J5KTtcbiAgICAgICAgICAgICAgICBpZiAoZW50cnkuc2lnbmF0dXJlICE9PSBTaWduYXR1cmUuQ2VudHJhbEZpbGVIZWFkZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeHBlY3RlZCBDZW50cmFsLUZpbGUtSGVhZGVyIHNpZ25hdHVyZScpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbnRyeS5maWxlbmFtZSA9IGF3YWl0IHRoaXMucmVhZFRva2VuKG5ldyBTdHJpbmdUeXBlKGVudHJ5LmZpbGVuYW1lTGVuZ3RoLCAndXRmLTgnKSwgZGlyZWN0b3J5KTtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmlnbm9yZShlbnRyeS5leHRyYUZpZWxkTGVuZ3RoLCBkaXJlY3RvcnkpO1xuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuaWdub3JlKGVudHJ5LmZpbGVDb21tZW50TGVuZ3RoLCBkaXJlY3RvcnkpO1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uID0gZGlyZWN0b3J5LnBvc2l0aW9uO1xuICAgICAgICAgICAgICAgIHlpZWxkIGVudHJ5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBkaXJlY3Rvcnk/LmNsb3NlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBzb3VyY2Uuc2V0UG9zaXRpb24ocG9zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyB1bnppcChmaWxlQ2IpIHtcbiAgICAgICAgdGhpcy5yZXNldFRyYXZlcnNhbCgpO1xuICAgICAgICBjb25zdCBlbnRyaWVzID0gdGhpcy51c2VDZW50cmFsRGlyZWN0b3J5ID8gYXdhaXQgdGhpcy5jZW50cmFsRGlyZWN0b3J5RW50cmllcygpIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAoZW50cmllcykge1xuICAgICAgICAgICAgLy8gVXNlIENlbnRyYWwgRGlyZWN0b3J5IHRvIGl0ZXJhdGUgb3ZlciBmaWxlc1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaXRlcmF0ZU92ZXJDZW50cmFsRGlyZWN0b3J5KGVudHJpZXMsIGZpbGVDYik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gU2NhbiBaaXAgZmlsZXMgZm9yIGxvY2FsLWZpbGUtaGVhZGVyXG4gICAgICAgIGxldCBzdG9wID0gZmFsc2U7XG4gICAgICAgIGxldCBlbnRyeUNvdW50ID0gMDtcbiAgICAgICAgZG8ge1xuICAgICAgICAgICAgY29uc3QgemlwSGVhZGVyID0gYXdhaXQgdGhpcy5yZWFkTG9jYWxGaWxlSGVhZGVyKCk7XG4gICAgICAgICAgICBpZiAoIXppcEhlYWRlcikge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhFbnRyeUNvdW50JywgKytlbnRyeUNvdW50KTtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBmaWxlQ2IoemlwSGVhZGVyKTtcbiAgICAgICAgICAgIHN0b3AgPSAhIW5leHQuc3RvcDtcbiAgICAgICAgICAgIGxldCBmaWxlRGF0YTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuaWdub3JlKHppcEhlYWRlci5leHRyYUZpZWxkTGVuZ3RoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmhhbmRsZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRW50cnlTaXplKHppcEhlYWRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrTGltaXQoJ21heFNraXBwZWRFbnRyeVNpemUnLCB6aXBIZWFkZXIuY29tcHJlc3NlZFNpemUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHppcEhlYWRlci5kYXRhRGVzY3JpcHRvciAmJiB6aXBIZWFkZXIuY29tcHJlc3NlZFNpemUgPT09IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjaHVua3MgPSBbXTtcbiAgICAgICAgICAgICAgICBsZXQgdG90YWxTaXplID0gMDtcbiAgICAgICAgICAgICAgICBjb25zdCBzY2FuTGltaXQgPSBNYXRoLm1pbih0aGlzLmxpbWl0cy5tYXhEYXRhRGVzY3JpcHRvclNjYW5CeXRlcywgdGhpcy5saW1pdHMubWF4VG90YWxEYXRhRGVzY3JpcHRvclNjYW5CeXRlcyAtIHRoaXMuZGVzY3JpcHRvclNjYW5uZWRCeXRlcywgdGhpcy5saW1pdHMubWF4VG90YWxTY2FuQnl0ZXMgLSB0aGlzLnNjYW5uZWRCeXRlcywgbmV4dC5oYW5kbGVyID8gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZIDogdGhpcy5saW1pdHMubWF4U2tpcHBlZEVudHJ5U2l6ZSwgbmV4dC5oYW5kbGVyID8gdGhpcy5saW1pdHMubWF4Q29tcHJlc3NlZFNpemUgOiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksIG5leHQuaGFuZGxlciAmJiB6aXBIZWFkZXIuY29tcHJlc3NlZE1ldGhvZCA9PT0gMCA/IHRoaXMubGltaXRzLm1heFVuY29tcHJlc3NlZFNpemUgOiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFkpO1xuICAgICAgICAgICAgICAgIGRlYnVnKCdDb21wcmVzc2VkLWZpbGUtc2l6ZSB1bmtub3duLCBzY2FubmluZyBmb3IgbmV4dCBkYXRhLWRlc2NyaXB0b3Itc2lnbmF0dXJlLi4uLicpO1xuICAgICAgICAgICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFJldGFpbiBhIGZ1bGwgZGVzY3JpcHRvciBvdmVybGFwIHNvIGl0cyBjb21wcmVzc2VkLXNpemUgZmllbGQgY2FuIGJlIHZhbGlkYXRlZC5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGVla0xlbmd0aCA9IE1hdGgubWluKHN5bmNCdWZmZXJTaXplLCBzY2FuTGltaXQgLSB0b3RhbFNpemUgKyBEYXRhRGVzY3JpcHRvci5sZW4pO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBsZW4gPSBhd2FpdCB0aGlzLnRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuc3luY0J1ZmZlci5zdWJhcnJheSgwLCBwZWVrTGVuZ3RoKSwgeyBtYXlCZUxlc3M6IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGFsbG93VHJ1bmNhdGVkID0gdGhpcy5hbGxvd1RydW5jYXRlZERhdGFEZXNjcmlwdG9yICYmIGxlbiA8IHBlZWtMZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHRIZWFkZXJJbmRleCA9IGZpbmREZXNjcmlwdG9yKHRoaXMuc3luY0J1ZmZlci5zdWJhcnJheSgwLCBsZW4pLCB0b3RhbFNpemUsIGFsbG93VHJ1bmNhdGVkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5leHRIZWFkZXJJbmRleCA8IDAgJiYgbGVuIDwgRGF0YURlc2NyaXB0b3IubGVuICYmICFhbGxvd1RydW5jYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeHBlY3RlZCBkYXRhLWRlc2NyaXB0b3Itc2lnbmF0dXJlIGJlZm9yZSBlbmQgb2YgaW5wdXQnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBzaXplID0gbmV4dEhlYWRlckluZGV4ID49IDAgPyBuZXh0SGVhZGVySW5kZXggOiBhbGxvd1RydW5jYXRlZCA/IGxlbiA6IGxlbiAtIERhdGFEZXNjcmlwdG9yLmxlbiArIDE7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzaXplID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrTGltaXQoJ21heERhdGFEZXNjcmlwdG9yU2NhbkJ5dGVzJywgdG90YWxTaXplICsgc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tMaW1pdCgnbWF4VG90YWxEYXRhRGVzY3JpcHRvclNjYW5CeXRlcycsIHRoaXMuZGVzY3JpcHRvclNjYW5uZWRCeXRlcyArIHNpemUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIW5leHQuaGFuZGxlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhTa2lwcGVkRW50cnlTaXplJywgdG90YWxTaXplICsgc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKG5leHQuaGFuZGxlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhDb21wcmVzc2VkU2l6ZScsIHRvdGFsU2l6ZSArIHNpemUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHppcEhlYWRlci5jb21wcmVzc2VkTWV0aG9kID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhVbmNvbXByZXNzZWRTaXplJywgdG90YWxTaXplICsgc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2l6ZSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5yZWFkRGF0YShzaXplKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaHVua3MucHVzaChkYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuaWdub3JlKHNpemUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRvdGFsU2l6ZSArPSBzaXplO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRlc2NyaXB0b3JTY2FubmVkQnl0ZXMgKz0gc2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5leHRIZWFkZXJJbmRleCA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkZWJ1ZyhgRm91bmQgZGF0YS1kZXNjcmlwdG9yLXNpZ25hdHVyZSBhdCBwb3M9JHt0aGlzLnRva2VuaXplci5wb3NpdGlvbn1gKTtcbiAgICAgICAgICAgICAgICBpZiAobmV4dC5oYW5kbGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tMaW1pdCgnbWF4Q29tcHJlc3NlZFNpemUnLCB0b3RhbFNpemUpO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmluZmxhdGUoemlwSGVhZGVyLCBtZXJnZUFycmF5cyhjaHVua3MpLCBuZXh0LmhhbmRsZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChuZXh0LmhhbmRsZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVidWcoYFJlYWRpbmcgY29tcHJlc3NlZC1maWxlLWRhdGE6ICR7emlwSGVhZGVyLmNvbXByZXNzZWRTaXplfSBieXRlc2ApO1xuICAgICAgICAgICAgICAgICAgICBmaWxlRGF0YSA9IGF3YWl0IHRoaXMucmVhZERhdGEoemlwSGVhZGVyLmNvbXByZXNzZWRTaXplKTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5pbmZsYXRlKHppcEhlYWRlciwgZmlsZURhdGEsIG5leHQuaGFuZGxlcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkZWJ1ZyhgSWdub3JpbmcgY29tcHJlc3NlZC1maWxlLWRhdGE6ICR7emlwSGVhZGVyLmNvbXByZXNzZWRTaXplfSBieXRlc2ApO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmlnbm9yZSh6aXBIZWFkZXIuY29tcHJlc3NlZFNpemUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlYnVnKGBSZWFkaW5nIGRhdGEtZGVzY3JpcHRvciBhdCBwb3M9JHt0aGlzLnRva2VuaXplci5wb3NpdGlvbn1gKTtcbiAgICAgICAgICAgIGlmICh6aXBIZWFkZXIuZGF0YURlc2NyaXB0b3IpIHtcbiAgICAgICAgICAgICAgICAvLyBhd2FpdCB0aGlzLnRva2VuaXplci5pZ25vcmUoRGF0YURlc2NyaXB0b3IubGVuKTtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhRGVzY3JpcHRvciA9IGF3YWl0IHRoaXMucmVhZFRva2VuKERhdGFEZXNjcmlwdG9yKTtcbiAgICAgICAgICAgICAgICBpZiAoZGF0YURlc2NyaXB0b3Iuc2lnbmF0dXJlICE9PSAweDA4MDc0YjUwKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgZGF0YS1kZXNjcmlwdG9yLXNpZ25hdHVyZSBhdCBwb3NpdGlvbiAke3RoaXMudG9rZW5pemVyLnBvc2l0aW9uIC0gRGF0YURlc2NyaXB0b3IubGVufWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSB3aGlsZSAoIXN0b3ApO1xuICAgIH1cbiAgICBhc3luYyBpdGVyYXRlT3ZlckNlbnRyYWxEaXJlY3RvcnkoZW50cmllcywgZmlsZUNiKSB7XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgZmlsZUhlYWRlciBvZiBlbnRyaWVzKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gZmlsZUNiKGZpbGVIZWFkZXIpO1xuICAgICAgICAgICAgaWYgKG5leHQuaGFuZGxlcikge1xuICAgICAgICAgICAgICAgIHRoaXMudG9rZW5pemVyLnNldFBvc2l0aW9uKGZpbGVIZWFkZXIucmVsYXRpdmVPZmZzZXRPZkxvY2FsSGVhZGVyKTtcbiAgICAgICAgICAgICAgICBjb25zdCB6aXBIZWFkZXIgPSBhd2FpdCB0aGlzLnJlYWRMb2NhbEZpbGVIZWFkZXIoKTtcbiAgICAgICAgICAgICAgICBpZiAoemlwSGVhZGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuaWdub3JlKHppcEhlYWRlci5leHRyYUZpZWxkTGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0VudHJ5U2l6ZShmaWxlSGVhZGVyKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0VudHJ5U2l6ZSh6aXBIZWFkZXIpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlRGF0YSA9IGF3YWl0IHRoaXMucmVhZERhdGEoZmlsZUhlYWRlci5jb21wcmVzc2VkU2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuaW5mbGF0ZSh6aXBIZWFkZXIsIGZpbGVEYXRhLCBuZXh0LmhhbmRsZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChuZXh0LnN0b3ApIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBpbmZsYXRlKHppcEhlYWRlciwgZmlsZURhdGEsIGNiKSB7XG4gICAgICAgIGlmICh6aXBIZWFkZXIuY29tcHJlc3NlZE1ldGhvZCA9PT0gMCkge1xuICAgICAgICAgICAgLy8gU3RvcmVkICh1bmNvbXByZXNzZWQpXG4gICAgICAgICAgICB0aGlzLmNoZWNrTGltaXQoJ21heFVuY29tcHJlc3NlZFNpemUnLCBmaWxlRGF0YS5sZW5ndGgpO1xuICAgICAgICAgICAgcmV0dXJuIGNiKGZpbGVEYXRhKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoemlwSGVhZGVyLmNvbXByZXNzZWRNZXRob2QgIT09IDgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgWklQIGNvbXByZXNzaW9uIG1ldGhvZDogJHt6aXBIZWFkZXIuY29tcHJlc3NlZE1ldGhvZH1gKTtcbiAgICAgICAgfVxuICAgICAgICBkZWJ1ZyhgRGVjb21wcmVzcyBmaWxlbmFtZT0ke3ppcEhlYWRlci5maWxlbmFtZX0sIGNvbXByZXNzZWQtc2l6ZT0ke2ZpbGVEYXRhLmxlbmd0aH1gKTtcbiAgICAgICAgY29uc3QgdW5jb21wcmVzc2VkRGF0YSA9IGF3YWl0IHRoaXMuZGVjb21wcmVzc0RlZmxhdGVSYXcoZmlsZURhdGEpO1xuICAgICAgICByZXR1cm4gY2IodW5jb21wcmVzc2VkRGF0YSk7XG4gICAgfVxuICAgIGFzeW5jIGRlY29tcHJlc3NEZWZsYXRlUmF3KGRhdGEpIHtcbiAgICAgICAgLy8gV3JhcCBVaW50OEFycmF5IGluIGEgUmVhZGFibGVTdHJlYW0gd2l0aG91dCBjb3B5aW5nXG4gICAgICAgIGNvbnN0IGlucHV0ID0gbmV3IFJlYWRhYmxlU3RyZWFtKHtcbiAgICAgICAgICAgIHN0YXJ0KGNvbnRyb2xsZXIpIHtcbiAgICAgICAgICAgICAgICBjb250cm9sbGVyLmVucXVldWUoZGF0YSk7XG4gICAgICAgICAgICAgICAgY29udHJvbGxlci5jbG9zZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgZHMgPSBuZXcgRGVjb21wcmVzc2lvblN0cmVhbSgnZGVmbGF0ZS1yYXcnKTtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gaW5wdXQucGlwZVRocm91Z2goZHMpO1xuICAgICAgICBjb25zdCByZWFkZXIgPSBvdXRwdXQuZ2V0UmVhZGVyKCk7XG4gICAgICAgIGNvbnN0IGNodW5rcyA9IFtdO1xuICAgICAgICBsZXQgdG90YWxTaXplID0gMDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgICAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0xpbWl0KCdtYXhVbmNvbXByZXNzZWRTaXplJywgdG90YWxTaXplICsgdmFsdWUubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICB0b3RhbFNpemUgKz0gdmFsdWUubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGNodW5rcy5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuY2hlY2tMaW1pdCgnbWF4VW5jb21wcmVzc2VkU2l6ZScsIHRvdGFsU2l6ZSk7XG4gICAgICAgICAgICByZXR1cm4gbWVyZ2VBcnJheXMoY2h1bmtzKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAvLyBDYW5jZWxsYXRpb24gcHJvcGFnYXRlcyB0aHJvdWdoIHBpcGVUaHJvdWdoIHRvIHN0b3AgZGVjb21wcmVzc2lvbi5cbiAgICAgICAgICAgIGF3YWl0IHJlYWRlci5jYW5jZWwoZXJyKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gUHJlc2VydmUgdGhlIG9yaWdpbmFsIGZhaWx1cmUgaWYgY2FuY2VsbGF0aW9uIGFsc28gZmFpbHMuXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBaaXBMaW1pdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gRGVzY3JpcHRvciBzY2FubmluZyBjYW4gcmV0YWluIGJ5dGVzIGFmdGVyIHRoZSBkZWZsYXRlIHN0cmVhbSwgaW5jbHVkaW5nXG4gICAgICAgICAgICAvLyB1bnNpZ25lZCBaSVAgZGF0YSBkZXNjcmlwdG9ycy4gTm9kZS5qcyByZWplY3RzIHRoZXNlIGFmdGVyIGRlbGl2ZXJpbmcgdGhlXG4gICAgICAgICAgICAvLyBpbmZsYXRlZCBkYXRhLiBSZWNvdmVyIG9ubHkgdGhpcyBlcnJvcjsgZXZlcnkgcmV0YWluZWQgY2h1bmsgd2FzIGJvdW5kZWQuXG4gICAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IgJiYgJ2NvZGUnIGluIGVyciAmJiBlcnIuY29kZSA9PT0gJ0VSUl9UUkFJTElOR19KVU5LX0FGVEVSX1NUUkVBTV9FTkQnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lcmdlQXJyYXlzKGNodW5rcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBQcm92aWRlIFpJUC1zcGVjaWZpYyBlcnJvciBjb250ZXh0XG4gICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICA/IGBGYWlsZWQgdG8gZGVmbGF0ZSBaSVAgZW50cnk6ICR7ZXJyLm1lc3NhZ2V9YFxuICAgICAgICAgICAgICAgIDogJ1Vua25vd24gZGVjb21wcmVzc2lvbiBlcnJvciBpbiBaSVAgZW50cnknO1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihtZXNzYWdlKTtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHJlYWRlci5yZWxlYXNlTG9jaygpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIHJlYWRMb2NhbEZpbGVIZWFkZXIoKSB7XG4gICAgICAgIGNvbnN0IHNpZ25hdHVyZSA9IGF3YWl0IHRoaXMudG9rZW5pemVyLnBlZWtUb2tlbihVSU5UMzJfTEUpO1xuICAgICAgICBpZiAoc2lnbmF0dXJlID09PSBTaWduYXR1cmUuTG9jYWxGaWxlSGVhZGVyKSB7XG4gICAgICAgICAgICBjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLnJlYWRUb2tlbihMb2NhbEZpbGVIZWFkZXJUb2tlbik7XG4gICAgICAgICAgICBoZWFkZXIuZmlsZW5hbWUgPSBhd2FpdCB0aGlzLnJlYWRUb2tlbihuZXcgU3RyaW5nVHlwZShoZWFkZXIuZmlsZW5hbWVMZW5ndGgsICd1dGYtOCcpKTtcbiAgICAgICAgICAgIHJldHVybiBoZWFkZXI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNpZ25hdHVyZSA9PT0gU2lnbmF0dXJlLkNlbnRyYWxGaWxlSGVhZGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNpZ25hdHVyZSA9PT0gMHhlMDExY2ZkMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFbmNyeXB0ZWQgWklQJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmV4cGVjdGVkIHNpZ25hdHVyZScpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZpbmREZXNjcmlwdG9yKGJ1ZmZlciwgY29uc3VtZWQsIGFsbG93VHJ1bmNhdGVkKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gYnVmZmVyLmxlbmd0aCAtIChhbGxvd1RydW5jYXRlZCA/IDQgOiBEYXRhRGVzY3JpcHRvci5sZW4pOyBpKyspIHtcbiAgICAgICAgaWYgKFVJTlQzMl9MRS5nZXQoYnVmZmVyLCBpKSA9PT0gU2lnbmF0dXJlLkRhdGFEZXNjcmlwdG9yICYmXG4gICAgICAgICAgICAoYnVmZmVyLmxlbmd0aCAtIGkgPCAxMiB8fCBVSU5UMzJfTEUuZ2V0KGJ1ZmZlciwgaSArIDgpID09PSBjb25zdW1lZCArIGkpKSB7XG4gICAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gLTE7XG59XG5mdW5jdGlvbiBtZXJnZUFycmF5cyhjaHVua3MpIHtcbiAgICAvLyBDb25jYXRlbmF0ZSBjaHVua3MgaW50byBhIHNpbmdsZSBVaW50OEFycmF5XG4gICAgY29uc3QgdG90YWxMZW5ndGggPSBjaHVua3MucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIGN1cnIubGVuZ3RoLCAwKTtcbiAgICBjb25zdCBtZXJnZWRBcnJheSA9IG5ldyBVaW50OEFycmF5KHRvdGFsTGVuZ3RoKTtcbiAgICBsZXQgb2Zmc2V0ID0gMDtcbiAgICBmb3IgKGNvbnN0IGNodW5rIG9mIGNodW5rcykge1xuICAgICAgICBtZXJnZWRBcnJheS5zZXQoY2h1bmssIG9mZnNldCk7XG4gICAgICAgIG9mZnNldCArPSBjaHVuay5sZW5ndGg7XG4gICAgfVxuICAgIHJldHVybiBtZXJnZWRBcnJheTtcbn1cbiIsImltcG9ydCB7U3RyaW5nVHlwZX0gZnJvbSAndG9rZW4tdHlwZXMnO1xuXG5leHBvcnQgZnVuY3Rpb24gc3RyaW5nVG9CeXRlcyhzdHJpbmcsIGVuY29kaW5nKSB7XG5cdGlmIChlbmNvZGluZyA9PT0gJ3V0Zi0xNmxlJykge1xuXHRcdGNvbnN0IGJ5dGVzID0gW107XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHN0cmluZy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IGNvZGUgPSBzdHJpbmcuY2hhckNvZGVBdChpbmRleCk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgdW5pY29ybi9wcmVmZXItY29kZS1wb2ludFxuXHRcdFx0Ynl0ZXMucHVzaChjb2RlICYgMHhGRiwgKGNvZGUgPj4gOCkgJiAweEZGKTsgLy8gSGlnaCBieXRlXG5cdFx0fVxuXG5cdFx0cmV0dXJuIGJ5dGVzO1xuXHR9XG5cblx0aWYgKGVuY29kaW5nID09PSAndXRmLTE2YmUnKSB7XG5cdFx0Y29uc3QgYnl0ZXMgPSBbXTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgc3RyaW5nLmxlbmd0aDsgaW5kZXgrKykge1xuXHRcdFx0Y29uc3QgY29kZSA9IHN0cmluZy5jaGFyQ29kZUF0KGluZGV4KTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSB1bmljb3JuL3ByZWZlci1jb2RlLXBvaW50XG5cdFx0XHRieXRlcy5wdXNoKChjb2RlID4+IDgpICYgMHhGRiwgY29kZSAmIDB4RkYpOyAvLyBMb3cgYnl0ZVxuXHRcdH1cblxuXHRcdHJldHVybiBieXRlcztcblx0fVxuXG5cdHJldHVybiBbLi4uc3RyaW5nXS5tYXAoY2hhcmFjdGVyID0+IGNoYXJhY3Rlci5jaGFyQ29kZUF0KDApKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSB1bmljb3JuL3ByZWZlci1jb2RlLXBvaW50XG59XG5cbi8qKlxuQ2hlY2tzIHdoZXRoZXIgdGhlIFRBUiBjaGVja3N1bSBpcyB2YWxpZC5cblxuQHBhcmFtIHtVaW50OEFycmF5fSBhcnJheUJ1ZmZlciAtIFRoZSBUQVIgaGVhZGVyIGBbb2Zmc2V0IC4uLiBvZmZzZXQgKyA1MTJdYC5cbkBwYXJhbSB7bnVtYmVyfSBvZmZzZXQgLSBQb3NpdGlvbiBvZiB0aGUgVEFSIGhlYWRlciBpbiBgYXJyYXlCdWZmZXJgLlxuQHJldHVybnMge2Jvb2xlYW59IGB0cnVlYCBpZiB0aGUgVEFSIGNoZWNrc3VtIGlzIHZhbGlkLCBvdGhlcndpc2UgYGZhbHNlYC5cbiovXG5leHBvcnQgZnVuY3Rpb24gdGFySGVhZGVyQ2hlY2tzdW1NYXRjaGVzKGFycmF5QnVmZmVyLCBvZmZzZXQgPSAwKSB7XG5cdGNvbnN0IHJlYWRTdW0gPSBOdW1iZXIucGFyc2VJbnQobmV3IFN0cmluZ1R5cGUoNikuZ2V0KGFycmF5QnVmZmVyLCAxNDgpLCA4KTsgLy8gUmVhZCBzdW0gaW4gaGVhZGVyXG5cdGlmIChOdW1iZXIuaXNOYU4ocmVhZFN1bSkpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRsZXQgc3VtID0gOCAqIDB4MjA7IC8vIEluaXRpYWxpemUgc2lnbmVkIGJpdCBzdW1cblxuXHRmb3IgKGxldCBpbmRleCA9IG9mZnNldDsgaW5kZXggPCBvZmZzZXQgKyAxNDg7IGluZGV4KyspIHtcblx0XHRzdW0gKz0gYXJyYXlCdWZmZXJbaW5kZXhdO1xuXHR9XG5cblx0Zm9yIChsZXQgaW5kZXggPSBvZmZzZXQgKyAxNTY7IGluZGV4IDwgb2Zmc2V0ICsgNTEyOyBpbmRleCsrKSB7XG5cdFx0c3VtICs9IGFycmF5QnVmZmVyW2luZGV4XTtcblx0fVxuXG5cdHJldHVybiByZWFkU3VtID09PSBzdW07XG59XG5cbi8qKlxuSUQzIFVJTlQzMiBzeW5jLXNhZmUgdG9rZW5pemVyIHRva2VuLlxuMjggYml0cyAocmVwcmVzZW50aW5nIHVwIHRvIDI1Nk1CKSBpbnRlZ2VyLCB0aGUgbXNiIGlzIDAgdG8gYXZvaWQgXCJmYWxzZSBzeW5jc2lnbmFsc1wiLlxuKi9cbmV4cG9ydCBjb25zdCB1aW50MzJTeW5jU2FmZVRva2VuID0ge1xuXHRnZXQ6IChidWZmZXIsIG9mZnNldCkgPT4gKGJ1ZmZlcltvZmZzZXQgKyAzXSAmIDB4N0YpIHwgKChidWZmZXJbb2Zmc2V0ICsgMl0gJiAweDdGKSA8PCA3KSB8ICgoYnVmZmVyW29mZnNldCArIDFdICYgMHg3RikgPDwgMTQpIHwgKChidWZmZXJbb2Zmc2V0XSAmIDB4N0YpIDw8IDIxKSxcblx0bGVuOiA0LFxufTtcbiIsIi8vIE1JTUUgbWVkaWEgc3VidHlwZXMgcHJlZml4ZWQgd2l0aCBgeC1mdC1gIGFyZSBjdXN0b20gYW5kIGRlZmluZWQgYnkgdXMuIFRoZXkgYXJlIG5laXRoZXIgZm9ybWFsbHkgcmVnaXN0ZXJlZCB3aXRoIElBTkEgbm9yIGJhc2VkIG9uIGFueSBpbmZvcm1hbCBjb252ZW50aW9ucy5cblxuZXhwb3J0IGNvbnN0IGV4dGVuc2lvbnMgPSBbXG5cdCdqcGcnLFxuXHQncG5nJyxcblx0J2FwbmcnLFxuXHQnZ2lmJyxcblx0J3dlYnAnLFxuXHQnZmxpZicsXG5cdCd4Y2YnLFxuXHQnY3IyJyxcblx0J2NyMycsXG5cdCdvcmYnLFxuXHQnYXJ3Jyxcblx0J2RuZycsXG5cdCduZWYnLFxuXHQncncyJyxcblx0J3JhZicsXG5cdCd0aWYnLFxuXHQnYm1wJyxcblx0J2ljbnMnLFxuXHQnanhyJyxcblx0J3BzZCcsXG5cdCdpbmRkJyxcblx0J3ppcCcsXG5cdCd0YXInLFxuXHQncmFyJyxcblx0J2d6Jyxcblx0J2J6MicsXG5cdCc3eicsXG5cdCdkbWcnLFxuXHQnbXA0Jyxcblx0J21pZCcsXG5cdCdta3YnLFxuXHQnd2VibScsXG5cdCdtb3YnLFxuXHQnYXZpJyxcblx0J21wZycsXG5cdCdtcDInLFxuXHQnbXAzJyxcblx0J200YScsXG5cdCdvZ2EnLFxuXHQnb2dnJyxcblx0J29ndicsXG5cdCdvcHVzJyxcblx0J2ZsYWMnLFxuXHQnd2F2Jyxcblx0J3NweCcsXG5cdCdhbXInLFxuXHQncGRmJyxcblx0J2VwdWInLFxuXHQnZWxmJyxcblx0J21hY2hvJyxcblx0J2V4ZScsXG5cdCdzd2YnLFxuXHQncnRmJyxcblx0J3dhc20nLFxuXHQnd29mZicsXG5cdCd3b2ZmMicsXG5cdCdlb3QnLFxuXHQndHRmJyxcblx0J290ZicsXG5cdCd0dGMnLFxuXHQnaWNvJyxcblx0J2ZsdicsXG5cdCdwcycsXG5cdCd4eicsXG5cdCdzcWxpdGUnLFxuXHQnbmVzJyxcblx0J2NyeCcsXG5cdCd4cGknLFxuXHQnY2FiJyxcblx0J2RlYicsXG5cdCdhcicsXG5cdCdycG0nLFxuXHQnWicsXG5cdCdseicsXG5cdCdjZmInLFxuXHQnbXhmJyxcblx0J210cycsXG5cdCdibGVuZCcsXG5cdCdicGcnLFxuXHQnZG9jeCcsXG5cdCdwcHR4Jyxcblx0J3hsc3gnLFxuXHQnM2dwJyxcblx0JzNnMicsXG5cdCdqMmMnLFxuXHQnanAyJyxcblx0J2pwbScsXG5cdCdqcHgnLFxuXHQnbWoyJyxcblx0J2FpZicsXG5cdCdjYWYnLFxuXHQncWNwJyxcblx0J29kdCcsXG5cdCdvZHMnLFxuXHQnb2RwJyxcblx0J3htbCcsXG5cdCdtb2JpJyxcblx0J2hlaWMnLFxuXHQnY3VyJyxcblx0J2t0eCcsXG5cdCdhcGUnLFxuXHQnd3YnLFxuXHQnZGNtJyxcblx0J2ljcycsXG5cdCdnbGInLFxuXHQncGNhcCcsXG5cdCdkc2YnLFxuXHQnZGZmJyxcblx0J2xuaycsXG5cdCdhbGlhcycsXG5cdCd2b2MnLFxuXHQnYWMzJyxcblx0J200dicsXG5cdCdtNHAnLFxuXHQnbTRiJyxcblx0J2Y0dicsXG5cdCdmNHAnLFxuXHQnZjRiJyxcblx0J2Y0YScsXG5cdCdtaWUnLFxuXHQnYXNmJyxcblx0J29nbScsXG5cdCdvZ3gnLFxuXHQnbXBjJyxcblx0J2Fycm93Jyxcblx0J3NocCcsXG5cdCdhYWMnLFxuXHQnbXAxJyxcblx0J2l0Jyxcblx0J3MzbScsXG5cdCd4bScsXG5cdCdza3AnLFxuXHQnYXZpZicsXG5cdCdlcHMnLFxuXHQnbHpoJyxcblx0J3BncCcsXG5cdCdhc2FyJyxcblx0J3N0bCcsXG5cdCdjaG0nLFxuXHQnM21mJyxcblx0J3pzdCcsXG5cdCdqeGwnLFxuXHQndmNmJyxcblx0J2pscycsXG5cdCdwc3QnLFxuXHQnZHdnJyxcblx0J3BhcnF1ZXQnLFxuXHQnY2xhc3MnLFxuXHQnYXJqJyxcblx0J2NwaW8nLFxuXHQnYWNlJyxcblx0J2F2cm8nLFxuXHQnaWNjJyxcblx0J2ZieCcsXG5cdCd2c2R4Jyxcblx0J3Z0dCcsXG5cdCdhcGsnLFxuXHQnZHJjJyxcblx0J2x6NCcsXG5cdCdwb3R4Jyxcblx0J3hsdHgnLFxuXHQnZG90eCcsXG5cdCd4bHRtJyxcblx0J290dCcsXG5cdCdvdHMnLFxuXHQnb3RwJyxcblx0J29kZycsXG5cdCdvdGcnLFxuXHQneGxzbScsXG5cdCdkb2NtJyxcblx0J2RvdG0nLFxuXHQncG90bScsXG5cdCdwcHRtJyxcblx0J2phcicsXG5cdCdqbXAnLFxuXHQncm0nLFxuXHQnc2F2Jyxcblx0J3Bwc20nLFxuXHQncHBzeCcsXG5cdCd0YXIuZ3onLFxuXHQncmVnJyxcblx0J2RhdCcsXG5cdCdrZXknLFxuXHQnbnVtYmVycycsXG5cdCdwYWdlcycsXG5cdCdpc28nLFxuXTtcblxuZXhwb3J0IGNvbnN0IG1pbWVUeXBlcyA9IFtcblx0J2ltYWdlL2pwZWcnLFxuXHQnaW1hZ2UvcG5nJyxcblx0J2ltYWdlL2dpZicsXG5cdCdpbWFnZS93ZWJwJyxcblx0J2ltYWdlL2ZsaWYnLFxuXHQnaW1hZ2UveC14Y2YnLFxuXHQnaW1hZ2UveC1jYW5vbi1jcjInLFxuXHQnaW1hZ2UveC1jYW5vbi1jcjMnLFxuXHQnaW1hZ2UvdGlmZicsXG5cdCdpbWFnZS9ibXAnLFxuXHQnaW1hZ2Uvdm5kLm1zLXBob3RvJyxcblx0J2ltYWdlL3ZuZC5hZG9iZS5waG90b3Nob3AnLFxuXHQnYXBwbGljYXRpb24veC1pbmRlc2lnbicsXG5cdCdhcHBsaWNhdGlvbi9lcHViK3ppcCcsXG5cdCdhcHBsaWNhdGlvbi94LXhwaW5zdGFsbCcsXG5cdCdhcHBsaWNhdGlvbi92bmQubXMtcG93ZXJwb2ludC5zbGlkZXNob3cubWFjcm9lbmFibGVkLjEyJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQudGV4dCcsXG5cdCdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LnNwcmVhZHNoZWV0Jyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQucHJlc2VudGF0aW9uJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC53b3JkcHJvY2Vzc2luZ21sLmRvY3VtZW50Jyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5wcmVzZW50YXRpb25tbC5wcmVzZW50YXRpb24nLFxuXHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQnLFxuXHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnByZXNlbnRhdGlvbm1sLnNsaWRlc2hvdycsXG5cdCdhcHBsaWNhdGlvbi96aXAnLFxuXHQnYXBwbGljYXRpb24veC10YXInLFxuXHQnYXBwbGljYXRpb24veC1yYXItY29tcHJlc3NlZCcsXG5cdCdhcHBsaWNhdGlvbi9nemlwJyxcblx0J2FwcGxpY2F0aW9uL3gtYnppcDInLFxuXHQnYXBwbGljYXRpb24veC03ei1jb21wcmVzc2VkJyxcblx0J2FwcGxpY2F0aW9uL3gtYXBwbGUtZGlza2ltYWdlJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5hcGFjaGUuYXJyb3cuZmlsZScsXG5cdCd2aWRlby9tcDQnLFxuXHQnYXVkaW8vbWlkaScsXG5cdCd2aWRlby9tYXRyb3NrYScsXG5cdCd2aWRlby93ZWJtJyxcblx0J3ZpZGVvL3F1aWNrdGltZScsXG5cdCd2aWRlby92bmQuYXZpJyxcblx0J2F1ZGlvL3dhdicsXG5cdCdhdWRpby9xY2VscCcsXG5cdCdhdWRpby94LW1zLWFzZicsXG5cdCd2aWRlby94LW1zLWFzZicsXG5cdCdhcHBsaWNhdGlvbi92bmQubXMtYXNmJyxcblx0J3ZpZGVvL21wZWcnLFxuXHQndmlkZW8vM2dwcCcsXG5cdCdhdWRpby9tcGVnJyxcblx0J2F1ZGlvL21wNCcsIC8vIFJGQyA0MzM3XG5cdCd2aWRlby9vZ2cnLFxuXHQnYXVkaW8vb2dnJyxcblx0J2F1ZGlvL29nZzsgY29kZWNzPW9wdXMnLFxuXHQnYXBwbGljYXRpb24vb2dnJyxcblx0J2F1ZGlvL2ZsYWMnLFxuXHQnYXVkaW8vYXBlJyxcblx0J2F1ZGlvL3dhdnBhY2snLFxuXHQnYXVkaW8vYW1yJyxcblx0J2FwcGxpY2F0aW9uL3BkZicsXG5cdCdhcHBsaWNhdGlvbi94LWVsZicsXG5cdCdhcHBsaWNhdGlvbi94LW1hY2gtYmluYXJ5Jyxcblx0J2FwcGxpY2F0aW9uL3gtbXNkb3dubG9hZCcsXG5cdCdhcHBsaWNhdGlvbi94LXNob2Nrd2F2ZS1mbGFzaCcsXG5cdCdhcHBsaWNhdGlvbi9ydGYnLFxuXHQnYXBwbGljYXRpb24vd2FzbScsXG5cdCdmb250L3dvZmYnLFxuXHQnZm9udC93b2ZmMicsXG5cdCdhcHBsaWNhdGlvbi92bmQubXMtZm9udG9iamVjdCcsXG5cdCdmb250L3R0ZicsXG5cdCdmb250L290ZicsXG5cdCdmb250L2NvbGxlY3Rpb24nLFxuXHQnaW1hZ2UveC1pY29uJyxcblx0J3ZpZGVvL3gtZmx2Jyxcblx0J2FwcGxpY2F0aW9uL3Bvc3RzY3JpcHQnLFxuXHQnYXBwbGljYXRpb24vZXBzJyxcblx0J2FwcGxpY2F0aW9uL3gteHonLFxuXHQnYXBwbGljYXRpb24veC1zcWxpdGUzJyxcblx0J2FwcGxpY2F0aW9uL3gtbmludGVuZG8tbmVzLXJvbScsXG5cdCdhcHBsaWNhdGlvbi94LWdvb2dsZS1jaHJvbWUtZXh0ZW5zaW9uJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5tcy1jYWItY29tcHJlc3NlZCcsXG5cdCdhcHBsaWNhdGlvbi94LWRlYicsXG5cdCdhcHBsaWNhdGlvbi94LXVuaXgtYXJjaGl2ZScsXG5cdCdhcHBsaWNhdGlvbi94LXJwbScsXG5cdCdhcHBsaWNhdGlvbi94LWNvbXByZXNzJyxcblx0J2FwcGxpY2F0aW9uL2x6aXAnLFxuXHQnYXBwbGljYXRpb24veC1jZmInLFxuXHQnYXBwbGljYXRpb24veC1taWUnLFxuXHQnYXBwbGljYXRpb24vbXhmJyxcblx0J3ZpZGVvL21wMnQnLFxuXHQnYXBwbGljYXRpb24veC1ibGVuZGVyJyxcblx0J2ltYWdlL2JwZycsXG5cdCdpbWFnZS9qMmMnLFxuXHQnaW1hZ2UvanAyJyxcblx0J2ltYWdlL2pweCcsXG5cdCdpbWFnZS9qcG0nLFxuXHQnaW1hZ2UvbWoyJyxcblx0J2F1ZGlvL2FpZmYnLFxuXHQnYXVkaW8veC1jYWYnLCAvLyBOb24tc3RhbmRhcmRcblx0J2FwcGxpY2F0aW9uL3htbCcsXG5cdCdhcHBsaWNhdGlvbi94LW1vYmlwb2NrZXQtZWJvb2snLFxuXHQnaW1hZ2UvaGVpZicsXG5cdCdpbWFnZS9oZWlmLXNlcXVlbmNlJyxcblx0J2ltYWdlL2hlaWMnLFxuXHQnaW1hZ2UvaGVpYy1zZXF1ZW5jZScsXG5cdCdpbWFnZS9pY25zJyxcblx0J2ltYWdlL2t0eCcsXG5cdCdhcHBsaWNhdGlvbi9kaWNvbScsXG5cdCdhdWRpby94LW11c2VwYWNrJyxcblx0J3RleHQvY2FsZW5kYXInLFxuXHQndGV4dC92Y2FyZCcsXG5cdCd0ZXh0L3Z0dCcsXG5cdCdtb2RlbC9nbHRmLWJpbmFyeScsXG5cdCdhcHBsaWNhdGlvbi92bmQudGNwZHVtcC5wY2FwJyxcblx0J2F1ZGlvL3gtZHNmJywgLy8gTm9uLXN0YW5kYXJkXG5cdCdhdWRpby94LWRmZicsIC8vIE5vbi1zdGFuZGFyZFxuXHQnYXBwbGljYXRpb24veC1tcy1zaG9ydGN1dCcsIC8vIEluZm9ybWFsLCB1c2VkIGJ5IGZyZWVkZXNrdG9wLm9yZyBzaGFyZWQtbWltZS1pbmZvXG5cdCdhcHBsaWNhdGlvbi94LWZ0LWFwcGxlLmFsaWFzJyxcblx0J2F1ZGlvL3gtdm9jJyxcblx0J2F1ZGlvL3ZuZC5kb2xieS5kZC1yYXcnLFxuXHQnYXVkaW8veC1tNGEnLFxuXHQnaW1hZ2UvYXBuZycsXG5cdCdpbWFnZS94LW9seW1wdXMtb3JmJyxcblx0J2ltYWdlL3gtc29ueS1hcncnLFxuXHQnaW1hZ2UveC1hZG9iZS1kbmcnLFxuXHQnaW1hZ2UveC1uaWtvbi1uZWYnLFxuXHQnaW1hZ2UveC1wYW5hc29uaWMtcncyJyxcblx0J2ltYWdlL3gtZnVqaWZpbG0tcmFmJyxcblx0J3ZpZGVvL3gtbTR2Jyxcblx0J3ZpZGVvLzNncHAyJyxcblx0J2FwcGxpY2F0aW9uL3gtZXNyaS1zaGFwZScsXG5cdCdhdWRpby9hYWMnLFxuXHQnYXVkaW8veC1pdCcsXG5cdCdhdWRpby94LXMzbScsXG5cdCdhdWRpby94LXhtJyxcblx0J3ZpZGVvL01QMVMnLFxuXHQndmlkZW8vTVAyUCcsXG5cdCdhcHBsaWNhdGlvbi92bmQuc2tldGNodXAuc2twJyxcblx0J2ltYWdlL2F2aWYnLFxuXHQnYXBwbGljYXRpb24veC1semgtY29tcHJlc3NlZCcsXG5cdCdhcHBsaWNhdGlvbi9wZ3AtZW5jcnlwdGVkJyxcblx0J2FwcGxpY2F0aW9uL3gtYXNhcicsXG5cdCdtb2RlbC9zdGwnLFxuXHQnYXBwbGljYXRpb24vdm5kLm1zLWh0bWxoZWxwJyxcblx0J21vZGVsLzNtZicsXG5cdCdpbWFnZS9qeGwnLFxuXHQnYXBwbGljYXRpb24venN0ZCcsXG5cdCdpbWFnZS9qbHMnLFxuXHQnYXBwbGljYXRpb24vdm5kLm1zLW91dGxvb2snLFxuXHQnaW1hZ2Uvdm5kLmR3ZycsXG5cdCdhcHBsaWNhdGlvbi92bmQuYXBhY2hlLnBhcnF1ZXQnLFxuXHQnYXBwbGljYXRpb24vamF2YS12bScsXG5cdCdhcHBsaWNhdGlvbi94LWFyaicsXG5cdCdhcHBsaWNhdGlvbi94LWNwaW8nLFxuXHQnYXBwbGljYXRpb24veC1hY2UtY29tcHJlc3NlZCcsXG5cdCdhcHBsaWNhdGlvbi9hdnJvJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5pY2Nwcm9maWxlJyxcblx0J2FwcGxpY2F0aW9uL3gtZnQtZmJ4Jyxcblx0J2FwcGxpY2F0aW9uL3ZuZC52aXNpbycsXG5cdCdhcHBsaWNhdGlvbi92bmQuYW5kcm9pZC5wYWNrYWdlLWFyY2hpdmUnLFxuXHQnYXBwbGljYXRpb24veC1mdC1kcmFjbycsXG5cdCdhcHBsaWNhdGlvbi94LWx6NCcsIC8vIEluZm9ybWFsLCB1c2VkIGJ5IGZyZWVkZXNrdG9wLm9yZyBzaGFyZWQtbWltZS1pbmZvXG5cdCdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQucHJlc2VudGF0aW9ubWwudGVtcGxhdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwudGVtcGxhdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LndvcmRwcm9jZXNzaW5nbWwudGVtcGxhdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsLnRlbXBsYXRlLm1hY3JvZW5hYmxlZC4xMicsXG5cdCdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LnRleHQtdGVtcGxhdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLm9hc2lzLm9wZW5kb2N1bWVudC5zcHJlYWRzaGVldC10ZW1wbGF0ZScsXG5cdCdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LnByZXNlbnRhdGlvbi10ZW1wbGF0ZScsXG5cdCdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LmdyYXBoaWNzJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQuZ3JhcGhpY3MtdGVtcGxhdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsLnNoZWV0Lm1hY3JvZW5hYmxlZC4xMicsXG5cdCdhcHBsaWNhdGlvbi92bmQubXMtd29yZC5kb2N1bWVudC5tYWNyb2VuYWJsZWQuMTInLFxuXHQnYXBwbGljYXRpb24vdm5kLm1zLXdvcmQudGVtcGxhdGUubWFjcm9lbmFibGVkLjEyJyxcblx0J2FwcGxpY2F0aW9uL3ZuZC5tcy1wb3dlcnBvaW50LnRlbXBsYXRlLm1hY3JvZW5hYmxlZC4xMicsXG5cdCdhcHBsaWNhdGlvbi92bmQubXMtcG93ZXJwb2ludC5wcmVzZW50YXRpb24ubWFjcm9lbmFibGVkLjEyJyxcblx0J2FwcGxpY2F0aW9uL2phdmEtYXJjaGl2ZScsXG5cdCdhcHBsaWNhdGlvbi92bmQucm4tcmVhbG1lZGlhJyxcblx0J2FwcGxpY2F0aW9uL3gtc3Bzcy1zYXYnLFxuXHQnYXBwbGljYXRpb24veC1tcy1yZWdlZGl0Jyxcblx0J2FwcGxpY2F0aW9uL3gtZnQtd2luZG93cy1yZWdpc3RyeS1oaXZlJyxcblx0J2FwcGxpY2F0aW9uL3gtam1wLWRhdGEnLFxuXHQnYXBwbGljYXRpb24vdm5kLmFwcGxlLmtleW5vdGUnLFxuXHQnYXBwbGljYXRpb24vdm5kLmFwcGxlLm51bWJlcnMnLFxuXHQnYXBwbGljYXRpb24vdm5kLmFwcGxlLnBhZ2VzJyxcblx0J2FwcGxpY2F0aW9uL3gtaXNvOTY2MC1pbWFnZScsXG5dO1xuIiwiZXhwb3J0IGNvbnN0IG1heGltdW1VbnRydXN0ZWRTa2lwU2l6ZUluQnl0ZXMgPSAxNiAqIDEwMjQgKiAxMDI0O1xuXG5leHBvcnQgY2xhc3MgUGFyc2VySGFyZExpbWl0RXJyb3IgZXh0ZW5kcyBFcnJvciB7fVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2FmZUJvdW5kKHZhbHVlLCBtYXhpbXVtLCByZWFzb24pIHtcblx0aWYgKFxuXHRcdCFOdW1iZXIuaXNGaW5pdGUodmFsdWUpXG5cdFx0fHwgdmFsdWUgPCAwXG5cdFx0fHwgdmFsdWUgPiBtYXhpbXVtXG5cdCkge1xuXHRcdHRocm93IG5ldyBQYXJzZXJIYXJkTGltaXRFcnJvcihgJHtyZWFzb259IGhhcyBpbnZhbGlkIHNpemUgJHt2YWx1ZX0gKG1heGltdW0gJHttYXhpbXVtfSBieXRlcylgKTtcblx0fVxuXG5cdHJldHVybiB2YWx1ZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhZmVJZ25vcmUodG9rZW5pemVyLCBsZW5ndGgsIHttYXhpbXVtTGVuZ3RoID0gbWF4aW11bVVudHJ1c3RlZFNraXBTaXplSW5CeXRlcywgcmVhc29uID0gJ3NraXAnfSA9IHt9KSB7XG5cdGNvbnN0IHNhZmVMZW5ndGggPSBnZXRTYWZlQm91bmQobGVuZ3RoLCBtYXhpbXVtTGVuZ3RoLCByZWFzb24pO1xuXHRhd2FpdCB0b2tlbml6ZXIuaWdub3JlKHNhZmVMZW5ndGgpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2FmZVJlYWRCdWZmZXIodG9rZW5pemVyLCBidWZmZXIsIG9wdGlvbnMsIHttYXhpbXVtTGVuZ3RoID0gYnVmZmVyLmxlbmd0aCwgcmVhc29uID0gJ3JlYWQnfSA9IHt9KSB7XG5cdGNvbnN0IGxlbmd0aCA9IG9wdGlvbnM/Lmxlbmd0aCA/PyBidWZmZXIubGVuZ3RoO1xuXHRjb25zdCBzYWZlTGVuZ3RoID0gZ2V0U2FmZUJvdW5kKGxlbmd0aCwgbWF4aW11bUxlbmd0aCwgcmVhc29uKTtcblx0cmV0dXJuIHRva2VuaXplci5yZWFkQnVmZmVyKGJ1ZmZlciwge1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0bGVuZ3RoOiBzYWZlTGVuZ3RoLFxuXHR9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrQnl0ZXMoYnVmZmVyLCBoZWFkZXJzLCBvcHRpb25zKSB7XG5cdG9wdGlvbnMgPSB7XG5cdFx0b2Zmc2V0OiAwLFxuXHRcdC4uLm9wdGlvbnMsXG5cdH07XG5cblx0Zm9yIChjb25zdCBbaW5kZXgsIGhlYWRlcl0gb2YgaGVhZGVycy5lbnRyaWVzKCkpIHtcblx0XHQvLyBJZiBhIGJpdG1hc2sgaXMgc2V0XG5cdFx0aWYgKG9wdGlvbnMubWFzaykge1xuXHRcdFx0Ly8gSWYgaGVhZGVyIGRvZXNuJ3QgZXF1YWwgYGJ1ZmAgd2l0aCBiaXRzIG1hc2tlZCBvZmZcblx0XHRcdGlmIChoZWFkZXIgIT09IChvcHRpb25zLm1hc2tbaW5kZXhdICYgYnVmZmVyW2luZGV4ICsgb3B0aW9ucy5vZmZzZXRdKSkge1xuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIGlmIChoZWFkZXIgIT09IGJ1ZmZlcltpbmRleCArIG9wdGlvbnMub2Zmc2V0XSkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiB0cnVlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaGFzVW5rbm93bkZpbGVTaXplKHRva2VuaXplcikge1xuXHRjb25zdCBmaWxlU2l6ZSA9IHRva2VuaXplci5maWxlSW5mby5zaXplO1xuXHRyZXR1cm4gKFxuXHRcdCFOdW1iZXIuaXNGaW5pdGUoZmlsZVNpemUpXG5cdFx0fHwgZmlsZVNpemUgPT09IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSXG5cdCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBoYXNFeGNlZWRlZFVua25vd25TaXplU2NhbkJ1ZGdldCh0b2tlbml6ZXIsIHN0YXJ0T2Zmc2V0LCBtYXhpbXVtQnl0ZXMpIHtcblx0cmV0dXJuIChcblx0XHRoYXNVbmtub3duRmlsZVNpemUodG9rZW5pemVyKVxuXHRcdCYmIHRva2VuaXplci5wb3NpdGlvbiAtIHN0YXJ0T2Zmc2V0ID4gbWF4aW11bUJ5dGVzXG5cdCk7XG59XG4iLCJpbXBvcnQgKiBhcyBzdHJ0b2szIGZyb20gJ3N0cnRvazMvY29yZSc7XG5pbXBvcnQge1ppcEhhbmRsZXIsIFppcExpbWl0RXJyb3J9IGZyb20gJ0B0b2tlbml6ZXIvaW5mbGF0ZSc7XG5pbXBvcnQge1xuXHRtYXhpbXVtVW50cnVzdGVkU2tpcFNpemVJbkJ5dGVzLFxuXHRQYXJzZXJIYXJkTGltaXRFcnJvcixcblx0aGFzVW5rbm93bkZpbGVTaXplLFxufSBmcm9tICcuLi9wYXJzZXIuanMnO1xuXG5jb25zdCBtYXhpbXVtWmlwRW50cnlTaXplSW5CeXRlcyA9IDEwMjQgKiAxMDI0O1xuY29uc3QgbWF4aW11bVppcEVudHJ5Q291bnQgPSAxMDI0O1xuY29uc3QgbWF4aW11bVppcFRleHRFbnRyeVNpemVJbkJ5dGVzID0gbWF4aW11bVppcEVudHJ5U2l6ZUluQnl0ZXM7XG5cbmNvbnN0IHJlY292ZXJhYmxlWmlwRXJyb3JNZXNzYWdlcyA9IG5ldyBTZXQoW1xuXHQnVW5leHBlY3RlZCBzaWduYXR1cmUnLFxuXHQnRW5jcnlwdGVkIFpJUCcsXG5cdCdFeHBlY3RlZCBDZW50cmFsLUZpbGUtSGVhZGVyIHNpZ25hdHVyZScsXG5dKTtcbmNvbnN0IHJlY292ZXJhYmxlWmlwRXJyb3JNZXNzYWdlUHJlZml4ZXMgPSBbXG5cdCdVbnN1cHBvcnRlZCBaSVAgY29tcHJlc3Npb24gbWV0aG9kOicsXG5cdCdFeHBlY3RlZCBkYXRhLWRlc2NyaXB0b3Itc2lnbmF0dXJlIGF0IHBvc2l0aW9uICcsXG5dO1xuY29uc3QgcmVjb3ZlcmFibGVaaXBFcnJvckNvZGVzID0gbmV3IFNldChbXG5cdCdaX0JVRl9FUlJPUicsXG5cdCdaX0RBVEFfRVJST1InLFxuXHQnRVJSX0lOVkFMSURfU1RBVEUnLFxuXSk7XG5cbmZ1bmN0aW9uIGlzUmVjb3ZlcmFibGVaaXBFcnJvcihlcnJvcikge1xuXHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBzdHJ0b2szLkVuZE9mU3RyZWFtRXJyb3IpIHtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXG5cdGlmIChlcnJvciBpbnN0YW5jZW9mIFBhcnNlckhhcmRMaW1pdEVycm9yIHx8IGVycm9yIGluc3RhbmNlb2YgWmlwTGltaXRFcnJvcikge1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0aWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBUeXBlRXJyb3IgJiYgZXJyb3IubWVzc2FnZS5zdGFydHNXaXRoKCdGYWlsZWQgdG8gZGVmbGF0ZSBaSVAgZW50cnk6JykpIHtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXG5cdGlmIChyZWNvdmVyYWJsZVppcEVycm9yTWVzc2FnZXMuaGFzKGVycm9yLm1lc3NhZ2UpKSB7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblxuXHRpZiAocmVjb3ZlcmFibGVaaXBFcnJvckNvZGVzLmhhcyhlcnJvci5jb2RlKSkge1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0Zm9yIChjb25zdCBwcmVmaXggb2YgcmVjb3ZlcmFibGVaaXBFcnJvck1lc3NhZ2VQcmVmaXhlcykge1xuXHRcdGlmIChlcnJvci5tZXNzYWdlLnN0YXJ0c1dpdGgocHJlZml4KSkge1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGZhbHNlO1xufVxuXG5mdW5jdGlvbiBpc1ppcFNjYW5MaW1pdEVycm9yKGVycm9yKSB7XG5cdHJldHVybiBlcnJvciBpbnN0YW5jZW9mIFppcExpbWl0RXJyb3IgJiYgW1xuXHRcdCdtYXhUb3RhbFNjYW5CeXRlcycsXG5cdFx0J21heFRvdGFsRGF0YURlc2NyaXB0b3JTY2FuQnl0ZXMnLFxuXHRcdCdtYXhEYXRhRGVzY3JpcHRvclNjYW5CeXRlcycsXG5cdFx0J21heFNraXBwZWRFbnRyeVNpemUnLFxuXHRdLmluY2x1ZGVzKGVycm9yLmxpbWl0KTtcbn1cblxuZnVuY3Rpb24gY2FuUmVhZFppcEVudHJ5Rm9yRGV0ZWN0aW9uKHppcEhlYWRlciwgbWF4aW11bVNpemUgPSBtYXhpbXVtWmlwRW50cnlTaXplSW5CeXRlcykge1xuXHRjb25zdCBzaXplcyA9IFt6aXBIZWFkZXIuY29tcHJlc3NlZFNpemUsIHppcEhlYWRlci51bmNvbXByZXNzZWRTaXplXTtcblx0Zm9yIChjb25zdCBzaXplIG9mIHNpemVzKSB7XG5cdFx0aWYgKFxuXHRcdFx0IU51bWJlci5pc0Zpbml0ZShzaXplKVxuXHRcdFx0fHwgc2l6ZSA8IDBcblx0XHRcdHx8IHNpemUgPiBtYXhpbXVtU2l6ZVxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fVxuXG5cdHJldHVybiB0cnVlO1xufVxuXG4vLyAtLSBpV29yayBoZWxwZXJzIC0tXG5cbmZ1bmN0aW9uIGNyZWF0ZUlXb3JrWmlwRGV0ZWN0aW9uU3RhdGUoKSB7XG5cdHJldHVybiB7XG5cdFx0aGFzRG9jdW1lbnRFbnRyeTogZmFsc2UsXG5cdFx0aGFzTWFzdGVyU2xpZGVFbnRyeTogZmFsc2UsXG5cdFx0aGFzVGFibGVzRW50cnk6IGZhbHNlLFxuXHRcdGhhc0NhbGN1bGF0aW9uRW5naW5lRW50cnk6IGZhbHNlLFxuXHR9O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVJV29ya1ppcERldGVjdGlvblN0YXRlRnJvbUZpbGVuYW1lKGlXb3JrU3RhdGUsIGZpbGVuYW1lKSB7XG5cdGlmIChmaWxlbmFtZSA9PT0gJ0luZGV4L0RvY3VtZW50Lml3YScpIHtcblx0XHRpV29ya1N0YXRlLmhhc0RvY3VtZW50RW50cnkgPSB0cnVlO1xuXHR9XG5cblx0aWYgKGZpbGVuYW1lLnN0YXJ0c1dpdGgoJ0luZGV4L01hc3RlclNsaWRlJykpIHtcblx0XHRpV29ya1N0YXRlLmhhc01hc3RlclNsaWRlRW50cnkgPSB0cnVlO1xuXHR9XG5cblx0aWYgKGZpbGVuYW1lLnN0YXJ0c1dpdGgoJ0luZGV4L1RhYmxlcy8nKSkge1xuXHRcdGlXb3JrU3RhdGUuaGFzVGFibGVzRW50cnkgPSB0cnVlO1xuXHR9XG5cblx0aWYgKGZpbGVuYW1lID09PSAnSW5kZXgvQ2FsY3VsYXRpb25FbmdpbmUuaXdhJykge1xuXHRcdGlXb3JrU3RhdGUuaGFzQ2FsY3VsYXRpb25FbmdpbmVFbnRyeSA9IHRydWU7XG5cdH1cbn1cblxuZnVuY3Rpb24gZ2V0SVdvcmtGaWxlVHlwZUZyb21aaXBFbnRyaWVzKGlXb3JrU3RhdGUpIHtcblx0aWYgKCFpV29ya1N0YXRlLmhhc0RvY3VtZW50RW50cnkpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHRpZiAoaVdvcmtTdGF0ZS5oYXNNYXN0ZXJTbGlkZUVudHJ5KSB7XG5cdFx0cmV0dXJuIHtleHQ6ICdrZXknLCBtaW1lOiAnYXBwbGljYXRpb24vdm5kLmFwcGxlLmtleW5vdGUnfTtcblx0fVxuXG5cdGlmIChpV29ya1N0YXRlLmhhc1RhYmxlc0VudHJ5KSB7XG5cdFx0cmV0dXJuIHtleHQ6ICdudW1iZXJzJywgbWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5hcHBsZS5udW1iZXJzJ307XG5cdH1cblxuXHRyZXR1cm4ge2V4dDogJ3BhZ2VzJywgbWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5hcHBsZS5wYWdlcyd9O1xufVxuXG4vLyAtLSBPcGVuWE1MIGhlbHBlcnMgLS1cblxuZnVuY3Rpb24gZ2V0RmlsZVR5cGVGcm9tTWltZVR5cGUobWltZVR5cGUpIHtcblx0bWltZVR5cGUgPSBtaW1lVHlwZS50b0xvd2VyQ2FzZSgpO1xuXHRzd2l0Y2ggKG1pbWVUeXBlKSB7XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vZXB1Yit6aXAnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdlcHViJywgbWltZTogbWltZVR5cGV9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQudGV4dCc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ29kdCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LnRleHQtdGVtcGxhdGUnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdvdHQnLCBtaW1lOiBtaW1lVHlwZX07XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm9hc2lzLm9wZW5kb2N1bWVudC5zcHJlYWRzaGVldCc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ29kcycsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQub2FzaXMub3BlbmRvY3VtZW50LnNwcmVhZHNoZWV0LXRlbXBsYXRlJzpcblx0XHRcdHJldHVybiB7ZXh0OiAnb3RzJywgbWltZTogbWltZVR5cGV9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQucHJlc2VudGF0aW9uJzpcblx0XHRcdHJldHVybiB7ZXh0OiAnb2RwJywgbWltZTogbWltZVR5cGV9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQucHJlc2VudGF0aW9uLXRlbXBsYXRlJzpcblx0XHRcdHJldHVybiB7ZXh0OiAnb3RwJywgbWltZTogbWltZVR5cGV9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vYXNpcy5vcGVuZG9jdW1lbnQuZ3JhcGhpY3MnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdvZGcnLCBtaW1lOiBtaW1lVHlwZX07XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm9hc2lzLm9wZW5kb2N1bWVudC5ncmFwaGljcy10ZW1wbGF0ZSc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ290ZycsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQucHJlc2VudGF0aW9ubWwuc2xpZGVzaG93Jzpcblx0XHRcdHJldHVybiB7ZXh0OiAncHBzeCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldCc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ3hsc3gnLCBtaW1lOiBtaW1lVHlwZX07XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsLnNoZWV0Lm1hY3JvZW5hYmxlZCc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ3hsc20nLCBtaW1lOiAnYXBwbGljYXRpb24vdm5kLm1zLWV4Y2VsLnNoZWV0Lm1hY3JvZW5hYmxlZC4xMid9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnRlbXBsYXRlJzpcblx0XHRcdHJldHVybiB7ZXh0OiAneGx0eCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQubXMtZXhjZWwudGVtcGxhdGUubWFjcm9lbmFibGVkJzpcblx0XHRcdHJldHVybiB7ZXh0OiAneGx0bScsIG1pbWU6ICdhcHBsaWNhdGlvbi92bmQubXMtZXhjZWwudGVtcGxhdGUubWFjcm9lbmFibGVkLjEyJ307XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm1zLXBvd2VycG9pbnQuc2xpZGVzaG93Lm1hY3JvZW5hYmxlZCc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ3Bwc20nLCBtaW1lOiAnYXBwbGljYXRpb24vdm5kLm1zLXBvd2VycG9pbnQuc2xpZGVzaG93Lm1hY3JvZW5hYmxlZC4xMid9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC53b3JkcHJvY2Vzc2luZ21sLmRvY3VtZW50Jzpcblx0XHRcdHJldHVybiB7ZXh0OiAnZG9jeCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQubXMtd29yZC5kb2N1bWVudC5tYWNyb2VuYWJsZWQnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdkb2NtJywgbWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5tcy13b3JkLmRvY3VtZW50Lm1hY3JvZW5hYmxlZC4xMid9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC53b3JkcHJvY2Vzc2luZ21sLnRlbXBsYXRlJzpcblx0XHRcdHJldHVybiB7ZXh0OiAnZG90eCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQubXMtd29yZC50ZW1wbGF0ZS5tYWNyb2VuYWJsZWR0ZW1wbGF0ZSc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ2RvdG0nLCBtaW1lOiAnYXBwbGljYXRpb24vdm5kLm1zLXdvcmQudGVtcGxhdGUubWFjcm9lbmFibGVkLjEyJ307XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnByZXNlbnRhdGlvbm1sLnRlbXBsYXRlJzpcblx0XHRcdHJldHVybiB7ZXh0OiAncG90eCcsIG1pbWU6IG1pbWVUeXBlfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQubXMtcG93ZXJwb2ludC50ZW1wbGF0ZS5tYWNyb2VuYWJsZWQnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdwb3RtJywgbWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5tcy1wb3dlcnBvaW50LnRlbXBsYXRlLm1hY3JvZW5hYmxlZC4xMid9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5wcmVzZW50YXRpb25tbC5wcmVzZW50YXRpb24nOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdwcHR4JywgbWltZTogbWltZVR5cGV9O1xuXHRcdGNhc2UgJ2FwcGxpY2F0aW9uL3ZuZC5tcy1wb3dlcnBvaW50LnByZXNlbnRhdGlvbi5tYWNyb2VuYWJsZWQnOlxuXHRcdFx0cmV0dXJuIHtleHQ6ICdwcHRtJywgbWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5tcy1wb3dlcnBvaW50LnByZXNlbnRhdGlvbi5tYWNyb2VuYWJsZWQuMTInfTtcblx0XHRjYXNlICdhcHBsaWNhdGlvbi92bmQubXMtdmlzaW8uZHJhd2luZyc6XG5cdFx0XHRyZXR1cm4ge2V4dDogJ3ZzZHgnLCBtaW1lOiAnYXBwbGljYXRpb24vdm5kLnZpc2lvJ307XG5cdFx0Y2FzZSAnYXBwbGljYXRpb24vdm5kLm1zLXBhY2thZ2UuM2RtYW51ZmFjdHVyaW5nLTNkbW9kZWwreG1sJzpcblx0XHRcdHJldHVybiB7ZXh0OiAnM21mJywgbWltZTogJ21vZGVsLzNtZid9O1xuXHRcdGRlZmF1bHQ6XG5cdH1cbn1cblxuZnVuY3Rpb24gY3JlYXRlT3BlblhtbFppcERldGVjdGlvblN0YXRlKCkge1xuXHRyZXR1cm4ge1xuXHRcdGhhc0NvbnRlbnRUeXBlc0VudHJ5OiBmYWxzZSxcblx0XHRoYXNQYXJzZWRDb250ZW50VHlwZXNFbnRyeTogZmFsc2UsXG5cdFx0aXNQYXJzaW5nQ29udGVudFR5cGVzOiBmYWxzZSxcblx0XHRoYXNVbnBhcnNlYWJsZUNvbnRlbnRUeXBlczogZmFsc2UsXG5cdFx0aGFzV29yZERpcmVjdG9yeTogZmFsc2UsXG5cdFx0aGFzUHJlc2VudGF0aW9uRGlyZWN0b3J5OiBmYWxzZSxcblx0XHRoYXNTcHJlYWRzaGVldERpcmVjdG9yeTogZmFsc2UsXG5cdFx0aGFzVGhyZWVEaW1lbnNpb25hbE1vZGVsRW50cnk6IGZhbHNlLFxuXHR9O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVPcGVuWG1sWmlwRGV0ZWN0aW9uU3RhdGVGcm9tRmlsZW5hbWUob3BlblhtbFN0YXRlLCBmaWxlbmFtZSkge1xuXHRpZiAoZmlsZW5hbWUuc3RhcnRzV2l0aCgnd29yZC8nKSkge1xuXHRcdG9wZW5YbWxTdGF0ZS5oYXNXb3JkRGlyZWN0b3J5ID0gdHJ1ZTtcblx0fVxuXG5cdGlmIChmaWxlbmFtZS5zdGFydHNXaXRoKCdwcHQvJykpIHtcblx0XHRvcGVuWG1sU3RhdGUuaGFzUHJlc2VudGF0aW9uRGlyZWN0b3J5ID0gdHJ1ZTtcblx0fVxuXG5cdGlmIChmaWxlbmFtZS5zdGFydHNXaXRoKCd4bC8nKSkge1xuXHRcdG9wZW5YbWxTdGF0ZS5oYXNTcHJlYWRzaGVldERpcmVjdG9yeSA9IHRydWU7XG5cdH1cblxuXHRpZiAoXG5cdFx0ZmlsZW5hbWUuc3RhcnRzV2l0aCgnM0QvJylcblx0XHQmJiBmaWxlbmFtZS5lbmRzV2l0aCgnLm1vZGVsJylcblx0KSB7XG5cdFx0b3BlblhtbFN0YXRlLmhhc1RocmVlRGltZW5zaW9uYWxNb2RlbEVudHJ5ID0gdHJ1ZTtcblx0fVxufVxuXG5mdW5jdGlvbiBnZXRPcGVuWG1sRmlsZVR5cGVGcm9tRGlyZWN0b3J5TmFtZXMob3BlblhtbFN0YXRlKSB7XG5cdGlmIChvcGVuWG1sU3RhdGUuaGFzV29yZERpcmVjdG9yeSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRleHQ6ICdkb2N4Jyxcblx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQud29yZHByb2Nlc3NpbmdtbC5kb2N1bWVudCcsXG5cdFx0fTtcblx0fVxuXG5cdGlmIChvcGVuWG1sU3RhdGUuaGFzUHJlc2VudGF0aW9uRGlyZWN0b3J5KSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGV4dDogJ3BwdHgnLFxuXHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5wcmVzZW50YXRpb25tbC5wcmVzZW50YXRpb24nLFxuXHRcdH07XG5cdH1cblxuXHRpZiAob3BlblhtbFN0YXRlLmhhc1NwcmVhZHNoZWV0RGlyZWN0b3J5KSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGV4dDogJ3hsc3gnLFxuXHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0Jyxcblx0XHR9O1xuXHR9XG5cblx0aWYgKG9wZW5YbWxTdGF0ZS5oYXNUaHJlZURpbWVuc2lvbmFsTW9kZWxFbnRyeSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRleHQ6ICczbWYnLFxuXHRcdFx0bWltZTogJ21vZGVsLzNtZicsXG5cdFx0fTtcblx0fVxufVxuXG5mdW5jdGlvbiBnZXRPcGVuWG1sRmlsZVR5cGVGcm9tWmlwRW50cmllcyhvcGVuWG1sU3RhdGUpIHtcblx0Ly8gT25seSB1c2UgZGlyZWN0b3J5LW5hbWUgaGV1cmlzdGljIHdoZW4gW0NvbnRlbnRfVHlwZXNdLnhtbCB3YXMgcHJlc2VudCBpbiB0aGUgYXJjaGl2ZVxuXHQvLyBidXQgaXRzIGhhbmRsZXIgd2FzIHNraXBwZWQgKG5vdCBpbnZva2VkLCBub3QgY3VycmVudGx5IHJ1bm5pbmcsIGFuZCBub3QgYWxyZWFkeSByZXNvbHZlZCkuXG5cdC8vIFRoaXMgYXZvaWRzIGd1ZXNzaW5nIGZyb20gZGlyZWN0b3J5IG5hbWVzIHdoZW4gY29udGVudC10eXBlIHBhcnNpbmcgYWxyZWFkeSBnYXZlIGEgZGVmaW5pdGl2ZSBhbnN3ZXIgb3IgZmFpbGVkLlxuXHRpZiAoXG5cdFx0IW9wZW5YbWxTdGF0ZS5oYXNDb250ZW50VHlwZXNFbnRyeVxuXHRcdHx8IG9wZW5YbWxTdGF0ZS5oYXNVbnBhcnNlYWJsZUNvbnRlbnRUeXBlc1xuXHRcdHx8IG9wZW5YbWxTdGF0ZS5pc1BhcnNpbmdDb250ZW50VHlwZXNcblx0XHR8fCBvcGVuWG1sU3RhdGUuaGFzUGFyc2VkQ29udGVudFR5cGVzRW50cnlcblx0KSB7XG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0cmV0dXJuIGdldE9wZW5YbWxGaWxlVHlwZUZyb21EaXJlY3RvcnlOYW1lcyhvcGVuWG1sU3RhdGUpO1xufVxuXG5mdW5jdGlvbiBnZXRPcGVuWG1sTWltZVR5cGVGcm9tQ29udGVudFR5cGVzWG1sKHhtbENvbnRlbnQpIHtcblx0Ly8gV2Ugb25seSBuZWVkIHRoZSBgQ29udGVudFR5cGU9XCIuLi5tYWluK3htbFwiYCB2YWx1ZSwgc28gYSBzbWFsbCBzdHJpbmcgc2NhbiBpcyBlbm91Z2ggYW5kIGF2b2lkcyBmdWxsIFhNTCBwYXJzaW5nLlxuXHRjb25zdCBlbmRQb3NpdGlvbiA9IHhtbENvbnRlbnQuaW5kZXhPZignLm1haW4reG1sXCInKTtcblx0aWYgKGVuZFBvc2l0aW9uID09PSAtMSkge1xuXHRcdGNvbnN0IG1pbWVUeXBlID0gJ2FwcGxpY2F0aW9uL3ZuZC5tcy1wYWNrYWdlLjNkbWFudWZhY3R1cmluZy0zZG1vZGVsK3htbCc7XG5cdFx0aWYgKHhtbENvbnRlbnQuaW5jbHVkZXMoYENvbnRlbnRUeXBlPVwiJHttaW1lVHlwZX1cImApKSB7XG5cdFx0XHRyZXR1cm4gbWltZVR5cGU7XG5cdFx0fVxuXG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0Y29uc3QgdHJ1bmNhdGVkQ29udGVudCA9IHhtbENvbnRlbnQuc2xpY2UoMCwgZW5kUG9zaXRpb24pO1xuXHRjb25zdCBmaXJzdFF1b3RlUG9zaXRpb24gPSB0cnVuY2F0ZWRDb250ZW50Lmxhc3RJbmRleE9mKCdcIicpO1xuXHQvLyBJZiBubyBxdW90ZSBpcyBmb3VuZCwgYGxhc3RJbmRleE9mYCByZXR1cm5zIC0xIGFuZCB0aGlzIGludGVudGlvbmFsbHkgZmFsbHMgYmFjayB0byB0aGUgZnVsbCB0cnVuY2F0ZWQgcHJlZml4LlxuXHRyZXR1cm4gdHJ1bmNhdGVkQ29udGVudC5zbGljZShmaXJzdFF1b3RlUG9zaXRpb24gKyAxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGVjdFppcCh0b2tlbml6ZXIpIHtcblx0bGV0IGZpbGVUeXBlO1xuXHRjb25zdCBvcGVuWG1sU3RhdGUgPSBjcmVhdGVPcGVuWG1sWmlwRGV0ZWN0aW9uU3RhdGUoKTtcblx0Y29uc3QgaVdvcmtTdGF0ZSA9IGNyZWF0ZUlXb3JrWmlwRGV0ZWN0aW9uU3RhdGUoKTtcblxuXHR0cnkge1xuXHRcdGF3YWl0IG5ldyBaaXBIYW5kbGVyKHRva2VuaXplciwge1xuXHRcdFx0Ly8gS2VlcCBsb2NhbC1oZWFkZXIgb3JkZXIgYW5kIHBhcnRpYWwtYXJjaGl2ZSBkZXRlY3Rpb24gY29uc2lzdGVudCBhY3Jvc3MgaW5wdXQgdHlwZXMuXG5cdFx0XHR1c2VDZW50cmFsRGlyZWN0b3J5OiBmYWxzZSxcblx0XHRcdGFsbG93VHJ1bmNhdGVkRGF0YURlc2NyaXB0b3I6IHRydWUsXG5cdFx0XHRtYXhFbnRyeUNvdW50OiBtYXhpbXVtWmlwRW50cnlDb3VudCxcblx0XHRcdC8vIFVua25vd24tc2l6ZSBpbnB1dCBpcyBib3VuZGVkIGJlZm9yZSBlYWNoIHJlYWQsIGluY2x1ZGluZyBlbnRyeSBtZXRhZGF0YS5cblx0XHRcdG1heFRvdGFsU2NhbkJ5dGVzOiBoYXNVbmtub3duRmlsZVNpemUodG9rZW5pemVyKSA/IG1heGltdW1VbnRydXN0ZWRTa2lwU2l6ZUluQnl0ZXMgOiBJbmZpbml0eSxcblx0XHRcdG1heFRvdGFsRGF0YURlc2NyaXB0b3JTY2FuQnl0ZXM6IGhhc1Vua25vd25GaWxlU2l6ZSh0b2tlbml6ZXIpID8gSW5maW5pdHkgOiBtYXhpbXVtWmlwRW50cnlTaXplSW5CeXRlcyxcblx0XHRcdG1heFNraXBwZWRFbnRyeVNpemU6IGhhc1Vua25vd25GaWxlU2l6ZSh0b2tlbml6ZXIpID8gbWF4aW11bVppcEVudHJ5U2l6ZUluQnl0ZXMgOiBJbmZpbml0eSxcblx0XHRcdG1heERhdGFEZXNjcmlwdG9yU2NhbkJ5dGVzOiBtYXhpbXVtWmlwRW50cnlTaXplSW5CeXRlcyxcblx0XHRcdG1heENvbXByZXNzZWRTaXplOiBtYXhpbXVtWmlwVGV4dEVudHJ5U2l6ZUluQnl0ZXMsXG5cdFx0XHRtYXhVbmNvbXByZXNzZWRTaXplOiBtYXhpbXVtWmlwVGV4dEVudHJ5U2l6ZUluQnl0ZXMsXG5cdFx0fSkudW56aXAoemlwSGVhZGVyID0+IHtcblx0XHRcdHVwZGF0ZU9wZW5YbWxaaXBEZXRlY3Rpb25TdGF0ZUZyb21GaWxlbmFtZShvcGVuWG1sU3RhdGUsIHppcEhlYWRlci5maWxlbmFtZSk7XG5cdFx0XHR1cGRhdGVJV29ya1ppcERldGVjdGlvblN0YXRlRnJvbUZpbGVuYW1lKGlXb3JrU3RhdGUsIHppcEhlYWRlci5maWxlbmFtZSk7XG5cblx0XHRcdC8vIEVhcmx5IGV4aXQgZm9yIEtleW5vdGUgb3IgTnVtYmVycyB3aGVuIG1hcmtlcnMgYXJlIGRlZmluaXRpdmVcblx0XHRcdGlmIChpV29ya1N0YXRlLmhhc0RvY3VtZW50RW50cnkgJiYgKGlXb3JrU3RhdGUuaGFzTWFzdGVyU2xpZGVFbnRyeSB8fCBpV29ya1N0YXRlLmhhc1RhYmxlc0VudHJ5KSkge1xuXHRcdFx0XHRmaWxlVHlwZSA9IGdldElXb3JrRmlsZVR5cGVGcm9tWmlwRW50cmllcyhpV29ya1N0YXRlKTtcblx0XHRcdFx0cmV0dXJuIHtzdG9wOiB0cnVlfTtcblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgaXNPcGVuWG1sQ29udGVudFR5cGVzRW50cnkgPSB6aXBIZWFkZXIuZmlsZW5hbWUgPT09ICdbQ29udGVudF9UeXBlc10ueG1sJztcblx0XHRcdGNvbnN0IG9wZW5YbWxGaWxlVHlwZUZyb21FbnRyaWVzID0gZ2V0T3BlblhtbEZpbGVUeXBlRnJvbVppcEVudHJpZXMob3BlblhtbFN0YXRlKTtcblx0XHRcdGlmIChcblx0XHRcdFx0IWlzT3BlblhtbENvbnRlbnRUeXBlc0VudHJ5XG5cdFx0XHRcdCYmIG9wZW5YbWxGaWxlVHlwZUZyb21FbnRyaWVzXG5cdFx0XHQpIHtcblx0XHRcdFx0ZmlsZVR5cGUgPSBvcGVuWG1sRmlsZVR5cGVGcm9tRW50cmllcztcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRzdG9wOiB0cnVlLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHRzd2l0Y2ggKHppcEhlYWRlci5maWxlbmFtZSkge1xuXHRcdFx0XHRjYXNlICdNRVRBLUlORi9tb3ppbGxhLnJzYSc6XG5cdFx0XHRcdFx0ZmlsZVR5cGUgPSB7XG5cdFx0XHRcdFx0XHRleHQ6ICd4cGknLFxuXHRcdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gteHBpbnN0YWxsJyxcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRzdG9wOiB0cnVlLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgJ01FVEEtSU5GL01BTklGRVNULk1GJzpcblx0XHRcdFx0XHRmaWxlVHlwZSA9IHtcblx0XHRcdFx0XHRcdGV4dDogJ2phcicsXG5cdFx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vamF2YS1hcmNoaXZlJyxcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRzdG9wOiB0cnVlLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgJ21pbWV0eXBlJzpcblx0XHRcdFx0XHRpZiAoIWNhblJlYWRaaXBFbnRyeUZvckRldGVjdGlvbih6aXBIZWFkZXIsIG1heGltdW1aaXBUZXh0RW50cnlTaXplSW5CeXRlcykpIHtcblx0XHRcdFx0XHRcdHJldHVybiB7fTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0YXN5bmMgaGFuZGxlcihmaWxlRGF0YSkge1xuXHRcdFx0XHRcdFx0XHQvLyBVc2UgVGV4dERlY29kZXIgdG8gZGVjb2RlIHRoZSBVVEYtOCBlbmNvZGVkIGRhdGFcblx0XHRcdFx0XHRcdFx0Y29uc3QgbWltZVR5cGUgPSBuZXcgVGV4dERlY29kZXIoJ3V0Zi04JykuZGVjb2RlKGZpbGVEYXRhKS50cmltKCk7XG5cdFx0XHRcdFx0XHRcdGZpbGVUeXBlID0gZ2V0RmlsZVR5cGVGcm9tTWltZVR5cGUobWltZVR5cGUpO1xuXHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRcdHN0b3A6IHRydWUsXG5cdFx0XHRcdFx0fTtcblxuXHRcdFx0XHRjYXNlICdbQ29udGVudF9UeXBlc10ueG1sJzoge1xuXHRcdFx0XHRcdG9wZW5YbWxTdGF0ZS5oYXNDb250ZW50VHlwZXNFbnRyeSA9IHRydWU7XG5cblx0XHRcdFx0XHRpZiAoIWNhblJlYWRaaXBFbnRyeUZvckRldGVjdGlvbih6aXBIZWFkZXIsIG1heGltdW1aaXBUZXh0RW50cnlTaXplSW5CeXRlcykpIHtcblx0XHRcdFx0XHRcdG9wZW5YbWxTdGF0ZS5oYXNVbnBhcnNlYWJsZUNvbnRlbnRUeXBlcyA9IHRydWU7XG5cdFx0XHRcdFx0XHRyZXR1cm4ge307XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0b3BlblhtbFN0YXRlLmlzUGFyc2luZ0NvbnRlbnRUeXBlcyA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdGFzeW5jIGhhbmRsZXIoZmlsZURhdGEpIHtcblx0XHRcdFx0XHRcdFx0Ly8gVXNlIFRleHREZWNvZGVyIHRvIGRlY29kZSB0aGUgVVRGLTggZW5jb2RlZCBkYXRhXG5cdFx0XHRcdFx0XHRcdGNvbnN0IHhtbENvbnRlbnQgPSBuZXcgVGV4dERlY29kZXIoJ3V0Zi04JykuZGVjb2RlKGZpbGVEYXRhKTtcblx0XHRcdFx0XHRcdFx0Y29uc3QgbWltZVR5cGUgPSBnZXRPcGVuWG1sTWltZVR5cGVGcm9tQ29udGVudFR5cGVzWG1sKHhtbENvbnRlbnQpO1xuXHRcdFx0XHRcdFx0XHRpZiAobWltZVR5cGUpIHtcblx0XHRcdFx0XHRcdFx0XHRmaWxlVHlwZSA9IGdldEZpbGVUeXBlRnJvbU1pbWVUeXBlKG1pbWVUeXBlKTtcblx0XHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRcdG9wZW5YbWxTdGF0ZS5oYXNQYXJzZWRDb250ZW50VHlwZXNFbnRyeSA9IHRydWU7XG5cdFx0XHRcdFx0XHRcdG9wZW5YbWxTdGF0ZS5pc1BhcnNpbmdDb250ZW50VHlwZXMgPSBmYWxzZTtcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRzdG9wOiB0cnVlLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRkZWZhdWx0OlxuXHRcdFx0XHRcdGlmICgvY2xhc3Nlc1xcZCpcXC5kZXgvdi50ZXN0KHppcEhlYWRlci5maWxlbmFtZSkpIHtcblx0XHRcdFx0XHRcdGZpbGVUeXBlID0ge1xuXHRcdFx0XHRcdFx0XHRleHQ6ICdhcGsnLFxuXHRcdFx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vdm5kLmFuZHJvaWQucGFja2FnZS1hcmNoaXZlJyxcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRyZXR1cm4ge3N0b3A6IHRydWV9O1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiB7fTtcblx0XHRcdH1cblx0XHR9KTtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRpZiAoIWlzUmVjb3ZlcmFibGVaaXBFcnJvcihlcnJvcikpIHtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH1cblxuXHRcdGlmIChvcGVuWG1sU3RhdGUuaXNQYXJzaW5nQ29udGVudFR5cGVzKSB7XG5cdFx0XHRvcGVuWG1sU3RhdGUuaXNQYXJzaW5nQ29udGVudFR5cGVzID0gZmFsc2U7XG5cdFx0XHRvcGVuWG1sU3RhdGUuaGFzVW5wYXJzZWFibGVDb250ZW50VHlwZXMgPSB0cnVlO1xuXHRcdH1cblxuXHRcdC8vIFByb2R1Y2VycyBhcmUgZnJlZSB0byBwdXQgW0NvbnRlbnRfVHlwZXNdLnhtbCBhZnRlciB0aGUgY29udGVudCBlbnRyaWVzLCBzbyBydW5uaW5nIG91dCBvZlxuXHRcdC8vIGlucHV0IG9yIGJ1ZGdldCBiZWZvcmUgcmVhY2hpbmcgaXQgc2F5cyBub3RoaW5nIGFib3V0IHdoZXRoZXIgdGhpcyBpcyBhbiBPT1hNTCBmaWxlLlxuXHRcdC8vIEd1ZXNzIGZyb20gdGhlIGRpcmVjdG9yeSBuYW1lcyBpbnN0ZWFkLlxuXHRcdGlmIChcblx0XHRcdCFmaWxlVHlwZVxuXHRcdFx0JiYgKGVycm9yIGluc3RhbmNlb2Ygc3RydG9rMy5FbmRPZlN0cmVhbUVycm9yIHx8IGVycm9yIGluc3RhbmNlb2YgUGFyc2VySGFyZExpbWl0RXJyb3IgfHwgaXNaaXBTY2FuTGltaXRFcnJvcihlcnJvcikpXG5cdFx0XHQmJiAhb3BlblhtbFN0YXRlLmhhc0NvbnRlbnRUeXBlc0VudHJ5XG5cdFx0KSB7XG5cdFx0XHRmaWxlVHlwZSA9IGdldE9wZW5YbWxGaWxlVHlwZUZyb21EaXJlY3RvcnlOYW1lcyhvcGVuWG1sU3RhdGUpO1xuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGlXb3JrRmlsZVR5cGUgPSBoYXNVbmtub3duRmlsZVNpemUodG9rZW5pemVyKVxuXHRcdCYmIGlXb3JrU3RhdGUuaGFzRG9jdW1lbnRFbnRyeVxuXHRcdCYmICFpV29ya1N0YXRlLmhhc01hc3RlclNsaWRlRW50cnlcblx0XHQmJiAhaVdvcmtTdGF0ZS5oYXNUYWJsZXNFbnRyeVxuXHRcdCYmICFpV29ya1N0YXRlLmhhc0NhbGN1bGF0aW9uRW5naW5lRW50cnlcblx0XHQ/IHVuZGVmaW5lZFxuXHRcdDogZ2V0SVdvcmtGaWxlVHlwZUZyb21aaXBFbnRyaWVzKGlXb3JrU3RhdGUpO1xuXG5cdHJldHVybiBmaWxlVHlwZSA/PyBnZXRPcGVuWG1sRmlsZVR5cGVGcm9tWmlwRW50cmllcyhvcGVuWG1sU3RhdGUpID8/IGlXb3JrRmlsZVR5cGUgPz8ge1xuXHRcdGV4dDogJ3ppcCcsXG5cdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ppcCcsXG5cdH07XG59XG4iLCJpbXBvcnQgKiBhcyBUb2tlbiBmcm9tICd0b2tlbi10eXBlcyc7XG5pbXBvcnQge2NyZWF0ZVRva2VuaXplclZpZXcsIFRva2VuaXplckJvdW5kYXJ5RXJyb3J9IGZyb20gJ3N0cnRvazMvY29yZSc7XG5pbXBvcnQge2dldFVpbnRCRX0gZnJvbSAndWludDhhcnJheS1leHRyYXMnO1xuaW1wb3J0IHtcblx0bWF4aW11bVVudHJ1c3RlZFNraXBTaXplSW5CeXRlcyxcblx0Z2V0U2FmZUJvdW5kLFxuXHRzYWZlUmVhZEJ1ZmZlcixcblx0c2FmZUlnbm9yZSxcblx0aGFzVW5rbm93bkZpbGVTaXplLFxuXHRoYXNFeGNlZWRlZFVua25vd25TaXplU2NhbkJ1ZGdldCxcbn0gZnJvbSAnLi4vcGFyc2VyLmpzJztcblxuY29uc3QgbWF4aW11bUVibWxEb2N1bWVudFR5cGVTaXplSW5CeXRlcyA9IDY0O1xuY29uc3QgbWF4aW11bUVibWxFbGVtZW50UGF5bG9hZFNpemVJbkJ5dGVzID0gMTAyNCAqIDEwMjQ7XG5jb25zdCBtYXhpbXVtRWJtbEVsZW1lbnRDb3VudCA9IDI1NjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGVjdEVibWwodG9rZW5pemVyKSB7XG5cdGFzeW5jIGZ1bmN0aW9uIHJlYWRGaWVsZChpbnB1dCkge1xuXHRcdGNvbnN0IG1zYiA9IGF3YWl0IGlucHV0LnBlZWtOdW1iZXIoVG9rZW4uVUlOVDgpO1xuXHRcdGxldCBtYXNrID0gMHg4MDtcblx0XHRsZXQgaWMgPSAwOyAvLyAwID0gQSwgMSA9IEIsIDIgPSBDLCAzID0gRFxuXG5cdFx0d2hpbGUgKG1hc2sgIT09IDAgJiYgKG1zYiAmIG1hc2spID09PSAwKSB7XG5cdFx0XHQrK2ljO1xuXHRcdFx0bWFzayA+Pj0gMTtcblx0XHR9XG5cblx0XHRjb25zdCBpZCA9IG5ldyBVaW50OEFycmF5KGljICsgMSk7XG5cdFx0YXdhaXQgc2FmZVJlYWRCdWZmZXIoaW5wdXQsIGlkLCB1bmRlZmluZWQsIHtcblx0XHRcdG1heGltdW1MZW5ndGg6IGlkLmxlbmd0aCxcblx0XHRcdHJlYXNvbjogJ0VCTUwgZmllbGQnLFxuXHRcdH0pO1xuXHRcdHJldHVybiBpZDtcblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIHJlYWRFbGVtZW50KGlucHV0KSB7XG5cdFx0Y29uc3QgaWRGaWVsZCA9IGF3YWl0IHJlYWRGaWVsZChpbnB1dCk7XG5cdFx0Y29uc3QgbGVuZ3RoRmllbGQgPSBhd2FpdCByZWFkRmllbGQoaW5wdXQpO1xuXG5cdFx0bGVuZ3RoRmllbGRbMF0gXj0gMHg4MCA+PiAobGVuZ3RoRmllbGQubGVuZ3RoIC0gMSk7XG5cdFx0Y29uc3QgbnJMZW5ndGggPSBNYXRoLm1pbig2LCBsZW5ndGhGaWVsZC5sZW5ndGgpOyAvLyBKYXZhU2NyaXB0IGNhbiBtYXggcmVhZCA2IGJ5dGVzIGludGVnZXJcblxuXHRcdGNvbnN0IGlkVmlldyA9IG5ldyBEYXRhVmlldyhpZEZpZWxkLmJ1ZmZlcik7XG5cdFx0Y29uc3QgbGVuZ3RoVmlldyA9IG5ldyBEYXRhVmlldyhsZW5ndGhGaWVsZC5idWZmZXIsIGxlbmd0aEZpZWxkLmxlbmd0aCAtIG5yTGVuZ3RoLCBuckxlbmd0aCk7XG5cblx0XHRyZXR1cm4ge1xuXHRcdFx0aWQ6IGdldFVpbnRCRShpZFZpZXcpLFxuXHRcdFx0bGVuOiBnZXRVaW50QkUobGVuZ3RoVmlldyksXG5cdFx0fTtcblx0fVxuXG5cdGNvbnN0IGlzVW5rbm93bkZpbGVTaXplID0gaGFzVW5rbm93bkZpbGVTaXplKHRva2VuaXplcik7XG5cblx0YXN5bmMgZnVuY3Rpb24gcmVhZENoaWxkcmVuKGhlYWRlcikge1xuXHRcdGxldCBlYm1sRWxlbWVudENvdW50ID0gMDtcblx0XHR3aGlsZSAoaGVhZGVyLnJlbWFpbmluZyA+IDApIHtcblx0XHRcdGVibWxFbGVtZW50Q291bnQrKztcblx0XHRcdGlmIChlYm1sRWxlbWVudENvdW50ID4gbWF4aW11bUVibWxFbGVtZW50Q291bnQpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoaGFzRXhjZWVkZWRVbmtub3duU2l6ZVNjYW5CdWRnZXQodG9rZW5pemVyLCBlYm1sU2NhblN0YXJ0LCBtYXhpbXVtVW50cnVzdGVkU2tpcFNpemVJbkJ5dGVzKSkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHByZXZpb3VzUG9zaXRpb24gPSB0b2tlbml6ZXIucG9zaXRpb247XG5cdFx0XHRjb25zdCBlbGVtZW50ID0gYXdhaXQgcmVhZEVsZW1lbnQoaGVhZGVyKTtcblxuXHRcdFx0aWYgKGVsZW1lbnQuaWQgPT09IDB4NDJfODIpIHtcblx0XHRcdFx0Ly8gYERvY1R5cGVgIGlzIGEgc2hvcnQgc3RyaW5nIChcIndlYm1cIiwgXCJtYXRyb3NrYVwiLCAuLi4pLCByZWplY3QgaW1wbGF1c2libGUgbGVuZ3RocyB0byBhdm9pZCBsYXJnZSBhbGxvY2F0aW9ucy5cblx0XHRcdFx0aWYgKGVsZW1lbnQubGVuID4gbWF4aW11bUVibWxEb2N1bWVudFR5cGVTaXplSW5CeXRlcykge1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IGRvY3VtZW50VHlwZUxlbmd0aCA9IGdldFNhZmVCb3VuZChlbGVtZW50LmxlbiwgbWF4aW11bUVibWxEb2N1bWVudFR5cGVTaXplSW5CeXRlcywgJ0VCTUwgRG9jVHlwZScpO1xuXHRcdFx0XHRjb25zdCByYXdWYWx1ZSA9IGF3YWl0IGhlYWRlci5yZWFkVG9rZW4obmV3IFRva2VuLlN0cmluZ1R5cGUoZG9jdW1lbnRUeXBlTGVuZ3RoKSk7XG5cdFx0XHRcdHJldHVybiByYXdWYWx1ZS5zcGxpdCgnXFwwJywgMSlbMF07IC8vIFJldHVybiBEb2NUeXBlXG5cdFx0XHR9XG5cblx0XHRcdGlmIChcblx0XHRcdFx0aXNVbmtub3duRmlsZVNpemVcblx0XHRcdFx0JiYgKFxuXHRcdFx0XHRcdCFOdW1iZXIuaXNGaW5pdGUoZWxlbWVudC5sZW4pXG5cdFx0XHRcdFx0fHwgZWxlbWVudC5sZW4gPCAwXG5cdFx0XHRcdFx0fHwgZWxlbWVudC5sZW4gPiBtYXhpbXVtRWJtbEVsZW1lbnRQYXlsb2FkU2l6ZUluQnl0ZXNcblx0XHRcdFx0KVxuXHRcdFx0KSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0YXdhaXQgc2FmZUlnbm9yZShoZWFkZXIsIGVsZW1lbnQubGVuLCB7XG5cdFx0XHRcdG1heGltdW1MZW5ndGg6IGlzVW5rbm93bkZpbGVTaXplID8gbWF4aW11bUVibWxFbGVtZW50UGF5bG9hZFNpemVJbkJ5dGVzIDogdG9rZW5pemVyLmZpbGVJbmZvLnNpemUsXG5cdFx0XHRcdHJlYXNvbjogJ0VCTUwgcGF5bG9hZCcsXG5cdFx0XHR9KTsgLy8gaWdub3JlIHBheWxvYWRcblxuXHRcdFx0Ly8gU2FmZWd1YXJkIGFnYWluc3QgbWFsZm9ybWVkIGZpbGVzOiBiYWlsIGlmIHRoZSBwb3NpdGlvbiBkaWQgbm90IGFkdmFuY2UuXG5cdFx0XHRpZiAodG9rZW5pemVyLnBvc2l0aW9uIDw9IHByZXZpb3VzUG9zaXRpb24pIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IHJvb3RFbGVtZW50ID0gYXdhaXQgcmVhZEVsZW1lbnQodG9rZW5pemVyKTtcblx0Y29uc3QgZWJtbFNjYW5TdGFydCA9IHRva2VuaXplci5wb3NpdGlvbjtcblx0Y29uc3QgaGVhZGVyID0gY3JlYXRlVG9rZW5pemVyVmlldyh0b2tlbml6ZXIsIHJvb3RFbGVtZW50Lmxlbik7XG5cdGxldCBkb2N1bWVudFR5cGU7XG5cdHRyeSB7XG5cdFx0ZG9jdW1lbnRUeXBlID0gYXdhaXQgcmVhZENoaWxkcmVuKGhlYWRlcik7XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgVG9rZW5pemVyQm91bmRhcnlFcnJvcikge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdHRocm93IGVycm9yO1xuXHR9IGZpbmFsbHkge1xuXHRcdC8vIERldGVjdGlvbiBjYW4gc3RvcCBhdCBEb2NUeXBlOyBkbyBub3QgZHJhaW4gdGhlIHJlc3Qgb3IgY2xvc2UgdGhlIHNvdXJjZS5cblx0XHRhd2FpdCBoZWFkZXIuY2xvc2UoKTtcblx0fVxuXG5cdHN3aXRjaCAoZG9jdW1lbnRUeXBlKSB7XG5cdFx0Y2FzZSAnd2VibSc6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICd3ZWJtJyxcblx0XHRcdFx0bWltZTogJ3ZpZGVvL3dlYm0nLFxuXHRcdFx0fTtcblxuXHRcdGNhc2UgJ21hdHJvc2thJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ21rdicsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby9tYXRyb3NrYScsXG5cdFx0XHR9O1xuXG5cdFx0ZGVmYXVsdDpcblx0fVxufVxuIiwiaW1wb3J0ICogYXMgVG9rZW4gZnJvbSAndG9rZW4tdHlwZXMnO1xuaW1wb3J0ICogYXMgc3RydG9rMyBmcm9tICdzdHJ0b2szL2NvcmUnO1xuaW1wb3J0IHtcblx0UGFyc2VySGFyZExpbWl0RXJyb3IsXG5cdHNhZmVJZ25vcmUsXG5cdGhhc1Vua25vd25GaWxlU2l6ZSxcblx0aGFzRXhjZWVkZWRVbmtub3duU2l6ZVNjYW5CdWRnZXQsXG59IGZyb20gJy4uL3BhcnNlci5qcyc7XG5cbmNvbnN0IG1heGltdW1QbmdDaHVua0NvdW50ID0gNTEyO1xuY29uc3QgbWF4aW11bVBuZ1N0cmVhbVNjYW5CdWRnZXRJbkJ5dGVzID0gMTYgKiAxMDI0ICogMTAyNDtcbmNvbnN0IG1heGltdW1QbmdDaHVua1NpemVJbkJ5dGVzID0gMTAyNCAqIDEwMjQ7XG5cbmZ1bmN0aW9uIGlzUG5nQW5jaWxsYXJ5Q2h1bmsodHlwZSkge1xuXHRyZXR1cm4gKHR5cGUuY29kZVBvaW50QXQoMCkgJiAweDIwKSAhPT0gMDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGVjdFBuZyh0b2tlbml6ZXIpIHtcblx0Y29uc3QgcG5nRmlsZVR5cGUgPSB7XG5cdFx0ZXh0OiAncG5nJyxcblx0XHRtaW1lOiAnaW1hZ2UvcG5nJyxcblx0fTtcblxuXHRjb25zdCBhcG5nRmlsZVR5cGUgPSB7XG5cdFx0ZXh0OiAnYXBuZycsXG5cdFx0bWltZTogJ2ltYWdlL2FwbmcnLFxuXHR9O1xuXG5cdC8vIEFQTkcgZm9ybWF0IChodHRwczovL3dpa2kubW96aWxsYS5vcmcvQVBOR19TcGVjaWZpY2F0aW9uKVxuXHQvLyAxLiBGaW5kIHRoZSBmaXJzdCBJREFUIChpbWFnZSBkYXRhKSBjaHVuayAoNDkgNDQgNDEgNTQpXG5cdC8vIDIuIENoZWNrIGlmIHRoZXJlIGlzIGFuIFwiYWNUTFwiIGNodW5rIGJlZm9yZSB0aGUgSURBVCBvbmUgKDYxIDYzIDU0IDRDKVxuXG5cdC8vIE9mZnNldCBjYWxjdWxhdGVkIGFzIGZvbGxvd3M6XG5cdC8vIC0gOCBieXRlczogUE5HIHNpZ25hdHVyZVxuXHQvLyAtIDQgKGxlbmd0aCkgKyA0IChjaHVuayB0eXBlKSArIDEzIChjaHVuayBkYXRhKSArIDQgKENSQyk6IElIRFIgY2h1bmtcblxuXHRhd2FpdCB0b2tlbml6ZXIuaWdub3JlKDgpOyAvLyBpZ25vcmUgUE5HIHNpZ25hdHVyZVxuXG5cdGFzeW5jIGZ1bmN0aW9uIHJlYWRDaHVua0hlYWRlcigpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0bGVuZ3RoOiBhd2FpdCB0b2tlbml6ZXIucmVhZFRva2VuKFRva2VuLklOVDMyX0JFKSxcblx0XHRcdHR5cGU6IGF3YWl0IHRva2VuaXplci5yZWFkVG9rZW4obmV3IFRva2VuLlN0cmluZ1R5cGUoNCwgJ2xhdGluMScpKSxcblx0XHR9O1xuXHR9XG5cblx0Y29uc3QgaXNVbmtub3duUG5nU3RyZWFtID0gaGFzVW5rbm93bkZpbGVTaXplKHRva2VuaXplcik7XG5cdGNvbnN0IHBuZ1NjYW5TdGFydCA9IHRva2VuaXplci5wb3NpdGlvbjtcblx0bGV0IHBuZ0NodW5rQ291bnQgPSAwO1xuXHRsZXQgaGFzU2VlbkltYWdlSGVhZGVyID0gZmFsc2U7XG5cdGRvIHtcblx0XHRwbmdDaHVua0NvdW50Kys7XG5cdFx0aWYgKHBuZ0NodW5rQ291bnQgPiBtYXhpbXVtUG5nQ2h1bmtDb3VudCkge1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXG5cdFx0aWYgKGhhc0V4Y2VlZGVkVW5rbm93blNpemVTY2FuQnVkZ2V0KHRva2VuaXplciwgcG5nU2NhblN0YXJ0LCBtYXhpbXVtUG5nU3RyZWFtU2NhbkJ1ZGdldEluQnl0ZXMpKSB7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cblx0XHRjb25zdCBwcmV2aW91c1Bvc2l0aW9uID0gdG9rZW5pemVyLnBvc2l0aW9uO1xuXHRcdGNvbnN0IGNodW5rID0gYXdhaXQgcmVhZENodW5rSGVhZGVyKCk7XG5cdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHVuaWNvcm4vbm8taW1wb3NzaWJsZS1sZW5ndGgtY29tcGFyaXNvbiAtLSBUaGUgbGVuZ3RoIGlzIHJlYWQgYXMgYSBzaWduZWQgMzItYml0IGludGVnZXIuXG5cdFx0aWYgKGNodW5rLmxlbmd0aCA8IDApIHtcblx0XHRcdHJldHVybjsgLy8gSW52YWxpZCBjaHVuayBsZW5ndGhcblx0XHR9XG5cblx0XHRpZiAoY2h1bmsudHlwZSA9PT0gJ0lIRFInKSB7XG5cdFx0XHQvLyBQTkcgcmVxdWlyZXMgdGhlIGZpcnN0IHJlYWwgaW1hZ2UgaGVhZGVyIHRvIGJlIGEgMTMtYnl0ZSBJSERSIGNodW5rLlxuXHRcdFx0aWYgKGNodW5rLmxlbmd0aCAhPT0gMTMpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHRoYXNTZWVuSW1hZ2VIZWFkZXIgPSB0cnVlO1xuXHRcdH1cblxuXHRcdHN3aXRjaCAoY2h1bmsudHlwZSkge1xuXHRcdFx0Y2FzZSAnSURBVCc6XG5cdFx0XHRcdHJldHVybiBwbmdGaWxlVHlwZTtcblx0XHRcdGNhc2UgJ2FjVEwnOlxuXHRcdFx0XHRyZXR1cm4gYXBuZ0ZpbGVUeXBlO1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdCFoYXNTZWVuSW1hZ2VIZWFkZXJcblx0XHRcdFx0XHQmJiBjaHVuay50eXBlICE9PSAnQ2dCSSdcblx0XHRcdFx0KSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdGlzVW5rbm93blBuZ1N0cmVhbVxuXHRcdFx0XHRcdCYmIGNodW5rLmxlbmd0aCA+IG1heGltdW1QbmdDaHVua1NpemVJbkJ5dGVzXG5cdFx0XHRcdCkge1xuXHRcdFx0XHRcdC8vIEF2b2lkIGh1Z2UgYXR0YWNrZXItY29udHJvbGxlZCBza2lwcyB3aGVuIHByb2JpbmcgdW5rbm93bi1zaXplIHN0cmVhbXMuXG5cdFx0XHRcdFx0cmV0dXJuIGhhc1NlZW5JbWFnZUhlYWRlciAmJiBpc1BuZ0FuY2lsbGFyeUNodW5rKGNodW5rLnR5cGUpID8gcG5nRmlsZVR5cGUgOiB1bmRlZmluZWQ7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGF3YWl0IHNhZmVJZ25vcmUodG9rZW5pemVyLCBjaHVuay5sZW5ndGggKyA0LCB7XG5cdFx0XHRcdFx0XHRtYXhpbXVtTGVuZ3RoOiBpc1Vua25vd25QbmdTdHJlYW0gPyBtYXhpbXVtUG5nQ2h1bmtTaXplSW5CeXRlcyArIDQgOiB0b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSxcblx0XHRcdFx0XHRcdHJlYXNvbjogJ1BORyBjaHVuayBwYXlsb2FkJyxcblx0XHRcdFx0XHR9KTsgLy8gSWdub3JlIGNodW5rLWRhdGEgKyBDUkNcblx0XHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0XHRpZiAoXG5cdFx0XHRcdFx0XHQhaXNVbmtub3duUG5nU3RyZWFtXG5cdFx0XHRcdFx0XHQmJiAoXG5cdFx0XHRcdFx0XHRcdGVycm9yIGluc3RhbmNlb2YgUGFyc2VySGFyZExpbWl0RXJyb3Jcblx0XHRcdFx0XHRcdFx0fHwgZXJyb3IgaW5zdGFuY2VvZiBzdHJ0b2szLkVuZE9mU3RyZWFtRXJyb3Jcblx0XHRcdFx0XHRcdClcblx0XHRcdFx0XHQpIHtcblx0XHRcdFx0XHRcdHJldHVybiBwbmdGaWxlVHlwZTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIFNhZmVndWFyZCBhZ2FpbnN0IG1hbGZvcm1lZCBmaWxlczogYmFpbCBpZiB0aGUgcG9zaXRpb24gZGlkIG5vdCBhZHZhbmNlLlxuXHRcdGlmICh0b2tlbml6ZXIucG9zaXRpb24gPD0gcHJldmlvdXNQb3NpdGlvbikge1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9IHdoaWxlICh0b2tlbml6ZXIucG9zaXRpb24gKyA4IDwgdG9rZW5pemVyLmZpbGVJbmZvLnNpemUpO1xuXG5cdHJldHVybiBwbmdGaWxlVHlwZTtcbn1cbiIsImltcG9ydCAqIGFzIFRva2VuIGZyb20gJ3Rva2VuLXR5cGVzJztcbmltcG9ydCAqIGFzIHN0cnRvazMgZnJvbSAnc3RydG9rMy9jb3JlJztcbmltcG9ydCB7XG5cdG1heGltdW1VbnRydXN0ZWRTa2lwU2l6ZUluQnl0ZXMsXG5cdFBhcnNlckhhcmRMaW1pdEVycm9yLFxuXHRjaGVja0J5dGVzLFxuXHRzYWZlUmVhZEJ1ZmZlcixcblx0c2FmZUlnbm9yZSxcblx0aGFzVW5rbm93bkZpbGVTaXplLFxuXHRoYXNFeGNlZWRlZFVua25vd25TaXplU2NhbkJ1ZGdldCxcbn0gZnJvbSAnLi4vcGFyc2VyLmpzJztcblxuY29uc3QgbWF4aW11bUFzZkhlYWRlck9iamVjdENvdW50ID0gNTEyO1xuY29uc3QgbWF4aW11bUFzZkhlYWRlclBheWxvYWRTaXplSW5CeXRlcyA9IDEwMjQgKiAxMDI0O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGV0ZWN0QXNmKHRva2VuaXplcikge1xuXHRsZXQgaXNNYWxmb3JtZWRBc2YgPSBmYWxzZTtcblx0dHJ5IHtcblx0XHRhc3luYyBmdW5jdGlvbiByZWFkSGVhZGVyKCkge1xuXHRcdFx0Y29uc3QgZ3VpZCA9IG5ldyBVaW50OEFycmF5KDE2KTtcblx0XHRcdGF3YWl0IHNhZmVSZWFkQnVmZmVyKHRva2VuaXplciwgZ3VpZCwgdW5kZWZpbmVkLCB7XG5cdFx0XHRcdG1heGltdW1MZW5ndGg6IGd1aWQubGVuZ3RoLFxuXHRcdFx0XHRyZWFzb246ICdBU0YgaGVhZGVyIEdVSUQnLFxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRpZDogZ3VpZCxcblx0XHRcdFx0c2l6ZTogTnVtYmVyKGF3YWl0IHRva2VuaXplci5yZWFkVG9rZW4oVG9rZW4uVUlOVDY0X0xFKSksXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGF3YWl0IHNhZmVJZ25vcmUodG9rZW5pemVyLCAzMCwge1xuXHRcdFx0bWF4aW11bUxlbmd0aDogMzAsXG5cdFx0XHRyZWFzb246ICdBU0YgaGVhZGVyIHByZWx1ZGUnLFxuXHRcdH0pO1xuXHRcdGNvbnN0IGlzVW5rbm93bkZpbGVTaXplID0gaGFzVW5rbm93bkZpbGVTaXplKHRva2VuaXplcik7XG5cdFx0Y29uc3QgYXNmSGVhZGVyU2NhblN0YXJ0ID0gdG9rZW5pemVyLnBvc2l0aW9uO1xuXHRcdGxldCBhc2ZIZWFkZXJPYmplY3RDb3VudCA9IDA7XG5cdFx0d2hpbGUgKHRva2VuaXplci5wb3NpdGlvbiArIDI0IDwgdG9rZW5pemVyLmZpbGVJbmZvLnNpemUpIHtcblx0XHRcdGFzZkhlYWRlck9iamVjdENvdW50Kys7XG5cdFx0XHRpZiAoYXNmSGVhZGVyT2JqZWN0Q291bnQgPiBtYXhpbXVtQXNmSGVhZGVyT2JqZWN0Q291bnQpIHtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChoYXNFeGNlZWRlZFVua25vd25TaXplU2NhbkJ1ZGdldCh0b2tlbml6ZXIsIGFzZkhlYWRlclNjYW5TdGFydCwgbWF4aW11bVVudHJ1c3RlZFNraXBTaXplSW5CeXRlcykpIHtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHByZXZpb3VzUG9zaXRpb24gPSB0b2tlbml6ZXIucG9zaXRpb247XG5cdFx0XHRjb25zdCBoZWFkZXIgPSBhd2FpdCByZWFkSGVhZGVyKCk7XG5cdFx0XHRsZXQgcGF5bG9hZCA9IGhlYWRlci5zaXplIC0gMjQ7XG5cdFx0XHRpZiAoXG5cdFx0XHRcdCFOdW1iZXIuaXNGaW5pdGUocGF5bG9hZClcblx0XHRcdFx0fHwgcGF5bG9hZCA8IDBcblx0XHRcdCkge1xuXHRcdFx0XHRpc01hbGZvcm1lZEFzZiA9IHRydWU7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoY2hlY2tCeXRlcyhoZWFkZXIuaWQsIFsweDkxLCAweDA3LCAweERDLCAweEI3LCAweEI3LCAweEE5LCAweENGLCAweDExLCAweDhFLCAweEU2LCAweDAwLCAweEMwLCAweDBDLCAweDIwLCAweDUzLCAweDY1XSkpIHtcblx0XHRcdFx0Ly8gU3luYyBvbiBTdHJlYW0tUHJvcGVydGllcy1PYmplY3QgKEI3REMwNzkxLUE5QjctMTFDRi04RUU2LTAwQzAwQzIwNTM2NSlcblx0XHRcdFx0Y29uc3QgdHlwZUlkID0gbmV3IFVpbnQ4QXJyYXkoMTYpO1xuXHRcdFx0XHRwYXlsb2FkIC09IGF3YWl0IHNhZmVSZWFkQnVmZmVyKHRva2VuaXplciwgdHlwZUlkLCB1bmRlZmluZWQsIHtcblx0XHRcdFx0XHRtYXhpbXVtTGVuZ3RoOiB0eXBlSWQubGVuZ3RoLFxuXHRcdFx0XHRcdHJlYXNvbjogJ0FTRiBzdHJlYW0gdHlwZSBHVUlEJyxcblx0XHRcdFx0fSk7XG5cblx0XHRcdFx0aWYgKGNoZWNrQnl0ZXModHlwZUlkLCBbMHg0MCwgMHg5RSwgMHg2OSwgMHhGOCwgMHg0RCwgMHg1QiwgMHhDRiwgMHgxMSwgMHhBOCwgMHhGRCwgMHgwMCwgMHg4MCwgMHg1RiwgMHg1QywgMHg0NCwgMHgyQl0pKSB7XG5cdFx0XHRcdFx0Ly8gRm91bmQgYXVkaW86XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdGV4dDogJ2FzZicsXG5cdFx0XHRcdFx0XHRtaW1lOiAnYXVkaW8veC1tcy1hc2YnLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoY2hlY2tCeXRlcyh0eXBlSWQsIFsweEMwLCAweEVGLCAweDE5LCAweEJDLCAweDRELCAweDVCLCAweENGLCAweDExLCAweEE4LCAweEZELCAweDAwLCAweDgwLCAweDVGLCAweDVDLCAweDQ0LCAweDJCXSkpIHtcblx0XHRcdFx0XHQvLyBGb3VuZCB2aWRlbzpcblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0ZXh0OiAnYXNmJyxcblx0XHRcdFx0XHRcdG1pbWU6ICd2aWRlby94LW1zLWFzZicsXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoXG5cdFx0XHRcdGlzVW5rbm93bkZpbGVTaXplXG5cdFx0XHRcdCYmIHBheWxvYWQgPiBtYXhpbXVtQXNmSGVhZGVyUGF5bG9hZFNpemVJbkJ5dGVzXG5cdFx0XHQpIHtcblx0XHRcdFx0aXNNYWxmb3JtZWRBc2YgPSB0cnVlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblxuXHRcdFx0YXdhaXQgc2FmZUlnbm9yZSh0b2tlbml6ZXIsIHBheWxvYWQsIHtcblx0XHRcdFx0bWF4aW11bUxlbmd0aDogaXNVbmtub3duRmlsZVNpemUgPyBtYXhpbXVtQXNmSGVhZGVyUGF5bG9hZFNpemVJbkJ5dGVzIDogdG9rZW5pemVyLmZpbGVJbmZvLnNpemUsXG5cdFx0XHRcdHJlYXNvbjogJ0FTRiBoZWFkZXIgcGF5bG9hZCcsXG5cdFx0XHR9KTtcblxuXHRcdFx0Ly8gU2FmZWd1YXJkIGFnYWluc3QgbWFsZm9ybWVkIGZpbGVzOiBicmVhayBpZiB0aGUgcG9zaXRpb24gZGlkIG5vdCBhZHZhbmNlLlxuXHRcdFx0aWYgKHRva2VuaXplci5wb3NpdGlvbiA8PSBwcmV2aW91c1Bvc2l0aW9uKSB7XG5cdFx0XHRcdGlzTWFsZm9ybWVkQXNmID0gdHJ1ZTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGlmIChcblx0XHRcdGVycm9yIGluc3RhbmNlb2Ygc3RydG9rMy5FbmRPZlN0cmVhbUVycm9yXG5cdFx0XHR8fCBlcnJvciBpbnN0YW5jZW9mIFBhcnNlckhhcmRMaW1pdEVycm9yXG5cdFx0KSB7XG5cdFx0XHRpZiAoaGFzVW5rbm93bkZpbGVTaXplKHRva2VuaXplcikpIHtcblx0XHRcdFx0aXNNYWxmb3JtZWRBc2YgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdH1cblxuXHRpZiAoaXNNYWxmb3JtZWRBc2YpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHQvLyBEZWZhdWx0IHRvIEFTRiBnZW5lcmljIGV4dGVuc2lvblxuXHRyZXR1cm4ge1xuXHRcdGV4dDogJ2FzZicsXG5cdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5tcy1hc2YnLFxuXHR9O1xufVxuIiwiLyoqXG5QcmltYXJ5IGVudHJ5IHBvaW50LCBOb2RlLmpzIHNwZWNpZmljIGVudHJ5IHBvaW50IGlzIGluZGV4LmpzXG4qL1xuXG5pbXBvcnQgKiBhcyBUb2tlbiBmcm9tICd0b2tlbi10eXBlcyc7XG5pbXBvcnQgKiBhcyBzdHJ0b2szIGZyb20gJ3N0cnRvazMvY29yZSc7XG5pbXBvcnQge0d6aXBIYW5kbGVyfSBmcm9tICdAdG9rZW5pemVyL2luZmxhdGUnO1xuaW1wb3J0IHtjb25jYXRVaW50OEFycmF5c30gZnJvbSAndWludDhhcnJheS1leHRyYXMnO1xuaW1wb3J0IHtcblx0c3RyaW5nVG9CeXRlcyxcblx0dGFySGVhZGVyQ2hlY2tzdW1NYXRjaGVzLFxuXHR1aW50MzJTeW5jU2FmZVRva2VuLFxufSBmcm9tICcuL3Rva2Vucy5qcyc7XG5pbXBvcnQge2V4dGVuc2lvbnMsIG1pbWVUeXBlc30gZnJvbSAnLi9zdXBwb3J0ZWQuanMnO1xuaW1wb3J0IHtcblx0bWF4aW11bVVudHJ1c3RlZFNraXBTaXplSW5CeXRlcyxcblx0UGFyc2VySGFyZExpbWl0RXJyb3IsXG5cdHNhZmVJZ25vcmUsXG5cdGNoZWNrQnl0ZXMsXG5cdGhhc1Vua25vd25GaWxlU2l6ZSxcbn0gZnJvbSAnLi9wYXJzZXIuanMnO1xuaW1wb3J0IHtkZXRlY3RaaXB9IGZyb20gJy4vZGV0ZWN0b3JzL3ppcC5qcyc7XG5pbXBvcnQge2RldGVjdEVibWx9IGZyb20gJy4vZGV0ZWN0b3JzL2VibWwuanMnO1xuaW1wb3J0IHtkZXRlY3RQbmd9IGZyb20gJy4vZGV0ZWN0b3JzL3BuZy5qcyc7XG5pbXBvcnQge2RldGVjdEFzZn0gZnJvbSAnLi9kZXRlY3RvcnMvYXNmLmpzJztcblxuZXhwb3J0IGNvbnN0IHJlYXNvbmFibGVEZXRlY3Rpb25TaXplSW5CeXRlcyA9IDQxMDA7IC8vIEEgZmFpciBhbW91bnQgb2YgZmlsZS10eXBlcyBhcmUgZGV0ZWN0YWJsZSB3aXRoaW4gdGhpcyByYW5nZS5cbmNvbnN0IG1heGltdW1NcGVnT2Zmc2V0VG9sZXJhbmNlID0gcmVhc29uYWJsZURldGVjdGlvblNpemVJbkJ5dGVzIC0gNDsgLy8gS2VlcCByb29tIGZvciB0aGUgNCBieXRlcyBvZiB0aGUgZnJhbWUgaGVhZGVyIGF0IHRoZSBkZWVwZXN0IHNjYW5uZWQgb2Zmc2V0LlxuY29uc3QgbWF4aW11bU5lc3RlZEd6aXBEZXRlY3Rpb25TaXplSW5CeXRlcyA9IG1heGltdW1VbnRydXN0ZWRTa2lwU2l6ZUluQnl0ZXM7XG5jb25zdCBtYXhpbXVtTmVzdGVkR3ppcFByb2JlRGVwdGggPSAxO1xuY29uc3QgdW5rbm93blNpemVHemlwUHJvYmVUaW1lb3V0SW5NaWxsaXNlY29uZHMgPSAxMDA7XG5jb25zdCBtYXhpbXVtSWQzSGVhZGVyU2l6ZUluQnl0ZXMgPSBtYXhpbXVtVW50cnVzdGVkU2tpcFNpemVJbkJ5dGVzO1xuY29uc3QgbWF4aW11bVRpZmZUYWdDb3VudCA9IDUxMjtcbmNvbnN0IG1heGltdW1EZXRlY3Rpb25SZWVudHJ5Q291bnQgPSAyNTY7XG5jb25zdCBtYXhpbXVtVGlmZlN0cmVhbUlmZE9mZnNldEluQnl0ZXMgPSAxMDI0ICogMTAyNDtcbmNvbnN0IG1heGltdW1UaWZmSWZkT2Zmc2V0SW5CeXRlcyA9IG1heGltdW1VbnRydXN0ZWRTa2lwU2l6ZUluQnl0ZXM7XG5cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVTYW1wbGVTaXplKHNhbXBsZVNpemUpIHtcblx0Ly8gYHNhbXBsZVNpemVgIGlzIGFuIGV4cGxpY2l0IGNhbGxlci1jb250cm9sbGVkIHR1bmluZyBrbm9iLCBub3QgdW50cnVzdGVkIGZpbGUgaW5wdXQuXG5cdC8vIFByZXNlcnZlIHZhbGlkIGNhbGxlci1yZXF1ZXN0ZWQgcHJvYmUgZGVwdGggaGVyZTsgYXBwbGljYXRpb25zIG11c3QgYm91bmQgYXR0YWNrZXItZGVyaXZlZCBvcHRpb24gdmFsdWVzIHRoZW1zZWx2ZXMuXG5cdGlmICghTnVtYmVyLmlzRmluaXRlKHNhbXBsZVNpemUpKSB7XG5cdFx0cmV0dXJuIHJlYXNvbmFibGVEZXRlY3Rpb25TaXplSW5CeXRlcztcblx0fVxuXG5cdHJldHVybiBNYXRoLm1heCgxLCBNYXRoLnRydW5jKHNhbXBsZVNpemUpKTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplTXBlZ09mZnNldFRvbGVyYW5jZShtcGVnT2Zmc2V0VG9sZXJhbmNlKSB7XG5cdC8vIFRoaXMgdmFsdWUgY29udHJvbHMgc2NhbiBkZXB0aCBhbmQgdGhlcmVmb3JlIHdvcnN0LWNhc2UgQ1BVIHdvcmsuXG5cdGlmICghTnVtYmVyLmlzRmluaXRlKG1wZWdPZmZzZXRUb2xlcmFuY2UpKSB7XG5cdFx0cmV0dXJuIDA7XG5cdH1cblxuXHRyZXR1cm4gTWF0aC5tYXgoMCwgTWF0aC5taW4obWF4aW11bU1wZWdPZmZzZXRUb2xlcmFuY2UsIE1hdGgudHJ1bmMobXBlZ09mZnNldFRvbGVyYW5jZSkpKTtcbn1cblxuZnVuY3Rpb24gZ2V0S25vd25GaWxlU2l6ZU9yTWF4aW11bShmaWxlU2l6ZSkge1xuXHRpZiAoIU51bWJlci5pc0Zpbml0ZShmaWxlU2l6ZSkpIHtcblx0XHRyZXR1cm4gTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVI7XG5cdH1cblxuXHRyZXR1cm4gTWF0aC5tYXgoMCwgZmlsZVNpemUpO1xufVxuXG4vLyBLZWVwIHRoZSBzcGVjaWZpZXIgbm9uLWxpdGVyYWwgYXQgdGhlIGNhbGwgc2l0ZSBzbyBicm93c2VyIGJ1bmRsZXJzIGRvIG5vdCB0cnkgdG8gcmVzb2x2ZSBOb2RlLW9ubHkgaW1wb3J0cy5cbmZ1bmN0aW9uIGltcG9ydEF0UnVudGltZShzcGVjaWZpZXIpIHtcblx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGpzZG9jL25vLWJhZC1ibG9ja3Ncblx0cmV0dXJuIGltcG9ydCgvKiBAdml0ZS1pZ25vcmUgKi8gLyogd2VicGFja0lnbm9yZTogdHJ1ZSAqLyBzcGVjaWZpZXIpO1xufVxuXG4vLyBXcmFwIHN0cmVhbSBpbiBhbiBpZGVudGl0eSBUcmFuc2Zvcm1TdHJlYW0gdG8gYXZvaWQgQllPQiByZWFkZXJzLlxuLy8gTm9kZS5qcyBoYXMgYSBidWcgd2hlcmUgY2FsbGluZyBjb250cm9sbGVyLmNsb3NlKCkgaW5zaWRlIGEgQllPQiBzdHJlYW0nc1xuLy8gcHVsbCgpIGNhbGxiYWNrIGRvZXMgbm90IHJlc29sdmUgcGVuZGluZyByZWFkZXIucmVhZCgpIGNhbGxzLCBjYXVzaW5nXG4vLyBwZXJtYW5lbnQgaGFuZ3Mgb24gc3RyZWFtcyBzaG9ydGVyIHRoYW4gdGhlIHJlcXVlc3RlZCByZWFkIHNpemUuXG4vLyBVc2luZyBhIGRlZmF1bHQgKG5vbi1CWU9CKSByZWFkZXIgdmlhIFRyYW5zZm9ybVN0cmVhbSBhdm9pZHMgdGhpcy5cbmZ1bmN0aW9uIHRvRGVmYXVsdFN0cmVhbShzdHJlYW0pIHtcblx0cmV0dXJuIHN0cmVhbS5waXBlVGhyb3VnaChuZXcgVHJhbnNmb3JtU3RyZWFtKCkpO1xufVxuXG5mdW5jdGlvbiByZWFkV2l0aFNpZ25hbChyZWFkZXIsIHNpZ25hbCkge1xuXHRpZiAoc2lnbmFsID09PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gcmVhZGVyLnJlYWQoKTtcblx0fVxuXG5cdHNpZ25hbC50aHJvd0lmQWJvcnRlZCgpO1xuXG5cdHJldHVybiBQcm9taXNlLnJhY2UoW1xuXHRcdHJlYWRlci5yZWFkKCksXG5cdFx0bmV3IFByb21pc2UoKF9yZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHtcblx0XHRcdFx0cmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuXHRcdFx0XHRyZWFkZXIuY2FuY2VsKHNpZ25hbC5yZWFzb24pLmNhdGNoKCgpID0+IHt9KTtcblx0XHRcdH0sIHtvbmNlOiB0cnVlfSk7XG5cdFx0fSksXG5cdF0pO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVCeXRlTGltaXRlZFJlYWRhYmxlU3RyZWFtKHN0cmVhbSwgbWF4aW11bUJ5dGVzKSB7XG5cdGNvbnN0IHJlYWRlciA9IHN0cmVhbS5nZXRSZWFkZXIoKTtcblx0bGV0IGVtaXR0ZWRCeXRlcyA9IDA7XG5cdGxldCBpc1NvdXJjZURvbmUgPSBmYWxzZTtcblx0bGV0IGlzU291cmNlQ2FuY2VsZWQgPSBmYWxzZTtcblxuXHRjb25zdCBjYW5jZWxTb3VyY2UgPSBhc3luYyByZWFzb24gPT4ge1xuXHRcdGlmIChcblx0XHRcdGlzU291cmNlRG9uZVxuXHRcdFx0fHwgaXNTb3VyY2VDYW5jZWxlZFxuXHRcdCkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGlzU291cmNlQ2FuY2VsZWQgPSB0cnVlO1xuXHRcdGF3YWl0IHJlYWRlci5jYW5jZWwocmVhc29uKTtcblx0fTtcblxuXHRyZXR1cm4gbmV3IFJlYWRhYmxlU3RyZWFtKHtcblx0XHRhc3luYyBwdWxsKGNvbnRyb2xsZXIpIHtcblx0XHRcdGlmIChlbWl0dGVkQnl0ZXMgPj0gbWF4aW11bUJ5dGVzKSB7XG5cdFx0XHRcdGNvbnRyb2xsZXIuY2xvc2UoKTtcblx0XHRcdFx0YXdhaXQgY2FuY2VsU291cmNlKCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Y29uc3Qge2RvbmUsIHZhbHVlfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG5cdFx0XHRpZiAoXG5cdFx0XHRcdGRvbmVcblx0XHRcdFx0fHwgIXZhbHVlXG5cdFx0XHQpIHtcblx0XHRcdFx0aXNTb3VyY2VEb25lID0gdHJ1ZTtcblx0XHRcdFx0Y29udHJvbGxlci5jbG9zZSgpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHJlbWFpbmluZ0J5dGVzID0gbWF4aW11bUJ5dGVzIC0gZW1pdHRlZEJ5dGVzO1xuXHRcdFx0aWYgKHZhbHVlLmxlbmd0aCA+IHJlbWFpbmluZ0J5dGVzKSB7XG5cdFx0XHRcdGNvbnRyb2xsZXIuZW5xdWV1ZSh2YWx1ZS5zdWJhcnJheSgwLCByZW1haW5pbmdCeXRlcykpO1xuXHRcdFx0XHRlbWl0dGVkQnl0ZXMgKz0gcmVtYWluaW5nQnl0ZXM7XG5cdFx0XHRcdGNvbnRyb2xsZXIuY2xvc2UoKTtcblx0XHRcdFx0YXdhaXQgY2FuY2VsU291cmNlKCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Y29udHJvbGxlci5lbnF1ZXVlKHZhbHVlKTtcblx0XHRcdGVtaXR0ZWRCeXRlcyArPSB2YWx1ZS5sZW5ndGg7XG5cdFx0fSxcblx0XHRhc3luYyBjYW5jZWwocmVhc29uKSB7XG5cdFx0XHRhd2FpdCBjYW5jZWxTb3VyY2UocmVhc29uKTtcblx0XHR9LFxuXHR9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZpbGVUeXBlRnJvbVN0cmVhbShzdHJlYW0sIG9wdGlvbnMpIHtcblx0cmV0dXJuIG5ldyBGaWxlVHlwZVBhcnNlcihvcHRpb25zKS5mcm9tU3RyZWFtKHN0cmVhbSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmaWxlVHlwZUZyb21CdWZmZXIoaW5wdXQsIG9wdGlvbnMpIHtcblx0cmV0dXJuIG5ldyBGaWxlVHlwZVBhcnNlcihvcHRpb25zKS5mcm9tQnVmZmVyKGlucHV0KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZpbGVUeXBlRnJvbUJsb2IoYmxvYiwgb3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IEZpbGVUeXBlUGFyc2VyKG9wdGlvbnMpLmZyb21CbG9iKGJsb2IpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmlsZVR5cGVGcm9tVG9rZW5pemVyKHRva2VuaXplciwgb3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IEZpbGVUeXBlUGFyc2VyKG9wdGlvbnMpLmZyb21Ub2tlbml6ZXIodG9rZW5pemVyKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZpbGVUeXBlU3RyZWFtKHdlYlN0cmVhbSwgb3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IEZpbGVUeXBlUGFyc2VyKG9wdGlvbnMpLnRvRGV0ZWN0aW9uU3RyZWFtKHdlYlN0cmVhbSwgb3B0aW9ucyk7XG59XG5cbmV4cG9ydCBjbGFzcyBGaWxlVHlwZVBhcnNlciB7XG5cdGJ1ZmZlcjtcblx0dG9rZW5pemVyO1xuXHRkZXRlY3Rpb25SZWVudHJ5Q291bnQ7XG5cblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdGNvbnN0IG5vcm1hbGl6ZWRNcGVnT2Zmc2V0VG9sZXJhbmNlID0gbm9ybWFsaXplTXBlZ09mZnNldFRvbGVyYW5jZShvcHRpb25zPy5tcGVnT2Zmc2V0VG9sZXJhbmNlKTtcblx0XHRjb25zdCBtYXhCdWZmZXJTaXplID0gb3B0aW9ucz8ubWF4QnVmZmVyU2l6ZSA/PyBJbmZpbml0eTtcblx0XHRpZiAobWF4QnVmZmVyU2l6ZSAhPT0gSW5maW5pdHkgJiYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihtYXhCdWZmZXJTaXplKSB8fCBtYXhCdWZmZXJTaXplIDw9IDApKSB7XG5cdFx0XHR0aHJvdyBuZXcgUmFuZ2VFcnJvcignbWF4QnVmZmVyU2l6ZSBtdXN0IGJlIGEgcG9zaXRpdmUgc2FmZSBpbnRlZ2VyIG9yIEluZmluaXR5Jyk7XG5cdFx0fVxuXG5cdFx0dGhpcy5vcHRpb25zID0ge1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1wZWdPZmZzZXRUb2xlcmFuY2U6IG5vcm1hbGl6ZWRNcGVnT2Zmc2V0VG9sZXJhbmNlLFxuXHRcdH07XG5cblx0XHR0aGlzLmRldGVjdG9ycyA9IFsuLi4odGhpcy5vcHRpb25zLmN1c3RvbURldGVjdG9ycyA/PyBbXSksXG5cdFx0XHR7aWQ6ICdjb3JlJywgZGV0ZWN0OiB0b2tlbml6ZXIgPT4gdGhpcy5kZXRlY3RDb25maWRlbnQodG9rZW5pemVyKX0sXG5cdFx0XHR7aWQ6ICdjb3JlLmltcHJlY2lzZScsIGRldGVjdDogdG9rZW5pemVyID0+IHRoaXMuZGV0ZWN0SW1wcmVjaXNlKHRva2VuaXplcil9XTtcblx0XHR0aGlzLnRva2VuaXplck9wdGlvbnMgPSB7XG5cdFx0XHRhYm9ydFNpZ25hbDogdGhpcy5vcHRpb25zLnNpZ25hbCxcblx0XHRcdG1heEJ1ZmZlclNpemUsXG5cdFx0fTtcblx0XHR0aGlzLmd6aXBQcm9iZURlcHRoID0gMDtcblx0fVxuXG5cdGdldFRva2VuaXplck9wdGlvbnMoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLnRoaXMudG9rZW5pemVyT3B0aW9ucyxcblx0XHR9O1xuXHR9XG5cblx0Y3JlYXRlVG9rZW5pemVyRnJvbVdlYlN0cmVhbShzdHJlYW0pIHtcblx0XHRyZXR1cm4gc3RydG9rMy5mcm9tV2ViU3RyZWFtKHRvRGVmYXVsdFN0cmVhbShzdHJlYW0pLCB0aGlzLmdldFRva2VuaXplck9wdGlvbnMoKSk7XG5cdH1cblxuXHRhc3luYyBwYXJzZVRva2VuaXplcih0b2tlbml6ZXIsIGRldGVjdGlvblJlZW50cnlDb3VudCA9IDApIHtcblx0XHR0aGlzLmRldGVjdGlvblJlZW50cnlDb3VudCA9IGRldGVjdGlvblJlZW50cnlDb3VudDtcblx0XHRjb25zdCBpbml0aWFsUG9zaXRpb24gPSB0b2tlbml6ZXIucG9zaXRpb247XG5cdFx0Ly8gSXRlcmF0ZSB0aHJvdWdoIGFsbCBmaWxlLXR5cGUgZGV0ZWN0b3JzXG5cdFx0Zm9yIChjb25zdCBkZXRlY3RvciBvZiB0aGlzLmRldGVjdG9ycykge1xuXHRcdFx0bGV0IGZpbGVUeXBlO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0ZmlsZVR5cGUgPSBhd2FpdCBkZXRlY3Rvci5kZXRlY3QodG9rZW5pemVyKTtcblx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIHN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvcikge1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIFBhcnNlckhhcmRMaW1pdEVycm9yKSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChmaWxlVHlwZSkge1xuXHRcdFx0XHRyZXR1cm4gZmlsZVR5cGU7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChpbml0aWFsUG9zaXRpb24gIT09IHRva2VuaXplci5wb3NpdGlvbikge1xuXHRcdFx0XHRyZXR1cm4gdW5kZWZpbmVkOyAvLyBDYW5ub3QgcHJvY2VlZCBzY2FubmluZyBvZiB0aGUgdG9rZW5pemVyIGlzIGF0IGFuIGFyYml0cmFyeSBwb3NpdGlvblxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGFzeW5jIGZyb21Ub2tlbml6ZXIodG9rZW5pemVyKSB7XG5cdFx0dHJ5IHtcblx0XHRcdHJldHVybiBhd2FpdCB0aGlzLnBhcnNlVG9rZW5pemVyKHRva2VuaXplcik7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGF3YWl0IHRva2VuaXplci5jbG9zZSgpO1xuXHRcdH1cblx0fVxuXG5cdGFzeW5jIGZyb21CdWZmZXIoaW5wdXQpIHtcblx0XHRpZiAoIShpbnB1dCBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgfHwgaW5wdXQgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikpIHtcblx0XHRcdHRocm93IG5ldyBUeXBlRXJyb3IoYEV4cGVjdGVkIHRoZSBcXGBpbnB1dFxcYCBhcmd1bWVudCB0byBiZSBvZiB0eXBlIFxcYFVpbnQ4QXJyYXlcXGAgb3IgXFxgQXJyYXlCdWZmZXJcXGAsIGdvdCBcXGAke3R5cGVvZiBpbnB1dH1cXGBgKTtcblx0XHR9XG5cblx0XHRjb25zdCBidWZmZXIgPSBpbnB1dCBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgPyBpbnB1dCA6IG5ldyBVaW50OEFycmF5KGlucHV0KTtcblxuXHRcdGlmICghKGJ1ZmZlcj8ubGVuZ3RoID4gMSkpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRyZXR1cm4gdGhpcy5mcm9tVG9rZW5pemVyKHN0cnRvazMuZnJvbUJ1ZmZlcihidWZmZXIsIHRoaXMuZ2V0VG9rZW5pemVyT3B0aW9ucygpKSk7XG5cdH1cblxuXHRhc3luYyBmcm9tQmxvYihibG9iKSB7XG5cdFx0dGhpcy5vcHRpb25zLnNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRjb25zdCB0b2tlbml6ZXIgPSBzdHJ0b2szLmZyb21CbG9iKGJsb2IsIHRoaXMuZ2V0VG9rZW5pemVyT3B0aW9ucygpKTtcblx0XHRyZXR1cm4gdGhpcy5mcm9tVG9rZW5pemVyKHRva2VuaXplcik7XG5cdH1cblxuXHRhc3luYyBmcm9tU3RyZWFtKHN0cmVhbSkge1xuXHRcdHRoaXMub3B0aW9ucy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0Y29uc3QgdG9rZW5pemVyID0gdGhpcy5jcmVhdGVUb2tlbml6ZXJGcm9tV2ViU3RyZWFtKHN0cmVhbSk7XG5cdFx0cmV0dXJuIHRoaXMuZnJvbVRva2VuaXplcih0b2tlbml6ZXIpO1xuXHR9XG5cblx0YXN5bmMgZnJvbUZpbGUocGF0aCkge1xuXHRcdHRoaXMub3B0aW9ucy5zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0Y29uc3Qge2Zyb21GaWxlLCBOb3RSZWd1bGFyRmlsZUVycm9yfSA9IGF3YWl0IGltcG9ydEF0UnVudGltZSgnc3RydG9rMycpO1xuXHRcdGxldCB0b2tlbml6ZXI7XG5cdFx0dHJ5IHtcblx0XHRcdHRva2VuaXplciA9IGF3YWl0IGZyb21GaWxlKHBhdGgsIHtcblx0XHRcdFx0Li4udGhpcy5nZXRUb2tlbml6ZXJPcHRpb25zKCksXG5cdFx0XHRcdHJlZ3VsYXJGaWxlT25seTogdHJ1ZSxcblx0XHRcdH0pO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBOb3RSZWd1bGFyRmlsZUVycm9yKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHRoaXMuZnJvbVRva2VuaXplcih0b2tlbml6ZXIpO1xuXHR9XG5cblx0YXN5bmMgdG9EZXRlY3Rpb25TdHJlYW0oc3RyZWFtLCBvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zLnNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRjb25zdCBzYW1wbGVTaXplID0gbm9ybWFsaXplU2FtcGxlU2l6ZShvcHRpb25zPy5zYW1wbGVTaXplID8/IHJlYXNvbmFibGVEZXRlY3Rpb25TaXplSW5CeXRlcyk7XG5cdFx0bGV0IGRldGVjdGVkRmlsZVR5cGU7XG5cdFx0bGV0IGhhc1N0cmVhbUVuZGVkID0gZmFsc2U7XG5cblx0XHRjb25zdCByZWFkZXIgPSBzdHJlYW0uZ2V0UmVhZGVyKCk7XG5cdFx0Y29uc3QgY2h1bmtzID0gW107XG5cdFx0bGV0IHRvdGFsU2l6ZSA9IDA7XG5cblx0XHR0cnkge1xuXHRcdFx0d2hpbGUgKHRvdGFsU2l6ZSA8IHNhbXBsZVNpemUpIHtcblx0XHRcdFx0Y29uc3Qge3ZhbHVlLCBkb25lfSA9IGF3YWl0IHJlYWRXaXRoU2lnbmFsKHJlYWRlciwgdGhpcy5vcHRpb25zLnNpZ25hbCk7XG5cdFx0XHRcdGlmIChkb25lIHx8ICF2YWx1ZSkge1xuXHRcdFx0XHRcdGhhc1N0cmVhbUVuZGVkID0gdHJ1ZTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNodW5rcy5wdXNoKHZhbHVlKTtcblx0XHRcdFx0dG90YWxTaXplICs9IHZhbHVlLmxlbmd0aDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKFxuXHRcdFx0XHQhaGFzU3RyZWFtRW5kZWRcblx0XHRcdFx0JiYgdG90YWxTaXplID09PSBzYW1wbGVTaXplXG5cdFx0XHQpIHtcblx0XHRcdFx0Y29uc3Qge3ZhbHVlLCBkb25lfSA9IGF3YWl0IHJlYWRXaXRoU2lnbmFsKHJlYWRlciwgdGhpcy5vcHRpb25zLnNpZ25hbCk7XG5cdFx0XHRcdGlmIChkb25lIHx8ICF2YWx1ZSkge1xuXHRcdFx0XHRcdGhhc1N0cmVhbUVuZGVkID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRjaHVua3MucHVzaCh2YWx1ZSk7XG5cdFx0XHRcdFx0dG90YWxTaXplICs9IHZhbHVlLmxlbmd0aDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRyZWFkZXIucmVsZWFzZUxvY2soKTtcblx0XHR9XG5cblx0XHRpZiAodG90YWxTaXplID4gMCkge1xuXHRcdFx0Y29uc3Qgc2FtcGxlID0gY2h1bmtzLmxlbmd0aCA9PT0gMSA/IGNodW5rc1swXSA6IGNvbmNhdFVpbnQ4QXJyYXlzKGNodW5rcyk7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRkZXRlY3RlZEZpbGVUeXBlID0gYXdhaXQgdGhpcy5mcm9tQnVmZmVyKHNhbXBsZS5zdWJhcnJheSgwLCBzYW1wbGVTaXplKSk7XG5cdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRpZiAoIShlcnJvciBpbnN0YW5jZW9mIHN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvcikpIHtcblx0XHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGRldGVjdGVkRmlsZVR5cGUgPSB1bmRlZmluZWQ7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChcblx0XHRcdFx0IWhhc1N0cmVhbUVuZGVkXG5cdFx0XHRcdCYmIGRldGVjdGVkRmlsZVR5cGU/LmV4dCA9PT0gJ3BhZ2VzJ1xuXHRcdFx0KSB7XG5cdFx0XHRcdGRldGVjdGVkRmlsZVR5cGUgPSB7XG5cdFx0XHRcdFx0ZXh0OiAnemlwJyxcblx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vemlwJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBQcmVwZW5kIGNvbGxlY3RlZCBjaHVua3MgYW5kIHBpcGUgdGhlIHJlc3QgdGhyb3VnaFxuXHRcdGNvbnN0IHRyYW5zZm9ybVN0cmVhbSA9IG5ldyBUcmFuc2Zvcm1TdHJlYW0oe1xuXHRcdFx0c3RhcnQoY29udHJvbGxlcikge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGNodW5rIG9mIGNodW5rcykge1xuXHRcdFx0XHRcdGNvbnRyb2xsZXIuZW5xdWV1ZShjaHVuayk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cdFx0XHR0cmFuc2Zvcm0oY2h1bmssIGNvbnRyb2xsZXIpIHtcblx0XHRcdFx0Y29udHJvbGxlci5lbnF1ZXVlKGNodW5rKTtcblx0XHRcdH0sXG5cdFx0fSk7XG5cblx0XHRjb25zdCBuZXdTdHJlYW0gPSBzdHJlYW0ucGlwZVRocm91Z2godHJhbnNmb3JtU3RyZWFtKTtcblx0XHRuZXdTdHJlYW0uZmlsZVR5cGUgPSBkZXRlY3RlZEZpbGVUeXBlO1xuXG5cdFx0cmV0dXJuIG5ld1N0cmVhbTtcblx0fVxuXG5cdGFzeW5jIGRldGVjdEd6aXAodG9rZW5pemVyKSB7XG5cdFx0aWYgKHRoaXMuZ3ppcFByb2JlRGVwdGggPj0gbWF4aW11bU5lc3RlZEd6aXBQcm9iZURlcHRoKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdneicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9nemlwJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Y29uc3QgZ3ppcEhhbmRsZXIgPSBuZXcgR3ppcEhhbmRsZXIodG9rZW5pemVyKTtcblx0XHRjb25zdCBsaW1pdGVkSW5mbGF0ZWRTdHJlYW0gPSBjcmVhdGVCeXRlTGltaXRlZFJlYWRhYmxlU3RyZWFtKGd6aXBIYW5kbGVyLmluZmxhdGUoKSwgbWF4aW11bU5lc3RlZEd6aXBEZXRlY3Rpb25TaXplSW5CeXRlcyk7XG5cdFx0Y29uc3QgaGFzVW5rbm93blNpemUgPSBoYXNVbmtub3duRmlsZVNpemUodG9rZW5pemVyKTtcblx0XHRsZXQgdGltZW91dDtcblx0XHRsZXQgcHJvYmVTaWduYWw7XG5cdFx0bGV0IHByb2JlUGFyc2VyO1xuXHRcdGxldCBjb21wcmVzc2VkRmlsZVR5cGU7XG5cblx0XHRpZiAoaGFzVW5rbm93blNpemUpIHtcblx0XHRcdGNvbnN0IHRpbWVvdXRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdFx0dGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHR0aW1lb3V0Q29udHJvbGxlci5hYm9ydChuZXcgRE9NRXhjZXB0aW9uKGBPcGVyYXRpb24gdGltZWQgb3V0IGFmdGVyICR7dW5rbm93blNpemVHemlwUHJvYmVUaW1lb3V0SW5NaWxsaXNlY29uZHN9IG1zYCwgJ1RpbWVvdXRFcnJvcicpKTtcblx0XHRcdH0sIHVua25vd25TaXplR3ppcFByb2JlVGltZW91dEluTWlsbGlzZWNvbmRzKTtcblx0XHRcdHByb2JlU2lnbmFsID0gdGhpcy5vcHRpb25zLnNpZ25hbCA9PT0gdW5kZWZpbmVkXG5cdFx0XHRcdD8gdGltZW91dENvbnRyb2xsZXIuc2lnbmFsXG5cdFx0XHRcdDogQWJvcnRTaWduYWwuYW55KFt0aGlzLm9wdGlvbnMuc2lnbmFsLCB0aW1lb3V0Q29udHJvbGxlci5zaWduYWxdKTtcblx0XHRcdHByb2JlUGFyc2VyID0gbmV3IEZpbGVUeXBlUGFyc2VyKHtcblx0XHRcdFx0Li4udGhpcy5vcHRpb25zLFxuXHRcdFx0XHRzaWduYWw6IHByb2JlU2lnbmFsLFxuXHRcdFx0fSk7XG5cdFx0XHRwcm9iZVBhcnNlci5nemlwUHJvYmVEZXB0aCA9IHRoaXMuZ3ppcFByb2JlRGVwdGggKyAxO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHR0aGlzLmd6aXBQcm9iZURlcHRoKys7XG5cdFx0fVxuXG5cdFx0dHJ5IHtcblx0XHRcdGNvbXByZXNzZWRGaWxlVHlwZSA9IGF3YWl0IChwcm9iZVBhcnNlciA/PyB0aGlzKS5mcm9tU3RyZWFtKGxpbWl0ZWRJbmZsYXRlZFN0cmVhbSk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGlmIChcblx0XHRcdFx0ZXJyb3I/Lm5hbWUgPT09ICdBYm9ydEVycm9yJ1xuXHRcdFx0XHQmJiBwcm9iZVNpZ25hbD8ucmVhc29uPy5uYW1lICE9PSAnVGltZW91dEVycm9yJ1xuXHRcdFx0KSB7XG5cdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBUaW1lb3V0LCBkZWNvbXByZXNzaW9uLCBvciBpbm5lci1kZXRlY3Rpb24gZmFpbHVyZXMgYXJlIGV4cGVjdGVkIGZvciBub24tdGFyIGd6aXAgZmlsZXMuXG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lb3V0KTtcblx0XHRcdGlmICghaGFzVW5rbm93blNpemUpIHtcblx0XHRcdFx0dGhpcy5nemlwUHJvYmVEZXB0aC0tO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmIChjb21wcmVzc2VkRmlsZVR5cGU/LmV4dCA9PT0gJ3RhcicpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3Rhci5neicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9nemlwJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHtcblx0XHRcdGV4dDogJ2d6Jyxcblx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9nemlwJyxcblx0XHR9O1xuXHR9XG5cblx0Y2hlY2soaGVhZGVyLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIGNoZWNrQnl0ZXModGhpcy5idWZmZXIsIGhlYWRlciwgb3B0aW9ucyk7XG5cdH1cblxuXHRjaGVja1N0cmluZyhoZWFkZXIsIG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5jaGVjayhzdHJpbmdUb0J5dGVzKGhlYWRlciwgb3B0aW9ucz8uZW5jb2RpbmcpLCBvcHRpb25zKTtcblx0fVxuXG5cdC8vIERldGVjdGlvbnMgd2l0aCBhIGhpZ2ggZGVncmVlIG9mIGNlcnRhaW50eSBpbiBpZGVudGlmeWluZyB0aGUgY29ycmVjdCBmaWxlIHR5cGVcblx0YXN5bmMgZGV0ZWN0Q29uZmlkZW50KHRva2VuaXplcikge1xuXHRcdHRoaXMuYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkocmVhc29uYWJsZURldGVjdGlvblNpemVJbkJ5dGVzKTtcblxuXHRcdC8vIEtlZXAgcmVhZGluZyB1bnRpbCBFT0YgaWYgdGhlIGZpbGUgc2l6ZSBpcyB1bmtub3duLlxuXHRcdGlmICh0b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHR0b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSA9IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSO1xuXHRcdH1cblxuXHRcdHRoaXMudG9rZW5pemVyID0gdG9rZW5pemVyO1xuXG5cdFx0aWYgKGhhc1Vua25vd25GaWxlU2l6ZSh0b2tlbml6ZXIpKSB7XG5cdFx0XHRhd2FpdCB0b2tlbml6ZXIucGVla0J1ZmZlcih0aGlzLmJ1ZmZlciwge2xlbmd0aDogMywgbWF5QmVMZXNzOiB0cnVlfSk7XG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHgxRiwgMHg4QiwgMHg4XSkpIHtcblx0XHRcdFx0cmV0dXJuIHRoaXMuZGV0ZWN0R3ppcCh0b2tlbml6ZXIpO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGF3YWl0IHRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuYnVmZmVyLCB7bGVuZ3RoOiAzMiwgbWF5QmVMZXNzOiB0cnVlfSk7XG5cblx0XHQvLyAtLSAyLWJ5dGUgc2lnbmF0dXJlcyAtLVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDIsIDB4NERdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnYm1wJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL2JtcCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDBCLCAweDc3XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2FjMycsXG5cdFx0XHRcdG1pbWU6ICdhdWRpby92bmQuZG9sYnkuZGQtcmF3Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NzgsIDB4MDFdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZG1nJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtYXBwbGUtZGlza2ltYWdlJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NEQsIDB4NUFdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZXhlJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtbXNkb3dubG9hZCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDI1LCAweDIxXSkpIHtcblx0XHRcdGF3YWl0IHRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuYnVmZmVyLCB7bGVuZ3RoOiAyNCwgbWF5QmVMZXNzOiB0cnVlfSk7XG5cblx0XHRcdGlmIChcblx0XHRcdFx0dGhpcy5jaGVja1N0cmluZygnUFMtQWRvYmUtJywge29mZnNldDogMn0pXG5cdFx0XHRcdCYmIHRoaXMuY2hlY2tTdHJpbmcoJyBFUFNGLScsIHtvZmZzZXQ6IDE0fSlcblx0XHRcdCkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ2VwcycsXG5cdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL2VwcycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3BzJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3Bvc3RzY3JpcHQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrKFsweDFGLCAweEEwXSlcblx0XHRcdHx8IHRoaXMuY2hlY2soWzB4MUYsIDB4OURdKVxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnWicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWNvbXByZXNzJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4QzcsIDB4NzFdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnY3BpbycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWNwaW8nLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg2MCwgMHhFQV0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdhcmonLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1hcmonLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyAtLSAzLWJ5dGUgc2lnbmF0dXJlcyAtLVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4RUYsIDB4QkIsIDB4QkZdKSkgeyAvLyBVVEYtOC1CT01cblx0XHRcdGlmICh0aGlzLmRldGVjdGlvblJlZW50cnlDb3VudCA+PSBtYXhpbXVtRGV0ZWN0aW9uUmVlbnRyeUNvdW50KSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0dGhpcy5kZXRlY3Rpb25SZWVudHJ5Q291bnQrKztcblx0XHRcdC8vIFN0cmlwIG9mZiBVVEYtOC1CT01cblx0XHRcdGF3YWl0IHRoaXMudG9rZW5pemVyLmlnbm9yZSgzKTtcblx0XHRcdHJldHVybiB0aGlzLmRldGVjdENvbmZpZGVudCh0b2tlbml6ZXIpO1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDQ3LCAweDQ5LCAweDQ2XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2dpZicsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS9naWYnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg0OSwgMHg0OSwgMHhCQ10pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdqeHInLFxuXHRcdFx0XHRtaW1lOiAnaW1hZ2Uvdm5kLm1zLXBob3RvJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MUYsIDB4OEIsIDB4OF0pKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5kZXRlY3RHemlwKHRva2VuaXplcik7XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDIsIDB4NUEsIDB4NjhdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnYnoyJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtYnppcDInLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnSUQzJykpIHtcblx0XHRcdGF3YWl0IHNhZmVJZ25vcmUodG9rZW5pemVyLCA2LCB7XG5cdFx0XHRcdG1heGltdW1MZW5ndGg6IDYsXG5cdFx0XHRcdHJlYXNvbjogJ0lEMyBoZWFkZXIgcHJlZml4Jyxcblx0XHRcdH0pOyAvLyBTa2lwIElEMyBoZWFkZXIgdW50aWwgdGhlIGhlYWRlciBzaXplXG5cdFx0XHRjb25zdCBpZDNIZWFkZXJMZW5ndGggPSBhd2FpdCB0b2tlbml6ZXIucmVhZFRva2VuKHVpbnQzMlN5bmNTYWZlVG9rZW4pO1xuXHRcdFx0Y29uc3QgaXNVbmtub3duRmlsZVNpemUgPSBoYXNVbmtub3duRmlsZVNpemUodG9rZW5pemVyKTtcblx0XHRcdGlmIChcblx0XHRcdFx0IU51bWJlci5pc0Zpbml0ZShpZDNIZWFkZXJMZW5ndGgpXG5cdFx0XHRcdHx8IGlkM0hlYWRlckxlbmd0aCA8IDBcblx0XHRcdFx0Ly8gS2VlcCBJRDMgcHJvYmluZyBib3VuZGVkIGZvciB1bmtub3duLXNpemUgc3RyZWFtcyB0byBhdm9pZCBhdHRhY2tlci1jb250cm9sbGVkIGxhcmdlIHNraXBzLlxuXHRcdFx0XHR8fCAoXG5cdFx0XHRcdFx0aXNVbmtub3duRmlsZVNpemVcblx0XHRcdFx0XHQmJiAoXG5cdFx0XHRcdFx0XHRpZDNIZWFkZXJMZW5ndGggPiBtYXhpbXVtSWQzSGVhZGVyU2l6ZUluQnl0ZXNcblx0XHRcdFx0XHRcdHx8ICh0b2tlbml6ZXIucG9zaXRpb24gKyBpZDNIZWFkZXJMZW5ndGgpID4gbWF4aW11bUlkM0hlYWRlclNpemVJbkJ5dGVzXG5cdFx0XHRcdFx0KVxuXHRcdFx0XHQpXG5cdFx0XHQpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAodG9rZW5pemVyLnBvc2l0aW9uICsgaWQzSGVhZGVyTGVuZ3RoID4gdG9rZW5pemVyLmZpbGVJbmZvLnNpemUpIHtcblx0XHRcdFx0aWYgKGlzVW5rbm93bkZpbGVTaXplKSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdtcDMnLFxuXHRcdFx0XHRcdG1pbWU6ICdhdWRpby9tcGVnJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgc2FmZUlnbm9yZSh0b2tlbml6ZXIsIGlkM0hlYWRlckxlbmd0aCwge1xuXHRcdFx0XHRcdG1heGltdW1MZW5ndGg6IGlzVW5rbm93bkZpbGVTaXplID8gbWF4aW11bUlkM0hlYWRlclNpemVJbkJ5dGVzIDogdG9rZW5pemVyLmZpbGVJbmZvLnNpemUsXG5cdFx0XHRcdFx0cmVhc29uOiAnSUQzIHBheWxvYWQnLFxuXHRcdFx0XHR9KTtcblx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIHN0cnRvazMuRW5kT2ZTdHJlYW1FcnJvcikge1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5kZXRlY3Rpb25SZWVudHJ5Q291bnQgPj0gbWF4aW11bURldGVjdGlvblJlZW50cnlDb3VudCkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdHRoaXMuZGV0ZWN0aW9uUmVlbnRyeUNvdW50Kys7XG5cdFx0XHRyZXR1cm4gdGhpcy5wYXJzZVRva2VuaXplcih0b2tlbml6ZXIsIHRoaXMuZGV0ZWN0aW9uUmVlbnRyeUNvdW50KTsgLy8gU2tpcCBJRDMgaGVhZGVyLCByZWN1cnNpb25cblx0XHR9XG5cblx0XHQvLyBNdXNlcGFjaywgU1Y3XG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ01QKycpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdtcGMnLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8veC1tdXNlcGFjaycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmIChcblx0XHRcdCh0aGlzLmJ1ZmZlclswXSA9PT0gMHg0MyB8fCB0aGlzLmJ1ZmZlclswXSA9PT0gMHg0Nilcblx0XHRcdCYmIHRoaXMuY2hlY2soWzB4NTcsIDB4NTNdLCB7b2Zmc2V0OiAxfSlcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3N3ZicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LXNob2Nrd2F2ZS1mbGFzaCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIC0tIDQtYnl0ZSBzaWduYXR1cmVzIC0tXG5cblx0XHQvLyBSZXF1aXJlcyBhIHNhbXBsZSBzaXplIG9mIDQgYnl0ZXNcblx0XHRpZiAodGhpcy5jaGVjayhbMHhGRiwgMHhEOCwgMHhGRl0pKSB7XG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHhGN10sIHtvZmZzZXQ6IDN9KSkgeyAvLyBKUEc3L1NPRjU1LCBpbmRpY2F0aW5nIGEgSVNPL0lFQyAxNDQ5NSAvIEpQRUctTFMgZmlsZVxuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ2pscycsXG5cdFx0XHRcdFx0bWltZTogJ2ltYWdlL2pscycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2pwZycsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS9qcGVnJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NEYsIDB4NjIsIDB4NkEsIDB4MDFdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnYXZybycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9hdnJvJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0ZMSUYnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZmxpZicsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS9mbGlmJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJzhCUFMnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAncHNkJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL3ZuZC5hZG9iZS5waG90b3Nob3AnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyBNdXNlcGFjaywgU1Y4XG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ01QQ0snKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnbXBjJyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL3gtbXVzZXBhY2snLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnRk9STScpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdhaWYnLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8vYWlmZicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIENvcmUgQXVkaW8gRm9ybWF0IChDQUYpLCB2ZXJzaW9uIDEsIGZvbGxvd2VkIGJ5IHRoZSByZXF1aXJlZCBBdWRpbyBEZXNjcmlwdGlvbiBjaHVuay5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnY2FmZicpICYmIHRoaXMuY2hlY2soWzB4MDAsIDB4MDFdLCB7b2Zmc2V0OiA0fSkgJiYgdGhpcy5jaGVja1N0cmluZygnZGVzYycsIHtvZmZzZXQ6IDh9KSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnY2FmJyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL3gtY2FmJywgLy8gTm9uLXN0YW5kYXJkXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdpY25zJywge29mZnNldDogMH0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdpY25zJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL2ljbnMnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyBaaXAtYmFzZWQgZmlsZSBmb3JtYXRzXG5cdFx0Ly8gTmVlZCB0byBiZSBiZWZvcmUgdGhlIGB6aXBgIGNoZWNrXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NTAsIDB4NEIsIDB4MywgMHg0XSkpIHsgLy8gTG9jYWwgZmlsZSBoZWFkZXIgc2lnbmF0dXJlXG5cdFx0XHRyZXR1cm4gZGV0ZWN0WmlwKHRva2VuaXplcik7XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ09nZ1MnKSkge1xuXHRcdFx0Ly8gVGhpcyBpcyBhbiBPR0cgY29udGFpbmVyXG5cdFx0XHRhd2FpdCB0b2tlbml6ZXIuaWdub3JlKDI4KTtcblx0XHRcdGNvbnN0IHR5cGUgPSBuZXcgVWludDhBcnJheSg4KTtcblx0XHRcdGF3YWl0IHRva2VuaXplci5yZWFkQnVmZmVyKHR5cGUpO1xuXG5cdFx0XHQvLyBOZWVkcyB0byBiZSBiZWZvcmUgYG9nZ2AgY2hlY2tcblx0XHRcdGlmIChjaGVja0J5dGVzKHR5cGUsIFsweDRGLCAweDcwLCAweDc1LCAweDczLCAweDQ4LCAweDY1LCAweDYxLCAweDY0XSkpIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdvcHVzJyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vb2dnOyBjb2RlY3M9b3B1cycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdC8vIElmICcgdGhlb3JhJyBpbiBoZWFkZXIuXG5cdFx0XHRpZiAoY2hlY2tCeXRlcyh0eXBlLCBbMHg4MCwgMHg3NCwgMHg2OCwgMHg2NSwgMHg2RiwgMHg3MiwgMHg2MV0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnb2d2Jyxcblx0XHRcdFx0XHRtaW1lOiAndmlkZW8vb2dnJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gSWYgJ1xceDAxdmlkZW8nIGluIGhlYWRlci5cblx0XHRcdGlmIChjaGVja0J5dGVzKHR5cGUsIFsweDAxLCAweDc2LCAweDY5LCAweDY0LCAweDY1LCAweDZGLCAweDAwXSkpIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdvZ20nLFxuXHRcdFx0XHRcdG1pbWU6ICd2aWRlby9vZ2cnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBJZiAnIEZMQUMnIGluIGhlYWRlciAgaHR0cHM6Ly94aXBoLm9yZy9mbGFjL2ZhcS5odG1sXG5cdFx0XHRpZiAoY2hlY2tCeXRlcyh0eXBlLCBbMHg3RiwgMHg0NiwgMHg0QywgMHg0MSwgMHg0M10pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnb2dhJyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vb2dnJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gJ1NwZWV4ICAnIGluIGhlYWRlciBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9TcGVleFxuXHRcdFx0aWYgKGNoZWNrQnl0ZXModHlwZSwgWzB4NTMsIDB4NzAsIDB4NjUsIDB4NjUsIDB4NzgsIDB4MjAsIDB4MjBdKSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ3NweCcsXG5cdFx0XHRcdFx0bWltZTogJ2F1ZGlvL29nZycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdC8vIElmICdcXHgwMXZvcmJpcycgaW4gaGVhZGVyXG5cdFx0XHRpZiAoY2hlY2tCeXRlcyh0eXBlLCBbMHgwMSwgMHg3NiwgMHg2RiwgMHg3MiwgMHg2MiwgMHg2OSwgMHg3M10pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnb2dnJyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vb2dnJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gRGVmYXVsdCBPR0cgY29udGFpbmVyIGh0dHBzOi8vd3d3LmlhbmEub3JnL2Fzc2lnbm1lbnRzL21lZGlhLXR5cGVzL2FwcGxpY2F0aW9uL29nZ1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnb2d4Jyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL29nZycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmIChcblx0XHRcdHRoaXMuY2hlY2soWzB4NTAsIDB4NEJdKVxuXHRcdFx0JiYgWzB4MywgMHg1LCAweDddLmluY2x1ZGVzKHRoaXMuYnVmZmVyWzJdKVxuXHRcdFx0JiYgWzB4NCwgMHg2LCAweDhdLmluY2x1ZGVzKHRoaXMuYnVmZmVyWzNdKVxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnemlwJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ppcCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdNVGhkJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ21pZCcsXG5cdFx0XHRcdG1pbWU6ICdhdWRpby9taWRpJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVja1N0cmluZygnd09GRicpXG5cdFx0XHQmJiAoXG5cdFx0XHRcdHRoaXMuY2hlY2soWzB4MDAsIDB4MDEsIDB4MDAsIDB4MDBdLCB7b2Zmc2V0OiA0fSlcblx0XHRcdFx0fHwgdGhpcy5jaGVja1N0cmluZygnT1RUTycsIHtvZmZzZXQ6IDR9KVxuXHRcdFx0KVxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnd29mZicsXG5cdFx0XHRcdG1pbWU6ICdmb250L3dvZmYnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrU3RyaW5nKCd3T0YyJylcblx0XHRcdCYmIChcblx0XHRcdFx0dGhpcy5jaGVjayhbMHgwMCwgMHgwMSwgMHgwMCwgMHgwMF0sIHtvZmZzZXQ6IDR9KVxuXHRcdFx0XHR8fCB0aGlzLmNoZWNrU3RyaW5nKCdPVFRPJywge29mZnNldDogNH0pXG5cdFx0XHQpXG5cdFx0KSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICd3b2ZmMicsXG5cdFx0XHRcdG1pbWU6ICdmb250L3dvZmYyJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4RDQsIDB4QzMsIDB4QjIsIDB4QTFdKSB8fCB0aGlzLmNoZWNrKFsweEExLCAweEIyLCAweEMzLCAweEQ0XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3BjYXAnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vdm5kLnRjcGR1bXAucGNhcCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIFNvbnkgRFNEIFN0cmVhbSBGaWxlIChEU0YpXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0RTRCAnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZHNmJyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL3gtZHNmJywgLy8gTm9uLXN0YW5kYXJkXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdMWklQJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2x6Jyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL2x6aXAnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnZkxhQycpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdmbGFjJyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL2ZsYWMnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg0MiwgMHg1MCwgMHg0NywgMHhGQl0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdicGcnLFxuXHRcdFx0XHRtaW1lOiAnaW1hZ2UvYnBnJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ3d2cGsnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnd3YnLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8vd2F2cGFjaycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCclUERGJykpIHtcblx0XHRcdC8vIEFzc3VtZSB0aGlzIGlzIGp1c3QgYSBub3JtYWwgUERGXG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdwZGYnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vcGRmJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MDAsIDB4NjEsIDB4NzMsIDB4NkRdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnd2FzbScsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi93YXNtJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gVElGRiwgbGl0dGxlLWVuZGlhbiB0eXBlXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDksIDB4NDldKSkge1xuXHRcdFx0Y29uc3QgZmlsZVR5cGUgPSBhd2FpdCB0aGlzLnJlYWRUaWZmSGVhZGVyKGZhbHNlKTtcblx0XHRcdGlmIChmaWxlVHlwZSkge1xuXHRcdFx0XHRyZXR1cm4gZmlsZVR5cGU7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gVElGRiwgYmlnLWVuZGlhbiB0eXBlXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NEQsIDB4NERdKSkge1xuXHRcdFx0Y29uc3QgZmlsZVR5cGUgPSBhd2FpdCB0aGlzLnJlYWRUaWZmSGVhZGVyKHRydWUpO1xuXHRcdFx0aWYgKGZpbGVUeXBlKSB7XG5cdFx0XHRcdHJldHVybiBmaWxlVHlwZTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnTUFDICcpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdhcGUnLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8vYXBlJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gaHR0cHM6Ly9naXRodWIuY29tL2ZpbGUvZmlsZS9ibG9iL21hc3Rlci9tYWdpYy9NYWdkaXIvbWF0cm9za2Fcblx0XHRpZiAodGhpcy5jaGVjayhbMHgxQSwgMHg0NSwgMHhERiwgMHhBM10pKSB7IC8vIFJvb3QgZWxlbWVudDogRUJNTFxuXHRcdFx0cmV0dXJuIGRldGVjdEVibWwodG9rZW5pemVyKTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnU1FMaScpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdzcWxpdGUnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1zcWxpdGUzJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NEUsIDB4NDUsIDB4NTMsIDB4MUFdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnbmVzJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtbmludGVuZG8tbmVzLXJvbScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdDcjI0JykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2NyeCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWdvb2dsZS1jaHJvbWUtZXh0ZW5zaW9uJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVja1N0cmluZygnTVNDRicpXG5cdFx0XHR8fCB0aGlzLmNoZWNrU3RyaW5nKCdJU2MoJylcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2NhYicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi92bmQubXMtY2FiLWNvbXByZXNzZWQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHhFRCwgMHhBQiwgMHhFRSwgMHhEQl0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdycG0nLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1ycG0nLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHhDNSwgMHhEMCwgMHhEMywgMHhDNl0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdlcHMnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vZXBzJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MjgsIDB4QjUsIDB4MkYsIDB4RkRdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnenN0Jyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3pzdGQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg3RiwgMHg0NSwgMHg0QywgMHg0Nl0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdlbGYnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1lbGYnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHgyMSwgMHg0MiwgMHg0NCwgMHg0RV0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdwc3QnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vdm5kLm1zLW91dGxvb2snLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnUEFSMScpIHx8IHRoaXMuY2hlY2tTdHJpbmcoJ1BBUkUnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAncGFycXVldCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi92bmQuYXBhY2hlLnBhcnF1ZXQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygndHRjZicpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICd0dGMnLFxuXHRcdFx0XHRtaW1lOiAnZm9udC9jb2xsZWN0aW9uJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVjayhbMHhGRSwgMHhFRCwgMHhGQSwgMHhDRV0pIC8vIDMyLWJpdCwgYmlnLWVuZGlhblxuXHRcdFx0fHwgdGhpcy5jaGVjayhbMHhGRSwgMHhFRCwgMHhGQSwgMHhDRl0pIC8vIDY0LWJpdCwgYmlnLWVuZGlhblxuXHRcdFx0fHwgdGhpcy5jaGVjayhbMHhDRSwgMHhGQSwgMHhFRCwgMHhGRV0pIC8vIDMyLWJpdCwgbGl0dGxlLWVuZGlhblxuXHRcdFx0fHwgdGhpcy5jaGVjayhbMHhDRiwgMHhGQSwgMHhFRCwgMHhGRV0pIC8vIDY0LWJpdCwgbGl0dGxlLWVuZGlhblxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnbWFjaG8nLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1tYWNoLWJpbmFyeScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDA0LCAweDIyLCAweDRELCAweDE4XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2x6NCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWx6NCcsIC8vIEluZm9ybWFsLCB1c2VkIGJ5IGZyZWVkZXNrdG9wLm9yZyBzaGFyZWQtbWltZS1pbmZvXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdyZWdmJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2RhdCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWZ0LXdpbmRvd3MtcmVnaXN0cnktaGl2ZScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIFNQU1MgU3RhdGlzdGljYWwgRGF0YSBGaWxlXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJyRGTDInKSB8fCB0aGlzLmNoZWNrU3RyaW5nKCckRkwzJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3NhdicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LXNwc3Mtc2F2Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gLS0gNS1ieXRlIHNpZ25hdHVyZXMgLS1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDRGLCAweDU0LCAweDU0LCAweDRGLCAweDAwXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ290ZicsXG5cdFx0XHRcdG1pbWU6ICdmb250L290ZicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCcjIUFNUicpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdhbXInLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8vYW1yJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoU3RyaW5nLnJhd2B7XFxydGZgKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAncnRmJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3J0ZicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDQ2LCAweDRDLCAweDU2LCAweDAxXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2ZsdicsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby94LWZsdicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdJTVBNJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2l0Jyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL3gtaXQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrU3RyaW5nKCctbGgwLScsIHtvZmZzZXQ6IDJ9KVxuXHRcdFx0fHwgdGhpcy5jaGVja1N0cmluZygnLWxoMS0nLCB7b2Zmc2V0OiAyfSlcblx0XHRcdHx8IHRoaXMuY2hlY2tTdHJpbmcoJy1saDItJywge29mZnNldDogMn0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrU3RyaW5nKCctbGgzLScsIHtvZmZzZXQ6IDJ9KVxuXHRcdFx0fHwgdGhpcy5jaGVja1N0cmluZygnLWxoNC0nLCB7b2Zmc2V0OiAyfSlcblx0XHRcdHx8IHRoaXMuY2hlY2tTdHJpbmcoJy1saDUtJywge29mZnNldDogMn0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrU3RyaW5nKCctbGg2LScsIHtvZmZzZXQ6IDJ9KVxuXHRcdFx0fHwgdGhpcy5jaGVja1N0cmluZygnLWxoNy0nLCB7b2Zmc2V0OiAyfSlcblx0XHRcdHx8IHRoaXMuY2hlY2tTdHJpbmcoJy1senMtJywge29mZnNldDogMn0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrU3RyaW5nKCctbHo0LScsIHtvZmZzZXQ6IDJ9KVxuXHRcdFx0fHwgdGhpcy5jaGVja1N0cmluZygnLWx6NS0nLCB7b2Zmc2V0OiAyfSlcblx0XHRcdHx8IHRoaXMuY2hlY2tTdHJpbmcoJy1saGQtJywge29mZnNldDogMn0pXG5cdFx0KSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdsemgnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1semgtY29tcHJlc3NlZCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIE1QRUcgcHJvZ3JhbSBzdHJlYW0gKFBTIG9yIE1QRUctUFMpXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MDAsIDB4MDAsIDB4MDEsIDB4QkFdKSkge1xuXHRcdFx0Ly8gIE1QRUctUFMsIE1QRUctMSBQYXJ0IDFcblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDIxXSwge29mZnNldDogNCwgbWFzazogWzB4RjFdfSkpIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdtcGcnLCAvLyBNYXkgYWxzbyBiZSAucHMsIC5tcGVnXG5cdFx0XHRcdFx0bWltZTogJ3ZpZGVvL01QMVMnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBNUEVHLVBTLCBNUEVHLTIgUGFydCAxXG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHg0NF0sIHtvZmZzZXQ6IDQsIG1hc2s6IFsweEM0XX0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnbXBnJywgLy8gTWF5IGFsc28gYmUgLm1wZywgLm0ycCwgLnZvYiBvciAuc3ViXG5cdFx0XHRcdFx0bWltZTogJ3ZpZGVvL01QMlAnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdJVFNGJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2NobScsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi92bmQubXMtaHRtbGhlbHAnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHhDQSwgMHhGRSwgMHhCQSwgMHhCRV0pKSB7XG5cdFx0XHQvLyBKYXZhIGJ5dGVjb2RlIGFuZCBNYWNoLU8gdW5pdmVyc2FsIGJpbmFyaWVzIGhhdmUgdGhlIHNhbWUgbWFnaWMgbnVtYmVyLlxuXHRcdFx0Ly8gV2UgZGlzYW1iaWd1YXRlIGJhc2VkIG9uIHRoZSBuZXh0IDQgYnl0ZXMsIGFzIGRvbmUgYnkgYGZpbGVgLlxuXHRcdFx0Ly8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9maWxlL2ZpbGUvYmxvYi9tYXN0ZXIvbWFnaWMvTWFnZGlyL2NhZmViYWJlXG5cdFx0XHRjb25zdCBtYWNoT0FyY2hpdGVjdHVyZUNvdW50ID0gVG9rZW4uVUlOVDMyX0JFLmdldCh0aGlzLmJ1ZmZlciwgNCk7XG5cdFx0XHRpZiAobWFjaE9BcmNoaXRlY3R1cmVDb3VudCA+IDAgJiYgbWFjaE9BcmNoaXRlY3R1cmVDb3VudCA8PSAzMCkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ21hY2hvJyxcblx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1tYWNoLWJpbmFyeScsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGphdmFDbGFzc0ZpbGVNYWpvclZlcnNpb24gPSBUb2tlbi5VSU5UMTZfQkUuZ2V0KHRoaXMuYnVmZmVyLCA2KTtcblx0XHRcdGlmIChqYXZhQ2xhc3NGaWxlTWFqb3JWZXJzaW9uID4gMzApIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdjbGFzcycsXG5cdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL2phdmEtdm0nLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCcuUk1GJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3JtJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5ybi1yZWFsbWVkaWEnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyAtLSA1LWJ5dGUgc2lnbmF0dXJlcyAtLVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0RSQUNPJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2RyYycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWZ0LWRyYWNvJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gLS0gNi1ieXRlIHNpZ25hdHVyZXMgLS1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweEZELCAweDM3LCAweDdBLCAweDU4LCAweDVBLCAweDAwXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3h6Jyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gteHonLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnPD94bWwgJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3htbCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94bWwnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHgzNywgMHg3QSwgMHhCQywgMHhBRiwgMHgyNywgMHgxQ10pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICc3eicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LTd6LWNvbXByZXNzZWQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrKFsweDUyLCAweDYxLCAweDcyLCAweDIxLCAweDFBLCAweDddKVxuXHRcdFx0JiYgKHRoaXMuYnVmZmVyWzZdID09PSAweDAgfHwgdGhpcy5idWZmZXJbNl0gPT09IDB4MSlcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3JhcicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LXJhci1jb21wcmVzc2VkJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ3NvbGlkICcpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdzdGwnLFxuXHRcdFx0XHRtaW1lOiAnbW9kZWwvc3RsJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0FDJykpIHtcblx0XHRcdGNvbnN0IHZlcnNpb24gPSBuZXcgVG9rZW4uU3RyaW5nVHlwZSg0LCAnbGF0aW4xJykuZ2V0KHRoaXMuYnVmZmVyLCAyKTtcblx0XHRcdGlmICgvXlxcZCskL3YudGVzdCh2ZXJzaW9uKSAmJiB2ZXJzaW9uID49IDEwMDAgJiYgdmVyc2lvbiA8PSAxMDUwKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnZHdnJyxcblx0XHRcdFx0XHRtaW1lOiAnaW1hZ2Uvdm5kLmR3ZycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJzA3MDcwNycpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdjcGlvJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtY3BpbycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIC0tIDctYnl0ZSBzaWduYXR1cmVzIC0tXG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnQkxFTkRFUicpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdibGVuZCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWJsZW5kZXInLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnITxhcmNoPicpKSB7XG5cdFx0XHRhd2FpdCB0b2tlbml6ZXIuaWdub3JlKDgpO1xuXHRcdFx0Y29uc3Qgc3RyaW5nID0gYXdhaXQgdG9rZW5pemVyLnJlYWRUb2tlbihuZXcgVG9rZW4uU3RyaW5nVHlwZSgxMywgJ2FzY2lpJykpO1xuXHRcdFx0aWYgKHN0cmluZyA9PT0gJ2RlYmlhbi1iaW5hcnknKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnZGViJyxcblx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1kZWInLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdhcicsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LXVuaXgtYXJjaGl2ZScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmIChcblx0XHRcdHRoaXMuY2hlY2tTdHJpbmcoJ1dFQlZUVCcpXG5cdFx0XHQmJlx0KFxuXHRcdFx0XHQvLyBPbmUgb2YgTEYsIENSLCB0YWIsIHNwYWNlLCBvciBlbmQgb2YgZmlsZSBtdXN0IGZvbGxvdyBcIldFQlZUVFwiIHBlciB0aGUgc3BlYyAoc2VlIGBmaXh0dXJlL2ZpeHR1cmUtdnR0LSoudnR0YCBmb3IgZXhhbXBsZXMpLiBOb3RlIHRoYXQgYFxcMGAgaXMgdGVjaG5pY2FsbHkgdGhlIG51bGwgY2hhcmFjdGVyICh0aGVyZSBpcyBubyBzdWNoIHRoaW5nIGFzIGFuIEVPRiBjaGFyYWN0ZXIpLiBIb3dldmVyLCBjaGVja2luZyBmb3IgYFxcMGAgZ2l2ZXMgdXMgdGhlIHNhbWUgcmVzdWx0IGFzIGNoZWNraW5nIGZvciB0aGUgZW5kIG9mIHRoZSBzdHJlYW0uXG5cdFx0XHRcdChbJ1xcbicsICdcXHInLCAnXFx0JywgJyAnLCAnXFwwJ10uc29tZShjaGFyNyA9PiB0aGlzLmNoZWNrU3RyaW5nKGNoYXI3LCB7b2Zmc2V0OiA2fSkpKSlcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3Z0dCcsXG5cdFx0XHRcdG1pbWU6ICd0ZXh0L3Z0dCcsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIC0tIDgtYnl0ZSBzaWduYXR1cmVzIC0tXG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg4OSwgMHg1MCwgMHg0RSwgMHg0NywgMHgwRCwgMHgwQSwgMHgxQSwgMHgwQV0pKSB7XG5cdFx0XHRyZXR1cm4gZGV0ZWN0UG5nKHRva2VuaXplcik7XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDEsIDB4NTIsIDB4NTIsIDB4NEYsIDB4NTcsIDB4MzEsIDB4MDAsIDB4MDBdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnYXJyb3cnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vdm5kLmFwYWNoZS5hcnJvdy5maWxlJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NjcsIDB4NkMsIDB4NTQsIDB4NDYsIDB4MDIsIDB4MDAsIDB4MDAsIDB4MDBdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZ2xiJyxcblx0XHRcdFx0bWltZTogJ21vZGVsL2dsdGYtYmluYXJ5Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gYG1vdmAgZm9ybWF0IHZhcmlhbnRzXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVjayhbMHg2NiwgMHg3MiwgMHg2NSwgMHg2NV0sIHtvZmZzZXQ6IDR9KSAvLyBgZnJlZWBcblx0XHRcdHx8IHRoaXMuY2hlY2soWzB4NkQsIDB4NjQsIDB4NjEsIDB4NzRdLCB7b2Zmc2V0OiA0fSkgLy8gYG1kYXRgIE1KUEVHXG5cdFx0XHR8fCB0aGlzLmNoZWNrKFsweDZELCAweDZGLCAweDZGLCAweDc2XSwge29mZnNldDogNH0pIC8vIGBtb292YFxuXHRcdFx0fHwgdGhpcy5jaGVjayhbMHg3NywgMHg2OSwgMHg2NCwgMHg2NV0sIHtvZmZzZXQ6IDR9KSAvLyBgd2lkZWBcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ21vdicsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby9xdWlja3RpbWUnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyAtLSA5LWJ5dGUgc2lnbmF0dXJlcyAtLVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDksIDB4NDksIDB4NTIsIDB4NEYsIDB4MDgsIDB4MDAsIDB4MDAsIDB4MDAsIDB4MThdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnb3JmJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL3gtb2x5bXB1cy1vcmYnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnZ2ltcCB4Y2YgJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3hjZicsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS94LXhjZicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIEZpbGUgVHlwZSBCb3ggKGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0lTT19iYXNlX21lZGlhX2ZpbGVfZm9ybWF0KVxuXHRcdC8vIEl0J3Mgbm90IHJlcXVpcmVkIHRvIGJlIGZpcnN0LCBidXQgaXQncyByZWNvbW1lbmRlZCB0byBiZS4gQWxtb3N0IGFsbCBJU08gYmFzZSBtZWRpYSBmaWxlcyBzdGFydCB3aXRoIGBmdHlwYCBib3guXG5cdFx0Ly8gYGZ0eXBgIGJveCBtdXN0IGNvbnRhaW4gYSBicmFuZCBtYWpvciBpZGVudGlmaWVyLCB3aGljaCBtdXN0IGNvbnNpc3Qgb2YgSVNPIDg4NTktMSBwcmludGFibGUgY2hhcmFjdGVycy5cblx0XHQvLyBIZXJlIHdlIGNoZWNrIGZvciA4ODU5LTEgcHJpbnRhYmxlIGNoYXJhY3RlcnMgKGZvciBzaW1wbGljaXR5LCBpdCdzIGEgbWFzayB3aGljaCBhbHNvIGNhdGNoZXMgb25lIG5vbi1wcmludGFibGUgY2hhcmFjdGVyKS5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrU3RyaW5nKCdmdHlwJywge29mZnNldDogNH0pXG5cdFx0XHQmJiAodGhpcy5idWZmZXJbOF0gJiAweDYwKSAhPT0gMHgwMCAvLyBCcmFuZCBtYWpvciwgZmlyc3QgY2hhcmFjdGVyIEFTQ0lJP1xuXHRcdCkge1xuXHRcdFx0Ly8gVGhleSBhbGwgY2FuIGhhdmUgTUlNRSBgdmlkZW8vbXA0YCBleGNlcHQgYGFwcGxpY2F0aW9uL21wNGAgc3BlY2lhbC1jYXNlIHdoaWNoIGlzIGhhcmQgdG8gZGV0ZWN0LlxuXHRcdFx0Ly8gRm9yIHNvbWUgY2FzZXMsIHdlJ3JlIHNwZWNpZmljLCBldmVyeXRoaW5nIGVsc2UgZmFsbHMgdG8gYHZpZGVvL21wNGAgd2l0aCBgbXA0YCBleHRlbnNpb24uXG5cdFx0XHRjb25zdCBicmFuZE1ham9yID0gbmV3IFRva2VuLlN0cmluZ1R5cGUoNCwgJ2xhdGluMScpLmdldCh0aGlzLmJ1ZmZlciwgOCkucmVwbGFjZSgnXFwwJywgJyAnKS50cmltKCk7XG5cdFx0XHRzd2l0Y2ggKGJyYW5kTWFqb3IpIHtcblx0XHRcdFx0Y2FzZSAnYXZpZic6XG5cdFx0XHRcdGNhc2UgJ2F2aXMnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnYXZpZicsIG1pbWU6ICdpbWFnZS9hdmlmJ307XG5cdFx0XHRcdGNhc2UgJ21pZjEnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnaGVpYycsIG1pbWU6ICdpbWFnZS9oZWlmJ307XG5cdFx0XHRcdGNhc2UgJ21zZjEnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnaGVpYycsIG1pbWU6ICdpbWFnZS9oZWlmLXNlcXVlbmNlJ307XG5cdFx0XHRcdGNhc2UgJ2hlaWMnOlxuXHRcdFx0XHRjYXNlICdoZWl4Jzpcblx0XHRcdFx0XHRyZXR1cm4ge2V4dDogJ2hlaWMnLCBtaW1lOiAnaW1hZ2UvaGVpYyd9O1xuXHRcdFx0XHRjYXNlICdoZXZjJzpcblx0XHRcdFx0Y2FzZSAnaGV2eCc6XG5cdFx0XHRcdFx0cmV0dXJuIHtleHQ6ICdoZWljJywgbWltZTogJ2ltYWdlL2hlaWMtc2VxdWVuY2UnfTtcblx0XHRcdFx0Y2FzZSAncXQnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnbW92JywgbWltZTogJ3ZpZGVvL3F1aWNrdGltZSd9O1xuXHRcdFx0XHRjYXNlICdNNFYnOlxuXHRcdFx0XHRjYXNlICdNNFZIJzpcblx0XHRcdFx0Y2FzZSAnTTRWUCc6XG5cdFx0XHRcdFx0cmV0dXJuIHtleHQ6ICdtNHYnLCBtaW1lOiAndmlkZW8veC1tNHYnfTtcblx0XHRcdFx0Y2FzZSAnTTRQJzpcblx0XHRcdFx0XHRyZXR1cm4ge2V4dDogJ200cCcsIG1pbWU6ICd2aWRlby9tcDQnfTtcblx0XHRcdFx0Y2FzZSAnTTRCJzpcblx0XHRcdFx0XHRyZXR1cm4ge2V4dDogJ200YicsIG1pbWU6ICdhdWRpby9tcDQnfTtcblx0XHRcdFx0Y2FzZSAnTTRBJzpcblx0XHRcdFx0XHRyZXR1cm4ge2V4dDogJ200YScsIG1pbWU6ICdhdWRpby94LW00YSd9O1xuXHRcdFx0XHRjYXNlICdGNFYnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnZjR2JywgbWltZTogJ3ZpZGVvL21wNCd9O1xuXHRcdFx0XHRjYXNlICdGNFAnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnZjRwJywgbWltZTogJ3ZpZGVvL21wNCd9O1xuXHRcdFx0XHRjYXNlICdGNEEnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnZjRhJywgbWltZTogJ2F1ZGlvL21wNCd9O1xuXHRcdFx0XHRjYXNlICdGNEInOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnZjRiJywgbWltZTogJ2F1ZGlvL21wNCd9O1xuXHRcdFx0XHRjYXNlICdjcngnOlxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnY3IzJywgbWltZTogJ2ltYWdlL3gtY2Fub24tY3IzJ307XG5cdFx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdFx0aWYgKGJyYW5kTWFqb3Iuc3RhcnRzV2l0aCgnM2cnKSkge1xuXHRcdFx0XHRcdFx0aWYgKGJyYW5kTWFqb3Iuc3RhcnRzV2l0aCgnM2cyJykpIHtcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHtleHQ6ICczZzInLCBtaW1lOiAndmlkZW8vM2dwcDInfTtcblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0cmV0dXJuIHtleHQ6ICczZ3AnLCBtaW1lOiAndmlkZW8vM2dwcCd9O1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHJldHVybiB7ZXh0OiAnbXA0JywgbWltZTogJ3ZpZGVvL21wNCd9O1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIC0tIDEwLWJ5dGUgc2lnbmF0dXJlcyAtLVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ1JFR0VESVQ0XFxyXFxuJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3JlZycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LW1zLXJlZ2VkaXQnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyAtLSAxMi1ieXRlIHNpZ25hdHVyZXMgLS1cblxuXHRcdC8vIFJJRkYgZmlsZSBmb3JtYXQgd2hpY2ggbWlnaHQgYmUgQVZJLCBXQVYsIFFDUCwgZXRjXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NTIsIDB4NDksIDB4NDYsIDB4NDZdKSkge1xuXHRcdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ1dFQlAnLCB7b2Zmc2V0OiA4fSkpIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICd3ZWJwJyxcblx0XHRcdFx0XHRtaW1lOiAnaW1hZ2Uvd2VicCcsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDQxLCAweDU2LCAweDQ5XSwge29mZnNldDogOH0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnYXZpJyxcblx0XHRcdFx0XHRtaW1lOiAndmlkZW8vdm5kLmF2aScsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDU3LCAweDQxLCAweDU2LCAweDQ1XSwge29mZnNldDogOH0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnd2F2Jyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vd2F2Jyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gUUxDTSwgUUNQIGZpbGVcblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDUxLCAweDRDLCAweDQzLCAweDREXSwge29mZnNldDogOH0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAncWNwJyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vcWNlbHAnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDQ5LCAweDQ5LCAweDU1LCAweDAwLCAweDE4LCAweDAwLCAweDAwLCAweDAwLCAweDg4LCAweEU3LCAweDc0LCAweEQ4XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3J3MicsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS94LXBhbmFzb25pYy1ydzInLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyBBU0ZfSGVhZGVyX09iamVjdCBmaXJzdCA4MCBieXRlc1xuXHRcdGlmICh0aGlzLmNoZWNrKFsweDMwLCAweDI2LCAweEIyLCAweDc1LCAweDhFLCAweDY2LCAweENGLCAweDExLCAweEE2LCAweEQ5XSkpIHtcblx0XHRcdHJldHVybiBkZXRlY3RBc2YodG9rZW5pemVyKTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHhBQiwgMHg0QiwgMHg1NCwgMHg1OCwgMHgyMCwgMHgzMSwgMHgzMSwgMHhCQiwgMHgwRCwgMHgwQSwgMHgxQSwgMHgwQV0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdrdHgnLFxuXHRcdFx0XHRtaW1lOiAnaW1hZ2Uva3R4Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKCh0aGlzLmNoZWNrKFsweDdFLCAweDEwLCAweDA0XSkgfHwgdGhpcy5jaGVjayhbMHg3RSwgMHgxOCwgMHgwNF0pKSAmJiB0aGlzLmNoZWNrKFsweDMwLCAweDRELCAweDQ5LCAweDQ1XSwge29mZnNldDogNH0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdtaWUnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1taWUnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHgyNywgMHgwQSwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMF0sIHtvZmZzZXQ6IDJ9KSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnc2hwJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtZXNyaS1zaGFwZScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweEZGLCAweDRGLCAweEZGLCAweDUxXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2oyYycsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS9qMmMnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHgwMCwgMHgwMCwgMHgwMCwgMHgwQywgMHg2QSwgMHg1MCwgMHgyMCwgMHgyMCwgMHgwRCwgMHgwQSwgMHg4NywgMHgwQV0pKSB7XG5cdFx0XHQvLyBKUEVHLTIwMDAgZmFtaWx5XG5cblx0XHRcdGF3YWl0IHRva2VuaXplci5pZ25vcmUoMjApO1xuXHRcdFx0Y29uc3QgdHlwZSA9IGF3YWl0IHRva2VuaXplci5yZWFkVG9rZW4obmV3IFRva2VuLlN0cmluZ1R5cGUoNCwgJ2FzY2lpJykpO1xuXHRcdFx0c3dpdGNoICh0eXBlKSB7XG5cdFx0XHRcdGNhc2UgJ2pwMiAnOlxuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRleHQ6ICdqcDInLFxuXHRcdFx0XHRcdFx0bWltZTogJ2ltYWdlL2pwMicsXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSAnanB4ICc6XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdGV4dDogJ2pweCcsXG5cdFx0XHRcdFx0XHRtaW1lOiAnaW1hZ2UvanB4Jyxcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlICdqcG0gJzpcblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0ZXh0OiAnanBtJyxcblx0XHRcdFx0XHRcdG1pbWU6ICdpbWFnZS9qcG0nLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgJ21qcDInOlxuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRleHQ6ICdtajInLFxuXHRcdFx0XHRcdFx0bWltZTogJ2ltYWdlL21qMicsXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVjayhbMHhGRiwgMHgwQV0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrKFsweDAwLCAweDAwLCAweDAwLCAweDBDLCAweDRBLCAweDU4LCAweDRDLCAweDIwLCAweDBELCAweDBBLCAweDg3LCAweDBBXSlcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2p4bCcsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS9qeGwnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHhGRSwgMHhGRl0pKSB7IC8vIFVURi0xNi1CT00tQkVcblx0XHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCc8P3htbCAnLCB7b2Zmc2V0OiAyLCBlbmNvZGluZzogJ3V0Zi0xNmJlJ30pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAneG1sJyxcblx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veG1sJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHVuZGVmaW5lZDsgLy8gU29tZSB1bmtub3duIHRleHQgYmFzZWQgZm9ybWF0XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4RDAsIDB4Q0YsIDB4MTEsIDB4RTAsIDB4QTEsIDB4QjEsIDB4MUEsIDB4RTFdKSkge1xuXHRcdFx0Ly8gRGV0ZWN0ZWQgTWljcm9zb2Z0IENvbXBvdW5kIEZpbGUgQmluYXJ5IEZpbGUgKE1TLUNGQikgRm9ybWF0LlxuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnY2ZiJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtY2ZiJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gRGlyZWN0IFN0cmVhbSBEaWdpdGFsIEludGVyY2hhbmdlIEZpbGUgRm9ybWF0IChEU0RJRkYpXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0ZSTTgnKSAmJiB0aGlzLmNoZWNrU3RyaW5nKCdEU0QgJywge29mZnNldDogMTJ9KSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZGZmJyxcblx0XHRcdFx0bWltZTogJ2F1ZGlvL3gtZGZmJywgLy8gTm9uLXN0YW5kYXJkXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIEluY3JlYXNlIHNhbXBsZSBzaXplIGZyb20gMzIgdG8gMjU2LlxuXHRcdGF3YWl0IHRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuYnVmZmVyLCB7bGVuZ3RoOiBNYXRoLm1pbigyNTYsIHRva2VuaXplci5maWxlSW5mby5zaXplKSwgbWF5QmVMZXNzOiB0cnVlfSk7XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHg2MSwgMHg2MywgMHg3MywgMHg3MF0sIHtvZmZzZXQ6IDM2fSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2ljYycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi92bmQuaWNjcHJvZmlsZScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdC8vIEFDRTogcmVxdWlyZXMgMTQgYnl0ZXMgaW4gdGhlIGJ1ZmZlclxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCcqKkFDRScsIHtvZmZzZXQ6IDd9KSAmJiB0aGlzLmNoZWNrU3RyaW5nKCcqKicsIHtvZmZzZXQ6IDEyfSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2FjZScsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWFjZS1jb21wcmVzc2VkJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gLS0gMTUtYnl0ZSBzaWduYXR1cmVzIC0tXG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnQkVHSU46JykpIHtcblx0XHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdWQ0FSRCcsIHtvZmZzZXQ6IDZ9KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ3ZjZicsXG5cdFx0XHRcdFx0bWltZTogJ3RleHQvdmNhcmQnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnVkNBTEVOREFSJywge29mZnNldDogNn0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnaWNzJyxcblx0XHRcdFx0XHRtaW1lOiAndGV4dC9jYWxlbmRhcicsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gYHJhZmAgaXMgaGVyZSBqdXN0IHRvIGtlZXAgYWxsIHRoZSByYXcgaW1hZ2UgZGV0ZWN0b3JzIHRvZ2V0aGVyLlxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdGVUpJRklMTUNDRC1SQVcnKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAncmFmJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL3gtZnVqaWZpbG0tcmFmJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0V4dGVuZGVkIE1vZHVsZTonKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAneG0nLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8veC14bScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdDcmVhdGl2ZSBWb2ljZSBGaWxlJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3ZvYycsXG5cdFx0XHRcdG1pbWU6ICdhdWRpby94LXZvYycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDA0LCAweDAwLCAweDAwLCAweDAwXSkgJiYgdGhpcy5idWZmZXIubGVuZ3RoID49IDE2KSB7IC8vIFJvdWdoICYgcXVpY2sgY2hlY2sgUGlja2xlL0FTQVJcblx0XHRcdGNvbnN0IGpzb25TaXplID0gbmV3IERhdGFWaWV3KHRoaXMuYnVmZmVyLmJ1ZmZlcikuZ2V0VWludDMyKDEyLCB0cnVlKTtcblxuXHRcdFx0aWYgKGpzb25TaXplID4gMTIgJiYgdGhpcy5idWZmZXIubGVuZ3RoID49IGpzb25TaXplICsgMTYpIHtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBoZWFkZXIgPSBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUodGhpcy5idWZmZXIuc3ViYXJyYXkoMTYsIGpzb25TaXplICsgMTYpKTtcblx0XHRcdFx0XHRjb25zdCBqc29uID0gSlNPTi5wYXJzZShoZWFkZXIpO1xuXHRcdFx0XHRcdC8vIENoZWNrIGlmIFBpY2tsZSBpcyBBU0FSXG5cdFx0XHRcdFx0aWYgKGpzb24uZmlsZXMpIHsgLy8gRmluYWwgY2hlY2ssIGFzc3VyaW5nIFBpY2tsZS9BU0FSIGZvcm1hdFxuXHRcdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdFx0ZXh0OiAnYXNhcicsXG5cdFx0XHRcdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWFzYXInLFxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdH1cblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVjayhbMHgwNiwgMHgwRSwgMHgyQiwgMHgzNCwgMHgwMiwgMHgwNSwgMHgwMSwgMHgwMSwgMHgwRCwgMHgwMSwgMHgwMiwgMHgwMSwgMHgwMSwgMHgwMl0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdteGYnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24vbXhmJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ1NDUk0nLCB7b2Zmc2V0OiA0NH0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdzM20nLFxuXHRcdFx0XHRtaW1lOiAnYXVkaW8veC1zM20nLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyBSYXcgTVBFRy0yIHRyYW5zcG9ydCBzdHJlYW0gKDE4OC1ieXRlIHBhY2tldHMpXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDddKSAmJiB0aGlzLmNoZWNrKFsweDQ3XSwge29mZnNldDogMTg4fSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ210cycsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby9tcDJ0Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gQmx1LXJheSBEaXNjIEF1ZGlvLVZpZGVvIChCREFWKSBNUEVHLTIgdHJhbnNwb3J0IHN0cmVhbSBoYXMgNC1ieXRlIFRQX2V4dHJhX2hlYWRlciBiZWZvcmUgZWFjaCAxODgtYnl0ZSBwYWNrZXRcblx0XHRpZiAodGhpcy5jaGVjayhbMHg0N10sIHtvZmZzZXQ6IDR9KSAmJiB0aGlzLmNoZWNrKFsweDQ3XSwge29mZnNldDogMTk2fSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ210cycsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby9tcDJ0Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NDIsIDB4NEYsIDB4NEYsIDB4NEIsIDB4NEQsIDB4NEYsIDB4NDIsIDB4NDldLCB7b2Zmc2V0OiA2MH0pKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdtb2JpJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtbW9iaXBvY2tldC1lYm9vaycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDQ0LCAweDQ5LCAweDQzLCAweDREXSwge29mZnNldDogMTI4fSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2RjbScsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9kaWNvbScsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDRDLCAweDAwLCAweDAwLCAweDAwLCAweDAxLCAweDE0LCAweDAyLCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweEMwLCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweDAwLCAweDQ2XSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2xuaycsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LW1zLXNob3J0Y3V0JywgLy8gSW5mb3JtYWwsIHVzZWQgYnkgZnJlZWRlc2t0b3Aub3JnIHNoYXJlZC1taW1lLWluZm9cblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4NjIsIDB4NkYsIDB4NkYsIDB4NkIsIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDAsIDB4NkQsIDB4NjEsIDB4NzIsIDB4NkIsIDB4MDAsIDB4MDAsIDB4MDAsIDB4MDBdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnYWxpYXMnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1mdC1hcHBsZS5hbGlhcycsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrU3RyaW5nKCdLYXlkYXJhIEZCWCBCaW5hcnkgIFxcMCcpKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRleHQ6ICdmYngnLFxuXHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1mdC1mYngnLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHRpZiAoXG5cdFx0XHR0aGlzLmNoZWNrKFsweDRDLCAweDUwXSwge29mZnNldDogMzR9KVxuXHRcdFx0JiYgKFxuXHRcdFx0XHR0aGlzLmNoZWNrKFsweDAwLCAweDAwLCAweDAxXSwge29mZnNldDogOH0pXG5cdFx0XHRcdHx8IHRoaXMuY2hlY2soWzB4MDEsIDB4MDAsIDB4MDJdLCB7b2Zmc2V0OiA4fSlcblx0XHRcdFx0fHwgdGhpcy5jaGVjayhbMHgwMiwgMHgwMCwgMHgwMl0sIHtvZmZzZXQ6IDh9KVxuXHRcdFx0KVxuXHRcdCkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnZW90Jyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5tcy1mb250b2JqZWN0Jyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MDYsIDB4MDYsIDB4RUQsIDB4RjUsIDB4RDgsIDB4MUQsIDB4NDYsIDB4RTUsIDB4QkQsIDB4MzEsIDB4RUYsIDB4RTcsIDB4RkUsIDB4NzQsIDB4QjcsIDB4MURdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnaW5kZCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWluZGVzaWduJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gLS0gMTYtYnl0ZSBzaWduYXR1cmVzIC0tXG5cblx0XHQvLyBKTVAgZmlsZXMgLSBjaGVjayBmb3IgYm90aCBMaXR0bGUgRW5kaWFuIGFuZCBCaWcgRW5kaWFuIHNpZ25hdHVyZXNcblx0XHRpZiAodGhpcy5jaGVjayhbMHhGRiwgMHhGRiwgMHgwMCwgMHgwMCwgMHgwNywgMHgwMCwgMHgwMCwgMHgwMCwgMHgwNCwgMHgwMCwgMHgwMCwgMHgwMCwgMHgwMSwgMHgwMCwgMHgwMSwgMHgwMF0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrKFsweDAwLCAweDAwLCAweEZGLCAweEZGLCAweDAwLCAweDAwLCAweDAwLCAweDA3LCAweDAwLCAweDAwLCAweDAwLCAweDA0LCAweDAwLCAweDAxLCAweDAwLCAweDAxXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2ptcCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi94LWptcC1kYXRhJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gSW5jcmVhc2Ugc2FtcGxlIHNpemUgZnJvbSAyNTYgdG8gNTEyXG5cdFx0YXdhaXQgdG9rZW5pemVyLnBlZWtCdWZmZXIodGhpcy5idWZmZXIsIHtsZW5ndGg6IE1hdGgubWluKDUxMiwgdG9rZW5pemVyLmZpbGVJbmZvLnNpemUpLCBtYXlCZUxlc3M6IHRydWV9KTtcblxuXHRcdC8vIFJlcXVpcmVzIGEgYnVmZmVyIHNpemUgb2YgNTEyIGJ5dGVzXG5cdFx0aWYgKCh0aGlzLmNoZWNrU3RyaW5nKCd1c3RhcicsIHtvZmZzZXQ6IDI1N30pICYmICh0aGlzLmNoZWNrU3RyaW5nKCdcXDAnLCB7b2Zmc2V0OiAyNjJ9KSB8fCB0aGlzLmNoZWNrU3RyaW5nKCcgJywge29mZnNldDogMjYyfSkpKVxuXHRcdFx0fHwgKHRoaXMuY2hlY2soWzAsIDAsIDAsIDAsIDAsIDBdLCB7b2Zmc2V0OiAyNTd9KSAmJiB0YXJIZWFkZXJDaGVja3N1bU1hdGNoZXModGhpcy5idWZmZXIpKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAndGFyJyxcblx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtdGFyJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4RkYsIDB4RkVdKSkgeyAvLyBVVEYtMTYtQk9NLUxFXG5cdFx0XHRjb25zdCBlbmNvZGluZyA9ICd1dGYtMTZsZSc7XG5cdFx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnPD94bWwgJywge29mZnNldDogMiwgZW5jb2Rpbmd9KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ3htbCcsXG5cdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3htbCcsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweEZGLCAweDBFXSwge29mZnNldDogMn0pICYmIHRoaXMuY2hlY2tTdHJpbmcoJ1NrZXRjaFVwIE1vZGVsJywge29mZnNldDogNCwgZW5jb2Rpbmd9KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ3NrcCcsXG5cdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3ZuZC5za2V0Y2h1cC5za3AnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnV2luZG93cyBSZWdpc3RyeSBFZGl0b3IgVmVyc2lvbiA1LjAwXFxyXFxuJywge29mZnNldDogMiwgZW5jb2Rpbmd9KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ3JlZycsXG5cdFx0XHRcdFx0bWltZTogJ2FwcGxpY2F0aW9uL3gtbXMtcmVnZWRpdCcsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiB1bmRlZmluZWQ7IC8vIFNvbWUgdGV4dCBiYXNlZCBmb3JtYXRcblx0XHR9XG5cblx0XHRpZiAodGhpcy5jaGVja1N0cmluZygnLS0tLS1CRUdJTiBQR1AgTUVTU0FHRS0tLS0tJykpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ3BncCcsXG5cdFx0XHRcdG1pbWU6ICdhcHBsaWNhdGlvbi9wZ3AtZW5jcnlwdGVkJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0Ly8gSVNPIDk2NjAgb3B0aWNhbCBkaXNjIGltYWdlOiB0aGUgVm9sdW1lIERlc2NyaXB0b3IgU2V0IHN0YXJ0cyBhdCBzZWN0b3IgMTYgKDIwNDgtYnl0ZVxuXHRcdC8vIHNlY3RvcnMpLiBFdmVyeSBkZXNjcmlwdG9yIGluIHRoYXQgc2V0IGNhcnJpZXMgdGhlIDUtYnl0ZSBzdGFuZGFyZCBpZGVudGlmaWVyIGBDRDAwMWBcblx0XHQvLyBhdCBvZmZzZXQgMSwgcmVnYXJkbGVzcyBvZiBkZXNjcmlwdG9yIHR5cGUsIHNvIGNoZWNraW5nIHRoZSBmaXJzdCBvbmUgaXMgc3VmZmljaWVudC5cblx0XHQvLyBPbmx5IGF0dGVtcHRlZCBmb3IgcmFuZG9tLWFjY2VzcyBpbnB1dHMgKGJ1ZmZlci9maWxlL2Jsb2IsIG9yIGEgc3RyZWFtIHNhbXBsZWQgd2l0aCBhXG5cdFx0Ly8gbGFyZ2UgZW5vdWdoIGBzYW1wbGVTaXplYCk6IG9uIGFuIHVua25vd24tc2l6ZSBzdHJlYW0gdGhpcyBvZmZzZXQgaXMgZmFyIHBhc3Qgd2hhdCdzXG5cdFx0Ly8gcmVhc29uYWJsZSB0byBidWZmZXIganVzdCB0byBydWxlIG91dCBvbmUgZm9ybWF0LCBzbyBpdCdzIGxlZnQgdW5kZXRlY3RlZCB0aGVyZS5cblx0XHRjb25zdCBpc29TdGFuZGFyZElkZW50aWZpZXJPZmZzZXQgPSAzMl83Njk7XG5cdFx0Y29uc3QgaXNvU3RhbmRhcmRJZGVudGlmaWVyTGVuZ3RoID0gNTtcblx0XHRpZiAoXG5cdFx0XHR0b2tlbml6ZXIuc3VwcG9ydHNSYW5kb21BY2Nlc3MoKVxuXHRcdFx0JiYgdG9rZW5pemVyLmZpbGVJbmZvLnNpemUgPj0gKGlzb1N0YW5kYXJkSWRlbnRpZmllck9mZnNldCArIGlzb1N0YW5kYXJkSWRlbnRpZmllckxlbmd0aClcblx0XHQpIHtcblx0XHRcdGNvbnN0IGlzb1N0YW5kYXJkSWRlbnRpZmllciA9IG5ldyBVaW50OEFycmF5KGlzb1N0YW5kYXJkSWRlbnRpZmllckxlbmd0aCk7XG5cdFx0XHRhd2FpdCB0b2tlbml6ZXIucGVla0J1ZmZlcihpc29TdGFuZGFyZElkZW50aWZpZXIsIHtcblx0XHRcdFx0cG9zaXRpb246IGlzb1N0YW5kYXJkSWRlbnRpZmllck9mZnNldCxcblx0XHRcdFx0bGVuZ3RoOiBpc29TdGFuZGFyZElkZW50aWZpZXJMZW5ndGgsXG5cdFx0XHRcdG1heUJlTGVzczogdHJ1ZSxcblx0XHRcdH0pO1xuXG5cdFx0XHRpZiAoY2hlY2tCeXRlcyhpc29TdGFuZGFyZElkZW50aWZpZXIsIHN0cmluZ1RvQnl0ZXMoJ0NEMDAxJykpKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnaXNvJyxcblx0XHRcdFx0XHRtaW1lOiAnYXBwbGljYXRpb24veC1pc285NjYwLWltYWdlJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBEZXRlY3Rpb25zIHdpdGggbGltaXRlZCBzdXBwb3J0aW5nIGRhdGEsIHJlc3VsdGluZyBpbiBhIGhpZ2hlciBsaWtlbGlob29kIG9mIGZhbHNlIHBvc2l0aXZlc1xuXHRhc3luYyBkZXRlY3RJbXByZWNpc2UodG9rZW5pemVyKSB7XG5cdFx0dGhpcy5idWZmZXIgPSBuZXcgVWludDhBcnJheShyZWFzb25hYmxlRGV0ZWN0aW9uU2l6ZUluQnl0ZXMpO1xuXHRcdGNvbnN0IGZpbGVTaXplID0gZ2V0S25vd25GaWxlU2l6ZU9yTWF4aW11bSh0b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSk7XG5cblx0XHQvLyBSZWFkIGluaXRpYWwgc2FtcGxlIHNpemUgb2YgOCBieXRlc1xuXHRcdGF3YWl0IHRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuYnVmZmVyLCB7bGVuZ3RoOiBNYXRoLm1pbig4LCBmaWxlU2l6ZSksIG1heUJlTGVzczogdHJ1ZX0pO1xuXG5cdFx0aWYgKFxuXHRcdFx0dGhpcy5jaGVjayhbMHgwLCAweDAsIDB4MSwgMHhCQV0pXG5cdFx0XHR8fCB0aGlzLmNoZWNrKFsweDAsIDB4MCwgMHgxLCAweEIzXSlcblx0XHQpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ21wZycsXG5cdFx0XHRcdG1pbWU6ICd2aWRlby9tcGVnJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MDAsIDB4MDEsIDB4MDAsIDB4MDAsIDB4MDBdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAndHRmJyxcblx0XHRcdFx0bWltZTogJ2ZvbnQvdHRmJyxcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4MDAsIDB4MDAsIDB4MDEsIDB4MDBdKSkge1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0ZXh0OiAnaWNvJyxcblx0XHRcdFx0bWltZTogJ2ltYWdlL3gtaWNvbicsXG5cdFx0XHR9O1xuXHRcdH1cblxuXHRcdGlmICh0aGlzLmNoZWNrKFsweDAwLCAweDAwLCAweDAyLCAweDAwXSkpIHtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGV4dDogJ2N1cicsXG5cdFx0XHRcdG1pbWU6ICdpbWFnZS94LWljb24nLFxuXHRcdFx0fTtcblx0XHR9XG5cblx0XHQvLyBBZGp1c3QgYnVmZmVyIHRvIGBtcGVnT2Zmc2V0VG9sZXJhbmNlYCwgcGx1cyB0aGUgNCBieXRlcyBvZiB0aGUgZnJhbWUgaGVhZGVyIGl0c2VsZlxuXHRcdGF3YWl0IHRva2VuaXplci5wZWVrQnVmZmVyKHRoaXMuYnVmZmVyLCB7bGVuZ3RoOiBNYXRoLm1pbig0ICsgdGhpcy5vcHRpb25zLm1wZWdPZmZzZXRUb2xlcmFuY2UsIGZpbGVTaXplKSwgbWF5QmVMZXNzOiB0cnVlfSk7XG5cblx0XHQvLyBDaGVjayBNUEVHIDEgb3IgMiBMYXllciAzIGhlYWRlciwgb3IgJ2xheWVyIDAnIGZvciBBRFRTIChNUEVHIHN5bmMtd29yZCAweEZGRSlcblx0XHRpZiAodGhpcy5idWZmZXIubGVuZ3RoID49ICg0ICsgdGhpcy5vcHRpb25zLm1wZWdPZmZzZXRUb2xlcmFuY2UpKSB7XG5cdFx0XHRmb3IgKGxldCBkZXB0aCA9IDA7IGRlcHRoIDw9IHRoaXMub3B0aW9ucy5tcGVnT2Zmc2V0VG9sZXJhbmNlOyArK2RlcHRoKSB7XG5cdFx0XHRcdGNvbnN0IHR5cGUgPSB0aGlzLnNjYW5NcGVnKGRlcHRoKTtcblx0XHRcdFx0aWYgKHR5cGUpIHtcblx0XHRcdFx0XHRyZXR1cm4gdHlwZTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGFzeW5jIHJlYWRUaWZmVGFnKGlzQmlnRW5kaWFuKSB7XG5cdFx0Y29uc3QgdGFnSWQgPSBhd2FpdCB0aGlzLnRva2VuaXplci5yZWFkVG9rZW4oaXNCaWdFbmRpYW4gPyBUb2tlbi5VSU5UMTZfQkUgOiBUb2tlbi5VSU5UMTZfTEUpO1xuXHRcdGF3YWl0IHRoaXMudG9rZW5pemVyLmlnbm9yZSgxMCk7XG5cdFx0c3dpdGNoICh0YWdJZCkge1xuXHRcdFx0Y2FzZSA1MF8zNDE6XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnYXJ3Jyxcblx0XHRcdFx0XHRtaW1lOiAnaW1hZ2UveC1zb255LWFydycsXG5cdFx0XHRcdH07XG5cdFx0XHRjYXNlIDUwXzcwNjpcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdkbmcnLFxuXHRcdFx0XHRcdG1pbWU6ICdpbWFnZS94LWFkb2JlLWRuZycsXG5cdFx0XHRcdH07XG5cdFx0XHRkZWZhdWx0OlxuXHRcdH1cblx0fVxuXG5cdGFzeW5jIHJlYWRUaWZmSUZEKGlzQmlnRW5kaWFuKSB7XG5cdFx0Y29uc3QgbnVtYmVyT2ZUYWdzID0gYXdhaXQgdGhpcy50b2tlbml6ZXIucmVhZFRva2VuKGlzQmlnRW5kaWFuID8gVG9rZW4uVUlOVDE2X0JFIDogVG9rZW4uVUlOVDE2X0xFKTtcblx0XHRpZiAobnVtYmVyT2ZUYWdzID4gbWF4aW11bVRpZmZUYWdDb3VudCkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGlmIChcblx0XHRcdGhhc1Vua25vd25GaWxlU2l6ZSh0aGlzLnRva2VuaXplcilcblx0XHRcdCYmICgyICsgKG51bWJlck9mVGFncyAqIDEyKSkgPiBtYXhpbXVtVGlmZklmZE9mZnNldEluQnl0ZXNcblx0XHQpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRmb3IgKGxldCBuID0gMDsgbiA8IG51bWJlck9mVGFnczsgKytuKSB7XG5cdFx0XHRjb25zdCBmaWxlVHlwZSA9IGF3YWl0IHRoaXMucmVhZFRpZmZUYWcoaXNCaWdFbmRpYW4pO1xuXHRcdFx0aWYgKGZpbGVUeXBlKSB7XG5cdFx0XHRcdHJldHVybiBmaWxlVHlwZTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRhc3luYyByZWFkVGlmZkhlYWRlcihpc0JpZ0VuZGlhbikge1xuXHRcdGNvbnN0IHRpZmZGaWxlVHlwZSA9IHtcblx0XHRcdGV4dDogJ3RpZicsXG5cdFx0XHRtaW1lOiAnaW1hZ2UvdGlmZicsXG5cdFx0fTtcblxuXHRcdGNvbnN0IHZlcnNpb24gPSAoaXNCaWdFbmRpYW4gPyBUb2tlbi5VSU5UMTZfQkUgOiBUb2tlbi5VSU5UMTZfTEUpLmdldCh0aGlzLmJ1ZmZlciwgMik7XG5cdFx0Y29uc3QgaWZkT2Zmc2V0ID0gKGlzQmlnRW5kaWFuID8gVG9rZW4uVUlOVDMyX0JFIDogVG9rZW4uVUlOVDMyX0xFKS5nZXQodGhpcy5idWZmZXIsIDQpO1xuXG5cdFx0aWYgKHZlcnNpb24gPT09IDQyKSB7XG5cdFx0XHQvLyBUSUZGIGZpbGUgaGVhZGVyXG5cdFx0XHRpZiAoaWZkT2Zmc2V0ID49IDYpIHtcblx0XHRcdFx0aWYgKHRoaXMuY2hlY2tTdHJpbmcoJ0NSJywge29mZnNldDogOH0pKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdGV4dDogJ2NyMicsXG5cdFx0XHRcdFx0XHRtaW1lOiAnaW1hZ2UveC1jYW5vbi1jcjInLFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoaWZkT2Zmc2V0ID49IDgpIHtcblx0XHRcdFx0XHRjb25zdCBzb21lSWQxID0gKGlzQmlnRW5kaWFuID8gVG9rZW4uVUlOVDE2X0JFIDogVG9rZW4uVUlOVDE2X0xFKS5nZXQodGhpcy5idWZmZXIsIDgpO1xuXHRcdFx0XHRcdGNvbnN0IHNvbWVJZDIgPSAoaXNCaWdFbmRpYW4gPyBUb2tlbi5VSU5UMTZfQkUgOiBUb2tlbi5VSU5UMTZfTEUpLmdldCh0aGlzLmJ1ZmZlciwgMTApO1xuXG5cdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0KHNvbWVJZDEgPT09IDB4MUMgJiYgc29tZUlkMiA9PT0gMHhGRSlcblx0XHRcdFx0XHRcdHx8IChzb21lSWQxID09PSAweDFGICYmIHNvbWVJZDIgPT09IDB4MEIpKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0XHRleHQ6ICduZWYnLFxuXHRcdFx0XHRcdFx0XHRtaW1lOiAnaW1hZ2UveC1uaWtvbi1uZWYnLFxuXHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0aWYgKFxuXHRcdFx0XHRoYXNVbmtub3duRmlsZVNpemUodGhpcy50b2tlbml6ZXIpXG5cdFx0XHRcdCYmIGlmZE9mZnNldCA+IG1heGltdW1UaWZmU3RyZWFtSWZkT2Zmc2V0SW5CeXRlc1xuXHRcdFx0KSB7XG5cdFx0XHRcdHJldHVybiB0aWZmRmlsZVR5cGU7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IG1heGltdW1UaWZmT2Zmc2V0ID0gaGFzVW5rbm93bkZpbGVTaXplKHRoaXMudG9rZW5pemVyKSA/IG1heGltdW1UaWZmSWZkT2Zmc2V0SW5CeXRlcyA6IHRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemU7XG5cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHNhZmVJZ25vcmUodGhpcy50b2tlbml6ZXIsIGlmZE9mZnNldCwge1xuXHRcdFx0XHRcdG1heGltdW1MZW5ndGg6IG1heGltdW1UaWZmT2Zmc2V0LFxuXHRcdFx0XHRcdHJlYXNvbjogJ1RJRkYgSUZEIG9mZnNldCcsXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2Ygc3RydG9rMy5FbmRPZlN0cmVhbUVycm9yKSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cblx0XHRcdGxldCBmaWxlVHlwZTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGZpbGVUeXBlID0gYXdhaXQgdGhpcy5yZWFkVGlmZklGRChpc0JpZ0VuZGlhbik7XG5cdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBzdHJ0b2szLkVuZE9mU3RyZWFtRXJyb3IpIHtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIGZpbGVUeXBlID8/IHRpZmZGaWxlVHlwZTtcblx0XHR9XG5cblx0XHRpZiAodmVyc2lvbiA9PT0gNDMpIHtcdC8vIEJpZyBUSUZGIGZpbGUgaGVhZGVyXG5cdFx0XHRyZXR1cm4gdGlmZkZpbGVUeXBlO1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHRTY2FuIGNoZWNrIE1QRUcgMSBvciAyIExheWVyIDMgaGVhZGVyLCBvciAnbGF5ZXIgMCcgZm9yIEFEVFMgKE1QRUcgc3luYy13b3JkIDB4RkZFKS5cblxuXHRAcGFyYW0ge251bWJlcn0gb2Zmc2V0IC0gT2Zmc2V0IHRvIHNjYW4gZm9yIHN5bmMtcHJlYW1ibGUuXG5cdEByZXR1cm5zIHt7ZXh0OiBzdHJpbmcsIG1pbWU6IHN0cmluZ30gfCB1bmRlZmluZWR9IFRoZSBkZXRlY3RlZCBmaWxlIHR5cGUsIGlmIGFueS5cblx0Ki9cblx0c2Nhbk1wZWcob2Zmc2V0KSB7XG5cdFx0aWYgKHRoaXMuY2hlY2soWzB4RkYsIDB4RTBdLCB7b2Zmc2V0LCBtYXNrOiBbMHhGRiwgMHhFMF19KSkge1xuXHRcdFx0Ly8gQm90aCAoQURUUykgTVBFRy0yIGFuZCBNUEVHLTQgYXJlIEFBQ1xuXHRcdFx0aWYgKHRoaXMuY2hlY2soWzB4MTBdLCB7b2Zmc2V0OiBvZmZzZXQgKyAxLCBtYXNrOiBbMHgxNl19KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ2FhYycsXG5cdFx0XHRcdFx0bWltZTogJ2F1ZGlvL2FhYycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cblx0XHRcdC8vIEFuIE1QRUctMSBMYXllciBJIGhlYWRlciB3aXRoIENSQyBwcm90ZWN0aW9uIGVuYWJsZWQgaXMgYnl0ZS1pZGVudGljYWwgdG8gYSBVVEYtMTYgTEUgQk9NLCBzbyB0ZXh0IGZpbGVzIGNhbm5vdCBiZSB0b2xkIGFwYXJ0IGZyb20gYXVkaW8uIGBmaWxlKDEpYCBkaXNhYmxlcyBNUEVHLTEgTGF5ZXIgSSBkZXRlY3Rpb24gY29tcGxldGVseSBmb3IgdGhpcyByZWFzb247IHdlIG9ubHkgZHJvcCB0aGUgY29sbGlkaW5nIHZhcmlhbnQuXG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHhGRiwgMHhGRV0sIHtvZmZzZXR9KSkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdC8vIFJlamVjdCB0aGUgcmVzZXJ2ZWQgTVBFRyB2ZXJzaW9uIGAwMWBcblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDA4XSwge29mZnNldDogb2Zmc2V0ICsgMSwgbWFzazogWzB4MThdfSkpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZWplY3QgdGhlIGBiYWRgIChgMTExMWApIGJpdHJhdGUgaW5kZXhcblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweEYwXSwge29mZnNldDogb2Zmc2V0ICsgMiwgbWFzazogWzB4RjBdfSkpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBSZWplY3QgdGhlIHJlc2VydmVkIHNhbXBsaW5nIGZyZXF1ZW5jeSBgMTFgXG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHgwQ10sIHtvZmZzZXQ6IG9mZnNldCArIDIsIG1hc2s6IFsweDBDXX0pKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Ly8gTVBFRyAxIG9yIDIgTGF5ZXIgMyBoZWFkZXJcblx0XHRcdC8vIENoZWNrIGZvciBNUEVHIGxheWVyIDNcblx0XHRcdGlmICh0aGlzLmNoZWNrKFsweDAyXSwge29mZnNldDogb2Zmc2V0ICsgMSwgbWFzazogWzB4MDZdfSkpIHtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRleHQ6ICdtcDMnLFxuXHRcdFx0XHRcdG1pbWU6ICdhdWRpby9tcGVnJyxcblx0XHRcdFx0fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gQ2hlY2sgZm9yIE1QRUcgbGF5ZXIgMlxuXHRcdFx0aWYgKHRoaXMuY2hlY2soWzB4MDRdLCB7b2Zmc2V0OiBvZmZzZXQgKyAxLCBtYXNrOiBbMHgwNl19KSkge1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGV4dDogJ21wMicsXG5cdFx0XHRcdFx0bWltZTogJ2F1ZGlvL21wZWcnLFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBDaGVjayBmb3IgTVBFRyBsYXllciAxXG5cdFx0XHRpZiAodGhpcy5jaGVjayhbMHgwNl0sIHtvZmZzZXQ6IG9mZnNldCArIDEsIG1hc2s6IFsweDA2XX0pKSB7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0ZXh0OiAnbXAxJyxcblx0XHRcdFx0XHRtaW1lOiAnYXVkaW8vbXBlZycsXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5cbmV4cG9ydCBjb25zdCBzdXBwb3J0ZWRFeHRlbnNpb25zID0gbmV3IFNldChleHRlbnNpb25zKTtcbmV4cG9ydCBjb25zdCBzdXBwb3J0ZWRNaW1lVHlwZXMgPSBuZXcgU2V0KG1pbWVUeXBlcyk7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmaWxlVHlwZUZyb21GaWxlKHBhdGgsIG9wdGlvbnMpIHtcblx0cmV0dXJuIChuZXcgRmlsZVR5cGVQYXJzZXIob3B0aW9ucykpLmZyb21GaWxlKHBhdGgpO1xufVxuIiwiaW1wb3J0IHsgZGVmYXVsdE1heE1ldGFkYXRhRW50cmllcyB9IGZyb20gJy4uL2NvbW1vbi9BbGxvY2F0aW9uLmpzJztcbmltcG9ydCB7IG1ha2VVbmV4cGVjdGVkRmlsZUNvbnRlbnRFcnJvciB9IGZyb20gJy4uL1BhcnNlRXJyb3IuanMnO1xuaW1wb3J0IHsgTHlyaWNzQ29udGVudFR5cGUsIFRpbWVzdGFtcEZvcm1hdCB9IGZyb20gJy4uL3R5cGUuanMnO1xuLy8gU2hhcmVkIHRpbWVzdGFtcCByZWdleCBmb3IgTFJDIGZvcm1hdFxuY29uc3QgVElNRVNUQU1QX1JFR0VYID0gL1xcWyhcXGR7Mn0pOihcXGR7Mn0pXFwuKFxcZHsyLDN9KV0vO1xuZXhwb3J0IGNsYXNzIEx5cmljc0NvbnRlbnRFcnJvciBleHRlbmRzIG1ha2VVbmV4cGVjdGVkRmlsZUNvbnRlbnRFcnJvcignbHlyaWNzJykge1xufVxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlTHlyaWNzKGlucHV0LCBtYXhMaW5lcyA9IGRlZmF1bHRNYXhNZXRhZGF0YUVudHJpZXMpIHtcbiAgICBpZiAoVElNRVNUQU1QX1JFR0VYLnRlc3QoaW5wdXQpKSB7XG4gICAgICAgIHJldHVybiBwYXJzZUxyYyhpbnB1dCwgbWF4TGluZXMpO1xuICAgIH1cbiAgICByZXR1cm4gdG9VbnN5bmNlZEx5cmljcyhpbnB1dCk7XG59XG5leHBvcnQgZnVuY3Rpb24gdG9VbnN5bmNlZEx5cmljcyhseXJpY3MpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICBjb250ZW50VHlwZTogTHlyaWNzQ29udGVudFR5cGUubHlyaWNzLFxuICAgICAgICB0aW1lU3RhbXBGb3JtYXQ6IFRpbWVzdGFtcEZvcm1hdC5ub3RTeW5jaHJvbml6ZWQsXG4gICAgICAgIHRleHQ6IGx5cmljcy50cmltKCksXG4gICAgICAgIHN5bmNUZXh0OiBbXVxuICAgIH07XG59XG4vKipcbiAqIFBhcnNlIExSQyAoTHlyaWNzKSBmb3JtYXR0ZWQgdGV4dFxuICogUmVmOiBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9MUkNfKGZpbGVfZm9ybWF0KVxuICogQHBhcmFtIGxyY1N0cmluZ1xuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VMcmMobHJjU3RyaW5nLCBtYXhMaW5lcyA9IGRlZmF1bHRNYXhNZXRhZGF0YUVudHJpZXMpIHtcbiAgICBsZXQgbGluZUNvdW50ID0gMTtcbiAgICBmb3IgKGxldCBvZmZzZXQgPSBscmNTdHJpbmcuaW5kZXhPZignXFxuJyk7IG9mZnNldCA+PSAwOyBvZmZzZXQgPSBscmNTdHJpbmcuaW5kZXhPZignXFxuJywgb2Zmc2V0ICsgMSkpIHtcbiAgICAgICAgKytsaW5lQ291bnQ7XG4gICAgfVxuICAgIGlmIChsaW5lQ291bnQgPiBtYXhMaW5lcykge1xuICAgICAgICB0aHJvdyBuZXcgTHlyaWNzQ29udGVudEVycm9yKGBMaW5lIGNvdW50ICR7bGluZUNvdW50fSBleGNlZWRzIGVudHJ5IGxpbWl0ICR7bWF4TGluZXN9YCk7XG4gICAgfVxuICAgIGNvbnN0IGxpbmVzID0gbHJjU3RyaW5nLnNwbGl0KCdcXG4nKTtcbiAgICBjb25zdCBzeW5jVGV4dCA9IFtdO1xuICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lcykge1xuICAgICAgICBjb25zdCBtYXRjaCA9IGxpbmUubWF0Y2goVElNRVNUQU1QX1JFR0VYKTtcbiAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgICBjb25zdCBtaW51dGVzID0gTnVtYmVyLnBhcnNlSW50KG1hdGNoWzFdLCAxMCk7XG4gICAgICAgICAgICBjb25zdCBzZWNvbmRzID0gTnVtYmVyLnBhcnNlSW50KG1hdGNoWzJdLCAxMCk7XG4gICAgICAgICAgICBjb25zdCBtcyA9IG1hdGNoWzNdLmxlbmd0aCA9PT0gMyA/IE51bWJlci5wYXJzZUludChtYXRjaFszXSwgMTApIDogTnVtYmVyLnBhcnNlSW50KG1hdGNoWzNdLCAxMCkgKiAxMDtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVzdGFtcCA9IChtaW51dGVzICogNjAgKyBzZWNvbmRzKSAqIDEwMDAgKyBtcztcbiAgICAgICAgICAgIGNvbnN0IHRleHQgPSBsaW5lLnJlcGxhY2UoVElNRVNUQU1QX1JFR0VYLCAnJykudHJpbSgpO1xuICAgICAgICAgICAgc3luY1RleHQucHVzaCh7IHRpbWVzdGFtcCwgdGV4dCB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBjb250ZW50VHlwZTogTHlyaWNzQ29udGVudFR5cGUubHlyaWNzLFxuICAgICAgICB0aW1lU3RhbXBGb3JtYXQ6IFRpbWVzdGFtcEZvcm1hdC5taWxsaXNlY29uZHMsXG4gICAgICAgIHRleHQ6IHN5bmNUZXh0Lm1hcChsaW5lID0+IGxpbmUudGV4dCkuam9pbignXFxuJyksXG4gICAgICAgIHN5bmNUZXh0XG4gICAgfTtcbn1cbiIsImV4cG9ydCBjbGFzcyBDb21tb25UYWdNYXBwZXIge1xuICAgIHN0YXRpYyBtYXhSYXRpbmdTY29yZSA9IDE7XG4gICAgc3RhdGljIHRvSW50T3JOdWxsKHN0cikge1xuICAgICAgICBjb25zdCBjbGVhbmVkID0gTnVtYmVyLnBhcnNlSW50KHN0ciwgMTApO1xuICAgICAgICByZXR1cm4gTnVtYmVyLmlzTmFOKGNsZWFuZWQpID8gbnVsbCA6IGNsZWFuZWQ7XG4gICAgfVxuICAgIC8vIFRPRE86IGEgc3RyaW5nIG9mIDFvZjEgd291bGQgZmFpbCB0byBiZSBjb252ZXJ0ZWRcbiAgICAvLyBjb252ZXJ0cyAxLzEwIHRvIG5vIDogMSwgb2YgOiAxMFxuICAgIC8vIG9yIDEgdG8gbm8gOiAxLCBvZiA6IDBcbiAgICBzdGF0aWMgbm9ybWFsaXplVHJhY2sob3JpZ1ZhbCkge1xuICAgICAgICBjb25zdCBzcGxpdCA9IG9yaWdWYWwudG9TdHJpbmcoKS5zcGxpdCgnLycsIDIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbm86IE51bWJlci5wYXJzZUludChzcGxpdFswXSwgMTApIHx8IG51bGwsXG4gICAgICAgICAgICBvZjogTnVtYmVyLnBhcnNlSW50KHNwbGl0WzFdLCAxMCkgfHwgbnVsbFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0YWdUeXBlcztcbiAgICB0YWdNYXA7XG4gICAgY29uc3RydWN0b3IodGFnVHlwZXMsIHRhZ01hcCkge1xuICAgICAgICB0aGlzLnRhZ1R5cGVzID0gdGFnVHlwZXM7XG4gICAgICAgIHRoaXMudGFnTWFwID0gdGFnTWFwO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQcm9jZXNzIGFuZCBzZXQgY29tbW9uIHRhZ3NcbiAgICAgKiB3cml0ZSBjb21tb24gdGFncyB0b1xuICAgICAqIEBwYXJhbSB0YWcgTmF0aXZlIHRhZ1xuICAgICAqIEBwYXJhbSB3YXJuaW5ncyBSZWdpc3RlciB3YXJuaW5nc1xuICAgICAqIEByZXR1cm4gY29tbW9uIG5hbWVcbiAgICAgKi9cbiAgICBtYXBHZW5lcmljVGFnKHRhZywgd2FybmluZ3MpIHtcbiAgICAgICAgdGFnID0geyBpZDogdGFnLmlkLCB2YWx1ZTogdGFnLnZhbHVlIH07IC8vIGNsb25lIG9iamVjdFxuICAgICAgICB0aGlzLnBvc3RNYXAodGFnLCB3YXJuaW5ncyk7XG4gICAgICAgIC8vIENvbnZlcnQgbmF0aXZlIHRhZyBldmVudCB0byBnZW5lcmljICdhbGlhcycgdGFnXG4gICAgICAgIGNvbnN0IGlkID0gdGhpcy5nZXRDb21tb25OYW1lKHRhZy5pZCk7XG4gICAgICAgIHJldHVybiBpZCA/IHsgaWQsIHZhbHVlOiB0YWcudmFsdWUgfSA6IG51bGw7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENvbnZlcnQgbmF0aXZlIHRhZyBrZXkgdG8gY29tbW9uIHRhZyBrZXlcbiAgICAgKiBAcGFyYW0gdGFnIE5hdGl2ZSBoZWFkZXIgdGFnXG4gICAgICogQHJldHVybiBjb21tb24gdGFnIG5hbWUgKGFsaWFzKVxuICAgICAqL1xuICAgIGdldENvbW1vbk5hbWUodGFnKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QuaGFzT3duKHRoaXMudGFnTWFwLCB0YWcpID8gdGhpcy50YWdNYXBbdGFnXSA6IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogSGFuZGxlIHBvc3QgbWFwcGluZyBleGNlcHRpb25zIC8gY29ycmVjdGlvblxuICAgICAqIEBwYXJhbSB0YWcgVGFnIGUuZy4ge1wiwqlhbGJcIiwgXCJCdWVuYSBWaXN0YSBTb2NpYWwgQ2x1YlwiKVxuICAgICAqIEBwYXJhbSB3YXJuaW5ncyBVc2VkIHRvIHJlZ2lzdGVyIHdhcm5pbmdzXG4gICAgICovXG4gICAgcG9zdE1hcChfdGFnLCBfd2FybmluZ3MpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbW1vblRhZ01hcHBlciB9IGZyb20gJy4uL2NvbW1vbi9HZW5lcmljVGFnTWFwcGVyLmpzJztcbi8qKlxuICogSUQzdjEgdGFnIG1hcHBpbmdzXG4gKi9cbmNvbnN0IHRhZ01hcCA9IHtcbiAgICBOQU1FOiAndGl0bGUnLFxuICAgIEFVVEg6ICdhcnRpc3QnLFxuICAgICcoYykgJzogJ2NvcHlyaWdodCcsXG4gICAgQU5OTzogJ2NvbW1lbnQnXG59O1xuZXhwb3J0IGNsYXNzIEFpZmZUYWdNYXBwZXIgZXh0ZW5kcyBDb21tb25UYWdNYXBwZXIge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihbJ0FJRkYnXSwgdGFnTWFwKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDb21tb25UYWdNYXBwZXIgfSBmcm9tICcuL0dlbmVyaWNUYWdNYXBwZXIuanMnO1xuZXhwb3J0IGNsYXNzIENhc2VJbnNlbnNpdGl2ZVRhZ01hcCBleHRlbmRzIENvbW1vblRhZ01hcHBlciB7XG4gICAgY29uc3RydWN0b3IodGFnVHlwZXMsIHRhZ01hcCkge1xuICAgICAgICBjb25zdCB1cHBlckNhc2VNYXAgPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBbdGFnLCBjb21tb25OYW1lXSBvZiBPYmplY3QuZW50cmllcyh0YWdNYXApKSB7XG4gICAgICAgICAgICB1cHBlckNhc2VNYXBbdGFnLnRvVXBwZXJDYXNlKCldID0gY29tbW9uTmFtZTtcbiAgICAgICAgfVxuICAgICAgICBzdXBlcih0YWdUeXBlcywgdXBwZXJDYXNlTWFwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHRhZyAgTmF0aXZlIGhlYWRlciB0YWdcbiAgICAgKiBAcmV0dXJuIGNvbW1vbiB0YWcgbmFtZSAoYWxpYXMpXG4gICAgICovXG4gICAgZ2V0Q29tbW9uTmFtZSh0YWcpIHtcbiAgICAgICAgcmV0dXJuIHN1cGVyLmdldENvbW1vbk5hbWUodGFnLnRvVXBwZXJDYXNlKCkpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENhc2VJbnNlbnNpdGl2ZVRhZ01hcCB9IGZyb20gJy4uL2NvbW1vbi9DYXNlSW5zZW5zaXRpdmVUYWdNYXAuanMnO1xuLyoqXG4gKiBJRDN2Mi4yIHRhZyBtYXBwaW5nc1xuICovXG5jb25zdCBhcGV2MlRhZ01hcCA9IHtcbiAgICBUaXRsZTogJ3RpdGxlJyxcbiAgICBBcnRpc3Q6ICdhcnRpc3QnLFxuICAgIEFydGlzdHM6ICdhcnRpc3RzJyxcbiAgICAnQWxidW0gQXJ0aXN0JzogJ2FsYnVtYXJ0aXN0JyxcbiAgICBBbGJ1bTogJ2FsYnVtJyxcbiAgICBZZWFyOiAnZGF0ZScsXG4gICAgRGF0ZTogJ2RhdGUnLFxuICAgIE9yaWdpbmFseWVhcjogJ29yaWdpbmFseWVhcicsXG4gICAgT3JpZ2luYWxkYXRlOiAnb3JpZ2luYWxkYXRlJyxcbiAgICBSZWxlYXNlZGF0ZTogJ3JlbGVhc2VkYXRlJyxcbiAgICBDb21tZW50OiAnY29tbWVudCcsXG4gICAgVHJhY2s6ICd0cmFjaycsXG4gICAgRGlzYzogJ2Rpc2snLFxuICAgIERJU0NOVU1CRVI6ICdkaXNrJywgLy8gVG9EbzogYmFja3dhcmRzIGNvbXBhdGliaWxpdHknLCB2YWxpZCB0YWc/XG4gICAgR2VucmU6ICdnZW5yZScsXG4gICAgJ0NvdmVyIEFydCAoRnJvbnQpJzogJ3BpY3R1cmUnLFxuICAgICdDb3ZlciBBcnQgKEJhY2spJzogJ3BpY3R1cmUnLFxuICAgIENvbXBvc2VyOiAnY29tcG9zZXInLFxuICAgIEx5cmljczogJ2x5cmljcycsXG4gICAgQUxCVU1TT1JUOiAnYWxidW1zb3J0JyxcbiAgICBUSVRMRVNPUlQ6ICd0aXRsZXNvcnQnLFxuICAgIFdPUks6ICd3b3JrJyxcbiAgICBBUlRJU1RTT1JUOiAnYXJ0aXN0c29ydCcsXG4gICAgQUxCVU1BUlRJU1RTT1JUOiAnYWxidW1hcnRpc3Rzb3J0JyxcbiAgICBDT01QT1NFUlNPUlQ6ICdjb21wb3NlcnNvcnQnLFxuICAgIEx5cmljaXN0OiAnbHlyaWNpc3QnLFxuICAgIFdyaXRlcjogJ3dyaXRlcicsXG4gICAgQ29uZHVjdG9yOiAnY29uZHVjdG9yJyxcbiAgICAvLyAnUGVyZm9ybWVyPWFydGlzdMKgKGluc3RydW1lbnQpJzogJ3BlcmZvcm1lcjppbnN0cnVtZW50JyxcbiAgICBNaXhBcnRpc3Q6ICdyZW1peGVyJyxcbiAgICBBcnJhbmdlcjogJ2FycmFuZ2VyJyxcbiAgICBFbmdpbmVlcjogJ2VuZ2luZWVyJyxcbiAgICBQcm9kdWNlcjogJ3Byb2R1Y2VyJyxcbiAgICBESk1peGVyOiAnZGptaXhlcicsXG4gICAgTWl4ZXI6ICdtaXhlcicsXG4gICAgTGFiZWw6ICdsYWJlbCcsXG4gICAgR3JvdXBpbmc6ICdncm91cGluZycsXG4gICAgU3VidGl0bGU6ICdzdWJ0aXRsZScsXG4gICAgRGlzY1N1YnRpdGxlOiAnZGlzY3N1YnRpdGxlJyxcbiAgICBDb21waWxhdGlvbjogJ2NvbXBpbGF0aW9uJyxcbiAgICBCUE06ICdicG0nLFxuICAgIE1vb2Q6ICdtb29kJyxcbiAgICBNZWRpYTogJ21lZGlhJyxcbiAgICBDYXRhbG9nTnVtYmVyOiAnY2F0YWxvZ251bWJlcicsXG4gICAgTVVTSUNCUkFJTlpfQUxCVU1TVEFUVVM6ICdyZWxlYXNlc3RhdHVzJyxcbiAgICBNVVNJQ0JSQUlOWl9BTEJVTVRZUEU6ICdyZWxlYXNldHlwZScsXG4gICAgUkVMRUFTRUNPVU5UUlk6ICdyZWxlYXNlY291bnRyeScsXG4gICAgU2NyaXB0OiAnc2NyaXB0JyxcbiAgICBMYW5ndWFnZTogJ2xhbmd1YWdlJyxcbiAgICBDb3B5cmlnaHQ6ICdjb3B5cmlnaHQnLFxuICAgIExJQ0VOU0U6ICdsaWNlbnNlJyxcbiAgICBFbmNvZGVkQnk6ICdlbmNvZGVkYnknLFxuICAgIEVuY29kZXJTZXR0aW5nczogJ2VuY29kZXJzZXR0aW5ncycsXG4gICAgQmFyY29kZTogJ2JhcmNvZGUnLFxuICAgIElTUkM6ICdpc3JjJyxcbiAgICBBU0lOOiAnYXNpbicsXG4gICAgbXVzaWNicmFpbnpfdHJhY2tpZDogJ211c2ljYnJhaW56X3JlY29yZGluZ2lkJyxcbiAgICBtdXNpY2JyYWluel9yZWxlYXNldHJhY2tpZDogJ211c2ljYnJhaW56X3RyYWNraWQnLFxuICAgIE1VU0lDQlJBSU5aX0FMQlVNSUQ6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICBNVVNJQ0JSQUlOWl9BUlRJU1RJRDogJ211c2ljYnJhaW56X2FydGlzdGlkJyxcbiAgICBNVVNJQ0JSQUlOWl9BTEJVTUFSVElTVElEOiAnbXVzaWNicmFpbnpfYWxidW1hcnRpc3RpZCcsXG4gICAgTVVTSUNCUkFJTlpfUkVMRUFTRUdST1VQSUQ6ICdtdXNpY2JyYWluel9yZWxlYXNlZ3JvdXBpZCcsXG4gICAgTVVTSUNCUkFJTlpfV09SS0lEOiAnbXVzaWNicmFpbnpfd29ya2lkJyxcbiAgICBNVVNJQ0JSQUlOWl9UUk1JRDogJ211c2ljYnJhaW56X3RybWlkJyxcbiAgICBNVVNJQ0JSQUlOWl9ESVNDSUQ6ICdtdXNpY2JyYWluel9kaXNjaWQnLFxuICAgIEFjb3VzdGlkX0lkOiAnYWNvdXN0aWRfaWQnLFxuICAgIEFDT1VTVElEX0ZJTkdFUlBSSU5UOiAnYWNvdXN0aWRfZmluZ2VycHJpbnQnLFxuICAgIE1VU0lDSVBfUFVJRDogJ211c2ljaXBfcHVpZCcsXG4gICAgV2VibGluazogJ3dlYnNpdGUnLFxuICAgIFJFUExBWUdBSU5fVFJBQ0tfR0FJTjogJ3JlcGxheWdhaW5fdHJhY2tfZ2FpbicsXG4gICAgUkVQTEFZR0FJTl9UUkFDS19QRUFLOiAncmVwbGF5Z2Fpbl90cmFja19wZWFrJyxcbiAgICBNUDNHQUlOX01JTk1BWDogJ3JlcGxheWdhaW5fdHJhY2tfbWlubWF4JyxcbiAgICBNUDNHQUlOX1VORE86ICdyZXBsYXlnYWluX3VuZG8nXG59O1xuZXhwb3J0IGNsYXNzIEFQRXYyVGFnTWFwcGVyIGV4dGVuZHMgQ2FzZUluc2Vuc2l0aXZlVGFnTWFwIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoWydBUEV2MiddLCBhcGV2MlRhZ01hcCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbW9uVGFnTWFwcGVyIH0gZnJvbSAnLi4vY29tbW9uL0dlbmVyaWNUYWdNYXBwZXIuanMnO1xuaW1wb3J0IHsgdG9SYXRpbyB9IGZyb20gJy4uL2NvbW1vbi9VdGlsLmpzJztcbi8qKlxuICogQVNGIE1ldGFkYXRhIHRhZyBtYXBwaW5ncy5cbiAqIFNlZSBodHRwOi8vbXNkbi5taWNyb3NvZnQuY29tL2VuLXVzL2xpYnJhcnkvbXM4Njc3MDIuYXNweFxuICovXG5jb25zdCBhc2ZUYWdNYXAgPSB7XG4gICAgVGl0bGU6ICd0aXRsZScsXG4gICAgQXV0aG9yOiAnYXJ0aXN0JyxcbiAgICAnV00vQWxidW1BcnRpc3QnOiAnYWxidW1hcnRpc3QnLFxuICAgICdXTS9BbGJ1bVRpdGxlJzogJ2FsYnVtJyxcbiAgICAnV00vWWVhcic6ICdkYXRlJywgLy8gY2hhbmdlZCB0byAneWVhcicgdG8gJ2RhdGUnIGJhc2VkIG9uIFBpY2FyZCBtYXBwaW5nczsgVG9EbzogY2hlY2sgbWVcbiAgICAnV00vT3JpZ2luYWxSZWxlYXNlVGltZSc6ICdvcmlnaW5hbGRhdGUnLFxuICAgICdXTS9PcmlnaW5hbFJlbGVhc2VZZWFyJzogJ29yaWdpbmFseWVhcicsXG4gICAgRGVzY3JpcHRpb246ICdjb21tZW50JyxcbiAgICAnV00vVHJhY2tOdW1iZXInOiAndHJhY2snLFxuICAgIFRvdGFsVHJhY2tzOiAndG90YWx0cmFja3MnLFxuICAgICdXTS9QYXJ0T2ZTZXQnOiAnZGlzaycsXG4gICAgJ1dNL0dlbnJlJzogJ2dlbnJlJyxcbiAgICAnV00vQ29tcG9zZXInOiAnY29tcG9zZXInLFxuICAgICdXTS9MeXJpY3MnOiAnbHlyaWNzJyxcbiAgICAnV00vQWxidW1Tb3J0T3JkZXInOiAnYWxidW1zb3J0JyxcbiAgICAnV00vVGl0bGVTb3J0T3JkZXInOiAndGl0bGVzb3J0JyxcbiAgICAnV00vQXJ0aXN0U29ydE9yZGVyJzogJ2FydGlzdHNvcnQnLFxuICAgICdXTS9BbGJ1bUFydGlzdFNvcnRPcmRlcic6ICdhbGJ1bWFydGlzdHNvcnQnLFxuICAgICdXTS9Db21wb3NlclNvcnRPcmRlcic6ICdjb21wb3NlcnNvcnQnLFxuICAgICdXTS9Xcml0ZXInOiAnbHlyaWNpc3QnLFxuICAgICdXTS9Db25kdWN0b3InOiAnY29uZHVjdG9yJyxcbiAgICAnV00vTW9kaWZpZWRCeSc6ICdyZW1peGVyJyxcbiAgICAnV00vRW5naW5lZXInOiAnZW5naW5lZXInLFxuICAgICdXTS9Qcm9kdWNlcic6ICdwcm9kdWNlcicsXG4gICAgJ1dNL0RKTWl4ZXInOiAnZGptaXhlcicsXG4gICAgJ1dNL01peGVyJzogJ21peGVyJyxcbiAgICAnV00vUHVibGlzaGVyJzogJ2xhYmVsJyxcbiAgICAnV00vQ29udGVudEdyb3VwRGVzY3JpcHRpb24nOiAnZ3JvdXBpbmcnLFxuICAgICdXTS9TdWJUaXRsZSc6ICdzdWJ0aXRsZScsXG4gICAgJ1dNL1NldFN1YlRpdGxlJzogJ2Rpc2NzdWJ0aXRsZScsXG4gICAgUkVQTEFZR0FJTl9UUkFDS19HQUlOOiAncmVwbGF5Z2Fpbl90cmFja19nYWluJyxcbiAgICBSRVBMQVlHQUlOX1RSQUNLX1BFQUs6ICdyZXBsYXlnYWluX3RyYWNrX3BlYWsnLFxuICAgIFJFUExBWUdBSU5fQUxCVU1fR0FJTjogJ3JlcGxheWdhaW5fYWxidW1fZ2FpbicsXG4gICAgUkVQTEFZR0FJTl9BTEJVTV9QRUFLOiAncmVwbGF5Z2Fpbl9hbGJ1bV9wZWFrJyxcbiAgICByZXBsYXlnYWluX3RyYWNrX2dhaW46ICdyZXBsYXlnYWluX3RyYWNrX2dhaW4nLFxuICAgIHJlcGxheWdhaW5fdHJhY2tfcGVhazogJ3JlcGxheWdhaW5fdHJhY2tfcGVhaycsXG4gICAgcmVwbGF5Z2Fpbl9hbGJ1bV9nYWluOiAncmVwbGF5Z2Fpbl9hbGJ1bV9nYWluJyxcbiAgICByZXBsYXlnYWluX2FsYnVtX3BlYWs6ICdyZXBsYXlnYWluX2FsYnVtX3BlYWsnLFxuICAgICdXTS9Jc0NvbXBpbGF0aW9uJzogJ2NvbXBpbGF0aW9uJyxcbiAgICAnV00vU2hhcmVkVXNlclJhdGluZyc6ICdyYXRpbmcnLFxuICAgIFBPUFVMQVJJTUVURVI6ICdyYXRpbmcnLFxuICAgICdXTS9CZWF0c1Blck1pbnV0ZSc6ICdicG0nLFxuICAgICdXTS9Nb29kJzogJ21vb2QnLFxuICAgICdXTS9NZWRpYSc6ICdtZWRpYScsXG4gICAgJ1dNL0NhdGFsb2dObyc6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICAnTXVzaWNCcmFpbnovQWxidW0gU3RhdHVzJzogJ3JlbGVhc2VzdGF0dXMnLFxuICAgICdNdXNpY0JyYWluei9BbGJ1bSBUeXBlJzogJ3JlbGVhc2V0eXBlJyxcbiAgICAnTXVzaWNCcmFpbnovQWxidW0gUmVsZWFzZSBDb3VudHJ5JzogJ3JlbGVhc2Vjb3VudHJ5JyxcbiAgICAnV00vU2NyaXB0JzogJ3NjcmlwdCcsXG4gICAgJ1dNL0xhbmd1YWdlJzogJ2xhbmd1YWdlJyxcbiAgICBDb3B5cmlnaHQ6ICdjb3B5cmlnaHQnLFxuICAgIExJQ0VOU0U6ICdsaWNlbnNlJyxcbiAgICAnV00vRW5jb2RlZEJ5JzogJ2VuY29kZWRieScsXG4gICAgJ1dNL0VuY29kaW5nU2V0dGluZ3MnOiAnZW5jb2RlcnNldHRpbmdzJyxcbiAgICAnV00vQmFyY29kZSc6ICdiYXJjb2RlJyxcbiAgICAnV00vSVNSQyc6ICdpc3JjJyxcbiAgICAnTXVzaWNCcmFpbnovVHJhY2sgSWQnOiAnbXVzaWNicmFpbnpfcmVjb3JkaW5naWQnLFxuICAgICdNdXNpY0JyYWluei9SZWxlYXNlIFRyYWNrIElkJzogJ211c2ljYnJhaW56X3RyYWNraWQnLFxuICAgICdNdXNpY0JyYWluei9BbGJ1bSBJZCc6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICAnTXVzaWNCcmFpbnovQXJ0aXN0IElkJzogJ211c2ljYnJhaW56X2FydGlzdGlkJyxcbiAgICAnTXVzaWNCcmFpbnovQWxidW0gQXJ0aXN0IElkJzogJ211c2ljYnJhaW56X2FsYnVtYXJ0aXN0aWQnLFxuICAgICdNdXNpY0JyYWluei9SZWxlYXNlIEdyb3VwIElkJzogJ211c2ljYnJhaW56X3JlbGVhc2Vncm91cGlkJyxcbiAgICAnTXVzaWNCcmFpbnovV29yayBJZCc6ICdtdXNpY2JyYWluel93b3JraWQnLFxuICAgICdNdXNpY0JyYWluei9UUk0gSWQnOiAnbXVzaWNicmFpbnpfdHJtaWQnLFxuICAgICdNdXNpY0JyYWluei9EaXNjIElkJzogJ211c2ljYnJhaW56X2Rpc2NpZCcsXG4gICAgJ0Fjb3VzdGlkL0lkJzogJ2Fjb3VzdGlkX2lkJyxcbiAgICAnQWNvdXN0aWQvRmluZ2VycHJpbnQnOiAnYWNvdXN0aWRfZmluZ2VycHJpbnQnLFxuICAgICdNdXNpY0lQL1BVSUQnOiAnbXVzaWNpcF9wdWlkJyxcbiAgICAnV00vQVJUSVNUUyc6ICdhcnRpc3RzJyxcbiAgICAnV00vSW5pdGlhbEtleSc6ICdrZXknLFxuICAgIEFTSU46ICdhc2luJyxcbiAgICAnV00vV29yayc6ICd3b3JrJyxcbiAgICAnV00vQXV0aG9yVVJMJzogJ3dlYnNpdGUnLFxuICAgICdXTS9QaWN0dXJlJzogJ3BpY3R1cmUnXG59O1xuZXhwb3J0IGNsYXNzIEFzZlRhZ01hcHBlciBleHRlbmRzIENvbW1vblRhZ01hcHBlciB7XG4gICAgc3RhdGljIHRvUmF0aW5nKHJhdGluZykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHR5cGVvZiByYXRpbmcgPT09ICdudW1iZXInID8gcmF0aW5nIDogTnVtYmVyLnBhcnNlRmxvYXQocmF0aW5nKTtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUodmFsdWUpIHx8IHZhbHVlIDw9IDApIHtcbiAgICAgICAgICAgIHJldHVybiB7IHJhdGluZzogdW5kZWZpbmVkIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgcmF0aW5nOiB2YWx1ZSAvIDk5IH07XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihbJ2FzZiddLCBhc2ZUYWdNYXApO1xuICAgIH1cbiAgICBwb3N0TWFwKHRhZywgd2FybmluZ3MpIHtcbiAgICAgICAgaWYgKHRoaXMuZ2V0Q29tbW9uTmFtZSh0YWcuaWQpPy5zdGFydHNXaXRoKCdyZXBsYXlnYWluXycpKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IHR5cGVvZiB0YWcudmFsdWUgPT09ICdzdHJpbmcnXG4gICAgICAgICAgICAgICAgPyB0YWcudmFsdWUudHJpbSgpLm1hdGNoKC9eKFsrLV0/KD86XFxkKyg/OlxcLlxcZCopP3xcXC5cXGQrKSg/OmVbKy1dP1xcZCspPylcXHMqKGRCKT8kL2kpXG4gICAgICAgICAgICAgICAgOiBudWxsO1xuICAgICAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHZhbHVlID8gYCR7dmFsdWVbMV19JHt2YWx1ZVsyXSA/ICcgZEInIDogJyd9YCA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGNvbnN0IHJhdGlvID0gbm9ybWFsaXplZCA/IHRvUmF0aW8obm9ybWFsaXplZCkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAvLyBBIHNpbGVudCBwZWFrIG9mIHplcm8gaXMgdmFsaWQgKGl0cyBkQiB2YWx1ZSBpcyAtSW5maW5pdHkpLlxuICAgICAgICAgICAgaWYgKCFyYXRpbyB8fCAhTnVtYmVyLmlzRmluaXRlKHJhdGlvLnJhdGlvKSB8fCBOdW1iZXIuaXNOYU4ocmF0aW8uZEIpKSB7XG4gICAgICAgICAgICAgICAgd2FybmluZ3MuYWRkV2FybmluZyhgSW52YWxpZCBBU0YgUmVwbGF5R2FpbiB2YWx1ZSBmb3IgJHt0YWcuaWR9YCk7XG4gICAgICAgICAgICAgICAgdGFnLmlkID0gJyc7IC8vIEtlZXAgaW52YWxpZCB2YWx1ZXMgbmF0aXZlIHdpdGhvdXQgbWFwcGluZyB0aGVtIHRvIGNvbW1vbiBtZXRhZGF0YS5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRhZy52YWx1ZSA9IG5vcm1hbGl6ZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgc3dpdGNoICh0YWcuaWQpIHtcbiAgICAgICAgICAgIGNhc2UgJ1BPUFVMQVJJTUVURVInOiB7XG4gICAgICAgICAgICAgICAgLy8gcG9wbS1zdHlsZSBhdHRyaWJ1dGUsIHdyaXR0ZW4gYnkgZS5nLiBmb29iYXIyMDAwOyB2YWx1ZSBpcyBcImVtYWlsfHJhdGluZ3xjb3VudGVyXCJcbiAgICAgICAgICAgICAgICBjb25zdCBbZW1haWwsIHJhdGluZ10gPSB0YWcudmFsdWUuc3BsaXQoJ3wnLCAyKTtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXRpbmcpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHZhbGlkID0gL15cXGQrJC8udGVzdChyYXRpbmcpICYmIE51bWJlci5pc0ludGVnZXIodmFsdWUpICYmIHZhbHVlID49IDAgJiYgdmFsdWUgPD0gMjU1O1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgd2FybmluZ3MuYWRkV2FybmluZyhgSW52YWxpZCBBU0YgUE9QVUxBUklNRVRFUiByYXRpbmc6ICR7cmF0aW5nfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSB7XG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZTogZW1haWwsXG4gICAgICAgICAgICAgICAgICAgIHJhdGluZzogdmFsaWQgJiYgdmFsdWUgPiAwID8gKCh2YWx1ZSAtIDEpIC8gMjU0KSAqIENvbW1vblRhZ01hcHBlci5tYXhSYXRpbmdTY29yZSA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdXTS9TaGFyZWRVc2VyUmF0aW5nJzoge1xuICAgICAgICAgICAgICAgIGNvbnN0IGtleXMgPSB0YWcuaWQuc3BsaXQoJzonLCAyKTtcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSBBc2ZUYWdNYXBwZXIudG9SYXRpbmcodGFnLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB0YWcuaWQgPSBrZXlzWzBdO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbW9uVGFnTWFwcGVyIH0gZnJvbSAnLi4vY29tbW9uL0dlbmVyaWNUYWdNYXBwZXIuanMnO1xuLy8gXCJ0aW1lIHNpZ25hdHVyZVwiLCBcIm5vbWluYWwgYml0IHJhdGVcIiBhbmQgXCJjaGFubmVsIGxheW91dFwiIGhhdmUgbm8gY29tbW9uXG4vLyBlcXVpdmFsZW50IGFuZCBzdGF5IG5hdGl2ZS4gVW5kb2N1bWVudGVkIGtleXMgYXJlIGFsd2F5cyBrZXB0IG5hdGl2ZWx5IHRvby5cbmNvbnN0IGluZm9UYWdNYXAgPSB7XG4gICAgdGVtcG86ICdicG0nLFxuICAgICdrZXkgc2lnbmF0dXJlJzogJ2tleScsXG4gICAgYXJ0aXN0OiAnYXJ0aXN0JyxcbiAgICBhbGJ1bTogJ2FsYnVtJyxcbiAgICAndHJhY2sgbnVtYmVyJzogJ3RyYWNrJyxcbiAgICB5ZWFyOiAneWVhcicsXG4gICAgY29tcG9zZXI6ICdjb21wb3NlcicsXG4gICAgbHlyaWNpc3Q6ICdseXJpY2lzdCcsXG4gICAgZ2VucmU6ICdnZW5yZScsXG4gICAgdGl0bGU6ICd0aXRsZScsXG4gICAgJ3JlY29yZGVkIGRhdGUnOiAnZGF0ZScsXG4gICAgY29tbWVudHM6ICdjb21tZW50JyxcbiAgICBjb3B5cmlnaHQ6ICdjb3B5cmlnaHQnLFxuICAgICdzb3VyY2UgZW5jb2Rlcic6ICdlbmNvZGVyc2V0dGluZ3MnLFxuICAgICdlbmNvZGluZyBhcHBsaWNhdGlvbic6ICdlbmNvZGVkYnknXG59O1xuY29uc3QgY29tbWFTZXBhcmF0ZWRLZXlzID0gbmV3IFNldChbJ2FydGlzdCcsICdjb21wb3NlcicsICdseXJpY2lzdCcsICdnZW5yZSddKTtcbmV4cG9ydCBjbGFzcyBDYWZUYWdNYXBwZXIgZXh0ZW5kcyBDb21tb25UYWdNYXBwZXIge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihbJ0NBRiddLCBpbmZvVGFnTWFwKTtcbiAgICB9XG4gICAgbWFwR2VuZXJpY1RhZyh0YWcsIHdhcm5pbmdzKSB7XG4gICAgICAgIGlmIChjb21tYVNlcGFyYXRlZEtleXMuaGFzKHRhZy5pZCkgJiYgdHlwZW9mIHRhZy52YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHRhZyA9IHtcbiAgICAgICAgICAgICAgICBpZDogdGFnLmlkLFxuICAgICAgICAgICAgICAgIHZhbHVlOiB0YWcudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgLnNwbGl0KCcsJylcbiAgICAgICAgICAgICAgICAgICAgLm1hcCh2YWx1ZSA9PiB2YWx1ZS50cmltKCkpXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIodmFsdWUgPT4gdmFsdWUubGVuZ3RoID4gMClcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1cGVyLm1hcEdlbmVyaWNUYWcodGFnLCB3YXJuaW5ncyk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbW9uVGFnTWFwcGVyIH0gZnJvbSAnLi4vY29tbW9uL0dlbmVyaWNUYWdNYXBwZXIuanMnO1xuLyoqXG4gKiBJRDN2MSB0YWcgbWFwcGluZ3NcbiAqL1xuY29uc3QgaWQzdjFUYWdNYXAgPSB7XG4gICAgdGl0bGU6ICd0aXRsZScsXG4gICAgYXJ0aXN0OiAnYXJ0aXN0JyxcbiAgICBhbGJ1bTogJ2FsYnVtJyxcbiAgICB5ZWFyOiAneWVhcicsXG4gICAgY29tbWVudDogJ2NvbW1lbnQnLFxuICAgIHRyYWNrOiAndHJhY2snLFxuICAgIGdlbnJlOiAnZ2VucmUnXG59O1xuZXhwb3J0IGNsYXNzIElEM3YxVGFnTWFwcGVyIGV4dGVuZHMgQ29tbW9uVGFnTWFwcGVyIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoWydJRDN2MSddLCBpZDN2MVRhZ01hcCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ2FzZUluc2Vuc2l0aXZlVGFnTWFwIH0gZnJvbSAnLi4vY29tbW9uL0Nhc2VJbnNlbnNpdGl2ZVRhZ01hcC5qcyc7XG4vKipcbiAqIElEM3YyLjIgdGFnIG1hcHBpbmdzXG4gKi9cbmV4cG9ydCBjb25zdCBpZDN2MjJUYWdNYXAgPSB7XG4gICAgVFQyOiAndGl0bGUnLFxuICAgIFRQMTogJ2FydGlzdCcsXG4gICAgVFAyOiAnYWxidW1hcnRpc3QnLFxuICAgIFRBTDogJ2FsYnVtJyxcbiAgICBUWUU6ICd5ZWFyJyxcbiAgICBDT006ICdjb21tZW50JyxcbiAgICBVTFQ6ICdseXJpY3MnLFxuICAgICdJUEw6YXJyYW5nZXInOiAnYXJyYW5nZXInLFxuICAgICdJUEw6ZW5naW5lZXInOiAnZW5naW5lZXInLFxuICAgICdJUEw6cHJvZHVjZXInOiAncHJvZHVjZXInLFxuICAgICdJUEw6REotbWl4JzogJ2RqbWl4ZXInLFxuICAgICdJUEw6bWl4JzogJ21peGVyJyxcbiAgICBUUks6ICd0cmFjaycsXG4gICAgVFBBOiAnZGlzaycsXG4gICAgVENPOiAnZ2VucmUnLFxuICAgIFBJQzogJ3BpY3R1cmUnLFxuICAgIFRDTTogJ2NvbXBvc2VyJyxcbiAgICBUT1I6ICdvcmlnaW5hbGRhdGUnLFxuICAgIFRPVDogJ29yaWdpbmFsYWxidW0nLFxuICAgIFRYVDogJ2x5cmljaXN0JyxcbiAgICBUUDM6ICdjb25kdWN0b3InLFxuICAgIFRQQjogJ2xhYmVsJyxcbiAgICBUVDE6ICdncm91cGluZycsXG4gICAgVFQzOiAnc3VidGl0bGUnLFxuICAgIFRMQTogJ2xhbmd1YWdlJyxcbiAgICBUQ1I6ICdjb3B5cmlnaHQnLFxuICAgIFdDUDogJ2xpY2Vuc2UnLFxuICAgIFRFTjogJ2VuY29kZWRieScsXG4gICAgVFNTOiAnZW5jb2RlcnNldHRpbmdzJyxcbiAgICBXQVI6ICd3ZWJzaXRlJyxcbiAgICBQQ1M6ICdwb2RjYXN0JyxcbiAgICBUQ1A6ICdjb21waWxhdGlvbicsXG4gICAgVERSOiAnZGF0ZScsXG4gICAgVFMyOiAnYWxidW1hcnRpc3Rzb3J0JyxcbiAgICBUU0E6ICdhbGJ1bXNvcnQnLFxuICAgIFRTQzogJ2NvbXBvc2Vyc29ydCcsXG4gICAgVFNQOiAnYXJ0aXN0c29ydCcsXG4gICAgVFNUOiAndGl0bGVzb3J0JyxcbiAgICBXRkQ6ICdwb2RjYXN0dXJsJyxcbiAgICBUQlA6ICdicG0nLFxuICAgIEdQMTogJ2dyb3VwaW5nJ1xufTtcbmV4cG9ydCBjbGFzcyBJRDN2MjJUYWdNYXBwZXIgZXh0ZW5kcyBDYXNlSW5zZW5zaXRpdmVUYWdNYXAge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihbJ0lEM3YyLjInXSwgaWQzdjIyVGFnTWFwKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBVSU5UMzJfTEUgfSBmcm9tICd0b2tlbi10eXBlcyc7XG5pbXBvcnQgeyBDYXNlSW5zZW5zaXRpdmVUYWdNYXAgfSBmcm9tICcuLi9jb21tb24vQ2FzZUluc2Vuc2l0aXZlVGFnTWFwLmpzJztcbmltcG9ydCB7IENvbW1vblRhZ01hcHBlciB9IGZyb20gJy4uL2NvbW1vbi9HZW5lcmljVGFnTWFwcGVyLmpzJztcbmltcG9ydCB7IGRlY29kZVN0cmluZyB9IGZyb20gJy4uL2NvbW1vbi9VdGlsLmpzJztcbi8qKlxuICogSUQzdjIuMy9JRDN2Mi40IHRhZyBtYXBwaW5nc1xuICovXG5leHBvcnQgY29uc3QgaWQzdjI0VGFnTWFwID0ge1xuICAgIC8vIGlkM3YyLjNcbiAgICBUSVQyOiAndGl0bGUnLFxuICAgIFRQRTE6ICdhcnRpc3QnLFxuICAgICdUWFhYOkFydGlzdHMnOiAnYXJ0aXN0cycsXG4gICAgVFBFMjogJ2FsYnVtYXJ0aXN0JyxcbiAgICBUQUxCOiAnYWxidW0nLFxuICAgIFREUlY6ICdkYXRlJywgLy8gWyAnZGF0ZScsICd5ZWFyJyBdIFRvRG86IGltcHJvdmUgJ3llYXInIG1hcHBpbmdcbiAgICAvKipcbiAgICAgKiBPcmlnaW5hbCByZWxlYXNlIHllYXJcbiAgICAgKi9cbiAgICBUT1JZOiAnb3JpZ2luYWx5ZWFyJyxcbiAgICBUUE9TOiAnZGlzaycsXG4gICAgVENPTjogJ2dlbnJlJyxcbiAgICBBUElDOiAncGljdHVyZScsXG4gICAgVENPTTogJ2NvbXBvc2VyJyxcbiAgICBVU0xUOiAnbHlyaWNzJyxcbiAgICBUU09BOiAnYWxidW1zb3J0JyxcbiAgICBUU09UOiAndGl0bGVzb3J0JyxcbiAgICBUT0FMOiAnb3JpZ2luYWxhbGJ1bScsXG4gICAgVFNPUDogJ2FydGlzdHNvcnQnLFxuICAgIFRTTzI6ICdhbGJ1bWFydGlzdHNvcnQnLFxuICAgIFRTT0M6ICdjb21wb3NlcnNvcnQnLFxuICAgIFRFWFQ6ICdseXJpY2lzdCcsXG4gICAgJ1RYWFg6V3JpdGVyJzogJ3dyaXRlcicsXG4gICAgVFBFMzogJ2NvbmR1Y3RvcicsXG4gICAgLy8gJ0lQTFM6aW5zdHJ1bWVudCc6ICdwZXJmb3JtZXI6aW5zdHJ1bWVudCcsIC8vIFRvRG9cbiAgICBUUEU0OiAncmVtaXhlcicsXG4gICAgJ0lQTFM6YXJyYW5nZXInOiAnYXJyYW5nZXInLFxuICAgICdJUExTOmVuZ2luZWVyJzogJ2VuZ2luZWVyJyxcbiAgICAnSVBMUzpwcm9kdWNlcic6ICdwcm9kdWNlcicsXG4gICAgJ0lQTFM6REotbWl4JzogJ2RqbWl4ZXInLFxuICAgICdJUExTOm1peCc6ICdtaXhlcicsXG4gICAgVFBVQjogJ2xhYmVsJyxcbiAgICBUSVQxOiAnZ3JvdXBpbmcnLFxuICAgIFRJVDM6ICdzdWJ0aXRsZScsXG4gICAgVFJDSzogJ3RyYWNrJyxcbiAgICBUQ01QOiAnY29tcGlsYXRpb24nLFxuICAgIFBPUE06ICdyYXRpbmcnLFxuICAgIFRCUE06ICdicG0nLFxuICAgIFRNRUQ6ICdtZWRpYScsXG4gICAgJ1RYWFg6Q0FUQUxPR05VTUJFUic6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBBbGJ1bSBTdGF0dXMnOiAncmVsZWFzZXN0YXR1cycsXG4gICAgJ1RYWFg6TXVzaWNCcmFpbnogQWxidW0gVHlwZSc6ICdyZWxlYXNldHlwZScsXG4gICAgLyoqXG4gICAgICogUmVsZWFzZSBjb3VudHJ5IGFzIGRvY3VtZW50ZWQ6IGh0dHBzOi8vcGljYXJkLm11c2ljYnJhaW56Lm9yZy9kb2NzL21hcHBpbmdzLyNjaXRlX25vdGUtMFxuICAgICAqL1xuICAgICdUWFhYOk11c2ljQnJhaW56IEFsYnVtIFJlbGVhc2UgQ291bnRyeSc6ICdyZWxlYXNlY291bnRyeScsXG4gICAgLyoqXG4gICAgICogUmVsZWFzZSBjb3VudHJ5IGFzIGltcGxlbWVudGVkIC8vIFRvRG86IHJlcG9ydFxuICAgICAqL1xuICAgICdUWFhYOlJFTEVBU0VDT1VOVFJZJzogJ3JlbGVhc2Vjb3VudHJ5JyxcbiAgICAnVFhYWDpTQ1JJUFQnOiAnc2NyaXB0JyxcbiAgICBUTEFOOiAnbGFuZ3VhZ2UnLFxuICAgIFRDT1A6ICdjb3B5cmlnaHQnLFxuICAgIFdDT1A6ICdsaWNlbnNlJyxcbiAgICBURU5DOiAnZW5jb2RlZGJ5JyxcbiAgICBUU1NFOiAnZW5jb2RlcnNldHRpbmdzJyxcbiAgICAnVFhYWDpCQVJDT0RFJzogJ2JhcmNvZGUnLFxuICAgICdUWFhYOklTUkMnOiAnaXNyYycsXG4gICAgVFNSQzogJ2lzcmMnLFxuICAgICdUWFhYOkFTSU4nOiAnYXNpbicsXG4gICAgJ1RYWFg6b3JpZ2luYWx5ZWFyJzogJ29yaWdpbmFseWVhcicsXG4gICAgJ1VGSUQ6aHR0cDovL211c2ljYnJhaW56Lm9yZyc6ICdtdXNpY2JyYWluel9yZWNvcmRpbmdpZCcsXG4gICAgJ1RYWFg6TXVzaWNCcmFpbnogUmVsZWFzZSBUcmFjayBJZCc6ICdtdXNpY2JyYWluel90cmFja2lkJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBBbGJ1bSBJZCc6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBBcnRpc3QgSWQnOiAnbXVzaWNicmFpbnpfYXJ0aXN0aWQnLFxuICAgICdUWFhYOk11c2ljQnJhaW56IEFsYnVtIEFydGlzdCBJZCc6ICdtdXNpY2JyYWluel9hbGJ1bWFydGlzdGlkJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBSZWxlYXNlIEdyb3VwIElkJzogJ211c2ljYnJhaW56X3JlbGVhc2Vncm91cGlkJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBXb3JrIElkJzogJ211c2ljYnJhaW56X3dvcmtpZCcsXG4gICAgJ1RYWFg6TXVzaWNCcmFpbnogVFJNIElkJzogJ211c2ljYnJhaW56X3RybWlkJyxcbiAgICAnVFhYWDpNdXNpY0JyYWlueiBEaXNjIElkJzogJ211c2ljYnJhaW56X2Rpc2NpZCcsXG4gICAgJ1RYWFg6QUNPVVNUSURfSUQnOiAnYWNvdXN0aWRfaWQnLFxuICAgICdUWFhYOkFjb3VzdGlkIElkJzogJ2Fjb3VzdGlkX2lkJyxcbiAgICAnVFhYWDpBY291c3RpZCBGaW5nZXJwcmludCc6ICdhY291c3RpZF9maW5nZXJwcmludCcsXG4gICAgJ1RYWFg6TXVzaWNJUCBQVUlEJzogJ211c2ljaXBfcHVpZCcsXG4gICAgJ1RYWFg6TXVzaWNNYWdpYyBGaW5nZXJwcmludCc6ICdtdXNpY2lwX2ZpbmdlcnByaW50JyxcbiAgICBXT0FSOiAnd2Vic2l0ZScsXG4gICAgLy8gaWQzdjIuNFxuICAgIC8vIFRvRG86IEluIHNhbWUgc2VxdWVuY2UgYXMgZGVmaW5lZCBhdCBodHRwOi8vaWQzLm9yZy9pZDN2Mi40LjAtZnJhbWVzXG4gICAgVERSQzogJ2RhdGUnLCAvLyBkYXRlIFlZWVktTU0tRERcbiAgICBUWUVSOiAneWVhcicsXG4gICAgVERPUjogJ29yaWdpbmFsZGF0ZScsXG4gICAgLy8gJ1RNQ0w6aW5zdHJ1bWVudCc6ICdwZXJmb3JtZXI6aW5zdHJ1bWVudCcsXG4gICAgJ1RJUEw6YXJyYW5nZXInOiAnYXJyYW5nZXInLFxuICAgICdUSVBMOmVuZ2luZWVyJzogJ2VuZ2luZWVyJyxcbiAgICAnVElQTDpwcm9kdWNlcic6ICdwcm9kdWNlcicsXG4gICAgJ1RJUEw6REotbWl4JzogJ2RqbWl4ZXInLFxuICAgICdUSVBMOm1peCc6ICdtaXhlcicsXG4gICAgVE1PTzogJ21vb2QnLFxuICAgIC8vIGFkZGl0aW9uYWwgbWFwcGluZ3M6XG4gICAgU1lMVDogJ2x5cmljcycsXG4gICAgVFNTVDogJ2Rpc2NzdWJ0aXRsZScsXG4gICAgVEtFWTogJ2tleScsXG4gICAgQ09NTTogJ2NvbW1lbnQnLFxuICAgIFRPUEU6ICdvcmlnaW5hbGFydGlzdCcsXG4gICAgLy8gV2luZG93cyBNZWRpYSBQbGF5ZXJcbiAgICAnUFJJVjpBdmVyYWdlTGV2ZWwnOiAnYXZlcmFnZUxldmVsJyxcbiAgICAnUFJJVjpQZWFrVmFsdWUnOiAncGVha0xldmVsJyxcbiAgICAnUFJJVjpQZWFrTGV2ZWwnOiAncGVha0xldmVsJyxcbiAgICAvLyBEaXNjb2dzXG4gICAgJ1RYWFg6RElTQ09HU19BUlRJU1RfSUQnOiAnZGlzY29nc19hcnRpc3RfaWQnLFxuICAgICdUWFhYOkRJU0NPR1NfQVJUSVNUUyc6ICdhcnRpc3RzJyxcbiAgICAnVFhYWDpESVNDT0dTX0FSVElTVF9OQU1FJzogJ2FydGlzdHMnLFxuICAgICdUWFhYOkRJU0NPR1NfQUxCVU1fQVJUSVNUUyc6ICdhbGJ1bWFydGlzdHMnLFxuICAgICdUWFhYOkRJU0NPR1NfQ0FUQUxPRyc6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICAnVFhYWDpESVNDT0dTX0NPVU5UUlknOiAncmVsZWFzZWNvdW50cnknLFxuICAgICdUWFhYOkRJU0NPR1NfREFURSc6ICdvcmlnaW5hbGRhdGUnLFxuICAgICdUWFhYOkRJU0NPR1NfTEFCRUwnOiAnbGFiZWwnLFxuICAgICdUWFhYOkRJU0NPR1NfTEFCRUxfSUQnOiAnZGlzY29nc19sYWJlbF9pZCcsXG4gICAgJ1RYWFg6RElTQ09HU19NQVNURVJfUkVMRUFTRV9JRCc6ICdkaXNjb2dzX21hc3Rlcl9yZWxlYXNlX2lkJyxcbiAgICAnVFhYWDpESVNDT0dTX1JBVElORyc6ICdkaXNjb2dzX3JhdGluZycsXG4gICAgJ1RYWFg6RElTQ09HU19SRUxFQVNFRCc6ICdkYXRlJyxcbiAgICAnVFhYWDpESVNDT0dTX1JFTEVBU0VfSUQnOiAnZGlzY29nc19yZWxlYXNlX2lkJyxcbiAgICAnVFhYWDpESVNDT0dTX1ZPVEVTJzogJ2Rpc2NvZ3Nfdm90ZXMnLFxuICAgICdUWFhYOkNBVEFMT0dJRCc6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICAnVFhYWDpTVFlMRSc6ICdnZW5yZScsXG4gICAgJ1RYWFg6UkVQTEFZR0FJTl9UUkFDS19QRUFLJzogJ3JlcGxheWdhaW5fdHJhY2tfcGVhaycsXG4gICAgJ1RYWFg6UkVQTEFZR0FJTl9UUkFDS19HQUlOJzogJ3JlcGxheWdhaW5fdHJhY2tfZ2FpbicsXG4gICAgJ1RYWFg6UkVQTEFZR0FJTl9BTEJVTV9QRUFLJzogJ3JlcGxheWdhaW5fYWxidW1fcGVhaycsXG4gICAgJ1RYWFg6UkVQTEFZR0FJTl9BTEJVTV9HQUlOJzogJ3JlcGxheWdhaW5fYWxidW1fZ2FpbicsXG4gICAgJ1RYWFg6TVAzR0FJTl9NSU5NQVgnOiAncmVwbGF5Z2Fpbl90cmFja19taW5tYXgnLFxuICAgICdUWFhYOk1QM0dBSU5fQUxCVU1fTUlOTUFYJzogJ3JlcGxheWdhaW5fYWxidW1fbWlubWF4JyxcbiAgICAnVFhYWDpNUDNHQUlOX1VORE8nOiAncmVwbGF5Z2Fpbl91bmRvJyxcbiAgICBNVk5NOiAnbW92ZW1lbnQnLFxuICAgIE1WSU46ICdtb3ZlbWVudEluZGV4JyxcbiAgICBQQ1NUOiAncG9kY2FzdCcsXG4gICAgVENBVDogJ2NhdGVnb3J5JyxcbiAgICBUREVTOiAnZGVzY3JpcHRpb24nLFxuICAgIFREUkw6ICdyZWxlYXNlZGF0ZScsXG4gICAgVEdJRDogJ3BvZGNhc3RJZCcsXG4gICAgVEtXRDogJ2tleXdvcmRzJyxcbiAgICBXRkVEOiAncG9kY2FzdHVybCcsXG4gICAgR1JQMTogJ2dyb3VwaW5nJyxcbiAgICBQQ05UOiAncGxheUNvdW50ZXInXG59O1xuZXhwb3J0IGNsYXNzIElEM3YyNFRhZ01hcHBlciBleHRlbmRzIENhc2VJbnNlbnNpdGl2ZVRhZ01hcCB7XG4gICAgc3RhdGljIHRvUmF0aW5nKHBvcG0pIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNvdXJjZTogcG9wbS5lbWFpbCxcbiAgICAgICAgICAgIHJhdGluZzogcG9wbS5yYXRpbmcgPiAwID8gKChwb3BtLnJhdGluZyAtIDEpIC8gMjU0KSAqIENvbW1vblRhZ01hcHBlci5tYXhSYXRpbmdTY29yZSA6IHVuZGVmaW5lZFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoWydJRDN2Mi4zJywgJ0lEM3YyLjQnXSwgaWQzdjI0VGFnTWFwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogSGFuZGxlIHBvc3QgbWFwcGluZyBleGNlcHRpb25zIC8gY29ycmVjdGlvblxuICAgICAqIEBwYXJhbSB0YWcgdG8gcG9zdCBtYXBcbiAgICAgKiBAcGFyYW0gd2FybmluZ3MgV2lsIGJlIHVzZWQgdG8gcmVnaXN0ZXIgKGNvbGxlY3QpIHdhcm5pbmdzXG4gICAgICovXG4gICAgcG9zdE1hcCh0YWcsIHdhcm5pbmdzKSB7XG4gICAgICAgIHN3aXRjaCAodGFnLmlkKSB7XG4gICAgICAgICAgICBjYXNlICdVRklEJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGRlY29kZSBNdXNpY0JyYWlueiBSZWNvcmRpbmcgSWRcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaWRUYWcgPSB0YWcudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpZFRhZy5vd25lcl9pZGVudGlmaWVyID09PSAnaHR0cDovL211c2ljYnJhaW56Lm9yZycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhZy5pZCArPSBgOiR7aWRUYWcub3duZXJfaWRlbnRpZmllcn1gO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFnLnZhbHVlID0gZGVjb2RlU3RyaW5nKGlkVGFnLmlkZW50aWZpZXIsICdsYXRpbjEnKTsgLy8gbGF0aW4xID09IGlzby04ODU5LTFcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ1BSSVYnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VzdG9tVGFnID0gdGFnLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGN1c3RvbVRhZy5vd25lcl9pZGVudGlmaWVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBkZWNvZGUgV2luZG93cyBNZWRpYSBQbGF5ZXJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ0F2ZXJhZ2VMZXZlbCc6XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdQZWFrVmFsdWUnOlxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnUGVha0xldmVsJzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWcuaWQgKz0gYDoke2N1c3RvbVRhZy5vd25lcl9pZGVudGlmaWVyfWA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFnLnZhbHVlID0gY3VzdG9tVGFnLmRhdGEubGVuZ3RoID09PSA0ID8gVUlOVDMyX0xFLmdldChjdXN0b21UYWcuZGF0YSwgMCkgOiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0YWcudmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2FybmluZ3MuYWRkV2FybmluZyhgRmFpbGVkIHRvIHBhcnNlIFBSSVY6JHtjdXN0b21UYWcub3duZXJfaWRlbnRpZmllcn1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdhcm5pbmdzLmFkZFdhcm5pbmcoYFVua25vd24gUFJJViBvd25lci1pZGVudGlmaWVyOiAke2N1c3RvbVRhZy5vd25lcl9pZGVudGlmaWVyLnNsaWNlKDAsIDEyOCl9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdQT1BNJzpcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSBJRDN2MjRUYWdNYXBwZXIudG9SYXRpbmcodGFnLnZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDYXNlSW5zZW5zaXRpdmVUYWdNYXAgfSBmcm9tICcuLi9jb21tb24vQ2FzZUluc2Vuc2l0aXZlVGFnTWFwLmpzJztcbi8qKlxuICogRUJNTCBUYWcgbWFwXG4gKi9cbmNvbnN0IGVibWxUYWdNYXAgPSB7XG4gICAgJ3NlZ21lbnQ6dGl0bGUnOiAndGl0bGUnLFxuICAgICdhbGJ1bTpBUlRJU1QnOiAnYWxidW1hcnRpc3QnLFxuICAgICdhbGJ1bTpBUlRJU1RTT1JUJzogJ2FsYnVtYXJ0aXN0c29ydCcsXG4gICAgJ2FsYnVtOlRJVExFJzogJ2FsYnVtJyxcbiAgICAnYWxidW06REFURV9SRUNPUkRFRCc6ICdvcmlnaW5hbGRhdGUnLFxuICAgICdhbGJ1bTpEQVRFX1JFTEVBU0VEJzogJ3JlbGVhc2VkYXRlJyxcbiAgICAnYWxidW06UEFSVF9OVU1CRVInOiAnZGlzaycsXG4gICAgJ2FsYnVtOlRPVEFMX1BBUlRTJzogJ3RvdGFsdHJhY2tzJyxcbiAgICAndHJhY2s6QVJUSVNUJzogJ2FydGlzdCcsXG4gICAgJ3RyYWNrOkFSVElTVFNPUlQnOiAnYXJ0aXN0c29ydCcsXG4gICAgJ3RyYWNrOlRJVExFJzogJ3RpdGxlJyxcbiAgICAndHJhY2s6UEFSVF9OVU1CRVInOiAndHJhY2snLFxuICAgICd0cmFjazpNVVNJQ0JSQUlOWl9UUkFDS0lEJzogJ211c2ljYnJhaW56X3JlY29yZGluZ2lkJyxcbiAgICAndHJhY2s6TVVTSUNCUkFJTlpfQUxCVU1JRCc6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICAndHJhY2s6TVVTSUNCUkFJTlpfQVJUSVNUSUQnOiAnbXVzaWNicmFpbnpfYXJ0aXN0aWQnLFxuICAgICd0cmFjazpQVUJMSVNIRVInOiAnbGFiZWwnLFxuICAgICd0cmFjazpHRU5SRSc6ICdnZW5yZScsXG4gICAgJ3RyYWNrOkVOQ09ERVInOiAnZW5jb2RlZGJ5JyxcbiAgICAndHJhY2s6RU5DT0RFUl9PUFRJT05TJzogJ2VuY29kZXJzZXR0aW5ncycsXG4gICAgJ2VkaXRpb246VE9UQUxfUEFSVFMnOiAndG90YWxkaXNjcycsXG4gICAgcGljdHVyZTogJ3BpY3R1cmUnXG59O1xuZXhwb3J0IGNsYXNzIE1hdHJvc2thVGFnTWFwcGVyIGV4dGVuZHMgQ2FzZUluc2Vuc2l0aXZlVGFnTWFwIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoWydtYXRyb3NrYSddLCBlYm1sVGFnTWFwKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBDYXNlSW5zZW5zaXRpdmVUYWdNYXAgfSBmcm9tICcuLi9jb21tb24vQ2FzZUluc2Vuc2l0aXZlVGFnTWFwLmpzJztcbi8qKlxuICogUmVmOiBodHRwczovL2dpdGh1Yi5jb20vc2VyZ2lvbWIyL2xpYm1wNHYyL3dpa2kvaVR1bmVzTWV0YWRhdGFcbiAqL1xuY29uc3QgbXA0VGFnTWFwID0ge1xuICAgICdtZHRhOnRpdGxlJzogJ3RpdGxlJyxcbiAgICAnbWR0YTphbGJ1bSc6ICdhbGJ1bScsXG4gICAgJ21kdGE6YXJ0aXN0JzogJ2FydGlzdCcsXG4gICAgJ21kdGE6YWxidW1fYXJ0aXN0JzogJ2FsYnVtYXJ0aXN0JyxcbiAgICAnbWR0YTphbGJ1bWFydGlzdCc6ICdhbGJ1bWFydGlzdCcsXG4gICAgJ21kdGE6Y29tcG9zZXInOiAnY29tcG9zZXInLFxuICAgICdtZHRhOmRhdGUnOiAnZGF0ZScsXG4gICAgJ21kdGE6Y29tbWVudCc6ICdjb21tZW50JyxcbiAgICAnbWR0YTpkZXNjcmlwdGlvbic6ICdkZXNjcmlwdGlvbicsXG4gICAgJ21kdGE6c3lub3BzaXMnOiAnbG9uZ0Rlc2NyaXB0aW9uJyxcbiAgICAnbWR0YTpnZW5yZSc6ICdnZW5yZScsXG4gICAgJ21kdGE6dHJhY2snOiAndHJhY2snLFxuICAgICdtZHRhOmRpc2MnOiAnZGlzaycsXG4gICAgJ21kdGE6cHVibGlzaGVyJzogJ2xhYmVsJyxcbiAgICAnbWR0YTpzdWJ0aXRsZSc6ICdzdWJ0aXRsZScsXG4gICAgJ21kdGE6bGFuZ3VhZ2UnOiAnbGFuZ3VhZ2UnLFxuICAgICdtZHRhOmNvcHlyaWdodCc6ICdjb3B5cmlnaHQnLFxuICAgICdtZHRhOmVuY29kZXInOiAnZW5jb2RlZGJ5JyxcbiAgICAnbWR0YTphc2luJzogJ2FzaW4nLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUudGl0bGUnOiAndGl0bGUnLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUuYWxidW0nOiAnYWxidW0nLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUuYXJ0aXN0JzogJ2FydGlzdCcsXG4gICAgJ21kdGE6Y29tLmFwcGxlLnF1aWNrdGltZS5jcmVhdGlvbmRhdGUnOiAnZGF0ZScsXG4gICAgJ21kdGE6Y29tLmFwcGxlLnF1aWNrdGltZS5jb21tZW50JzogJ2NvbW1lbnQnLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUuZGVzY3JpcHRpb24nOiAnZGVzY3JpcHRpb24nLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUuZ2VucmUnOiAnZ2VucmUnLFxuICAgICdtZHRhOmNvbS5hcHBsZS5xdWlja3RpbWUuY29weXJpZ2h0JzogJ2NvcHlyaWdodCcsXG4gICAgJ8KpbmFtJzogJ3RpdGxlJyxcbiAgICAnwqlBUlQnOiAnYXJ0aXN0JyxcbiAgICBhQVJUOiAnYWxidW1hcnRpc3QnLFxuICAgIC8qKlxuICAgICAqIFRvRG86IEFsYnVtIGFydGlzdCBzZWVtcyB0byBiZSBzdG9yZWQgaGVyZSB3aGlsZSBQaWNhcmQgZG9jdW1lbnRhdGlvbiBzYXlzOiBhQVJUXG4gICAgICovXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpCYW5kJzogJ2FsYnVtYXJ0aXN0JyxcbiAgICAnwqlhbGInOiAnYWxidW0nLFxuICAgICfCqWRheSc6ICdkYXRlJyxcbiAgICAnwqljbXQnOiAnY29tbWVudCcsXG4gICAgJ8KpY29tJzogJ2NvbW1lbnQnLFxuICAgIHRya246ICd0cmFjaycsXG4gICAgZGlzazogJ2Rpc2snLFxuICAgICfCqWdlbic6ICdnZW5yZScsXG4gICAgY292cjogJ3BpY3R1cmUnLFxuICAgICfCqXdydCc6ICdjb21wb3NlcicsXG4gICAgJ8KpbHlyJzogJ2x5cmljcycsXG4gICAgc29hbDogJ2FsYnVtc29ydCcsXG4gICAgc29ubTogJ3RpdGxlc29ydCcsXG4gICAgc29hcjogJ2FydGlzdHNvcnQnLFxuICAgIHNvYWE6ICdhbGJ1bWFydGlzdHNvcnQnLFxuICAgIHNvY286ICdjb21wb3NlcnNvcnQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6TFlSSUNJU1QnOiAnbHlyaWNpc3QnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6Q09ORFVDVE9SJzogJ2NvbmR1Y3RvcicsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpSRU1JWEVSJzogJ3JlbWl4ZXInLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6RU5HSU5FRVInOiAnZW5naW5lZXInLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6UFJPRFVDRVInOiAncHJvZHVjZXInLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6REpNSVhFUic6ICdkam1peGVyJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk1JWEVSJzogJ21peGVyJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOkxBQkVMJzogJ2xhYmVsJyxcbiAgICAnwqlncnAnOiAnZ3JvdXBpbmcnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6U1VCVElUTEUnOiAnc3VidGl0bGUnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6RElTQ1NVQlRJVExFJzogJ2Rpc2NzdWJ0aXRsZScsXG4gICAgY3BpbDogJ2NvbXBpbGF0aW9uJyxcbiAgICB0bXBvOiAnYnBtJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk1PT0QnOiAnbW9vZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNRURJQSc6ICdtZWRpYScsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpDQVRBTE9HTlVNQkVSJzogJ2NhdGFsb2dudW1iZXInLFxuICAgIHR2c2g6ICd0dlNob3cnLFxuICAgIHR2c246ICd0dlNlYXNvbicsXG4gICAgdHZlczogJ3R2RXBpc29kZScsXG4gICAgc29zbjogJ3R2U2hvd1NvcnQnLFxuICAgIHR2ZW46ICd0dkVwaXNvZGVJZCcsXG4gICAgdHZubjogJ3R2TmV0d29yaycsXG4gICAgcGNzdDogJ3BvZGNhc3QnLFxuICAgIHB1cmw6ICdwb2RjYXN0dXJsJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IEFsYnVtIFN0YXR1cyc6ICdyZWxlYXNlc3RhdHVzJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IEFsYnVtIFR5cGUnOiAncmVsZWFzZXR5cGUnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6TXVzaWNCcmFpbnogQWxidW0gUmVsZWFzZSBDb3VudHJ5JzogJ3JlbGVhc2Vjb3VudHJ5JyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOlNDUklQVCc6ICdzY3JpcHQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6TEFOR1VBR0UnOiAnbGFuZ3VhZ2UnLFxuICAgIGNwcnQ6ICdjb3B5cmlnaHQnLFxuICAgICfCqWNweSc6ICdjb3B5cmlnaHQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6TElDRU5TRSc6ICdsaWNlbnNlJyxcbiAgICAnwql0b28nOiAnZW5jb2RlZGJ5JyxcbiAgICBwZ2FwOiAnZ2FwbGVzcycsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpCQVJDT0RFJzogJ2JhcmNvZGUnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6SVNSQyc6ICdpc3JjJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOkFTSU4nOiAnYXNpbicsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpOT1RFUyc6ICdjb21tZW50JyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IFRyYWNrIElkJzogJ211c2ljYnJhaW56X3JlY29yZGluZ2lkJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IFJlbGVhc2UgVHJhY2sgSWQnOiAnbXVzaWNicmFpbnpfdHJhY2tpZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNdXNpY0JyYWlueiBBbGJ1bSBJZCc6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IEFydGlzdCBJZCc6ICdtdXNpY2JyYWluel9hcnRpc3RpZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNdXNpY0JyYWlueiBBbGJ1bSBBcnRpc3QgSWQnOiAnbXVzaWNicmFpbnpfYWxidW1hcnRpc3RpZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNdXNpY0JyYWlueiBSZWxlYXNlIEdyb3VwIElkJzogJ211c2ljYnJhaW56X3JlbGVhc2Vncm91cGlkJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IFdvcmsgSWQnOiAnbXVzaWNicmFpbnpfd29ya2lkJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk11c2ljQnJhaW56IFRSTSBJZCc6ICdtdXNpY2JyYWluel90cm1pZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNdXNpY0JyYWlueiBEaXNjIElkJzogJ211c2ljYnJhaW56X2Rpc2NpZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpBY291c3RpZCBJZCc6ICdhY291c3RpZF9pZCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpBY291c3RpZCBGaW5nZXJwcmludCc6ICdhY291c3RpZF9maW5nZXJwcmludCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNdXNpY0lQIFBVSUQnOiAnbXVzaWNpcF9wdWlkJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOmZpbmdlcnByaW50JzogJ211c2ljaXBfZmluZ2VycHJpbnQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6cmVwbGF5Z2Fpbl90cmFja19nYWluJzogJ3JlcGxheWdhaW5fdHJhY2tfZ2FpbicsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpyZXBsYXlnYWluX3RyYWNrX3BlYWsnOiAncmVwbGF5Z2Fpbl90cmFja19wZWFrJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOnJlcGxheWdhaW5fYWxidW1fZ2Fpbic6ICdyZXBsYXlnYWluX2FsYnVtX2dhaW4nLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6cmVwbGF5Z2Fpbl9hbGJ1bV9wZWFrJzogJ3JlcGxheWdhaW5fYWxidW1fcGVhaycsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpyZXBsYXlnYWluX3RyYWNrX21pbm1heCc6ICdyZXBsYXlnYWluX3RyYWNrX21pbm1heCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpyZXBsYXlnYWluX2FsYnVtX21pbm1heCc6ICdyZXBsYXlnYWluX2FsYnVtX21pbm1heCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpyZXBsYXlnYWluX3VuZG8nOiAncmVwbGF5Z2Fpbl91bmRvJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk1vdmVtZW50IE5hbWUnOiAnbW92ZW1lbnQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6TW92ZW1lbnQnOiAnbW92ZW1lbnRJbmRleCcsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpNb3ZlbWVudCBUb3RhbCc6ICdtb3ZlbWVudFRvdGFsJyxcbiAgICAvLyBBZGRpdGlvbmFsIG1hcHBpbmdzOlxuICAgIGducmU6ICdnZW5yZScsIC8vIFRvRG86IGNoZWNrIG1hcHBpbmdcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOkFMQlVNQVJUSVNUU09SVCc6ICdhbGJ1bWFydGlzdHNvcnQnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6QVJUSVNUUyc6ICdhcnRpc3RzJyxcbiAgICAnLS0tLTpjb20uYXBwbGUuaVR1bmVzOk9SSUdJTkFMREFURSc6ICdvcmlnaW5hbGRhdGUnLFxuICAgICctLS0tOmNvbS5hcHBsZS5pVHVuZXM6T1JJR0lOQUxZRUFSJzogJ29yaWdpbmFseWVhcicsXG4gICAgJy0tLS06Y29tLmFwcGxlLmlUdW5lczpSRUxFQVNFREFURSc6ICdyZWxlYXNlZGF0ZScsXG4gICAgLy8gJy0tLS06Y29tLmFwcGxlLmlUdW5lczpQRVJGT1JNRVInOiAncGVyZm9ybWVyJ1xuICAgIGRlc2M6ICdkZXNjcmlwdGlvbicsXG4gICAgbGRlczogJ2xvbmdEZXNjcmlwdGlvbicsXG4gICAgJ8KpbXZuJzogJ21vdmVtZW50JyxcbiAgICAnwqltdmknOiAnbW92ZW1lbnRJbmRleCcsXG4gICAgJ8KpbXZjJzogJ21vdmVtZW50VG90YWwnLFxuICAgICfCqXdyayc6ICd3b3JrJyxcbiAgICBjYXRnOiAnY2F0ZWdvcnknLFxuICAgIGVnaWQ6ICdwb2RjYXN0SWQnLFxuICAgIGhkdmQ6ICdoZFZpZGVvJyxcbiAgICBrZXl3OiAna2V5d29yZHMnLFxuICAgIHNod206ICdzaG93TW92ZW1lbnQnLFxuICAgIHN0aWs6ICdzdGlrJyxcbiAgICByYXRlOiAncmF0aW5nJ1xufTtcbmV4cG9ydCBjb25zdCB0YWdUeXBlID0gJ2lUdW5lcyc7XG5leHBvcnQgY2xhc3MgTVA0VGFnTWFwcGVyIGV4dGVuZHMgQ2FzZUluc2Vuc2l0aXZlVGFnTWFwIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoW3RhZ1R5cGVdLCBtcDRUYWdNYXApO1xuICAgIH1cbiAgICBwb3N0TWFwKHRhZywgX3dhcm5pbmdzKSB7XG4gICAgICAgIHN3aXRjaCAodGFnLmlkKSB7XG4gICAgICAgICAgICBjYXNlICdyYXRlJzpcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSB7XG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICByYXRpbmc6IE51bWJlci5wYXJzZUZsb2F0KHRhZy52YWx1ZSkgLyAxMDBcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tbW9uVGFnTWFwcGVyIH0gZnJvbSAnLi4vLi4vY29tbW9uL0dlbmVyaWNUYWdNYXBwZXIuanMnO1xuLyoqXG4gKiBWb3JiaXMgdGFnIG1hcHBpbmdzXG4gKlxuICogTWFwcGluZyBmcm9tIG5hdGl2ZSBoZWFkZXIgZm9ybWF0IHRvIG9uZSBvciBwb3NzaWJseSBtb3JlICdjb21tb24nIGVudHJpZXNcbiAqIFRoZSBjb21tb24gZW50cmllcyBhaW0gdG8gcmVhZCB0aGUgc2FtZSBpbmZvcm1hdGlvbiBmcm9tIGRpZmZlcmVudCBtZWRpYSBmaWxlc1xuICogaW5kZXBlbmRlbnQgb2YgdGhlIHVuZGVybHlpbmcgZm9ybWF0XG4gKi9cbmNvbnN0IHZvcmJpc1RhZ01hcCA9IHtcbiAgICBUSVRMRTogJ3RpdGxlJyxcbiAgICBBUlRJU1Q6ICdhcnRpc3QnLFxuICAgIEFSVElTVFM6ICdhcnRpc3RzJyxcbiAgICBBTEJVTUFSVElTVDogJ2FsYnVtYXJ0aXN0JyxcbiAgICAnQUxCVU0gQVJUSVNUJzogJ2FsYnVtYXJ0aXN0JyxcbiAgICBBTEJVTTogJ2FsYnVtJyxcbiAgICBEQVRFOiAnZGF0ZScsXG4gICAgT1JJR0lOQUxEQVRFOiAnb3JpZ2luYWxkYXRlJyxcbiAgICBPUklHSU5BTFlFQVI6ICdvcmlnaW5hbHllYXInLFxuICAgIFJFTEVBU0VEQVRFOiAncmVsZWFzZWRhdGUnLFxuICAgIENPTU1FTlQ6ICdjb21tZW50JyxcbiAgICBERVNDUklQVElPTjogJ2NvbW1lbnQnLFxuICAgIFRSQUNLTlVNQkVSOiAndHJhY2snLFxuICAgIERJU0NOVU1CRVI6ICdkaXNrJyxcbiAgICBHRU5SRTogJ2dlbnJlJyxcbiAgICBNRVRBREFUQV9CTE9DS19QSUNUVVJFOiAncGljdHVyZScsXG4gICAgQ09NUE9TRVI6ICdjb21wb3NlcicsXG4gICAgTFlSSUNTOiAnbHlyaWNzJyxcbiAgICBVTlNZTkNFRExZUklDUzogJ2x5cmljcycsXG4gICAgQUxCVU1TT1JUOiAnYWxidW1zb3J0JyxcbiAgICBUSVRMRVNPUlQ6ICd0aXRsZXNvcnQnLFxuICAgIFdPUks6ICd3b3JrJyxcbiAgICBBUlRJU1RTT1JUOiAnYXJ0aXN0c29ydCcsXG4gICAgQUxCVU1BUlRJU1RTT1JUOiAnYWxidW1hcnRpc3Rzb3J0JyxcbiAgICBDT01QT1NFUlNPUlQ6ICdjb21wb3NlcnNvcnQnLFxuICAgIExZUklDSVNUOiAnbHlyaWNpc3QnLFxuICAgIFdSSVRFUjogJ3dyaXRlcicsXG4gICAgQ09ORFVDVE9SOiAnY29uZHVjdG9yJyxcbiAgICAvLyAnUEVSRk9STUVSPWFydGlzdMKgKGluc3RydW1lbnQpJzogJ3BlcmZvcm1lcjppbnN0cnVtZW50JywgLy8gVG9Eb1xuICAgIFJFTUlYRVI6ICdyZW1peGVyJyxcbiAgICBBUlJBTkdFUjogJ2FycmFuZ2VyJyxcbiAgICBFTkdJTkVFUjogJ2VuZ2luZWVyJyxcbiAgICBQUk9EVUNFUjogJ3Byb2R1Y2VyJyxcbiAgICBESk1JWEVSOiAnZGptaXhlcicsXG4gICAgTUlYRVI6ICdtaXhlcicsXG4gICAgTEFCRUw6ICdsYWJlbCcsXG4gICAgT1JHQU5JWkFUSU9OOiAnbGFiZWwnLFxuICAgIFBVQkxJU0hFUjogJ2xhYmVsJyxcbiAgICBHUk9VUElORzogJ2dyb3VwaW5nJyxcbiAgICBTVUJUSVRMRTogJ3N1YnRpdGxlJyxcbiAgICBESVNDU1VCVElUTEU6ICdkaXNjc3VidGl0bGUnLFxuICAgIFRSQUNLVE9UQUw6ICd0b3RhbHRyYWNrcycsXG4gICAgRElTQ1RPVEFMOiAndG90YWxkaXNjcycsXG4gICAgQ09NUElMQVRJT046ICdjb21waWxhdGlvbicsXG4gICAgUkFUSU5HOiAncmF0aW5nJyxcbiAgICBCUE06ICdicG0nLFxuICAgIEtFWTogJ2tleScsXG4gICAgTU9PRDogJ21vb2QnLFxuICAgIE1FRElBOiAnbWVkaWEnLFxuICAgIENBVEFMT0dOVU1CRVI6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICBSRUxFQVNFU1RBVFVTOiAncmVsZWFzZXN0YXR1cycsXG4gICAgUkVMRUFTRVRZUEU6ICdyZWxlYXNldHlwZScsXG4gICAgUkVMRUFTRUNPVU5UUlk6ICdyZWxlYXNlY291bnRyeScsXG4gICAgU0NSSVBUOiAnc2NyaXB0JyxcbiAgICBMQU5HVUFHRTogJ2xhbmd1YWdlJyxcbiAgICBDT1BZUklHSFQ6ICdjb3B5cmlnaHQnLFxuICAgIExJQ0VOU0U6ICdsaWNlbnNlJyxcbiAgICBFTkNPREVEQlk6ICdlbmNvZGVkYnknLFxuICAgIEVOQ09ERVJTRVRUSU5HUzogJ2VuY29kZXJzZXR0aW5ncycsXG4gICAgQkFSQ09ERTogJ2JhcmNvZGUnLFxuICAgIElTUkM6ICdpc3JjJyxcbiAgICBBU0lOOiAnYXNpbicsXG4gICAgTVVTSUNCUkFJTlpfVFJBQ0tJRDogJ211c2ljYnJhaW56X3JlY29yZGluZ2lkJyxcbiAgICBNVVNJQ0JSQUlOWl9SRUxFQVNFVFJBQ0tJRDogJ211c2ljYnJhaW56X3RyYWNraWQnLFxuICAgIE1VU0lDQlJBSU5aX0FMQlVNSUQ6ICdtdXNpY2JyYWluel9hbGJ1bWlkJyxcbiAgICBNVVNJQ0JSQUlOWl9BUlRJU1RJRDogJ211c2ljYnJhaW56X2FydGlzdGlkJyxcbiAgICBNVVNJQ0JSQUlOWl9BTEJVTUFSVElTVElEOiAnbXVzaWNicmFpbnpfYWxidW1hcnRpc3RpZCcsXG4gICAgTVVTSUNCUkFJTlpfUkVMRUFTRUdST1VQSUQ6ICdtdXNpY2JyYWluel9yZWxlYXNlZ3JvdXBpZCcsXG4gICAgTVVTSUNCUkFJTlpfV09SS0lEOiAnbXVzaWNicmFpbnpfd29ya2lkJyxcbiAgICBNVVNJQ0JSQUlOWl9UUk1JRDogJ211c2ljYnJhaW56X3RybWlkJyxcbiAgICBNVVNJQ0JSQUlOWl9ESVNDSUQ6ICdtdXNpY2JyYWluel9kaXNjaWQnLFxuICAgIEFDT1VTVElEX0lEOiAnYWNvdXN0aWRfaWQnLFxuICAgIEFDT1VTVElEX0lEX0ZJTkdFUlBSSU5UOiAnYWNvdXN0aWRfZmluZ2VycHJpbnQnLFxuICAgIE1VU0lDSVBfUFVJRDogJ211c2ljaXBfcHVpZCcsXG4gICAgLy8gJ0ZJTkdFUlBSSU5UPU11c2ljTWFnaWMgRmluZ2VycHJpbnTCoHtmaW5nZXJwcmludH0nOiAnbXVzaWNpcF9maW5nZXJwcmludCcsIC8vIFRvRG9cbiAgICBXRUJTSVRFOiAnd2Vic2l0ZScsXG4gICAgTk9URVM6ICdub3RlcycsXG4gICAgVE9UQUxUUkFDS1M6ICd0b3RhbHRyYWNrcycsXG4gICAgVE9UQUxESVNDUzogJ3RvdGFsZGlzY3MnLFxuICAgIC8vIERpc2NvZ3NcbiAgICBESVNDT0dTX0FSVElTVF9JRDogJ2Rpc2NvZ3NfYXJ0aXN0X2lkJyxcbiAgICBESVNDT0dTX0FSVElTVFM6ICdhcnRpc3RzJyxcbiAgICBESVNDT0dTX0FSVElTVF9OQU1FOiAnYXJ0aXN0cycsXG4gICAgRElTQ09HU19BTEJVTV9BUlRJU1RTOiAnYWxidW1hcnRpc3RzJyxcbiAgICBESVNDT0dTX0NBVEFMT0c6ICdjYXRhbG9nbnVtYmVyJyxcbiAgICBESVNDT0dTX0NPVU5UUlk6ICdyZWxlYXNlY291bnRyeScsXG4gICAgRElTQ09HU19EQVRFOiAnb3JpZ2luYWxkYXRlJyxcbiAgICBESVNDT0dTX0xBQkVMOiAnbGFiZWwnLFxuICAgIERJU0NPR1NfTEFCRUxfSUQ6ICdkaXNjb2dzX2xhYmVsX2lkJyxcbiAgICBESVNDT0dTX01BU1RFUl9SRUxFQVNFX0lEOiAnZGlzY29nc19tYXN0ZXJfcmVsZWFzZV9pZCcsXG4gICAgRElTQ09HU19SQVRJTkc6ICdkaXNjb2dzX3JhdGluZycsXG4gICAgRElTQ09HU19SRUxFQVNFRDogJ2RhdGUnLFxuICAgIERJU0NPR1NfUkVMRUFTRV9JRDogJ2Rpc2NvZ3NfcmVsZWFzZV9pZCcsXG4gICAgRElTQ09HU19WT1RFUzogJ2Rpc2NvZ3Nfdm90ZXMnLFxuICAgIENBVEFMT0dJRDogJ2NhdGFsb2dudW1iZXInLFxuICAgIFNUWUxFOiAnZ2VucmUnLFxuICAgIC8vXG4gICAgUkVQTEFZR0FJTl9UUkFDS19HQUlOOiAncmVwbGF5Z2Fpbl90cmFja19nYWluJyxcbiAgICBSRVBMQVlHQUlOX1RSQUNLX1BFQUs6ICdyZXBsYXlnYWluX3RyYWNrX3BlYWsnLFxuICAgIFJFUExBWUdBSU5fQUxCVU1fR0FJTjogJ3JlcGxheWdhaW5fYWxidW1fZ2FpbicsXG4gICAgUkVQTEFZR0FJTl9BTEJVTV9QRUFLOiAncmVwbGF5Z2Fpbl9hbGJ1bV9wZWFrJyxcbiAgICAvLyBUbyBTdXJlIGlmIHRoZXNlIChSRVBMQVlHQUlOX01JTk1BWCwgUkVQTEFZR0FJTl9BTEJVTV9NSU5NQVggJiBSRVBMQVlHQUlOX1VORE8pIGFyZSB1c2VkIGZvciBWb3JiaXM6XG4gICAgUkVQTEFZR0FJTl9NSU5NQVg6ICdyZXBsYXlnYWluX3RyYWNrX21pbm1heCcsXG4gICAgUkVQTEFZR0FJTl9BTEJVTV9NSU5NQVg6ICdyZXBsYXlnYWluX2FsYnVtX21pbm1heCcsXG4gICAgUkVQTEFZR0FJTl9VTkRPOiAncmVwbGF5Z2Fpbl91bmRvJ1xufTtcbmV4cG9ydCBjbGFzcyBWb3JiaXNUYWdNYXBwZXIgZXh0ZW5kcyBDb21tb25UYWdNYXBwZXIge1xuICAgIGhhc1N0YW5kYXJkRGF0ZSA9IGZhbHNlO1xuICAgIHN0YXRpYyB0b1JhdGluZyhlbWFpbCwgcmF0aW5nLCBtYXhTY29yZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc291cmNlOiBlbWFpbCA/IGVtYWlsLnRvTG93ZXJDYXNlKCkgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICByYXRpbmc6IChOdW1iZXIucGFyc2VGbG9hdChyYXRpbmcpIC8gbWF4U2NvcmUpICogQ29tbW9uVGFnTWFwcGVyLm1heFJhdGluZ1Njb3JlXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihbJ3ZvcmJpcyddLCB2b3JiaXNUYWdNYXApO1xuICAgIH1cbiAgICBtYXBHZW5lcmljVGFnKHRhZywgd2FybmluZ3MpIHtcbiAgICAgICAgaWYgKHRhZy5pZCA9PT0gJ0RBVEUnKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHRhZy52YWx1ZSAhPT0gJ3N0cmluZycgfHwgdGFnLnZhbHVlLnRyaW0oKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuaGFzU3RhbmRhcmREYXRlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0YWcuaWQgPT09ICdESVNDT0dTX1JFTEVBU0VEJyAmJiB0aGlzLmhhc1N0YW5kYXJkRGF0ZSkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN1cGVyLm1hcEdlbmVyaWNUYWcodGFnLCB3YXJuaW5ncyk7XG4gICAgfVxuICAgIHBvc3RNYXAodGFnKSB7XG4gICAgICAgIGlmICh0YWcuaWQgPT09ICdSQVRJTkcnKSB7XG4gICAgICAgICAgICAvLyBUaGUgd2F5IFdpbmFtcCA1LjY2NiBhc3NpZ25zIHJhdGluZ1xuICAgICAgICAgICAgdGFnLnZhbHVlID0gVm9yYmlzVGFnTWFwcGVyLnRvUmF0aW5nKHVuZGVmaW5lZCwgdGFnLnZhbHVlLCAxMDApO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRhZy5pZC5pbmRleE9mKCdSQVRJTkc6JykgPT09IDApIHtcbiAgICAgICAgICAgIGNvbnN0IGtleXMgPSB0YWcuaWQuc3BsaXQoJzonLCAyKTtcbiAgICAgICAgICAgIHRhZy52YWx1ZSA9IFZvcmJpc1RhZ01hcHBlci50b1JhdGluZyhrZXlzWzFdLCB0YWcudmFsdWUsIDEpO1xuICAgICAgICAgICAgdGFnLmlkID0ga2V5c1swXTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbW1vblRhZ01hcHBlciB9IGZyb20gJy4uL2NvbW1vbi9HZW5lcmljVGFnTWFwcGVyLmpzJztcbi8qKlxuICogUklGRiBJbmZvIFRhZ3M7IHBhcnQgb2YgdGhlIEVYSUYgMi4zXG4gKiBSZWY6IGh0dHA6Ly9vd2wucGh5LnF1ZWVuc3UuY2EvfnBoaWwvZXhpZnRvb2wvVGFnTmFtZXMvUklGRi5odG1sI0luZm9cbiAqL1xuZXhwb3J0IGNvbnN0IHJpZmZJbmZvVGFnTWFwID0ge1xuICAgIElBUlQ6ICdhcnRpc3QnLCAvLyBBcnRpc3RcbiAgICBJQ1JEOiAnZGF0ZScsIC8vIERhdGVDcmVhdGVkXG4gICAgSU5BTTogJ3RpdGxlJywgLy8gVGl0bGVcbiAgICBUSVRMOiAndGl0bGUnLFxuICAgIElQUkQ6ICdhbGJ1bScsIC8vIFByb2R1Y3RcbiAgICBJVFJLOiAndHJhY2snLFxuICAgIElQUlQ6ICd0cmFjaycsIC8vIEFkZGl0aW9uYWwgdGFnIGZvciB0cmFjayBpbmRleFxuICAgIENPTU06ICdjb21tZW50JywgLy8gQ29tbWVudHNcbiAgICBJQ01UOiAnY29tbWVudCcsIC8vIENvdW50cnlcbiAgICBJQ09QOiAnY29weXJpZ2h0JyxcbiAgICBJQ05UOiAncmVsZWFzZWNvdW50cnknLFxuICAgIEdOUkU6ICdnZW5yZScsIC8vIEdlbnJlXG4gICAgSVdSSTogJ3dyaXRlcicsIC8vIFdyaXR0ZW5CeVxuICAgIFJBVEU6ICdyYXRpbmcnLFxuICAgIFlFQVI6ICd5ZWFyJyxcbiAgICBJU0ZUOiAnZW5jb2RlZGJ5JywgLy8gU29mdHdhcmVcbiAgICBDT0RFOiAnZW5jb2RlZGJ5JywgLy8gRW5jb2RlZEJ5XG4gICAgVFVSTDogJ3dlYnNpdGUnLCAvLyBVUkwsXG4gICAgSUdOUjogJ2dlbnJlJywgLy8gR2VucmVcbiAgICBJRU5HOiAnZW5naW5lZXInLCAvLyBFbmdpbmVlclxuICAgIElUQ0g6ICd0ZWNobmljaWFuJywgLy8gVGVjaG5pY2lhblxuICAgIElNRUQ6ICdtZWRpYScsIC8vIE9yaWdpbmFsIE1lZGlhXG4gICAgSVJQRDogJ2FsYnVtJyAvLyBQcm9kdWN0LCB3aGVyZSB0aGUgZmlsZSB3YXMgaW50ZW5kZWQgZm9yXG59O1xuZXhwb3J0IGNsYXNzIFJpZmZJbmZvVGFnTWFwcGVyIGV4dGVuZHMgQ29tbW9uVGFnTWFwcGVyIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoWydleGlmJ10sIHJpZmZJbmZvVGFnTWFwKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBBaWZmVGFnTWFwcGVyIH0gZnJvbSAnLi4vYWlmZi9BaWZmVGFnTWFwLmpzJztcbmltcG9ydCB7IEFQRXYyVGFnTWFwcGVyIH0gZnJvbSAnLi4vYXBldjIvQVBFdjJUYWdNYXBwZXIuanMnO1xuaW1wb3J0IHsgQXNmVGFnTWFwcGVyIH0gZnJvbSAnLi4vYXNmL0FzZlRhZ01hcHBlci5qcyc7XG5pbXBvcnQgeyBDYWZUYWdNYXBwZXIgfSBmcm9tICcuLi9jYWYvQ2FmVGFnTWFwLmpzJztcbmltcG9ydCB7IElEM3YxVGFnTWFwcGVyIH0gZnJvbSAnLi4vaWQzdjEvSUQzdjFUYWdNYXAuanMnO1xuaW1wb3J0IHsgSUQzdjIyVGFnTWFwcGVyIH0gZnJvbSAnLi4vaWQzdjIvSUQzdjIyVGFnTWFwcGVyLmpzJztcbmltcG9ydCB7IElEM3YyNFRhZ01hcHBlciB9IGZyb20gJy4uL2lkM3YyL0lEM3YyNFRhZ01hcHBlci5qcyc7XG5pbXBvcnQgeyBNYXRyb3NrYVRhZ01hcHBlciB9IGZyb20gJy4uL21hdHJvc2thL01hdHJvc2thVGFnTWFwcGVyLmpzJztcbmltcG9ydCB7IE1QNFRhZ01hcHBlciB9IGZyb20gJy4uL21wNC9NUDRUYWdNYXBwZXIuanMnO1xuaW1wb3J0IHsgVm9yYmlzVGFnTWFwcGVyIH0gZnJvbSAnLi4vb2dnL3ZvcmJpcy9Wb3JiaXNUYWdNYXBwZXIuanMnO1xuaW1wb3J0IHsgSW50ZXJuYWxQYXJzZXJFcnJvciB9IGZyb20gJy4uL1BhcnNlRXJyb3IuanMnO1xuaW1wb3J0IHsgUmlmZkluZm9UYWdNYXBwZXIgfSBmcm9tICcuLi9yaWZmL1JpZmZJbmZvVGFnTWFwLmpzJztcbmV4cG9ydCBjbGFzcyBDb21iaW5lZFRhZ01hcHBlciB7XG4gICAgdGFnTWFwcGVycyA9IHt9O1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBbXG4gICAgICAgICAgICBuZXcgSUQzdjFUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBJRDN2MjJUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBJRDN2MjRUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBNUDRUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBWb3JiaXNUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBBUEV2MlRhZ01hcHBlcigpLFxuICAgICAgICAgICAgbmV3IEFzZlRhZ01hcHBlcigpLFxuICAgICAgICAgICAgbmV3IFJpZmZJbmZvVGFnTWFwcGVyKCksXG4gICAgICAgICAgICBuZXcgTWF0cm9za2FUYWdNYXBwZXIoKSxcbiAgICAgICAgICAgIG5ldyBBaWZmVGFnTWFwcGVyKCksXG4gICAgICAgICAgICBuZXcgQ2FmVGFnTWFwcGVyKClcbiAgICAgICAgXS5mb3JFYWNoKG1hcHBlciA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyVGFnTWFwcGVyKG1hcHBlcik7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0IG5hdGl2ZSB0byBnZW5lcmljIChjb21tb24pIHRhZ3NcbiAgICAgKiBAcGFyYW0gdGFnVHlwZSBPcmlnaW5hdGluZyB0YWcgZm9ybWF0XG4gICAgICogQHBhcmFtIHRhZyAgICAgTmF0aXZlIHRhZyB0byBtYXAgdG8gYSBnZW5lcmljIHRhZyBpZFxuICAgICAqIEBwYXJhbSB3YXJuaW5nc1xuICAgICAqIEByZXR1cm4gR2VuZXJpYyB0YWcgcmVzdWx0IChvdXRwdXQgb2YgdGhpcyBmdW5jdGlvbilcbiAgICAgKi9cbiAgICBtYXBUYWcodGFnVHlwZSwgdGFnLCB3YXJuaW5ncykge1xuICAgICAgICBjb25zdCB0YWdNYXBwZXIgPSB0aGlzLnRhZ01hcHBlcnNbdGFnVHlwZV07XG4gICAgICAgIGlmICh0YWdNYXBwZXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRhZ01hcHBlcnNbdGFnVHlwZV0ubWFwR2VuZXJpY1RhZyh0YWcsIHdhcm5pbmdzKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgSW50ZXJuYWxQYXJzZXJFcnJvcihgTm8gZ2VuZXJpYyB0YWcgbWFwcGVyIGRlZmluZWQgZm9yIHRhZy1mb3JtYXQ6ICR7dGFnVHlwZX1gKTtcbiAgICB9XG4gICAgcmVnaXN0ZXJUYWdNYXBwZXIoZ2VuZXJpY1RhZ01hcHBlcikge1xuICAgICAgICBmb3IgKGNvbnN0IHRhZ1R5cGUgb2YgZ2VuZXJpY1RhZ01hcHBlci50YWdUeXBlcykge1xuICAgICAgICAgICAgdGhpcy50YWdNYXBwZXJzW3RhZ1R5cGVdID0gZ2VuZXJpY1RhZ01hcHBlcjtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImNvbnN0IGRlZmF1bHRUYWdJbmZvID0ge1xuICAgIG11bHRpcGxlOiBmYWxzZVxufTtcbmNvbnN0IGNvbW1vblRhZ3MgPSB7XG4gICAgeWVhcjogZGVmYXVsdFRhZ0luZm8sXG4gICAgdHJhY2s6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2s6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHRpdGxlOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBhcnRpc3Q6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGFydGlzdHM6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIGFsYnVtYXJ0aXN0OiBkZWZhdWx0VGFnSW5mbyxcbiAgICBhbGJ1bWFydGlzdHM6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIGFsYnVtOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBkYXRlOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBvcmlnaW5hbGRhdGU6IGRlZmF1bHRUYWdJbmZvLFxuICAgIG9yaWdpbmFseWVhcjogZGVmYXVsdFRhZ0luZm8sXG4gICAgcmVsZWFzZWRhdGU6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGNvbW1lbnQ6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogZmFsc2UgfSxcbiAgICBnZW5yZTogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgcGljdHVyZTogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgY29tcG9zZXI6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIGx5cmljczogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiBmYWxzZSB9LFxuICAgIGFsYnVtc29ydDogeyBtdWx0aXBsZTogZmFsc2UsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIHRpdGxlc29ydDogeyBtdWx0aXBsZTogZmFsc2UsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIHdvcms6IHsgbXVsdGlwbGU6IGZhbHNlLCB1bmlxdWU6IHRydWUgfSxcbiAgICBhcnRpc3Rzb3J0OiB7IG11bHRpcGxlOiBmYWxzZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgYWxidW1hcnRpc3Rzb3J0OiB7IG11bHRpcGxlOiBmYWxzZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgY29tcG9zZXJzb3J0OiB7IG11bHRpcGxlOiBmYWxzZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgbHlyaWNpc3Q6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIHdyaXRlcjogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgY29uZHVjdG9yOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICByZW1peGVyOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICBhcnJhbmdlcjogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgZW5naW5lZXI6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIHByb2R1Y2VyOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICB0ZWNobmljaWFuOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICBkam1peGVyOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICBtaXhlcjogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiB0cnVlIH0sXG4gICAgbGFiZWw6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIGdyb3VwaW5nOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBzdWJ0aXRsZTogeyBtdWx0aXBsZTogdHJ1ZSB9LFxuICAgIGRpc2NzdWJ0aXRsZTogZGVmYXVsdFRhZ0luZm8sXG4gICAgdG90YWx0cmFja3M6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHRvdGFsZGlzY3M6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGNvbXBpbGF0aW9uOiBkZWZhdWx0VGFnSW5mbyxcbiAgICByYXRpbmc6IHsgbXVsdGlwbGU6IHRydWUgfSxcbiAgICBicG06IGRlZmF1bHRUYWdJbmZvLFxuICAgIG1vb2Q6IGRlZmF1bHRUYWdJbmZvLFxuICAgIG1lZGlhOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBjYXRhbG9nbnVtYmVyOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICB0dlNob3c6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHR2U2hvd1NvcnQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHR2U2Vhc29uOiBkZWZhdWx0VGFnSW5mbyxcbiAgICB0dkVwaXNvZGU6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHR2RXBpc29kZUlkOiBkZWZhdWx0VGFnSW5mbyxcbiAgICB0dk5ldHdvcms6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHBvZGNhc3Q6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHBvZGNhc3R1cmw6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHJlbGVhc2VzdGF0dXM6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHJlbGVhc2V0eXBlOiB7IG11bHRpcGxlOiB0cnVlIH0sXG4gICAgcmVsZWFzZWNvdW50cnk6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHNjcmlwdDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbGFuZ3VhZ2U6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGNvcHlyaWdodDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbGljZW5zZTogZGVmYXVsdFRhZ0luZm8sXG4gICAgZW5jb2RlZGJ5OiBkZWZhdWx0VGFnSW5mbyxcbiAgICBlbmNvZGVyc2V0dGluZ3M6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGdhcGxlc3M6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGJhcmNvZGU6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGlzcmM6IHsgbXVsdGlwbGU6IHRydWUgfSxcbiAgICBhc2luOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBtdXNpY2JyYWluel9yZWNvcmRpbmdpZDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbXVzaWNicmFpbnpfdHJhY2tpZDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbXVzaWNicmFpbnpfYWxidW1pZDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbXVzaWNicmFpbnpfYXJ0aXN0aWQ6IHsgbXVsdGlwbGU6IHRydWUgfSxcbiAgICBtdXNpY2JyYWluel9hbGJ1bWFydGlzdGlkOiB7IG11bHRpcGxlOiB0cnVlIH0sXG4gICAgbXVzaWNicmFpbnpfcmVsZWFzZWdyb3VwaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIG11c2ljYnJhaW56X3dvcmtpZDogZGVmYXVsdFRhZ0luZm8sXG4gICAgbXVzaWNicmFpbnpfdHJtaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIG11c2ljYnJhaW56X2Rpc2NpZDogZGVmYXVsdFRhZ0luZm8sXG4gICAgYWNvdXN0aWRfaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGFjb3VzdGlkX2ZpbmdlcnByaW50OiBkZWZhdWx0VGFnSW5mbyxcbiAgICBtdXNpY2lwX3B1aWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIG11c2ljaXBfZmluZ2VycHJpbnQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHdlYnNpdGU6IGRlZmF1bHRUYWdJbmZvLFxuICAgICdwZXJmb3JtZXI6aW5zdHJ1bWVudCc6IHsgbXVsdGlwbGU6IHRydWUsIHVuaXF1ZTogdHJ1ZSB9LFxuICAgIGF2ZXJhZ2VMZXZlbDogZGVmYXVsdFRhZ0luZm8sXG4gICAgcGVha0xldmVsOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBub3RlczogeyBtdWx0aXBsZTogdHJ1ZSwgdW5pcXVlOiBmYWxzZSB9LFxuICAgIGtleTogZGVmYXVsdFRhZ0luZm8sXG4gICAgb3JpZ2luYWxhbGJ1bTogZGVmYXVsdFRhZ0luZm8sXG4gICAgb3JpZ2luYWxhcnRpc3Q6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2NvZ3NfYXJ0aXN0X2lkOiB7IG11bHRpcGxlOiB0cnVlLCB1bmlxdWU6IHRydWUgfSxcbiAgICBkaXNjb2dzX3JlbGVhc2VfaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2NvZ3NfbGFiZWxfaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2NvZ3NfbWFzdGVyX3JlbGVhc2VfaWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2NvZ3Nfdm90ZXM6IGRlZmF1bHRUYWdJbmZvLFxuICAgIGRpc2NvZ3NfcmF0aW5nOiBkZWZhdWx0VGFnSW5mbyxcbiAgICByZXBsYXlnYWluX3RyYWNrX3BlYWs6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHJlcGxheWdhaW5fdHJhY2tfZ2FpbjogZGVmYXVsdFRhZ0luZm8sXG4gICAgcmVwbGF5Z2Fpbl9hbGJ1bV9wZWFrOiBkZWZhdWx0VGFnSW5mbyxcbiAgICByZXBsYXlnYWluX2FsYnVtX2dhaW46IGRlZmF1bHRUYWdJbmZvLFxuICAgIHJlcGxheWdhaW5fdHJhY2tfbWlubWF4OiBkZWZhdWx0VGFnSW5mbyxcbiAgICByZXBsYXlnYWluX2FsYnVtX21pbm1heDogZGVmYXVsdFRhZ0luZm8sXG4gICAgcmVwbGF5Z2Fpbl91bmRvOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBkZXNjcmlwdGlvbjogeyBtdWx0aXBsZTogdHJ1ZSB9LFxuICAgIGxvbmdEZXNjcmlwdGlvbjogZGVmYXVsdFRhZ0luZm8sXG4gICAgY2F0ZWdvcnk6IHsgbXVsdGlwbGU6IHRydWUgfSxcbiAgICBoZFZpZGVvOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBrZXl3b3JkczogeyBtdWx0aXBsZTogdHJ1ZSB9LFxuICAgIG1vdmVtZW50OiBkZWZhdWx0VGFnSW5mbyxcbiAgICBtb3ZlbWVudEluZGV4OiBkZWZhdWx0VGFnSW5mbyxcbiAgICBtb3ZlbWVudFRvdGFsOiBkZWZhdWx0VGFnSW5mbyxcbiAgICBwb2RjYXN0SWQ6IGRlZmF1bHRUYWdJbmZvLFxuICAgIHNob3dNb3ZlbWVudDogZGVmYXVsdFRhZ0luZm8sXG4gICAgc3RpazogZGVmYXVsdFRhZ0luZm8sXG4gICAgcGxheUNvdW50ZXI6IGRlZmF1bHRUYWdJbmZvXG59O1xuZXhwb3J0IGNvbnN0IGNvbW1vblRhZ3NLZXlzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5rZXlzKGNvbW1vblRhZ3MpO1xuLyoqXG4gKiBAcGFyYW0gYWxpYXMgTmFtZSBvZiBjb21tb24gdGFnXG4gKiBAcmV0dXJucyB7Ym9vbGVhbnwqfSB0cnVlIGlmIGdpdmVuIGFsaWFzIGlzIG1hcHBlZCBhcyBhIHNpbmdsZXRvbicsIG90aGVyd2lzZSBmYWxzZVxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNTaW5nbGV0b24oYWxpYXMpIHtcbiAgICByZXR1cm4gY29tbW9uVGFnc1thbGlhc10gJiYgIWNvbW1vblRhZ3NbYWxpYXNdLm11bHRpcGxlO1xufVxuLyoqXG4gKiBAcGFyYW0gYWxpYXMgQ29tbW9uIChnZW5lcmljKSB0YWdcbiAqIEByZXR1cm5zIHtib29sZWFufCp9IHRydWUgaWYgZ2l2ZW4gYWxpYXMgaXMgYSBzaW5nbGV0b24gb3IgZXhwbGljaXRseSBtYXJrZWQgYXMgdW5pcXVlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc1VuaXF1ZShhbGlhcykge1xuICAgIHJldHVybiAhY29tbW9uVGFnc1thbGlhc10ubXVsdGlwbGUgfHwgY29tbW9uVGFnc1thbGlhc10udW5pcXVlIHx8IGZhbHNlO1xufVxuIiwiaW1wb3J0IHsgVHJhY2tUeXBlIH0gZnJvbSAnLi4vdHlwZS5qcyc7XG4vKiogUmV0dXJuIGEgYml0cmF0ZSBvbmx5IHdoZW4gaXQgY29udmV5cyBhIGZpbml0ZSwgcG9zaXRpdmUgdmFsdWUuICovXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplQml0cmF0ZShiaXRyYXRlKSB7XG4gICAgcmV0dXJuIGJpdHJhdGUgIT09IHVuZGVmaW5lZCAmJiBOdW1iZXIuaXNGaW5pdGUoYml0cmF0ZSkgJiYgYml0cmF0ZSA+IDAgPyBiaXRyYXRlIDogdW5kZWZpbmVkO1xufVxuLyoqIE1hcCB0aGUgZm9ybWF0IG9mIGEgc2luZ2xlIGF1ZGlvIHN0cmVhbSB0byB0aGUgc2hhcmVkIHRyYWNrIGFic3RyYWN0aW9uLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUF1ZGlvVHJhY2tJbmZvKGZvcm1hdCkge1xuICAgIGNvbnN0IGF1ZGlvID0ge307XG4gICAgY29uc3QgdHJhY2sgPSB7IHR5cGU6IFRyYWNrVHlwZS5hdWRpbywgYXVkaW8gfTtcbiAgICBpZiAoZm9ybWF0LmNvZGVjICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdHJhY2suY29kZWNOYW1lID0gZm9ybWF0LmNvZGVjO1xuICAgIH1cbiAgICBpZiAoZm9ybWF0LmNvZGVjUHJvZmlsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRyYWNrLmNvZGVjUHJvZmlsZSA9IGZvcm1hdC5jb2RlY1Byb2ZpbGU7XG4gICAgfVxuICAgIGlmIChmb3JtYXQuZHVyYXRpb24gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0cmFjay5kdXJhdGlvbiA9IGZvcm1hdC5kdXJhdGlvbjtcbiAgICB9XG4gICAgY29uc3QgYml0cmF0ZSA9IG5vcm1hbGl6ZUJpdHJhdGUoZm9ybWF0LmJpdHJhdGUpO1xuICAgIGlmIChiaXRyYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdHJhY2suYml0cmF0ZSA9IGJpdHJhdGU7XG4gICAgfVxuICAgIGlmIChmb3JtYXQubG9zc2xlc3MgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0cmFjay5sb3NzbGVzcyA9IGZvcm1hdC5sb3NzbGVzcztcbiAgICB9XG4gICAgaWYgKGZvcm1hdC5zYW1wbGVSYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYXVkaW8uc2FtcGxpbmdGcmVxdWVuY3kgPSBmb3JtYXQuc2FtcGxlUmF0ZTtcbiAgICB9XG4gICAgaWYgKGZvcm1hdC5udW1iZXJPZkNoYW5uZWxzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYXVkaW8uY2hhbm5lbHMgPSBmb3JtYXQubnVtYmVyT2ZDaGFubmVscztcbiAgICB9XG4gICAgaWYgKGZvcm1hdC5iaXRzUGVyU2FtcGxlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYXVkaW8uYml0RGVwdGggPSBmb3JtYXQuYml0c1BlclNhbXBsZTtcbiAgICB9XG4gICAgaWYgKGZvcm1hdC5udW1iZXJPZlNhbXBsZXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBhdWRpby5udW1iZXJPZlNhbXBsZXMgPSBmb3JtYXQubnVtYmVyT2ZTYW1wbGVzO1xuICAgIH1cbiAgICByZXR1cm4gdHJhY2s7XG59XG4vKiogRGVyaXZlIHdob2xlLWZpbGUgc3RhdGlzdGljcyB3aXRob3V0IHRyZWF0aW5nIGFuIGF1ZGlvIGJpdHJhdGUgYXMgYSB2aWRlbyBiaXRyYXRlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmFsaXplQ29udGFpbmVySW5mbyhtZXRhZGF0YSwgZmlsZVNpemUpIHtcbiAgICBjb25zdCB7IGZvcm1hdCB9ID0gbWV0YWRhdGE7XG4gICAgbGV0IGR1cmF0aW9uID0gZm9ybWF0LmNvbnRhaW5lckR1cmF0aW9uO1xuICAgIGlmIChkdXJhdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGNvbnN0IGR1cmF0aW9ucyA9IGZvcm1hdC50cmFja0luZm9cbiAgICAgICAgICAgIC5maWx0ZXIodHJhY2sgPT4gdHJhY2sudHlwZSA9PT0gVHJhY2tUeXBlLmF1ZGlvIHx8IHRyYWNrLnR5cGUgPT09IFRyYWNrVHlwZS52aWRlbylcbiAgICAgICAgICAgIC5tYXAodHJhY2sgPT4gdHJhY2suZHVyYXRpb24pO1xuICAgICAgICBpZiAoZHVyYXRpb25zLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICAgIGR1cmF0aW9ucy5ldmVyeSgoZHVyYXRpb24pID0+IGR1cmF0aW9uICE9PSB1bmRlZmluZWQgJiYgZHVyYXRpb24gPiAwICYmIE51bWJlci5pc0Zpbml0ZShkdXJhdGlvbikpKSB7XG4gICAgICAgICAgICBkdXJhdGlvbiA9IGR1cmF0aW9ucy5yZWR1Y2UoKG1heGltdW0sIHRyYWNrRHVyYXRpb24pID0+IE1hdGgubWF4KG1heGltdW0sIHRyYWNrRHVyYXRpb24pLCAwKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICghZm9ybWF0Lmhhc1ZpZGVvKSB7XG4gICAgICAgICAgICBkdXJhdGlvbiA9IGZvcm1hdC5kdXJhdGlvbjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoZHVyYXRpb24gIT09IHVuZGVmaW5lZCAmJiBOdW1iZXIuaXNGaW5pdGUoZHVyYXRpb24pICYmIGR1cmF0aW9uID4gMCkge1xuICAgICAgICBtZXRhZGF0YS5zZXRGb3JtYXQoJ2NvbnRhaW5lckR1cmF0aW9uJywgZHVyYXRpb24pO1xuICAgICAgICBpZiAoZm9ybWF0LmR1cmF0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIG1ldGFkYXRhLnNldEZvcm1hdCgnZHVyYXRpb24nLCBkdXJhdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZpbGVTaXplICE9PSB1bmRlZmluZWQgJiYgTnVtYmVyLmlzU2FmZUludGVnZXIoZmlsZVNpemUpICYmIGZpbGVTaXplID4gMCkge1xuICAgICAgICAgICAgY29uc3QgYml0cmF0ZSA9ICg4ICogZmlsZVNpemUpIC8gZHVyYXRpb247XG4gICAgICAgICAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGJpdHJhdGUpKSB7XG4gICAgICAgICAgICAgICAgbWV0YWRhdGEuc2V0Rm9ybWF0KCdvdmVyYWxsQml0cmF0ZScsIGJpdHJhdGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IGluaXREZWJ1ZyBmcm9tICdkZWJ1Zyc7XG5pbXBvcnQgeyBmaWxlVHlwZUZyb21CdWZmZXIgfSBmcm9tICdmaWxlLXR5cGUnO1xuaW1wb3J0IHsgcGFyc2VMeXJpY3MgfSBmcm9tICcuLi9scmMvTHlyaWNzUGFyc2VyLmpzJztcbmltcG9ydCB7IFRyYWNrVHlwZVZhbHVlVG9LZXlNYXAgfSBmcm9tICcuLi90eXBlLmpzJztcbmltcG9ydCB7IGdldE1heE1lbW9yeUFsbG9jYXRpb24sIGdldE1heE1ldGFkYXRhRW50cmllcyB9IGZyb20gJy4vQWxsb2NhdGlvbi5qcyc7XG5pbXBvcnQgeyBDb21iaW5lZFRhZ01hcHBlciB9IGZyb20gJy4vQ29tYmluZWRUYWdNYXBwZXIuanMnO1xuaW1wb3J0IHsgQ29tbW9uVGFnTWFwcGVyIH0gZnJvbSAnLi9HZW5lcmljVGFnTWFwcGVyLmpzJztcbmltcG9ydCB7IGlzU2luZ2xldG9uLCBpc1VuaXF1ZSB9IGZyb20gJy4vR2VuZXJpY1RhZ1R5cGVzLmpzJztcbmltcG9ydCB7IG5vcm1hbGl6ZUJpdHJhdGUgfSBmcm9tICcuL1RyYWNrSW5mby5qcyc7XG5pbXBvcnQgeyB0b1JhdGlvIH0gZnJvbSAnLi9VdGlsLmpzJztcbmNvbnN0IGRlYnVnID0gaW5pdERlYnVnKCdtdXNpYy1tZXRhZGF0YTpjb2xsZWN0b3InKTtcbmNvbnN0IFRhZ1ByaW9yaXR5ID0gW1xuICAgICdtYXRyb3NrYScsXG4gICAgJ0FQRXYyJyxcbiAgICAndm9yYmlzJyxcbiAgICAnSUQzdjIuNCcsXG4gICAgJ0lEM3YyLjMnLFxuICAgICdJRDN2Mi4yJyxcbiAgICAnZXhpZicsXG4gICAgJ2FzZicsXG4gICAgJ2lUdW5lcycsXG4gICAgJ0FJRkYnLFxuICAgICdDQUYnLFxuICAgICdJRDN2MSdcbl07XG4vKipcbiAqIFByb3ZpZGVkIHRvIHRoZSBwYXJzZXIgdG8gdXBkYXRlIHRoZSBtZXRhZGF0YSByZXN1bHQuXG4gKiBSZXNwb25zaWJsZSBmb3Igbm90aWZ5aW5nIG9ic2VydmVycyBzeW5jaHJvbm91c2x5IGFmdGVyIHVwZGF0ZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBNZXRhZGF0YUNvbGxlY3RvciB7XG4gICAgZm9ybWF0ID0ge1xuICAgICAgICB0YWdUeXBlczogW10sXG4gICAgICAgIHRyYWNrSW5mbzogW11cbiAgICB9O1xuICAgIG5hdGl2ZSA9IHt9O1xuICAgIGNvbW1vbiA9IHtcbiAgICAgICAgdHJhY2s6IHsgbm86IG51bGwsIG9mOiBudWxsIH0sXG4gICAgICAgIGRpc2s6IHsgbm86IG51bGwsIG9mOiBudWxsIH0sXG4gICAgICAgIG1vdmVtZW50SW5kZXg6IHsgbm86IG51bGwsIG9mOiBudWxsIH1cbiAgICB9O1xuICAgIHF1YWxpdHkgPSB7XG4gICAgICAgIHdhcm5pbmdzOiBbXVxuICAgIH07XG4gICAgLyoqXG4gICAgICogS2VlcHMgdHJhY2sgb2Ygb3JpZ2luIHByaW9yaXR5IGZvciBlYWNoIG1hcHBlZCBpZFxuICAgICAqL1xuICAgIGNvbW1vbk9yaWdpbiA9IHt9O1xuICAgIC8qKlxuICAgICAqIE1hcHMgYSB0YWcgdHlwZSB0byBhIHByaW9yaXR5XG4gICAgICovXG4gICAgb3JpZ2luUHJpb3JpdHkgPSB7fTtcbiAgICB0YWdNYXBwZXIgPSBuZXcgQ29tYmluZWRUYWdNYXBwZXIoKTtcbiAgICBvcHRzO1xuICAgIGNvbnN0cnVjdG9yKG9wdHMpIHtcbiAgICAgICAgdGhpcy5vcHRzID0gb3B0cztcbiAgICAgICAgbGV0IHByaW9yaXR5ID0gMTtcbiAgICAgICAgZm9yIChjb25zdCB0YWdUeXBlIG9mIFRhZ1ByaW9yaXR5KSB7XG4gICAgICAgICAgICB0aGlzLm9yaWdpblByaW9yaXR5W3RhZ1R5cGVdID0gcHJpb3JpdHkrKztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm9yaWdpblByaW9yaXR5LmFydGlmaWNpYWwgPSA1MDA7IC8vIEZpbGxlZCB1c2luZyBhbHRlcm5hdGl2ZSB0YWdzXG4gICAgICAgIHRoaXMub3JpZ2luUHJpb3JpdHkuaWQzdjEgPSA2MDA7IC8vIENvbnNpZGVyIGFzIHRoZSB3b3JzdCBiZWNhdXNlIG9mIHRoZSBmaWVsZCBsZW5ndGggbGltaXRcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHJldHVybnMge2Jvb2xlYW59IHRydWUgaWYgb25lIG9yIG1vcmUgdGFncyBoYXZlIGJlZW4gZm91bmRcbiAgICAgKi9cbiAgICBoYXNBbnkoKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLm5hdGl2ZSkubGVuZ3RoID4gMDtcbiAgICB9XG4gICAgYWRkU3RyZWFtSW5mbyhzdHJlYW1JbmZvKSB7XG4gICAgICAgIGRlYnVnKGBzdHJlYW1JbmZvOiB0eXBlPSR7c3RyZWFtSW5mby50eXBlID8gVHJhY2tUeXBlVmFsdWVUb0tleU1hcFtzdHJlYW1JbmZvLnR5cGVdIDogJz8nfSwgY29kZWM9JHtzdHJlYW1JbmZvLmNvZGVjTmFtZX1gKTtcbiAgICAgICAgaWYgKG5vcm1hbGl6ZUJpdHJhdGUoc3RyZWFtSW5mby5iaXRyYXRlKSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBkZWxldGUgc3RyZWFtSW5mby5iaXRyYXRlO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZm9ybWF0LnRyYWNrSW5mby5wdXNoKHN0cmVhbUluZm8pO1xuICAgIH1cbiAgICBzZXRGb3JtYXQoa2V5LCB2YWx1ZSkge1xuICAgICAgICAvLyBPYmplY3RzIG1heSBoYXZlIGJlZW4gbXV0YXRlZCBpbiBwbGFjZSwgc28gb25seSBza2lwIHVuY2hhbmdlZCBwcmltaXRpdmVzLlxuICAgICAgICBpZiAoKHZhbHVlID09PSBudWxsIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpICYmIE9iamVjdC5pcyh0aGlzLmZvcm1hdFtrZXldLCB2YWx1ZSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBkZWJ1ZyhgZm9ybWF0OiAke2tleX0gPSAke3ZhbHVlfWApO1xuICAgICAgICAvLyBBbGxvdyBpbnRlcm5hbCB3cml0ZXMgd2hpbGUgcHJlc2VydmluZyBlYWNoIHByb3BlcnR5J3MgdmFsdWUgdHlwZS5cbiAgICAgICAgdGhpcy5mb3JtYXRba2V5XSA9IHZhbHVlO1xuICAgICAgICBpZiAodGhpcy5vcHRzPy5vYnNlcnZlcikge1xuICAgICAgICAgICAgdGhpcy5vcHRzLm9ic2VydmVyKHsgbWV0YWRhdGE6IHRoaXMsIHRhZzogeyB0eXBlOiAnZm9ybWF0JywgaWQ6IGtleSwgdmFsdWUgfSB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXRBdWRpb09ubHkoKSB7XG4gICAgICAgIHRoaXMuc2V0Rm9ybWF0KCdoYXNBdWRpbycsIHRydWUpO1xuICAgICAgICB0aGlzLnNldEZvcm1hdCgnaGFzVmlkZW8nLCBmYWxzZSk7XG4gICAgfVxuICAgIHJlZ2lzdGVyVGFnVHlwZSh0YWdUeXBlKSB7XG4gICAgICAgIGlmICghdGhpcy5mb3JtYXQudGFnVHlwZXMuaW5jbHVkZXModGFnVHlwZSkpIHtcbiAgICAgICAgICAgIHRoaXMuZm9ybWF0LnRhZ1R5cGVzLnB1c2godGFnVHlwZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgYWRkVGFnKHRhZ1R5cGUsIHRhZ0lkLCB2YWx1ZSkge1xuICAgICAgICBkZWJ1ZygndGFnICVzLiVzID0gJW8nLCB0YWdUeXBlLCB0YWdJZCwgdmFsdWUpO1xuICAgICAgICBpZiAoIXRoaXMubmF0aXZlW3RhZ1R5cGVdKSB7XG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyVGFnVHlwZSh0YWdUeXBlKTtcbiAgICAgICAgICAgIHRoaXMubmF0aXZlW3RhZ1R5cGVdID0gW107XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5uYXRpdmVbdGFnVHlwZV0ucHVzaCh7IGlkOiB0YWdJZCwgdmFsdWUgfSk7XG4gICAgICAgIGF3YWl0IHRoaXMudG9Db21tb24odGFnVHlwZSwgdGFnSWQsIHZhbHVlKTtcbiAgICB9XG4gICAgYWRkV2FybmluZyh3YXJuaW5nKSB7XG4gICAgICAgIHRoaXMucXVhbGl0eS53YXJuaW5ncy5wdXNoKHsgbWVzc2FnZTogd2FybmluZyB9KTtcbiAgICB9XG4gICAgYXN5bmMgcG9zdE1hcCh0YWdUeXBlLCB0YWcpIHtcbiAgICAgICAgLy8gQ29tbW9uIHRhZyAoYWxpYXMpIGZvdW5kXG4gICAgICAgIC8vIGNoZWNrIGlmIHdlIG5lZWQgdG8gZG8gc29tZXRoaW5nIHNwZWNpYWwgd2l0aCBjb21tb24gdGFnXG4gICAgICAgIC8vIGlmIHRoZSBldmVudCBoYXMgYmVlbiBhbGlhc2VkIHRoZW4gd2UgbmVlZCB0byBjbGVhbiBpdCBiZWZvcmVcbiAgICAgICAgLy8gaXQgaXMgZW1pdHRlZCB0byB0aGUgdXNlci4gZS5nLiBnZW5yZSAoMjApIC0+IEVsZWN0cm9uaWNcbiAgICAgICAgc3dpdGNoICh0YWcuaWQpIHtcbiAgICAgICAgICAgIGNhc2UgJ2FydGlzdCc6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlU2luZ3VsYXJBcnRpc3RUYWcodGFnVHlwZSwgdGFnLCAnYXJ0aXN0JywgJ2FydGlzdHMnKTtcbiAgICAgICAgICAgIGNhc2UgJ2FsYnVtYXJ0aXN0JzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVTaW5ndWxhckFydGlzdFRhZyh0YWdUeXBlLCB0YWcsICdhbGJ1bWFydGlzdCcsICdhbGJ1bWFydGlzdHMnKTtcbiAgICAgICAgICAgIGNhc2UgJ2FydGlzdHMnOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVBsdXJhbEFydGlzdFRhZyh0YWdUeXBlLCB0YWcsICdhcnRpc3QnLCAnYXJ0aXN0cycpO1xuICAgICAgICAgICAgY2FzZSAnYWxidW1hcnRpc3RzJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVQbHVyYWxBcnRpc3RUYWcodGFnVHlwZSwgdGFnLCAnYWxidW1hcnRpc3QnLCAnYWxidW1hcnRpc3RzJyk7XG4gICAgICAgICAgICBjYXNlICdwaWN0dXJlJzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5wb3N0Rml4UGljdHVyZSh0YWcudmFsdWUpLnRoZW4ocGljdHVyZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwaWN0dXJlICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSBwaWN0dXJlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKHRhZ1R5cGUsIHRhZyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNhc2UgJ3RvdGFsdHJhY2tzJzpcbiAgICAgICAgICAgICAgICB0aGlzLmNvbW1vbi50cmFjay5vZiA9IENvbW1vblRhZ01hcHBlci50b0ludE9yTnVsbCh0YWcudmFsdWUpO1xuICAgICAgICAgICAgICAgIHRoaXMubm90aWZ5Q29tbW9uVGFnKHsgaWQ6ICd0cmFjaycsIHZhbHVlOiB7IC4uLnRoaXMuY29tbW9uLnRyYWNrIH0gfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgY2FzZSAndG90YWxkaXNjcyc6XG4gICAgICAgICAgICAgICAgdGhpcy5jb21tb24uZGlzay5vZiA9IENvbW1vblRhZ01hcHBlci50b0ludE9yTnVsbCh0YWcudmFsdWUpO1xuICAgICAgICAgICAgICAgIHRoaXMubm90aWZ5Q29tbW9uVGFnKHsgaWQ6ICdkaXNrJywgdmFsdWU6IHsgLi4udGhpcy5jb21tb24uZGlzayB9IH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGNhc2UgJ21vdmVtZW50VG90YWwnOlxuICAgICAgICAgICAgICAgIHRoaXMuY29tbW9uLm1vdmVtZW50SW5kZXgub2YgPSBDb21tb25UYWdNYXBwZXIudG9JbnRPck51bGwodGFnLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB0aGlzLm5vdGlmeUNvbW1vblRhZyh7IGlkOiAnbW92ZW1lbnRJbmRleCcsIHZhbHVlOiB7IC4uLnRoaXMuY29tbW9uLm1vdmVtZW50SW5kZXggfSB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBjYXNlICd0cmFjayc6XG4gICAgICAgICAgICBjYXNlICdkaXNrJzpcbiAgICAgICAgICAgIGNhc2UgJ21vdmVtZW50SW5kZXgnOiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2YgPSB0aGlzLmNvbW1vblt0YWcuaWRdLm9mOyAvLyBzdG9yZSBvZiB2YWx1ZSwgbWF5YmUgbWF5YmUgb3ZlcndyaXR0ZW5cbiAgICAgICAgICAgICAgICB0aGlzLmNvbW1vblt0YWcuaWRdID0gQ29tbW9uVGFnTWFwcGVyLm5vcm1hbGl6ZVRyYWNrKHRhZy52YWx1ZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21tb25bdGFnLmlkXS5vZiA9IG9mICE9IG51bGwgPyBvZiA6IHRoaXMuY29tbW9uW3RhZy5pZF0ub2Y7XG4gICAgICAgICAgICAgICAgdGhpcy5ub3RpZnlDb21tb25UYWcoeyBpZDogdGFnLmlkLCB2YWx1ZTogeyAuLi50aGlzLmNvbW1vblt0YWcuaWRdIH0gfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnYnBtJzpcbiAgICAgICAgICAgIGNhc2UgJ3llYXInOlxuICAgICAgICAgICAgY2FzZSAnb3JpZ2luYWx5ZWFyJzpcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSBOdW1iZXIucGFyc2VJbnQodGFnLnZhbHVlLCAxMCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdkYXRlJzoge1xuICAgICAgICAgICAgICAgIC8vIFRvRG86IGJlIG1vcmUgc3RyaWN0IG9uICdZWVlZLi4uJ1xuICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSBOdW1iZXIucGFyc2VJbnQodGFnLnZhbHVlLnN1YnN0cigwLCA0KSwgMTApO1xuICAgICAgICAgICAgICAgIGlmICghTnVtYmVyLmlzTmFOKHllYXIpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tbW9uLnllYXIgPSB5ZWFyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ2Rpc2NvZ3NfbGFiZWxfaWQnOlxuICAgICAgICAgICAgY2FzZSAnZGlzY29nc19yZWxlYXNlX2lkJzpcbiAgICAgICAgICAgIGNhc2UgJ2Rpc2NvZ3NfbWFzdGVyX3JlbGVhc2VfaWQnOlxuICAgICAgICAgICAgY2FzZSAnZGlzY29nc19hcnRpc3RfaWQnOlxuICAgICAgICAgICAgY2FzZSAnZGlzY29nc192b3Rlcyc6XG4gICAgICAgICAgICAgICAgdGFnLnZhbHVlID0gdHlwZW9mIHRhZy52YWx1ZSA9PT0gJ3N0cmluZycgPyBOdW1iZXIucGFyc2VJbnQodGFnLnZhbHVlLCAxMCkgOiB0YWcudmFsdWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdyZXBsYXlnYWluX3RyYWNrX2dhaW4nOlxuICAgICAgICAgICAgY2FzZSAncmVwbGF5Z2Fpbl90cmFja19wZWFrJzpcbiAgICAgICAgICAgIGNhc2UgJ3JlcGxheWdhaW5fYWxidW1fZ2Fpbic6XG4gICAgICAgICAgICBjYXNlICdyZXBsYXlnYWluX2FsYnVtX3BlYWsnOlxuICAgICAgICAgICAgICAgIHRhZy52YWx1ZSA9IHRvUmF0aW8odGFnLnZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JlcGxheWdhaW5fdHJhY2tfbWlubWF4JzpcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSB0YWcudmFsdWUuc3BsaXQoJywnLCAyKS5tYXAodiA9PiBOdW1iZXIucGFyc2VJbnQodiwgMTApKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JlcGxheWdhaW5fdW5kbyc6IHtcbiAgICAgICAgICAgICAgICBjb25zdCBtaW5NaXggPSB0YWcudmFsdWUuc3BsaXQoJywnLCAyKS5tYXAodiA9PiBOdW1iZXIucGFyc2VJbnQodiwgMTApKTtcbiAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSB7XG4gICAgICAgICAgICAgICAgICAgIGxlZnRDaGFubmVsOiBtaW5NaXhbMF0sXG4gICAgICAgICAgICAgICAgICAgIHJpZ2h0Q2hhbm5lbDogbWluTWl4WzFdXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ2dhcGxlc3MnOiAvLyBpVHVuZXMgZ2FwLWxlc3MgZmxhZ1xuICAgICAgICAgICAgY2FzZSAnY29tcGlsYXRpb24nOlxuICAgICAgICAgICAgY2FzZSAncG9kY2FzdCc6XG4gICAgICAgICAgICBjYXNlICdzaG93TW92ZW1lbnQnOlxuICAgICAgICAgICAgICAgIHRhZy52YWx1ZSA9IHRhZy52YWx1ZSA9PT0gJzEnIHx8IHRhZy52YWx1ZSA9PT0gMSB8fCB0YWcudmFsdWUgPT09IHRydWU7IC8vIGJvb2xlYW5cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ2lzcmMnOiB7XG4gICAgICAgICAgICAgICAgLy8gT25seSBrZWVwIHVuaXF1ZSB2YWx1ZXNcbiAgICAgICAgICAgICAgICBjb25zdCBjb21tb25UYWcgPSB0aGlzLmNvbW1vblt0YWcuaWRdO1xuICAgICAgICAgICAgICAgIGlmIChjb21tb25UYWcgJiYgY29tbW9uVGFnLmluZGV4T2YodGFnLnZhbHVlKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgJ2NvbW1lbnQnOlxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGFnLnZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgICAgICB0YWcudmFsdWUgPSB7IHRleHQ6IHRhZy52YWx1ZSB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodGFnLnZhbHVlLmRlc2NyaXB0b3IgPT09ICdpVHVuUEdBUCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKHRhZ1R5cGUsIHsgaWQ6ICdnYXBsZXNzJywgdmFsdWU6IHRhZy52YWx1ZS50ZXh0ID09PSAnMScgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnbHlyaWNzJzpcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRhZy52YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFnLnZhbHVlID0gcGFyc2VMeXJpY3ModGFnLnZhbHVlLCBnZXRNYXhNZXRhZGF0YUVudHJpZXModGhpcy5vcHRzID8/IHt9KSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIC8vIG5vdGhpbmcgdG8gZG9cbiAgICAgICAgfVxuICAgICAgICBpZiAodGFnLnZhbHVlICE9PSBudWxsKSB7XG4gICAgICAgICAgICB0aGlzLnNldEdlbmVyaWNUYWcodGFnVHlwZSwgdGFnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb252ZXJ0IG5hdGl2ZSB0YWdzIHRvIGNvbW1vbiB0YWdzXG4gICAgICogQHJldHVybnMge0lBdWRpb01ldGFkYXRhfSBOYXRpdmUgKyBjb21tb24gdGFnc1xuICAgICAqL1xuICAgIHRvQ29tbW9uTWV0YWRhdGEoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBmb3JtYXQ6IHRoaXMuZm9ybWF0LFxuICAgICAgICAgICAgbmF0aXZlOiB0aGlzLm5hdGl2ZSxcbiAgICAgICAgICAgIHF1YWxpdHk6IHRoaXMucXVhbGl0eSxcbiAgICAgICAgICAgIGNvbW1vbjogdGhpcy5jb21tb25cbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogSGFuZGxlIHNpbmd1bGFyIGFydGlzdCB0YWdzIChhcnRpc3QsIGFsYnVtYXJ0aXN0KSBhbmQgY3Jvc3MtcG9wdWxhdGUgdG8gcGx1cmFsIGZvcm1cbiAgICAgKi9cbiAgICBoYW5kbGVTaW5ndWxhckFydGlzdFRhZyh0YWdUeXBlLCB0YWcsIHNpbmd1bGFySWQsIHBsdXJhbElkKSB7XG4gICAgICAgIGlmICh0aGlzLmNvbW1vbk9yaWdpbltzaW5ndWxhcklkXSA9PT0gdGhpcy5vcmlnaW5Qcmlvcml0eVt0YWdUeXBlXSkge1xuICAgICAgICAgICAgLy8gQXNzdW1lIHRoZSBzaW5ndWxhciBmaWVsZCBpcyB1c2VkIGFzIHBsdXJhbCAobXVsdGlwbGUgdmFsdWVzIGZyb20gc2FtZSBzb3VyY2UpXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5wb3N0TWFwKCdhcnRpZmljaWFsJywgeyBpZDogcGx1cmFsSWQsIHZhbHVlOiB0YWcudmFsdWUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLmNvbW1vbltwbHVyYWxJZF0pIHtcbiAgICAgICAgICAgIC8vIEZpbGwgcGx1cmFsIHVzaW5nIHNpbmd1bGFyIHNvdXJjZVxuICAgICAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKCdhcnRpZmljaWFsJywgeyBpZDogcGx1cmFsSWQsIHZhbHVlOiB0YWcudmFsdWUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKHRhZ1R5cGUsIHRhZyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEhhbmRsZSBwbHVyYWwgYXJ0aXN0IHRhZ3MgKGFydGlzdHMsIGFsYnVtYXJ0aXN0cykgYW5kIGNyb3NzLXBvcHVsYXRlIHRvIHNpbmd1bGFyIGZvcm1cbiAgICAgKi9cbiAgICBoYW5kbGVQbHVyYWxBcnRpc3RUYWcodGFnVHlwZSwgdGFnLCBzaW5ndWxhcklkLCBwbHVyYWxJZCkge1xuICAgICAgICBpZiAoIXRoaXMuY29tbW9uW3Npbmd1bGFySWRdIHx8IHRoaXMuY29tbW9uT3JpZ2luW3Npbmd1bGFySWRdID09PSB0aGlzLm9yaWdpblByaW9yaXR5LmFydGlmaWNpYWwpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5jb21tb25bcGx1cmFsSWRdIHx8IHRoaXMuY29tbW9uW3BsdXJhbElkXS5pbmRleE9mKHRhZy52YWx1ZSkgPT09IC0xKSB7XG4gICAgICAgICAgICAgICAgLy8gRmlsbCBzaW5ndWxhciB1c2luZyBwbHVyYWwgc291cmNlXG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gKHRoaXMuY29tbW9uW3BsdXJhbElkXSB8fCBbXSkuY29uY2F0KFt0YWcudmFsdWVdKTtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGpvaW5BcnRpc3RzKHZhbHVlcyk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKCdhcnRpZmljaWFsJywgeyBpZDogc2luZ3VsYXJJZCwgdmFsdWUgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXRHZW5lcmljVGFnKHRhZ1R5cGUsIHRhZyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEZpeCBzb21lIGNvbW1vbiBpc3N1ZXMgd2l0aCBwaWN0dXJlIG9iamVjdFxuICAgICAqIEBwYXJhbSBwaWN0dXJlIFBpY3R1cmVcbiAgICAgKi9cbiAgICBhc3luYyBwb3N0Rml4UGljdHVyZShwaWN0dXJlKSB7XG4gICAgICAgIGlmIChwaWN0dXJlLmRhdGEgJiYgcGljdHVyZS5kYXRhLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGlmICghcGljdHVyZS5mb3JtYXQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWxlVHlwZSA9IGF3YWl0IGZpbGVUeXBlRnJvbUJ1ZmZlcihVaW50OEFycmF5LmZyb20ocGljdHVyZS5kYXRhKSwge1xuICAgICAgICAgICAgICAgICAgICBtYXhCdWZmZXJTaXplOiBnZXRNYXhNZW1vcnlBbGxvY2F0aW9uKHRoaXMub3B0cyA/PyB7fSlcbiAgICAgICAgICAgICAgICB9KTsgLy8gVG9ETzogcmVtb3ZlIEJ1ZmZlclxuICAgICAgICAgICAgICAgIGlmIChmaWxlVHlwZSkge1xuICAgICAgICAgICAgICAgICAgICBwaWN0dXJlLmZvcm1hdCA9IGZpbGVUeXBlLm1pbWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwaWN0dXJlLmZvcm1hdCA9IHBpY3R1cmUuZm9ybWF0LnRvTG9jYWxlTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBzd2l0Y2ggKHBpY3R1cmUuZm9ybWF0KSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnaW1hZ2UvanBnJzpcbiAgICAgICAgICAgICAgICAgICAgcGljdHVyZS5mb3JtYXQgPSAnaW1hZ2UvanBlZyc7IC8vIFRvRG86IHJlZ2lzdGVyIHdhcm5pbmdcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwaWN0dXJlO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWRkV2FybmluZygnRW1wdHkgcGljdHVyZSB0YWcgZm91bmQnKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENvbnZlcnQgbmF0aXZlIHRhZyB0byBjb21tb24gdGFnc1xuICAgICAqL1xuICAgIGFzeW5jIHRvQ29tbW9uKHRhZ1R5cGUsIHRhZ0lkLCB2YWx1ZSkge1xuICAgICAgICAvLyBFeHBhbmQgaW52b2x2ZWQtcGVyc29uIHJvbGVzIGZvciBtYXBwaW5nIHdpdGhvdXQgYWRkaW5nIHN5bnRoZXRpYyBuYXRpdmUgdGFncy5cbiAgICAgICAgaWYgKCgodGFnVHlwZSA9PT0gJ0lEM3YyLjInICYmIHRhZ0lkID09PSAnSVBMJykgfHxcbiAgICAgICAgICAgICh0YWdUeXBlID09PSAnSUQzdjIuMycgJiYgdGFnSWQgPT09ICdJUExTJykgfHxcbiAgICAgICAgICAgICh0YWdUeXBlID09PSAnSUQzdjIuNCcgJiYgdGFnSWQgPT09ICdUSVBMJykpICYmXG4gICAgICAgICAgICB2YWx1ZSAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgZm9yIChjb25zdCBbcm9sZSwgcGVvcGxlXSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShwZW9wbGUpKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgcGVyc29uIG9mIHBlb3BsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBwZXJzb24gPT09ICdzdHJpbmcnICYmIHBlcnNvbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy50b0NvbW1vbih0YWdUeXBlLCBgJHt0YWdJZH06JHtyb2xlfWAsIHBlcnNvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGFnID0geyBpZDogdGFnSWQsIHZhbHVlIH07XG4gICAgICAgIGNvbnN0IGdlbmVyaWNUYWcgPSB0aGlzLnRhZ01hcHBlci5tYXBUYWcodGFnVHlwZSwgdGFnLCB0aGlzKTtcbiAgICAgICAgaWYgKGdlbmVyaWNUYWcpIHtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGdlbmVyaWNUYWcudmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBnZW5lcmljVGFnLnZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMucG9zdE1hcCh0YWdUeXBlLCB7IGlkOiBnZW5lcmljVGFnLmlkLCB2YWx1ZSB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBvc3RNYXAodGFnVHlwZSwgZ2VuZXJpY1RhZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogU2V0IGdlbmVyaWMgdGFnXG4gICAgICovXG4gICAgc2V0R2VuZXJpY1RhZyh0YWdUeXBlLCB0YWcpIHtcbiAgICAgICAgZGVidWcoYGNvbW1vbi4ke3RhZy5pZH0gPSAke3RhZy52YWx1ZX1gKTtcbiAgICAgICAgY29uc3QgcHJpbzAgPSB0aGlzLmNvbW1vbk9yaWdpblt0YWcuaWRdIHx8IDEwMDA7XG4gICAgICAgIGNvbnN0IHByaW8xID0gdGhpcy5vcmlnaW5Qcmlvcml0eVt0YWdUeXBlXTtcbiAgICAgICAgaWYgKGlzU2luZ2xldG9uKHRhZy5pZCkpIHtcbiAgICAgICAgICAgIGlmIChwcmlvMSA8PSBwcmlvMCkge1xuICAgICAgICAgICAgICAgIHRoaXMuY29tbW9uW3RhZy5pZF0gPSB0YWcudmFsdWU7XG4gICAgICAgICAgICAgICAgdGhpcy5jb21tb25PcmlnaW5bdGFnLmlkXSA9IHByaW8xO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlYnVnKGBJZ25vcmUgbmF0aXZlIHRhZyAoc2luZ2xldG9uKTogJHt0YWdUeXBlfS4ke3RhZy5pZH0gPSAke3RhZy52YWx1ZX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGlmIChwcmlvMSA9PT0gcHJpbzApIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzVW5pcXVlKHRhZy5pZCkgfHwgdGhpcy5jb21tb25bdGFnLmlkXS5pbmRleE9mKHRhZy52YWx1ZSkgPT09IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29tbW9uW3RhZy5pZF0ucHVzaCh0YWcudmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRlYnVnKGBJZ25vcmUgZHVwbGljYXRlIHZhbHVlOiAke3RhZ1R5cGV9LiR7dGFnLmlkfSA9ICR7dGFnLnZhbHVlfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBubyBlZmZlY3Q/IHRoaXMuY29tbW9uT3JpZ2luW3RhZy5pZF0gPSBwcmlvMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHByaW8xIDwgcHJpbzApIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbW1vblt0YWcuaWRdID0gW3RhZy52YWx1ZV07XG4gICAgICAgICAgICAgICAgdGhpcy5jb21tb25PcmlnaW5bdGFnLmlkXSA9IHByaW8xO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlYnVnKGBJZ25vcmUgbmF0aXZlIHRhZyAobGlzdCk6ICR7dGFnVHlwZX0uJHt0YWcuaWR9ID0gJHt0YWcudmFsdWV9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ub3RpZnlDb21tb25UYWcodGFnKTtcbiAgICB9XG4gICAgbm90aWZ5Q29tbW9uVGFnKHRhZykge1xuICAgICAgICBpZiAodGhpcy5vcHRzPy5vYnNlcnZlcikge1xuICAgICAgICAgICAgdGhpcy5vcHRzLm9ic2VydmVyKHsgbWV0YWRhdGE6IHRoaXMsIHRhZzogeyB0eXBlOiAnY29tbW9uJywgaWQ6IHRhZy5pZCwgdmFsdWU6IHRhZy52YWx1ZSB9IH0pO1xuICAgICAgICB9XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGpvaW5BcnRpc3RzKGFydGlzdHMpIHtcbiAgICBpZiAoYXJ0aXN0cy5sZW5ndGggPiAyKSB7XG4gICAgICAgIHJldHVybiBgJHthcnRpc3RzLnNsaWNlKDAsIGFydGlzdHMubGVuZ3RoIC0gMSkuam9pbignLCAnKX0gJiAke2FydGlzdHNbYXJ0aXN0cy5sZW5ndGggLSAxXX1gO1xuICAgIH1cbiAgICByZXR1cm4gYXJ0aXN0cy5qb2luKCcgJiAnKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsSUFBYSxjQUFiLE1BQXlCO0NBQ3JCLFlBQVksV0FBVztFQUNuQixLQUFLLFlBQVk7Q0FDckI7Q0FDQSxVQUFVO0VBQ04sTUFBTSxZQUFZLEtBQUs7RUFDdkIsT0FBTyxJQUFJLGVBQWUsRUFDdEIsTUFBTSxLQUFLLFlBQVk7R0FDbkIsTUFBTSx5QkFBUyxJQUFJLFdBQVcsSUFBSTtHQUNsQyxNQUFNLE9BQU8sTUFBTSxVQUFVLFdBQVcsUUFBUSxFQUFFLFdBQVcsS0FBSyxDQUFDO0dBQ25FLElBQUksU0FBUyxHQUFHO0lBQ1osV0FBVyxNQUFNO0lBQ2pCO0dBQ0o7R0FDQSxXQUFXLFFBQVEsT0FBTyxTQUFTLEdBQUcsSUFBSSxDQUFDO0VBQy9DLEVBQ0osQ0FBQyxDQUFDLENBQUMsWUFBWSxJQUFJLG9CQUFvQixNQUFNLENBQUM7Q0FDbEQ7QUFDSjs7O0FDakJBLElBQWEsZ0JBQWIsY0FBbUMsV0FBVztDQUMxQyxZQUFZLE9BQU8sZUFBZSxTQUFTO0VBQ3ZDLE1BQU0sT0FBTyxNQUFNLGFBQWEsY0FBYyxvQkFBb0IsU0FBUztFQUMzRSxLQUFLLFFBQVE7RUFDYixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLFVBQVU7RUFDZixLQUFLLE9BQU87Q0FDaEI7QUFDSjs7Ozs7QUNMQSxJQUFhLFlBQVk7Q0FDckIsaUJBQWlCO0NBQ2pCLGdCQUFnQjtDQUNoQixtQkFBbUI7Q0FDbkIsdUJBQXVCO0FBQzNCO0FBQ0EsSUFBYSxpQkFBaUI7Q0FDMUIsSUFBSSxPQUFPO0VBQ1AsT0FBTztHQUNILFdBQVcsVUFBVSxJQUFJLE9BQU8sQ0FBQztHQUNqQyxnQkFBZ0IsVUFBVSxJQUFJLE9BQU8sQ0FBQztHQUN0QyxrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtFQUM3QztDQUNKO0NBQ0EsS0FBSztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQWEsdUJBQXVCO0NBQ2hDLElBQUksT0FBTztFQUNQLE1BQU0sUUFBUSxVQUFVLElBQUksT0FBTyxDQUFDO0VBQ3BDLE9BQU87R0FDSCxXQUFXLFVBQVUsSUFBSSxPQUFPLENBQUM7R0FDakMsWUFBWSxVQUFVLElBQUksT0FBTyxDQUFDO0dBQ2xDLGdCQUFnQixDQUFDLEVBQUUsUUFBUTtHQUMzQixrQkFBa0IsVUFBVSxJQUFJLE9BQU8sQ0FBQztHQUN4QyxnQkFBZ0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN2QyxrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN6QyxnQkFBZ0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN2QyxrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN6QyxVQUFVO0VBQ2Q7Q0FDSjtDQUNBLEtBQUs7QUFDVDs7Ozs7Ozs7Ozs7OztBQWFBLElBQWEsbUNBQW1DO0NBQzVDLElBQUksT0FBTztFQUNQLE9BQU87R0FDSCxXQUFXLFVBQVUsSUFBSSxPQUFPLENBQUM7R0FDakMsY0FBYyxVQUFVLElBQUksT0FBTyxDQUFDO0dBQ3BDLDBCQUEwQixVQUFVLElBQUksT0FBTyxDQUFDO0dBQ2hELHVCQUF1QixVQUFVLElBQUksT0FBTyxDQUFDO0dBQzdDLG1CQUFtQixVQUFVLElBQUksT0FBTyxFQUFFO0dBQzFDLFVBQVUsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUNqQyxtQkFBbUIsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUMxQyxzQkFBc0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtFQUNqRDtDQUNKO0NBQ0EsS0FBSztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQkEsSUFBYSxhQUFhO0NBQ3RCLElBQUksT0FBTztFQUNQLE1BQU0sUUFBUSxVQUFVLElBQUksT0FBTyxDQUFDO0VBQ3BDLE9BQU87R0FDSCxXQUFXLFVBQVUsSUFBSSxPQUFPLENBQUM7R0FDakMsWUFBWSxVQUFVLElBQUksT0FBTyxDQUFDO0dBQ2xDLGdCQUFnQixDQUFDLEVBQUUsUUFBUTtHQUMzQixrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN6QyxnQkFBZ0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN2QyxrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN6QyxnQkFBZ0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN2QyxrQkFBa0IsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUN6QyxtQkFBbUIsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUMxQyw2QkFBNkIsVUFBVSxJQUFJLE9BQU8sRUFBRTtHQUNwRCxVQUFVO0VBQ2Q7Q0FDSjtDQUNBLEtBQUs7QUFDVDs7QUNuSEEsU0FBUyxpQkFBaUIsV0FBVztDQUNqQyxNQUFNLGlCQUFpQixJQUFJLFdBQVcsVUFBVSxHQUFHO0NBQ25ELFVBQVUsSUFBSSxnQkFBZ0IsR0FBRyxTQUFTO0NBQzFDLE9BQU87QUFDWDtBQUNBLElBQU1BLFdBQUFBLEdBQVFDLGVBQUFBLFFBQUFBLENBQVUsbUJBQW1CO0FBQzNDLElBQU0saUJBQWlCO0FBQ3ZCLElBQU0scUJBQXFCLGlCQUFpQixVQUFVLHFCQUFxQjtBQUMzRSxJQUFhLGFBQWIsTUFBd0I7Q0FDcEIsWUFBWSxXQUFXLFVBQVUsQ0FBQyxHQUFHO0VBQ2pDLEtBQUssWUFBWTtFQUNqQixLQUFLLGFBQWEsSUFBSSxXQUFXLGNBQWM7RUFDL0MsS0FBSyxlQUFlO0VBQ3BCLEtBQUsseUJBQXlCO0VBQzlCLEtBQUssU0FBUztHQUNWLGVBQWUsUUFBUSxpQkFBaUIsT0FBTztHQUMvQyxtQkFBbUIsUUFBUSxxQkFBcUIsT0FBTztHQUN2RCxpQ0FBaUMsUUFBUSxtQ0FBbUMsT0FBTztHQUNuRixxQkFBcUIsUUFBUSx1QkFBdUIsT0FBTztHQUMzRCw0QkFBNEIsUUFBUSw4QkFBOEIsT0FBTztHQUN6RSxtQkFBbUIsUUFBUSxxQkFBcUIsT0FBTztHQUN2RCxxQkFBcUIsUUFBUSx1QkFBdUIsT0FBTztFQUMvRDtFQUNBLEtBQUssc0JBQXNCLFFBQVEsdUJBQXVCO0VBQzFELEtBQUssK0JBQStCLFFBQVEsZ0NBQWdDO0VBQzVFLElBQUksT0FBTyxLQUFLLHdCQUF3QixXQUNwQyxNQUFNLElBQUksVUFBVSx1Q0FBdUM7RUFFL0QsSUFBSSxPQUFPLEtBQUssaUNBQWlDLFdBQzdDLE1BQU0sSUFBSSxVQUFVLGdEQUFnRDtFQUV4RSxLQUFLLE1BQU0sQ0FBQyxNQUFNLFVBQVUsT0FBTyxRQUFRLEtBQUssTUFBTSxHQUNsRCxJQUFJLFVBQVUsT0FBTyxzQkFBc0IsQ0FBQyxPQUFPLGNBQWMsS0FBSyxLQUFLLFNBQVMsSUFDaEYsTUFBTSxJQUFJLFdBQVcsR0FBRyxLQUFLLDZDQUE2QztDQUd0Rjs7Q0FFQSxXQUFXLE9BQU8sTUFBTTtFQUNwQixJQUFJLE9BQU8sS0FBSyxPQUFPLFFBQ25CLE1BQU0sSUFBSSxjQUFjLE9BQU8sTUFBTSxLQUFLLE9BQU8sTUFBTTtDQUUvRDtDQUNBLGlCQUFpQjtFQUNiLEtBQUssZUFBZTtFQUNwQixLQUFLLHlCQUF5QjtDQUNsQztDQUNBLGFBQWEsUUFBUTtFQUNqQixLQUFLLFdBQVcscUJBQXFCLEtBQUssZUFBZSxNQUFNO0VBQy9ELEtBQUssZ0JBQWdCO0NBQ3pCO0NBQ0EsVUFBVSxPQUFPLFFBQVEsS0FBSyxXQUFXO0VBQ3JDLEtBQUssYUFBYSxNQUFNLEdBQUc7RUFDM0IsT0FBTyxNQUFNLFVBQVUsS0FBSztDQUNoQztDQUNBLE9BQU8sUUFBUSxRQUFRLEtBQUssV0FBVztFQUNuQyxLQUFLLGFBQWEsTUFBTTtFQUN4QixPQUFPLE1BQU0sT0FBTyxNQUFNO0NBQzlCO0NBQ0EsU0FBUyxRQUFRO0VBQ2IsS0FBSyxhQUFhLE1BQU07RUFDeEIsTUFBTSxPQUFPLElBQUksV0FBVyxNQUFNO0VBQ2xDLE9BQU8sS0FBSyxVQUFVLFdBQVcsSUFBSSxDQUFDLENBQUMsV0FBVyxJQUFJO0NBQzFEO0NBQ0EsZUFBZSxRQUFRO0VBQ25CLEtBQUssV0FBVyxxQkFBcUIsT0FBTyxjQUFjO0VBQzFELEtBQUssV0FBVyx1QkFBdUIsT0FBTyxnQkFBZ0I7RUFDOUQsSUFBSSxPQUFPLHFCQUFxQixHQUM1QixLQUFLLFdBQVcsdUJBQXVCLE9BQU8sY0FBYztDQUVwRTtDQUNBLE1BQU0sUUFBUTtFQUNWLE9BQVEsTUFBTSxLQUFLLGNBQWMsTUFBTyxVQUFVO0NBQ3REO0NBQ0EsZ0JBQWdCO0VBQ1osT0FBTyxLQUFLLFVBQVUsVUFBVSxTQUFTO0NBQzdDO0NBQ0EsTUFBTSxtQ0FBbUM7RUFDckMsTUFBTSxzQkFBc0IsS0FBSztFQUNqQyxNQUFNLGNBQWMsS0FBSyxJQUFJLE9BQVcsb0JBQW9CLFNBQVMsSUFBSTtFQUN6RSxNQUFNLFNBQVMsS0FBSyxXQUFXLFNBQVMsR0FBRyxXQUFXO0VBQ3RELEtBQUssYUFBYSxXQUFXO0VBQzdCLE1BQU0sS0FBSyxVQUFVLFdBQVcsUUFBUSxFQUFFLFVBQVUsb0JBQW9CLFNBQVMsT0FBTyxZQUFZLENBQUM7RUFHckcsS0FBSyxJQUFJLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBRXBDLElBQUksT0FBTyxPQUFPLG1CQUFtQixNQUNqQyxPQUFPLElBQUksT0FBTyxtQkFBbUIsTUFDckMsT0FBTyxJQUFJLE9BQU8sbUJBQW1CLE1BQ3JDLE9BQU8sSUFBSSxPQUFPLG1CQUFtQixJQUNyQyxPQUFPLG9CQUFvQixTQUFTLE9BQU8sY0FBYztFQUdqRSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLHVCQUF1QjtFQUN6QixLQUFLLGVBQWU7RUFDcEIsTUFBTSxVQUFVLE1BQU0sS0FBSyx3QkFBd0I7RUFDbkQsSUFBSSxDQUFDLFNBQ0Q7RUFFSixNQUFNLFFBQVEsQ0FBQztFQUNmLFdBQVcsTUFBTSxTQUFTLFNBQ3RCLE1BQU0sS0FBSyxLQUFLO0VBRXBCLE9BQU87Q0FDWDtDQUNBLE1BQU0sMEJBQTBCO0VBQzVCLElBQUksQ0FBQyxLQUFLLFVBQVUscUJBQXFCLEdBQUc7R0FDeEMsUUFBTSw4REFBOEQ7R0FDcEU7RUFDSjtFQUNBLFFBQU0sOEJBQThCO0VBQ3BDLE1BQU0sTUFBTSxLQUFLLFVBQVU7RUFDM0IsSUFBSTtHQUNBLE1BQU0sU0FBUyxNQUFNLEtBQUssaUNBQWlDO0dBQzNELElBQUksU0FBUyxHQUFHO0lBQ1osUUFBTSwwQ0FBMEM7SUFDaEQsS0FBSyxVQUFVLFlBQVksTUFBTTtJQUNqQyxNQUFNLGFBQWEsTUFBTSxLQUFLLFVBQVUsZ0NBQWdDO0lBQ3hFLE9BQU8sS0FBSyxpQkFBaUIsV0FBVyxtQkFBbUIsV0FBVyxVQUFVLFdBQVcsaUJBQWlCO0dBQ2hIO0VBQ0osVUFDUTtHQUNKLEtBQUssVUFBVSxZQUFZLEdBQUc7RUFDbEM7Q0FDSjtDQUNBLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPO0VBQ3pDLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLE1BQU0sTUFBTSxPQUFPO0VBQ25CLElBQUk7RUFDSixJQUFJLFdBQVc7RUFDZixJQUFJO0dBQ0EsT0FBTyxZQUFZLE1BQU07R0FDekIsWUFBWSxvQkFBb0IsUUFBUSxJQUFJO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEVBQUUsR0FBRztJQUM1QixLQUFLLFdBQVcsaUJBQWlCLElBQUksQ0FBQztJQUV0QyxVQUFVLFlBQVksUUFBUTtJQUM5QixNQUFNLFFBQVEsTUFBTSxLQUFLLFVBQVUsWUFBWSxTQUFTO0lBQ3hELElBQUksTUFBTSxjQUFjLFVBQVUsbUJBQzlCLE1BQU0sSUFBSSxNQUFNLHdDQUF3QztJQUU1RCxNQUFNLFdBQVcsTUFBTSxLQUFLLFVBQVUsSUFBSSxXQUFXLE1BQU0sZ0JBQWdCLE9BQU8sR0FBRyxTQUFTO0lBQzlGLE1BQU0sS0FBSyxPQUFPLE1BQU0sa0JBQWtCLFNBQVM7SUFDbkQsTUFBTSxLQUFLLE9BQU8sTUFBTSxtQkFBbUIsU0FBUztJQUNwRCxXQUFXLFVBQVU7SUFDckIsTUFBTTtHQUNWO0VBQ0osVUFDUTtHQUNKLElBQUk7SUFDQSxNQUFNLFdBQVcsTUFBTTtHQUMzQixVQUNRO0lBQ0osT0FBTyxZQUFZLEdBQUc7R0FDMUI7RUFDSjtDQUNKO0NBQ0EsTUFBTSxNQUFNLFFBQVE7RUFDaEIsS0FBSyxlQUFlO0VBQ3BCLE1BQU0sVUFBVSxLQUFLLHNCQUFzQixNQUFNLEtBQUssd0JBQXdCLElBQUksS0FBQTtFQUNsRixJQUFJLFNBRUEsT0FBTyxLQUFLLDRCQUE0QixTQUFTLE1BQU07RUFHM0QsSUFBSSxPQUFPO0VBQ1gsSUFBSSxhQUFhO0VBQ2pCLEdBQUc7R0FDQyxNQUFNLFlBQVksTUFBTSxLQUFLLG9CQUFvQjtHQUNqRCxJQUFJLENBQUMsV0FDRDtHQUVKLEtBQUssV0FBVyxpQkFBaUIsRUFBRSxVQUFVO0dBQzdDLE1BQU0sT0FBTyxPQUFPLFNBQVM7R0FDN0IsT0FBTyxDQUFDLENBQUMsS0FBSztHQUNkLElBQUk7R0FDSixNQUFNLEtBQUssT0FBTyxVQUFVLGdCQUFnQjtHQUM1QyxJQUFJLEtBQUssU0FDTCxLQUFLLGVBQWUsU0FBUztRQUc3QixLQUFLLFdBQVcsdUJBQXVCLFVBQVUsY0FBYztHQUVuRSxJQUFJLFVBQVUsa0JBQWtCLFVBQVUsbUJBQW1CLEdBQUc7SUFDNUQsTUFBTSxTQUFTLENBQUM7SUFDaEIsSUFBSSxZQUFZO0lBQ2hCLE1BQU0sWUFBWSxLQUFLLElBQUksS0FBSyxPQUFPLDRCQUE0QixLQUFLLE9BQU8sa0NBQWtDLEtBQUssd0JBQXdCLEtBQUssT0FBTyxvQkFBb0IsS0FBSyxjQUFjLEtBQUssVUFBVSxPQUFPLG9CQUFvQixLQUFLLE9BQU8scUJBQXFCLEtBQUssVUFBVSxLQUFLLE9BQU8sb0JBQW9CLE9BQU8sbUJBQW1CLEtBQUssV0FBVyxVQUFVLHFCQUFxQixJQUFJLEtBQUssT0FBTyxzQkFBc0IsT0FBTyxpQkFBaUI7SUFDbGMsUUFBTSwrRUFBK0U7SUFDckYsT0FBTyxNQUFNO0tBRVQsTUFBTSxhQUFhLEtBQUssSUFBSSxnQkFBZ0IsWUFBWSxZQUFZLGVBQWUsR0FBRztLQUN0RixNQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsV0FBVyxLQUFLLFdBQVcsU0FBUyxHQUFHLFVBQVUsR0FBRyxFQUFFLFdBQVcsS0FBSyxDQUFDO0tBQ3hHLE1BQU0saUJBQWlCLEtBQUssZ0NBQWdDLE1BQU07S0FDbEUsTUFBTSxrQkFBa0IsZUFBZSxLQUFLLFdBQVcsU0FBUyxHQUFHLEdBQUcsR0FBRyxXQUFXLGNBQWM7S0FDbEcsSUFBSSxrQkFBa0IsS0FBSyxNQUFNLGVBQWUsT0FBTyxDQUFDLGdCQUNwRCxNQUFNLElBQUksTUFBTSx3REFBd0Q7S0FFNUUsTUFBTSxPQUFPLG1CQUFtQixJQUFJLGtCQUFrQixpQkFBaUIsTUFBTSxNQUFNLGVBQWUsTUFBTTtLQUN4RyxJQUFJLFNBQVMsR0FDVDtLQUVKLEtBQUssV0FBVyw4QkFBOEIsWUFBWSxJQUFJO0tBQzlELEtBQUssV0FBVyxtQ0FBbUMsS0FBSyx5QkFBeUIsSUFBSTtLQUNyRixJQUFJLENBQUMsS0FBSyxTQUNOLEtBQUssV0FBVyx1QkFBdUIsWUFBWSxJQUFJO0tBRTNELElBQUksS0FBSyxTQUFTO01BQ2QsS0FBSyxXQUFXLHFCQUFxQixZQUFZLElBQUk7TUFDckQsSUFBSSxVQUFVLHFCQUFxQixHQUMvQixLQUFLLFdBQVcsdUJBQXVCLFlBQVksSUFBSTtNQUUzRCxJQUFJLE9BQU8sR0FBRztPQUNWLE1BQU0sT0FBTyxNQUFNLEtBQUssU0FBUyxJQUFJO09BQ3JDLE9BQU8sS0FBSyxJQUFJO01BQ3BCO0tBQ0osT0FFSSxNQUFNLEtBQUssT0FBTyxJQUFJO0tBRTFCLGFBQWE7S0FDYixLQUFLLDBCQUEwQjtLQUMvQixJQUFJLG1CQUFtQixHQUNuQjtJQUVSO0lBQ0EsUUFBTSwwQ0FBMEMsS0FBSyxVQUFVLFVBQVU7SUFDekUsSUFBSSxLQUFLLFNBQVM7S0FDZCxLQUFLLFdBQVcscUJBQXFCLFNBQVM7S0FDOUMsTUFBTSxLQUFLLFFBQVEsV0FBVyxZQUFZLE1BQU0sR0FBRyxLQUFLLE9BQU87SUFDbkU7R0FDSixPQUVJLElBQUksS0FBSyxTQUFTO0lBQ2QsUUFBTSxpQ0FBaUMsVUFBVSxlQUFlLE9BQU87SUFDdkUsV0FBVyxNQUFNLEtBQUssU0FBUyxVQUFVLGNBQWM7SUFDdkQsTUFBTSxLQUFLLFFBQVEsV0FBVyxVQUFVLEtBQUssT0FBTztHQUN4RCxPQUNLO0lBQ0QsUUFBTSxrQ0FBa0MsVUFBVSxlQUFlLE9BQU87SUFDeEUsTUFBTSxLQUFLLE9BQU8sVUFBVSxjQUFjO0dBQzlDO0dBRUosUUFBTSxrQ0FBa0MsS0FBSyxVQUFVLFVBQVU7R0FDakUsSUFBSSxVQUFVLGdCQUdOO1NBQUEsTUFEeUIsS0FBSyxVQUFVLGNBQWMsRUFBQSxDQUN2QyxjQUFjLFdBQzdCLE1BQU0sSUFBSSxNQUFNLGtEQUFrRCxLQUFLLFVBQVUsV0FBVyxlQUFlLEtBQUs7R0FBQTtFQUc1SCxTQUFTLENBQUM7Q0FDZDtDQUNBLE1BQU0sNEJBQTRCLFNBQVMsUUFBUTtFQUMvQyxXQUFXLE1BQU0sY0FBYyxTQUFTO0dBQ3BDLE1BQU0sT0FBTyxPQUFPLFVBQVU7R0FDOUIsSUFBSSxLQUFLLFNBQVM7SUFDZCxLQUFLLFVBQVUsWUFBWSxXQUFXLDJCQUEyQjtJQUNqRSxNQUFNLFlBQVksTUFBTSxLQUFLLG9CQUFvQjtJQUNqRCxJQUFJLFdBQVc7S0FDWCxNQUFNLEtBQUssT0FBTyxVQUFVLGdCQUFnQjtLQUM1QyxLQUFLLGVBQWUsVUFBVTtLQUM5QixLQUFLLGVBQWUsU0FBUztLQUM3QixNQUFNLFdBQVcsTUFBTSxLQUFLLFNBQVMsV0FBVyxjQUFjO0tBQzlELE1BQU0sS0FBSyxRQUFRLFdBQVcsVUFBVSxLQUFLLE9BQU87SUFDeEQ7R0FDSjtHQUNBLElBQUksS0FBSyxNQUNMO0VBRVI7Q0FDSjtDQUNBLE1BQU0sUUFBUSxXQUFXLFVBQVUsSUFBSTtFQUNuQyxJQUFJLFVBQVUscUJBQXFCLEdBQUc7R0FFbEMsS0FBSyxXQUFXLHVCQUF1QixTQUFTLE1BQU07R0FDdEQsT0FBTyxHQUFHLFFBQVE7RUFDdEI7RUFDQSxJQUFJLFVBQVUscUJBQXFCLEdBQy9CLE1BQU0sSUFBSSxNQUFNLHVDQUF1QyxVQUFVLGtCQUFrQjtFQUV2RixRQUFNLHVCQUF1QixVQUFVLFNBQVMsb0JBQW9CLFNBQVMsUUFBUTtFQUVyRixPQUFPLEdBQUcsTUFEcUIsS0FBSyxxQkFBcUIsUUFBUSxDQUN2QztDQUM5QjtDQUNBLE1BQU0scUJBQXFCLE1BQU07RUFFN0IsTUFBTSxRQUFRLElBQUksZUFBZSxFQUM3QixNQUFNLFlBQVk7R0FDZCxXQUFXLFFBQVEsSUFBSTtHQUN2QixXQUFXLE1BQU07RUFDckIsRUFDSixDQUFDO0VBQ0QsTUFBTSxLQUFLLElBQUksb0JBQW9CLGFBQWE7RUFFaEQsTUFBTSxTQURTLE1BQU0sWUFBWSxFQUNiLENBQUMsQ0FBQyxVQUFVO0VBQ2hDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLElBQUksWUFBWTtFQUNoQixJQUFJO0dBQ0EsT0FBTyxNQUFNO0lBQ1QsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE9BQU8sS0FBSztJQUMxQyxJQUFJLE1BQ0E7SUFFSixLQUFLLFdBQVcsdUJBQXVCLFlBQVksTUFBTSxNQUFNO0lBQy9ELGFBQWEsTUFBTTtJQUNuQixPQUFPLEtBQUssS0FBSztHQUNyQjtHQUNBLEtBQUssV0FBVyx1QkFBdUIsU0FBUztHQUNoRCxPQUFPLFlBQVksTUFBTTtFQUM3QixTQUNPLEtBQUs7R0FFUixNQUFNLE9BQU8sT0FBTyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBRXJDLENBQUM7R0FDRCxJQUFJLGVBQWUsZUFDZixNQUFNO0dBS1YsSUFBSSxlQUFlLFNBQVMsVUFBVSxPQUFPLElBQUksU0FBUyxzQ0FDdEQsT0FBTyxZQUFZLE1BQU07R0FHN0IsTUFBTSxVQUFVLGVBQWUsUUFDekIsZ0NBQWdDLElBQUksWUFDcEM7R0FDTixNQUFNLElBQUksVUFBVSxPQUFPO0VBQy9CLFVBQ1E7R0FDSixPQUFPLFlBQVk7RUFDdkI7Q0FDSjtDQUNBLE1BQU0sc0JBQXNCO0VBQ3hCLE1BQU0sWUFBWSxNQUFNLEtBQUssVUFBVSxVQUFVLFNBQVM7RUFDMUQsSUFBSSxjQUFjLFVBQVUsaUJBQWlCO0dBQ3pDLE1BQU0sU0FBUyxNQUFNLEtBQUssVUFBVSxvQkFBb0I7R0FDeEQsT0FBTyxXQUFXLE1BQU0sS0FBSyxVQUFVLElBQUksV0FBVyxPQUFPLGdCQUFnQixPQUFPLENBQUM7R0FDckYsT0FBTztFQUNYO0VBQ0EsSUFBSSxjQUFjLFVBQVUsbUJBQ3hCLE9BQU87RUFFWCxJQUFJLGNBQWMsWUFDZCxNQUFNLElBQUksTUFBTSxlQUFlO0VBRW5DLE1BQU0sSUFBSSxNQUFNLHNCQUFzQjtDQUMxQztBQUNKO0FBQ0EsU0FBUyxlQUFlLFFBQVEsVUFBVSxnQkFBZ0I7Q0FDdEQsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLE9BQU8sVUFBVSxpQkFBaUIsSUFBSSxlQUFlLE1BQU0sS0FDNUUsSUFBSSxVQUFVLElBQUksUUFBUSxDQUFDLE1BQU0sVUFBVSxtQkFDdEMsT0FBTyxTQUFTLElBQUksTUFBTSxVQUFVLElBQUksUUFBUSxJQUFJLENBQUMsTUFBTSxXQUFXLElBQ3ZFLE9BQU87Q0FHZixPQUFPO0FBQ1g7QUFDQSxTQUFTLFlBQVksUUFBUTtDQUV6QixNQUFNLGNBQWMsT0FBTyxRQUFRLEtBQUssU0FBUyxNQUFNLEtBQUssUUFBUSxDQUFDO0NBQ3JFLE1BQU0sY0FBYyxJQUFJLFdBQVcsV0FBVztDQUM5QyxJQUFJLFNBQVM7Q0FDYixLQUFLLE1BQU0sU0FBUyxRQUFRO0VBQ3hCLFlBQVksSUFBSSxPQUFPLE1BQU07RUFDN0IsVUFBVSxNQUFNO0NBQ3BCO0NBQ0EsT0FBTztBQUNYOztBQ3ZYQSxTQUFnQixjQUFjLFFBQVEsVUFBVTtDQUMvQyxJQUFJLGFBQWEsWUFBWTtFQUM1QixNQUFNLFFBQVEsQ0FBQztFQUNmLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxPQUFPLFFBQVEsU0FBUztHQUNuRCxNQUFNLE9BQU8sT0FBTyxXQUFXLEtBQUs7R0FDcEMsTUFBTSxLQUFLLE9BQU8sS0FBTyxRQUFRLElBQUssR0FBSTtFQUMzQztFQUVBLE9BQU87Q0FDUjtDQUVBLElBQUksYUFBYSxZQUFZO0VBQzVCLE1BQU0sUUFBUSxDQUFDO0VBQ2YsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLE9BQU8sUUFBUSxTQUFTO0dBQ25ELE1BQU0sT0FBTyxPQUFPLFdBQVcsS0FBSztHQUNwQyxNQUFNLEtBQU0sUUFBUSxJQUFLLEtBQU0sT0FBTyxHQUFJO0VBQzNDO0VBRUEsT0FBTztDQUNSO0NBRUEsT0FBTyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsS0FBSSxjQUFhLFVBQVUsV0FBVyxDQUFDLENBQUM7QUFDNUQ7Ozs7Ozs7O0FBU0EsU0FBZ0IseUJBQXlCLGFBQWEsU0FBUyxHQUFHO0NBQ2pFLE1BQU0sVUFBVSxPQUFPLFNBQVMsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksYUFBYSxHQUFHLEdBQUcsQ0FBQztDQUMxRSxJQUFJLE9BQU8sTUFBTSxPQUFPLEdBQ3ZCLE9BQU87Q0FHUixJQUFJLE1BQU07Q0FFVixLQUFLLElBQUksUUFBUSxRQUFRLFFBQVEsU0FBUyxLQUFLLFNBQzlDLE9BQU8sWUFBWTtDQUdwQixLQUFLLElBQUksUUFBUSxTQUFTLEtBQUssUUFBUSxTQUFTLEtBQUssU0FDcEQsT0FBTyxZQUFZO0NBR3BCLE9BQU8sWUFBWTtBQUNwQjs7Ozs7QUFNQSxJQUFhLHNCQUFzQjtDQUNsQyxNQUFNLFFBQVEsV0FBWSxPQUFPLFNBQVMsS0FBSyxPQUFVLE9BQU8sU0FBUyxLQUFLLFFBQVMsS0FBTyxPQUFPLFNBQVMsS0FBSyxRQUFTLE1BQVEsT0FBTyxVQUFVLFFBQVM7Q0FDOUosS0FBSztBQUNOOztBQ3pEQSxJQUFhLGFBQWE7Q0FDekI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFFQSxJQUFhLFlBQVk7Q0FDeEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRDs7QUNyWEEsSUFBYSxrQ0FBa0M7QUFFL0MsSUFBYSx1QkFBYixjQUEwQyxNQUFNLENBQUM7QUFFakQsU0FBZ0IsYUFBYSxPQUFPLFNBQVMsUUFBUTtDQUNwRCxJQUNDLENBQUMsT0FBTyxTQUFTLEtBQUssS0FDbkIsUUFBUSxLQUNSLFFBQVEsU0FFWCxNQUFNLElBQUkscUJBQXFCLEdBQUcsT0FBTyxvQkFBb0IsTUFBTSxZQUFZLFFBQVEsUUFBUTtDQUdoRyxPQUFPO0FBQ1I7QUFFQSxlQUFzQixXQUFXLFdBQVcsUUFBUSxFQUFDLGdCQUFnQixpQ0FBaUMsU0FBUyxXQUFVLENBQUMsR0FBRztDQUM1SCxNQUFNLGFBQWEsYUFBYSxRQUFRLGVBQWUsTUFBTTtDQUM3RCxNQUFNLFVBQVUsT0FBTyxVQUFVO0FBQ2xDO0FBRUEsZUFBc0IsZUFBZSxXQUFXLFFBQVEsU0FBUyxFQUFDLGdCQUFnQixPQUFPLFFBQVEsU0FBUyxXQUFVLENBQUMsR0FBRztDQUV2SCxNQUFNLGFBQWEsYUFESixTQUFTLFVBQVUsT0FBTyxRQUNELGVBQWUsTUFBTTtDQUM3RCxPQUFPLFVBQVUsV0FBVyxRQUFRO0VBQ25DLEdBQUc7RUFDSCxRQUFRO0NBQ1QsQ0FBQztBQUNGO0FBRUEsU0FBZ0IsV0FBVyxRQUFRLFNBQVMsU0FBUztDQUNwRCxVQUFVO0VBQ1QsUUFBUTtFQUNSLEdBQUc7Q0FDSjtDQUVBLEtBQUssTUFBTSxDQUFDLE9BQU8sV0FBVyxRQUFRLFFBQVEsR0FFN0MsSUFBSSxRQUFRLE1BRVA7TUFBQSxZQUFZLFFBQVEsS0FBSyxTQUFTLE9BQU8sUUFBUSxRQUFRLFVBQzVELE9BQU87Q0FBQSxPQUVGLElBQUksV0FBVyxPQUFPLFFBQVEsUUFBUSxTQUM1QyxPQUFPO0NBSVQsT0FBTztBQUNSO0FBRUEsU0FBZ0IsbUJBQW1CLFdBQVc7Q0FDN0MsTUFBTSxXQUFXLFVBQVUsU0FBUztDQUNwQyxPQUNDLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FDdEIsYUFBYSxPQUFPO0FBRXpCO0FBRUEsU0FBZ0IsaUNBQWlDLFdBQVcsYUFBYSxjQUFjO0NBQ3RGLE9BQ0MsbUJBQW1CLFNBQVMsS0FDekIsVUFBVSxXQUFXLGNBQWM7QUFFeEM7O0FDeERBLElBQU0sNkJBQTZCO0FBQ25DLElBQU0sdUJBQXVCO0FBQzdCLElBQU0saUNBQWlDO0FBRXZDLElBQU0sOENBQThCLElBQUksSUFBSTtDQUMzQztDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsSUFBTSxxQ0FBcUMsQ0FDMUMsdUNBQ0EsaURBQ0Q7QUFDQSxJQUFNLDJDQUEyQixJQUFJLElBQUk7Q0FDeEM7Q0FDQTtDQUNBO0FBQ0QsQ0FBQztBQUVELFNBQVMsc0JBQXNCLE9BQU87Q0FDckMsSUFBSSxpQkFBaUJDLGtCQUNwQixPQUFPO0NBR1IsSUFBSSxpQkFBaUIsd0JBQXdCLGlCQUFpQixlQUM3RCxPQUFPO0NBR1IsSUFBSSxFQUFFLGlCQUFpQixRQUN0QixPQUFPO0NBR1IsSUFBSSxpQkFBaUIsYUFBYSxNQUFNLFFBQVEsV0FBVyw4QkFBOEIsR0FDeEYsT0FBTztDQUdSLElBQUksNEJBQTRCLElBQUksTUFBTSxPQUFPLEdBQ2hELE9BQU87Q0FHUixJQUFJLHlCQUF5QixJQUFJLE1BQU0sSUFBSSxHQUMxQyxPQUFPO0NBR1IsS0FBSyxNQUFNLFVBQVUsb0NBQ3BCLElBQUksTUFBTSxRQUFRLFdBQVcsTUFBTSxHQUNsQyxPQUFPO0NBSVQsT0FBTztBQUNSO0FBRUEsU0FBUyxvQkFBb0IsT0FBTztDQUNuQyxPQUFPLGlCQUFpQixpQkFBaUI7RUFDeEM7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDLENBQUMsU0FBUyxNQUFNLEtBQUs7QUFDdkI7QUFFQSxTQUFTLDRCQUE0QixXQUFXLGNBQWMsNEJBQTRCO0NBQ3pGLE1BQU0sUUFBUSxDQUFDLFVBQVUsZ0JBQWdCLFVBQVUsZ0JBQWdCO0NBQ25FLEtBQUssTUFBTSxRQUFRLE9BQ2xCLElBQ0MsQ0FBQyxPQUFPLFNBQVMsSUFBSSxLQUNsQixPQUFPLEtBQ1AsT0FBTyxhQUVWLE9BQU87Q0FJVCxPQUFPO0FBQ1I7QUFJQSxTQUFTLCtCQUErQjtDQUN2QyxPQUFPO0VBQ04sa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQixnQkFBZ0I7RUFDaEIsMkJBQTJCO0NBQzVCO0FBQ0Q7QUFFQSxTQUFTLHlDQUF5QyxZQUFZLFVBQVU7Q0FDdkUsSUFBSSxhQUFhLHNCQUNoQixXQUFXLG1CQUFtQjtDQUcvQixJQUFJLFNBQVMsV0FBVyxtQkFBbUIsR0FDMUMsV0FBVyxzQkFBc0I7Q0FHbEMsSUFBSSxTQUFTLFdBQVcsZUFBZSxHQUN0QyxXQUFXLGlCQUFpQjtDQUc3QixJQUFJLGFBQWEsK0JBQ2hCLFdBQVcsNEJBQTRCO0FBRXpDO0FBRUEsU0FBUywrQkFBK0IsWUFBWTtDQUNuRCxJQUFJLENBQUMsV0FBVyxrQkFDZjtDQUdELElBQUksV0FBVyxxQkFDZCxPQUFPO0VBQUMsS0FBSztFQUFPLE1BQU07Q0FBK0I7Q0FHMUQsSUFBSSxXQUFXLGdCQUNkLE9BQU87RUFBQyxLQUFLO0VBQVcsTUFBTTtDQUErQjtDQUc5RCxPQUFPO0VBQUMsS0FBSztFQUFTLE1BQU07Q0FBNkI7QUFDMUQ7QUFJQSxTQUFTLHdCQUF3QixVQUFVO0NBQzFDLFdBQVcsU0FBUyxZQUFZO0NBQ2hDLFFBQVEsVUFBUjtFQUNDLEtBQUssd0JBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQVE7RUFDcEMsS0FBSywyQ0FDSixPQUFPO0dBQUMsS0FBSztHQUFPLE1BQU07RUFBUTtFQUNuQyxLQUFLLG9EQUNKLE9BQU87R0FBQyxLQUFLO0dBQU8sTUFBTTtFQUFRO0VBQ25DLEtBQUssa0RBQ0osT0FBTztHQUFDLEtBQUs7R0FBTyxNQUFNO0VBQVE7RUFDbkMsS0FBSywyREFDSixPQUFPO0dBQUMsS0FBSztHQUFPLE1BQU07RUFBUTtFQUNuQyxLQUFLLG1EQUNKLE9BQU87R0FBQyxLQUFLO0dBQU8sTUFBTTtFQUFRO0VBQ25DLEtBQUssNERBQ0osT0FBTztHQUFDLEtBQUs7R0FBTyxNQUFNO0VBQVE7RUFDbkMsS0FBSywrQ0FDSixPQUFPO0dBQUMsS0FBSztHQUFPLE1BQU07RUFBUTtFQUNuQyxLQUFLLHdEQUNKLE9BQU87R0FBQyxLQUFLO0dBQU8sTUFBTTtFQUFRO0VBQ25DLEtBQUssMEVBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQVE7RUFDcEMsS0FBSyxxRUFDSixPQUFPO0dBQUMsS0FBSztHQUFRLE1BQU07RUFBUTtFQUNwQyxLQUFLLCtDQUNKLE9BQU87R0FBQyxLQUFLO0dBQVEsTUFBTTtFQUFnRDtFQUM1RSxLQUFLLHdFQUNKLE9BQU87R0FBQyxLQUFLO0dBQVEsTUFBTTtFQUFRO0VBQ3BDLEtBQUssa0RBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQW1EO0VBQy9FLEtBQUssd0RBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQXlEO0VBQ3JGLEtBQUssMkVBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQVE7RUFDcEMsS0FBSyxpREFDSixPQUFPO0dBQUMsS0FBSztHQUFRLE1BQU07RUFBa0Q7RUFDOUUsS0FBSywyRUFDSixPQUFPO0dBQUMsS0FBSztHQUFRLE1BQU07RUFBUTtFQUNwQyxLQUFLLHlEQUNKLE9BQU87R0FBQyxLQUFLO0dBQVEsTUFBTTtFQUFrRDtFQUM5RSxLQUFLLHlFQUNKLE9BQU87R0FBQyxLQUFLO0dBQVEsTUFBTTtFQUFRO0VBQ3BDLEtBQUssdURBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQXdEO0VBQ3BGLEtBQUssNkVBQ0osT0FBTztHQUFDLEtBQUs7R0FBUSxNQUFNO0VBQVE7RUFDcEMsS0FBSywyREFDSixPQUFPO0dBQUMsS0FBSztHQUFRLE1BQU07RUFBNEQ7RUFDeEYsS0FBSyxvQ0FDSixPQUFPO0dBQUMsS0FBSztHQUFRLE1BQU07RUFBdUI7RUFDbkQsS0FBSywwREFDSixPQUFPO0dBQUMsS0FBSztHQUFPLE1BQU07RUFBVztDQUV2QztBQUNEO0FBRUEsU0FBUyxpQ0FBaUM7Q0FDekMsT0FBTztFQUNOLHNCQUFzQjtFQUN0Qiw0QkFBNEI7RUFDNUIsdUJBQXVCO0VBQ3ZCLDRCQUE0QjtFQUM1QixrQkFBa0I7RUFDbEIsMEJBQTBCO0VBQzFCLHlCQUF5QjtFQUN6QiwrQkFBK0I7Q0FDaEM7QUFDRDtBQUVBLFNBQVMsMkNBQTJDLGNBQWMsVUFBVTtDQUMzRSxJQUFJLFNBQVMsV0FBVyxPQUFPLEdBQzlCLGFBQWEsbUJBQW1CO0NBR2pDLElBQUksU0FBUyxXQUFXLE1BQU0sR0FDN0IsYUFBYSwyQkFBMkI7Q0FHekMsSUFBSSxTQUFTLFdBQVcsS0FBSyxHQUM1QixhQUFhLDBCQUEwQjtDQUd4QyxJQUNDLFNBQVMsV0FBVyxLQUFLLEtBQ3RCLFNBQVMsU0FBUyxRQUFRLEdBRTdCLGFBQWEsZ0NBQWdDO0FBRS9DO0FBRUEsU0FBUyxxQ0FBcUMsY0FBYztDQUMzRCxJQUFJLGFBQWEsa0JBQ2hCLE9BQU87RUFDTixLQUFLO0VBQ0wsTUFBTTtDQUNQO0NBR0QsSUFBSSxhQUFhLDBCQUNoQixPQUFPO0VBQ04sS0FBSztFQUNMLE1BQU07Q0FDUDtDQUdELElBQUksYUFBYSx5QkFDaEIsT0FBTztFQUNOLEtBQUs7RUFDTCxNQUFNO0NBQ1A7Q0FHRCxJQUFJLGFBQWEsK0JBQ2hCLE9BQU87RUFDTixLQUFLO0VBQ0wsTUFBTTtDQUNQO0FBRUY7QUFFQSxTQUFTLGlDQUFpQyxjQUFjO0NBSXZELElBQ0MsQ0FBQyxhQUFhLHdCQUNYLGFBQWEsOEJBQ2IsYUFBYSx5QkFDYixhQUFhLDRCQUVoQjtDQUdELE9BQU8scUNBQXFDLFlBQVk7QUFDekQ7QUFFQSxTQUFTLHNDQUFzQyxZQUFZO0NBRTFELE1BQU0sY0FBYyxXQUFXLFFBQVEsYUFBWTtDQUNuRCxJQUFJLGdCQUFnQixJQUFJO0VBQ3ZCLE1BQU0sV0FBVztFQUNqQixJQUFJLFdBQVcsU0FBUyxnQkFBZ0IsU0FBUyxFQUFFLEdBQ2xELE9BQU87RUFHUjtDQUNEO0NBRUEsTUFBTSxtQkFBbUIsV0FBVyxNQUFNLEdBQUcsV0FBVztDQUN4RCxNQUFNLHFCQUFxQixpQkFBaUIsWUFBWSxJQUFHO0NBRTNELE9BQU8saUJBQWlCLE1BQU0scUJBQXFCLENBQUM7QUFDckQ7QUFFQSxlQUFzQixVQUFVLFdBQVc7Q0FDMUMsSUFBSTtDQUNKLE1BQU0sZUFBZSwrQkFBK0I7Q0FDcEQsTUFBTSxhQUFhLDZCQUE2QjtDQUVoRCxJQUFJO0VBQ0gsTUFBTSxJQUFJLFdBQVcsV0FBVztHQUUvQixxQkFBcUI7R0FDckIsOEJBQThCO0dBQzlCLGVBQWU7R0FFZixtQkFBbUIsbUJBQW1CLFNBQVMsSUFBSSxrQ0FBa0M7R0FDckYsaUNBQWlDLG1CQUFtQixTQUFTLElBQUksV0FBVztHQUM1RSxxQkFBcUIsbUJBQW1CLFNBQVMsSUFBSSw2QkFBNkI7R0FDbEYsNEJBQTRCO0dBQzVCLG1CQUFtQjtHQUNuQixxQkFBcUI7RUFDdEIsQ0FBQyxDQUFDLENBQUMsT0FBTSxjQUFhO0dBQ3JCLDJDQUEyQyxjQUFjLFVBQVUsUUFBUTtHQUMzRSx5Q0FBeUMsWUFBWSxVQUFVLFFBQVE7R0FHdkUsSUFBSSxXQUFXLHFCQUFxQixXQUFXLHVCQUF1QixXQUFXLGlCQUFpQjtJQUNqRyxXQUFXLCtCQUErQixVQUFVO0lBQ3BELE9BQU8sRUFBQyxNQUFNLEtBQUk7R0FDbkI7R0FFQSxNQUFNLDZCQUE2QixVQUFVLGFBQWE7R0FDMUQsTUFBTSw2QkFBNkIsaUNBQWlDLFlBQVk7R0FDaEYsSUFDQyxDQUFDLDhCQUNFLDRCQUNGO0lBQ0QsV0FBVztJQUNYLE9BQU8sRUFDTixNQUFNLEtBQ1A7R0FDRDtHQUVBLFFBQVEsVUFBVSxVQUFsQjtJQUNDLEtBQUs7S0FDSixXQUFXO01BQ1YsS0FBSztNQUNMLE1BQU07S0FDUDtLQUNBLE9BQU8sRUFDTixNQUFNLEtBQ1A7SUFDRCxLQUFLO0tBQ0osV0FBVztNQUNWLEtBQUs7TUFDTCxNQUFNO0tBQ1A7S0FDQSxPQUFPLEVBQ04sTUFBTSxLQUNQO0lBQ0QsS0FBSztLQUNKLElBQUksQ0FBQyw0QkFBNEIsV0FBVyw4QkFBOEIsR0FDekUsT0FBTyxDQUFDO0tBR1QsT0FBTztNQUNOLE1BQU0sUUFBUSxVQUFVO09BR3ZCLFdBQVcsd0JBRE0sSUFBSSxZQUFZLE9BQU8sQ0FBQyxDQUFDLE9BQU8sUUFBUSxDQUFDLENBQUMsS0FDakIsQ0FBQztNQUM1QztNQUNBLE1BQU07S0FDUDtJQUVELEtBQUs7S0FDSixhQUFhLHVCQUF1QjtLQUVwQyxJQUFJLENBQUMsNEJBQTRCLFdBQVcsOEJBQThCLEdBQUc7TUFDNUUsYUFBYSw2QkFBNkI7TUFDMUMsT0FBTyxDQUFDO0tBQ1Q7S0FFQSxhQUFhLHdCQUF3QjtLQUNyQyxPQUFPO01BQ04sTUFBTSxRQUFRLFVBQVU7T0FHdkIsTUFBTSxXQUFXLHNDQURFLElBQUksWUFBWSxPQUFPLENBQUMsQ0FBQyxPQUFPLFFBQ2EsQ0FBQztPQUNqRSxJQUFJLFVBQ0gsV0FBVyx3QkFBd0IsUUFBUTtPQUc1QyxhQUFhLDZCQUE2QjtPQUMxQyxhQUFhLHdCQUF3QjtNQUN0QztNQUNBLE1BQU07S0FDUDtJQUdEO0tBQ0MsSUFBSSxJQUFBLE9BQUEscUJBQUEsR0FBaUIsQ0FBQyxDQUFDLEtBQUssVUFBVSxRQUFRLEdBQUc7TUFDaEQsV0FBVztPQUNWLEtBQUs7T0FDTCxNQUFNO01BQ1A7TUFDQSxPQUFPLEVBQUMsTUFBTSxLQUFJO0tBQ25CO0tBRUEsT0FBTyxDQUFDO0dBQ1Y7RUFDRCxDQUFDO0NBQ0YsU0FBUyxPQUFPO0VBQ2YsSUFBSSxDQUFDLHNCQUFzQixLQUFLLEdBQy9CLE1BQU07RUFHUCxJQUFJLGFBQWEsdUJBQXVCO0dBQ3ZDLGFBQWEsd0JBQXdCO0dBQ3JDLGFBQWEsNkJBQTZCO0VBQzNDO0VBS0EsSUFDQyxDQUFDLGFBQ0csaUJBQWlCQSxvQkFBNEIsaUJBQWlCLHdCQUF3QixvQkFBb0IsS0FBSyxNQUNoSCxDQUFDLGFBQWEsc0JBRWpCLFdBQVcscUNBQXFDLFlBQVk7Q0FFOUQ7Q0FFQSxNQUFNLGdCQUFnQixtQkFBbUIsU0FBUyxLQUM5QyxXQUFXLG9CQUNYLENBQUMsV0FBVyx1QkFDWixDQUFDLFdBQVcsa0JBQ1osQ0FBQyxXQUFXLDRCQUNiLEtBQUEsSUFDQSwrQkFBK0IsVUFBVTtDQUU1QyxPQUFPLFlBQVksaUNBQWlDLFlBQVksS0FBSyxpQkFBaUI7RUFDckYsS0FBSztFQUNMLE1BQU07Q0FDUDtBQUNEOztBQ2phQSxJQUFNLHFDQUFxQztBQUMzQyxJQUFNLHVDQUF1QztBQUM3QyxJQUFNLDBCQUEwQjtBQUVoQyxlQUFzQixXQUFXLFdBQVc7Q0FDM0MsZUFBZSxVQUFVLE9BQU87RUFDL0IsTUFBTSxNQUFNLE1BQU0sTUFBTSxXQUFXQyxLQUFXO0VBQzlDLElBQUksT0FBTztFQUNYLElBQUksS0FBSztFQUVULE9BQU8sU0FBUyxNQUFNLE1BQU0sVUFBVSxHQUFHO0dBQ3hDLEVBQUU7R0FDRixTQUFTO0VBQ1Y7RUFFQSxNQUFNLEtBQUssSUFBSSxXQUFXLEtBQUssQ0FBQztFQUNoQyxNQUFNLGVBQWUsT0FBTyxJQUFJLEtBQUEsR0FBVztHQUMxQyxlQUFlLEdBQUc7R0FDbEIsUUFBUTtFQUNULENBQUM7RUFDRCxPQUFPO0NBQ1I7Q0FFQSxlQUFlLFlBQVksT0FBTztFQUNqQyxNQUFNLFVBQVUsTUFBTSxVQUFVLEtBQUs7RUFDckMsTUFBTSxjQUFjLE1BQU0sVUFBVSxLQUFLO0VBRXpDLFlBQVksTUFBTSxPQUFTLFlBQVksU0FBUztFQUNoRCxNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsWUFBWSxNQUFNO0VBRS9DLE1BQU0sU0FBUyxJQUFJLFNBQVMsUUFBUSxNQUFNO0VBQzFDLE1BQU0sYUFBYSxJQUFJLFNBQVMsWUFBWSxRQUFRLFlBQVksU0FBUyxVQUFVLFFBQVE7RUFFM0YsT0FBTztHQUNOLElBQUksVUFBVSxNQUFNO0dBQ3BCLEtBQUssVUFBVSxVQUFVO0VBQzFCO0NBQ0Q7Q0FFQSxNQUFNLG9CQUFvQixtQkFBbUIsU0FBUztDQUV0RCxlQUFlLGFBQWEsUUFBUTtFQUNuQyxJQUFJLG1CQUFtQjtFQUN2QixPQUFPLE9BQU8sWUFBWSxHQUFHO0dBQzVCO0dBQ0EsSUFBSSxtQkFBbUIseUJBQ3RCO0dBR0QsSUFBSSxpQ0FBaUMsV0FBVyxlQUFBLFFBQThDLEdBQzdGO0dBR0QsTUFBTSxtQkFBbUIsVUFBVTtHQUNuQyxNQUFNLFVBQVUsTUFBTSxZQUFZLE1BQU07R0FFeEMsSUFBSSxRQUFRLE9BQU8sT0FBUztJQUUzQixJQUFJLFFBQVEsTUFBTSxvQ0FDakI7SUFHRCxNQUFNLHFCQUFxQixhQUFhLFFBQVEsS0FBSyxvQ0FBb0MsY0FBYztJQUV2RyxRQUFPLE1BRGdCLE9BQU8sVUFBVSxJQUFJQyxXQUFpQixrQkFBa0IsQ0FBQyxFQUFBLENBQ2hFLE1BQU0sTUFBTSxDQUFDLENBQUMsQ0FBQztHQUNoQztHQUVBLElBQ0Msc0JBRUMsQ0FBQyxPQUFPLFNBQVMsUUFBUSxHQUFHLEtBQ3pCLFFBQVEsTUFBTSxLQUNkLFFBQVEsTUFBTSx1Q0FHbEI7R0FHRCxNQUFNLFdBQVcsUUFBUSxRQUFRLEtBQUs7SUFDckMsZUFBZSxvQkFBb0IsdUNBQXVDLFVBQVUsU0FBUztJQUM3RixRQUFRO0dBQ1QsQ0FBQztHQUdELElBQUksVUFBVSxZQUFZLGtCQUN6QjtFQUVGO0NBQ0Q7Q0FFQSxNQUFNLGNBQWMsTUFBTSxZQUFZLFNBQVM7Q0FDL0MsTUFBTSxnQkFBZ0IsVUFBVTtDQUNoQyxNQUFNLFNBQVMsb0JBQW9CLFdBQVcsWUFBWSxHQUFHO0NBQzdELElBQUk7Q0FDSixJQUFJO0VBQ0gsZUFBZSxNQUFNLGFBQWEsTUFBTTtDQUN6QyxTQUFTLE9BQU87RUFDZixJQUFJLGlCQUFpQix3QkFDcEI7RUFHRCxNQUFNO0NBQ1AsVUFBVTtFQUVULE1BQU0sT0FBTyxNQUFNO0NBQ3BCO0NBRUEsUUFBUSxjQUFSO0VBQ0MsS0FBSyxRQUNKLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBRUQsS0FBSyxZQUNKLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0NBR0Y7QUFDRDs7QUM3SEEsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxvQ0FBb0M7QUFDMUMsSUFBTSw2QkFBNkI7QUFFbkMsU0FBUyxvQkFBb0IsTUFBTTtDQUNsQyxRQUFRLEtBQUssWUFBWSxDQUFDLElBQUksUUFBVTtBQUN6QztBQUVBLGVBQXNCLFVBQVUsV0FBVztDQUMxQyxNQUFNLGNBQWM7RUFDbkIsS0FBSztFQUNMLE1BQU07Q0FDUDtDQUVBLE1BQU0sZUFBZTtFQUNwQixLQUFLO0VBQ0wsTUFBTTtDQUNQO0NBVUEsTUFBTSxVQUFVLE9BQU8sQ0FBQztDQUV4QixlQUFlLGtCQUFrQjtFQUNoQyxPQUFPO0dBQ04sUUFBUSxNQUFNLFVBQVUsVUFBVUMsUUFBYztHQUNoRCxNQUFNLE1BQU0sVUFBVSxVQUFVLElBQUlDLFdBQWlCLEdBQUcsUUFBUSxDQUFDO0VBQ2xFO0NBQ0Q7Q0FFQSxNQUFNLHFCQUFxQixtQkFBbUIsU0FBUztDQUN2RCxNQUFNLGVBQWUsVUFBVTtDQUMvQixJQUFJLGdCQUFnQjtDQUNwQixJQUFJLHFCQUFxQjtDQUN6QixHQUFHO0VBQ0Y7RUFDQSxJQUFJLGdCQUFnQixzQkFDbkI7RUFHRCxJQUFJLGlDQUFpQyxXQUFXLGNBQWMsaUNBQWlDLEdBQzlGO0VBR0QsTUFBTSxtQkFBbUIsVUFBVTtFQUNuQyxNQUFNLFFBQVEsTUFBTSxnQkFBZ0I7RUFFcEMsSUFBSSxNQUFNLFNBQVMsR0FDbEI7RUFHRCxJQUFJLE1BQU0sU0FBUyxRQUFRO0dBRTFCLElBQUksTUFBTSxXQUFXLElBQ3BCO0dBR0QscUJBQXFCO0VBQ3RCO0VBRUEsUUFBUSxNQUFNLE1BQWQ7R0FDQyxLQUFLLFFBQ0osT0FBTztHQUNSLEtBQUssUUFDSixPQUFPO0dBQ1I7SUFDQyxJQUNDLENBQUMsc0JBQ0UsTUFBTSxTQUFTLFFBRWxCO0lBR0QsSUFDQyxzQkFDRyxNQUFNLFNBQVMsNEJBR2xCLE9BQU8sc0JBQXNCLG9CQUFvQixNQUFNLElBQUksSUFBSSxjQUFjLEtBQUE7SUFHOUUsSUFBSTtLQUNILE1BQU0sV0FBVyxXQUFXLE1BQU0sU0FBUyxHQUFHO01BQzdDLGVBQWUscUJBQXFCLFVBQWlDLFVBQVUsU0FBUztNQUN4RixRQUFRO0tBQ1QsQ0FBQztJQUNGLFNBQVMsT0FBTztLQUNmLElBQ0MsQ0FBQyx1QkFFQSxpQkFBaUIsd0JBQ2QsaUJBQWlCQyxtQkFHckIsT0FBTztLQUdSLE1BQU07SUFDUDtFQUNGO0VBR0EsSUFBSSxVQUFVLFlBQVksa0JBQ3pCO0NBRUYsU0FBUyxVQUFVLFdBQVcsSUFBSSxVQUFVLFNBQVM7Q0FFckQsT0FBTztBQUNSOztBQy9HQSxJQUFNLDhCQUE4QjtBQUNwQyxJQUFNLHFDQUFxQztBQUUzQyxlQUFzQixVQUFVLFdBQVc7Q0FDMUMsSUFBSSxpQkFBaUI7Q0FDckIsSUFBSTtFQUNILGVBQWUsYUFBYTtHQUMzQixNQUFNLHVCQUFPLElBQUksV0FBVyxFQUFFO0dBQzlCLE1BQU0sZUFBZSxXQUFXLE1BQU0sS0FBQSxHQUFXO0lBQ2hELGVBQWUsS0FBSztJQUNwQixRQUFRO0dBQ1QsQ0FBQztHQUNELE9BQU87SUFDTixJQUFJO0lBQ0osTUFBTSxPQUFPLE1BQU0sVUFBVSxVQUFVQyxTQUFlLENBQUM7R0FDeEQ7RUFDRDtFQUVBLE1BQU0sV0FBVyxXQUFXLElBQUk7R0FDL0IsZUFBZTtHQUNmLFFBQVE7RUFDVCxDQUFDO0VBQ0QsTUFBTSxvQkFBb0IsbUJBQW1CLFNBQVM7RUFDdEQsTUFBTSxxQkFBcUIsVUFBVTtFQUNyQyxJQUFJLHVCQUF1QjtFQUMzQixPQUFPLFVBQVUsV0FBVyxLQUFLLFVBQVUsU0FBUyxNQUFNO0dBQ3pEO0dBQ0EsSUFBSSx1QkFBdUIsNkJBQzFCO0dBR0QsSUFBSSxpQ0FBaUMsV0FBVyxvQkFBQSxRQUFtRCxHQUNsRztHQUdELE1BQU0sbUJBQW1CLFVBQVU7R0FDbkMsTUFBTSxTQUFTLE1BQU0sV0FBVztHQUNoQyxJQUFJLFVBQVUsT0FBTyxPQUFPO0dBQzVCLElBQ0MsQ0FBQyxPQUFPLFNBQVMsT0FBTyxLQUNyQixVQUFVLEdBQ1o7SUFDRCxpQkFBaUI7SUFDakI7R0FDRDtHQUVBLElBQUksV0FBVyxPQUFPLElBQUk7SUFBQztJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtHQUFJLENBQUMsR0FBRztJQUU1SCxNQUFNLHlCQUFTLElBQUksV0FBVyxFQUFFO0lBQ2hDLFdBQVcsTUFBTSxlQUFlLFdBQVcsUUFBUSxLQUFBLEdBQVc7S0FDN0QsZUFBZSxPQUFPO0tBQ3RCLFFBQVE7SUFDVCxDQUFDO0lBRUQsSUFBSSxXQUFXLFFBQVE7S0FBQztLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtJQUFJLENBQUMsR0FFdEgsT0FBTztLQUNOLEtBQUs7S0FDTCxNQUFNO0lBQ1A7SUFHRCxJQUFJLFdBQVcsUUFBUTtLQUFDO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0tBQU07S0FBTTtLQUFNO0lBQUksQ0FBQyxHQUV0SCxPQUFPO0tBQ04sS0FBSztLQUNMLE1BQU07SUFDUDtJQUdEO0dBQ0Q7R0FFQSxJQUNDLHFCQUNHLFVBQVUsb0NBQ1o7SUFDRCxpQkFBaUI7SUFDakI7R0FDRDtHQUVBLE1BQU0sV0FBVyxXQUFXLFNBQVM7SUFDcEMsZUFBZSxvQkFBb0IscUNBQXFDLFVBQVUsU0FBUztJQUMzRixRQUFRO0dBQ1QsQ0FBQztHQUdELElBQUksVUFBVSxZQUFZLGtCQUFrQjtJQUMzQyxpQkFBaUI7SUFDakI7R0FDRDtFQUNEO0NBQ0QsU0FBUyxPQUFPO0VBQ2YsSUFDQyxpQkFBaUJDLG9CQUNkLGlCQUFpQixzQkFFaEI7T0FBQSxtQkFBbUIsU0FBUyxHQUMvQixpQkFBaUI7RUFBQSxPQUdsQixNQUFNO0NBRVI7Q0FFQSxJQUFJLGdCQUNIO0NBSUQsT0FBTztFQUNOLEtBQUs7RUFDTCxNQUFNO0NBQ1A7QUFDRDs7Ozs7QUNwR0EsSUFBYSxpQ0FBaUM7QUFDOUMsSUFBTSw2QkFBNkI7QUFDbkMsSUFBTSx3Q0FBd0M7QUFDOUMsSUFBTSw4QkFBOEI7QUFDcEMsSUFBTSw0Q0FBNEM7QUFDbEQsSUFBTSw4QkFBOEI7QUFDcEMsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSwrQkFBK0I7QUFDckMsSUFBTSxvQ0FBb0M7QUFDMUMsSUFBTSw4QkFBOEI7QUFFcEMsU0FBZ0Isb0JBQW9CLFlBQVk7Q0FHL0MsSUFBSSxDQUFDLE9BQU8sU0FBUyxVQUFVLEdBQzlCLE9BQU87Q0FHUixPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxVQUFVLENBQUM7QUFDMUM7QUFFQSxTQUFTLDZCQUE2QixxQkFBcUI7Q0FFMUQsSUFBSSxDQUFDLE9BQU8sU0FBUyxtQkFBbUIsR0FDdkMsT0FBTztDQUdSLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLDRCQUE0QixLQUFLLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztBQUN6RjtBQUVBLFNBQVMsMEJBQTBCLFVBQVU7Q0FDNUMsSUFBSSxDQUFDLE9BQU8sU0FBUyxRQUFRLEdBQzVCLE9BQU8sT0FBTztDQUdmLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUTtBQUM1QjtBQUdBLFNBQVMsZ0JBQWdCLFdBQVc7Q0FFbkMsT0FBTzs7O0VBQW9EOztBQUM1RDtBQU9BLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDaEMsT0FBTyxPQUFPLFlBQVksSUFBSSxnQkFBZ0IsQ0FBQztBQUNoRDtBQUVBLFNBQVMsZUFBZSxRQUFRLFFBQVE7Q0FDdkMsSUFBSSxXQUFXLEtBQUEsR0FDZCxPQUFPLE9BQU8sS0FBSztDQUdwQixPQUFPLGVBQWU7Q0FFdEIsT0FBTyxRQUFRLEtBQUssQ0FDbkIsT0FBTyxLQUFLLEdBQ1osSUFBSSxTQUFTLFVBQVUsV0FBVztFQUNqQyxPQUFPLGlCQUFpQixlQUFlO0dBQ3RDLE9BQU8sT0FBTyxNQUFNO0dBQ3BCLE9BQU8sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQzVDLEdBQUcsRUFBQyxNQUFNLEtBQUksQ0FBQztDQUNoQixDQUFDLENBQ0YsQ0FBQztBQUNGO0FBRUEsU0FBUyxnQ0FBZ0MsUUFBUSxjQUFjO0NBQzlELE1BQU0sU0FBUyxPQUFPLFVBQVU7Q0FDaEMsSUFBSSxlQUFlO0NBQ25CLElBQUksZUFBZTtDQUNuQixJQUFJLG1CQUFtQjtDQUV2QixNQUFNLGVBQWUsT0FBTSxXQUFVO0VBQ3BDLElBQ0MsZ0JBQ0csa0JBRUg7RUFHRCxtQkFBbUI7RUFDbkIsTUFBTSxPQUFPLE9BQU8sTUFBTTtDQUMzQjtDQUVBLE9BQU8sSUFBSSxlQUFlO0VBQ3pCLE1BQU0sS0FBSyxZQUFZO0dBQ3RCLElBQUksZ0JBQWdCLGNBQWM7SUFDakMsV0FBVyxNQUFNO0lBQ2pCLE1BQU0sYUFBYTtJQUNuQjtHQUNEO0dBRUEsTUFBTSxFQUFDLE1BQU0sVUFBUyxNQUFNLE9BQU8sS0FBSztHQUN4QyxJQUNDLFFBQ0csQ0FBQyxPQUNIO0lBQ0QsZUFBZTtJQUNmLFdBQVcsTUFBTTtJQUNqQjtHQUNEO0dBRUEsTUFBTSxpQkFBaUIsZUFBZTtHQUN0QyxJQUFJLE1BQU0sU0FBUyxnQkFBZ0I7SUFDbEMsV0FBVyxRQUFRLE1BQU0sU0FBUyxHQUFHLGNBQWMsQ0FBQztJQUNwRCxnQkFBZ0I7SUFDaEIsV0FBVyxNQUFNO0lBQ2pCLE1BQU0sYUFBYTtJQUNuQjtHQUNEO0dBRUEsV0FBVyxRQUFRLEtBQUs7R0FDeEIsZ0JBQWdCLE1BQU07RUFDdkI7RUFDQSxNQUFNLE9BQU8sUUFBUTtHQUNwQixNQUFNLGFBQWEsTUFBTTtFQUMxQjtDQUNELENBQUM7QUFDRjtBQU1BLGVBQXNCLG1CQUFtQixPQUFPLFNBQVM7Q0FDeEQsT0FBTyxJQUFJLGVBQWUsT0FBTyxDQUFDLENBQUMsV0FBVyxLQUFLO0FBQ3BEO0FBY0EsSUFBYSxpQkFBYixNQUFhLGVBQWU7Q0FDM0I7Q0FDQTtDQUNBO0NBRUEsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sZ0NBQWdDLDZCQUE2QixTQUFTLG1CQUFtQjtFQUMvRixNQUFNLGdCQUFnQixTQUFTLGlCQUFpQjtFQUNoRCxJQUFJLGtCQUFrQixhQUFhLENBQUMsT0FBTyxjQUFjLGFBQWEsS0FBSyxpQkFBaUIsSUFDM0YsTUFBTSxJQUFJLFdBQVcsMkRBQTJEO0VBR2pGLEtBQUssVUFBVTtHQUNkLEdBQUc7R0FDSCxxQkFBcUI7RUFDdEI7RUFFQSxLQUFLLFlBQVk7R0FBQyxHQUFJLEtBQUssUUFBUSxtQkFBbUIsQ0FBQztHQUN0RDtJQUFDLElBQUk7SUFBUSxTQUFRLGNBQWEsS0FBSyxnQkFBZ0IsU0FBUztHQUFDO0dBQ2pFO0lBQUMsSUFBSTtJQUFrQixTQUFRLGNBQWEsS0FBSyxnQkFBZ0IsU0FBUztHQUFDO0VBQUM7RUFDN0UsS0FBSyxtQkFBbUI7R0FDdkIsYUFBYSxLQUFLLFFBQVE7R0FDMUI7RUFDRDtFQUNBLEtBQUssaUJBQWlCO0NBQ3ZCO0NBRUEsc0JBQXNCO0VBQ3JCLE9BQU8sRUFDTixHQUFHLEtBQUssaUJBQ1Q7Q0FDRDtDQUVBLDZCQUE2QixRQUFRO0VBQ3BDLE9BQU9DLGNBQXNCLGdCQUFnQixNQUFNLEdBQUcsS0FBSyxvQkFBb0IsQ0FBQztDQUNqRjtDQUVBLE1BQU0sZUFBZSxXQUFXLHdCQUF3QixHQUFHO0VBQzFELEtBQUssd0JBQXdCO0VBQzdCLE1BQU0sa0JBQWtCLFVBQVU7RUFFbEMsS0FBSyxNQUFNLFlBQVksS0FBSyxXQUFXO0dBQ3RDLElBQUk7R0FDSixJQUFJO0lBQ0gsV0FBVyxNQUFNLFNBQVMsT0FBTyxTQUFTO0dBQzNDLFNBQVMsT0FBTztJQUNmLElBQUksaUJBQWlCQyxrQkFDcEI7SUFHRCxJQUFJLGlCQUFpQixzQkFDcEI7SUFHRCxNQUFNO0dBQ1A7R0FFQSxJQUFJLFVBQ0gsT0FBTztHQUdSLElBQUksb0JBQW9CLFVBQVUsVUFDakM7RUFFRjtDQUNEO0NBRUEsTUFBTSxjQUFjLFdBQVc7RUFDOUIsSUFBSTtHQUNILE9BQU8sTUFBTSxLQUFLLGVBQWUsU0FBUztFQUMzQyxVQUFVO0dBQ1QsTUFBTSxVQUFVLE1BQU07RUFDdkI7Q0FDRDtDQUVBLE1BQU0sV0FBVyxPQUFPO0VBQ3ZCLElBQUksRUFBRSxpQkFBaUIsY0FBYyxpQkFBaUIsY0FDckQsTUFBTSxJQUFJLFVBQVUsMEZBQTBGLE9BQU8sTUFBTSxHQUFHO0VBRy9ILE1BQU0sU0FBUyxpQkFBaUIsYUFBYSxRQUFRLElBQUksV0FBVyxLQUFLO0VBRXpFLElBQUksRUFBRSxRQUFRLFNBQVMsSUFDdEI7RUFHRCxPQUFPLEtBQUssY0FBY0MsV0FBbUIsUUFBUSxLQUFLLG9CQUFvQixDQUFDLENBQUM7Q0FDakY7Q0FFQSxNQUFNLFNBQVMsTUFBTTtFQUNwQixLQUFLLFFBQVEsUUFBUSxlQUFlO0VBQ3BDLE1BQU0sWUFBWUMsU0FBaUIsTUFBTSxLQUFLLG9CQUFvQixDQUFDO0VBQ25FLE9BQU8sS0FBSyxjQUFjLFNBQVM7Q0FDcEM7Q0FFQSxNQUFNLFdBQVcsUUFBUTtFQUN4QixLQUFLLFFBQVEsUUFBUSxlQUFlO0VBQ3BDLE1BQU0sWUFBWSxLQUFLLDZCQUE2QixNQUFNO0VBQzFELE9BQU8sS0FBSyxjQUFjLFNBQVM7Q0FDcEM7Q0FFQSxNQUFNLFNBQVMsTUFBTTtFQUNwQixLQUFLLFFBQVEsUUFBUSxlQUFlO0VBQ3BDLE1BQU0sRUFBQyxVQUFVLHdCQUF1QixNQUFNLGdCQUFnQixTQUFTO0VBQ3ZFLElBQUk7RUFDSixJQUFJO0dBQ0gsWUFBWSxNQUFNLFNBQVMsTUFBTTtJQUNoQyxHQUFHLEtBQUssb0JBQW9CO0lBQzVCLGlCQUFpQjtHQUNsQixDQUFDO0VBQ0YsU0FBUyxPQUFPO0dBQ2YsSUFBSSxpQkFBaUIscUJBQ3BCO0dBR0QsTUFBTTtFQUNQO0VBRUEsT0FBTyxLQUFLLGNBQWMsU0FBUztDQUNwQztDQUVBLE1BQU0sa0JBQWtCLFFBQVEsU0FBUztFQUN4QyxLQUFLLFFBQVEsUUFBUSxlQUFlO0VBQ3BDLE1BQU0sYUFBYSxvQkFBb0IsU0FBUyxjQUFBLElBQTRDO0VBQzVGLElBQUk7RUFDSixJQUFJLGlCQUFpQjtFQUVyQixNQUFNLFNBQVMsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLElBQUksWUFBWTtFQUVoQixJQUFJO0dBQ0gsT0FBTyxZQUFZLFlBQVk7SUFDOUIsTUFBTSxFQUFDLE9BQU8sU0FBUSxNQUFNLGVBQWUsUUFBUSxLQUFLLFFBQVEsTUFBTTtJQUN0RSxJQUFJLFFBQVEsQ0FBQyxPQUFPO0tBQ25CLGlCQUFpQjtLQUNqQjtJQUNEO0lBRUEsT0FBTyxLQUFLLEtBQUs7SUFDakIsYUFBYSxNQUFNO0dBQ3BCO0dBRUEsSUFDQyxDQUFDLGtCQUNFLGNBQWMsWUFDaEI7SUFDRCxNQUFNLEVBQUMsT0FBTyxTQUFRLE1BQU0sZUFBZSxRQUFRLEtBQUssUUFBUSxNQUFNO0lBQ3RFLElBQUksUUFBUSxDQUFDLE9BQ1osaUJBQWlCO1NBQ1g7S0FDTixPQUFPLEtBQUssS0FBSztLQUNqQixhQUFhLE1BQU07SUFDcEI7R0FDRDtFQUNELFVBQVU7R0FDVCxPQUFPLFlBQVk7RUFDcEI7RUFFQSxJQUFJLFlBQVksR0FBRztHQUNsQixNQUFNLFNBQVMsT0FBTyxXQUFXLElBQUksT0FBTyxLQUFLLGtCQUFrQixNQUFNO0dBQ3pFLElBQUk7SUFDSCxtQkFBbUIsTUFBTSxLQUFLLFdBQVcsT0FBTyxTQUFTLEdBQUcsVUFBVSxDQUFDO0dBQ3hFLFNBQVMsT0FBTztJQUNmLElBQUksRUFBRSxpQkFBaUJGLG1CQUN0QixNQUFNO0lBR1AsbUJBQW1CLEtBQUE7R0FDcEI7R0FFQSxJQUNDLENBQUMsa0JBQ0Usa0JBQWtCLFFBQVEsU0FFN0IsbUJBQW1CO0lBQ2xCLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFFRjtFQUdBLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0dBQzNDLE1BQU0sWUFBWTtJQUNqQixLQUFLLE1BQU0sU0FBUyxRQUNuQixXQUFXLFFBQVEsS0FBSztHQUUxQjtHQUNBLFVBQVUsT0FBTyxZQUFZO0lBQzVCLFdBQVcsUUFBUSxLQUFLO0dBQ3pCO0VBQ0QsQ0FBQztFQUVELE1BQU0sWUFBWSxPQUFPLFlBQVksZUFBZTtFQUNwRCxVQUFVLFdBQVc7RUFFckIsT0FBTztDQUNSO0NBRUEsTUFBTSxXQUFXLFdBQVc7RUFDM0IsSUFBSSxLQUFLLGtCQUFrQiw2QkFDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxNQUFNLHdCQUF3QixnQ0FBZ0MsSUFEdEMsWUFBWSxTQUNvQyxDQUFDLENBQUMsUUFBUSxHQUFHLHFDQUFxQztFQUMxSCxNQUFNLGlCQUFpQixtQkFBbUIsU0FBUztFQUNuRCxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBRUosSUFBSSxnQkFBZ0I7R0FDbkIsTUFBTSxvQkFBb0IsSUFBSSxnQkFBZ0I7R0FDOUMsVUFBVSxpQkFBaUI7SUFDMUIsa0JBQWtCLE1BQU0sSUFBSSxhQUFhLDZCQUE2QiwwQ0FBMEMsTUFBTSxjQUFjLENBQUM7R0FDdEksR0FBRyx5Q0FBeUM7R0FDNUMsY0FBYyxLQUFLLFFBQVEsV0FBVyxLQUFBLElBQ25DLGtCQUFrQixTQUNsQixZQUFZLElBQUksQ0FBQyxLQUFLLFFBQVEsUUFBUSxrQkFBa0IsTUFBTSxDQUFDO0dBQ2xFLGNBQWMsSUFBSSxlQUFlO0lBQ2hDLEdBQUcsS0FBSztJQUNSLFFBQVE7R0FDVCxDQUFDO0dBQ0QsWUFBWSxpQkFBaUIsS0FBSyxpQkFBaUI7RUFDcEQsT0FDQyxLQUFLO0VBR04sSUFBSTtHQUNILHFCQUFxQixPQUFPLGVBQWUsS0FBQSxDQUFNLFdBQVcscUJBQXFCO0VBQ2xGLFNBQVMsT0FBTztHQUNmLElBQ0MsT0FBTyxTQUFTLGdCQUNiLGFBQWEsUUFBUSxTQUFTLGdCQUVqQyxNQUFNO0VBSVIsVUFBVTtHQUNULGFBQWEsT0FBTztHQUNwQixJQUFJLENBQUMsZ0JBQ0osS0FBSztFQUVQO0VBRUEsSUFBSSxvQkFBb0IsUUFBUSxPQUMvQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0NBQ0Q7Q0FFQSxNQUFNLFFBQVEsU0FBUztFQUN0QixPQUFPLFdBQVcsS0FBSyxRQUFRLFFBQVEsT0FBTztDQUMvQztDQUVBLFlBQVksUUFBUSxTQUFTO0VBQzVCLE9BQU8sS0FBSyxNQUFNLGNBQWMsUUFBUSxTQUFTLFFBQVEsR0FBRyxPQUFPO0NBQ3BFO0NBR0EsTUFBTSxnQkFBZ0IsV0FBVztFQUNoQyxLQUFLLFNBQVMsSUFBSSxXQUFXLDhCQUE4QjtFQUczRCxJQUFJLFVBQVUsU0FBUyxTQUFTLEtBQUEsR0FDL0IsVUFBVSxTQUFTLE9BQU8sT0FBTztFQUdsQyxLQUFLLFlBQVk7RUFFakIsSUFBSSxtQkFBbUIsU0FBUyxHQUFHO0dBQ2xDLE1BQU0sVUFBVSxXQUFXLEtBQUssUUFBUTtJQUFDLFFBQVE7SUFBRyxXQUFXO0dBQUksQ0FBQztHQUNwRSxJQUFJLEtBQUssTUFBTTtJQUFDO0lBQU07SUFBTTtHQUFHLENBQUMsR0FDL0IsT0FBTyxLQUFLLFdBQVcsU0FBUztFQUVsQztFQUVBLE1BQU0sVUFBVSxXQUFXLEtBQUssUUFBUTtHQUFDLFFBQVE7R0FBSSxXQUFXO0VBQUksQ0FBQztFQUlyRSxJQUFJLEtBQUssTUFBTSxDQUFDLElBQU0sRUFBSSxDQUFDLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFNLEdBQUksQ0FBQyxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNLENBQUMsS0FBTSxDQUFJLENBQUMsR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTSxDQUFDLElBQU0sRUFBSSxDQUFDLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFNLEVBQUksQ0FBQyxHQUFHO0dBQzdCLE1BQU0sVUFBVSxXQUFXLEtBQUssUUFBUTtJQUFDLFFBQVE7SUFBSSxXQUFXO0dBQUksQ0FBQztHQUVyRSxJQUNDLEtBQUssWUFBWSxhQUFhLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDdEMsS0FBSyxZQUFZLFVBQVUsRUFBQyxRQUFRLEdBQUUsQ0FBQyxHQUUxQyxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUdELE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0VBQ0Q7RUFFQSxJQUNDLEtBQUssTUFBTSxDQUFDLElBQU0sR0FBSSxDQUFDLEtBQ3BCLEtBQUssTUFBTSxDQUFDLElBQU0sR0FBSSxDQUFDLEdBRTFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxLQUFNLEdBQUksQ0FBQyxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNLENBQUMsSUFBTSxHQUFJLENBQUMsR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFLRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtFQUFJLENBQUMsR0FBRztHQUNuQyxJQUFJLEtBQUsseUJBQXlCLDhCQUNqQztHQUdELEtBQUs7R0FFTCxNQUFNLEtBQUssVUFBVSxPQUFPLENBQUM7R0FDN0IsT0FBTyxLQUFLLGdCQUFnQixTQUFTO0VBQ3RDO0VBRUEsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ2hDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ2hDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBRyxDQUFDLEdBQy9CLE9BQU8sS0FBSyxXQUFXLFNBQVM7RUFHakMsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ2hDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksS0FBSyxHQUFHO0dBQzVCLE1BQU0sV0FBVyxXQUFXLEdBQUc7SUFDOUIsZUFBZTtJQUNmLFFBQVE7R0FDVCxDQUFDO0dBQ0QsTUFBTSxrQkFBa0IsTUFBTSxVQUFVLFVBQVUsbUJBQW1CO0dBQ3JFLE1BQU0sb0JBQW9CLG1CQUFtQixTQUFTO0dBQ3RELElBQ0MsQ0FBQyxPQUFPLFNBQVMsZUFBZSxLQUM3QixrQkFBa0IsS0FHcEIsc0JBRUMsa0JBQWtCLCtCQUNkLFVBQVUsV0FBVyxrQkFBbUIsOEJBSTlDO0dBR0QsSUFBSSxVQUFVLFdBQVcsa0JBQWtCLFVBQVUsU0FBUyxNQUFNO0lBQ25FLElBQUksbUJBQ0g7SUFHRCxPQUFPO0tBQ04sS0FBSztLQUNMLE1BQU07SUFDUDtHQUNEO0dBRUEsSUFBSTtJQUNILE1BQU0sV0FBVyxXQUFXLGlCQUFpQjtLQUM1QyxlQUFlLG9CQUFvQiw4QkFBOEIsVUFBVSxTQUFTO0tBQ3BGLFFBQVE7SUFDVCxDQUFDO0dBQ0YsU0FBUyxPQUFPO0lBQ2YsSUFBSSxpQkFBaUJBLGtCQUNwQjtJQUdELE1BQU07R0FDUDtHQUVBLElBQUksS0FBSyx5QkFBeUIsOEJBQ2pDO0dBR0QsS0FBSztHQUNMLE9BQU8sS0FBSyxlQUFlLFdBQVcsS0FBSyxxQkFBcUI7RUFDakU7RUFHQSxJQUFJLEtBQUssWUFBWSxLQUFLLEdBQ3pCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsS0FDRSxLQUFLLE9BQU8sT0FBTyxNQUFRLEtBQUssT0FBTyxPQUFPLE9BQzVDLEtBQUssTUFBTSxDQUFDLElBQU0sRUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsR0FFdkMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFNRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtFQUFJLENBQUMsR0FBRztHQUNuQyxJQUFJLEtBQUssTUFBTSxDQUFDLEdBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEdBQ2pDLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBR0QsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFDRDtFQUVBLElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksTUFBTSxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLE1BQU0sR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksTUFBTSxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUlELElBQUksS0FBSyxZQUFZLE1BQU0sS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFNLENBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQUssS0FBSyxZQUFZLFFBQVEsRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUM1RyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLFFBQVEsRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUN2QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUtELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQUs7RUFBRyxDQUFDLEdBQ3BDLE9BQU8sVUFBVSxTQUFTO0VBRzNCLElBQUksS0FBSyxZQUFZLE1BQU0sR0FBRztHQUU3QixNQUFNLFVBQVUsT0FBTyxFQUFFO0dBQ3pCLE1BQU0sdUJBQU8sSUFBSSxXQUFXLENBQUM7R0FDN0IsTUFBTSxVQUFVLFdBQVcsSUFBSTtHQUcvQixJQUFJLFdBQVcsTUFBTTtJQUFDO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07R0FBSSxDQUFDLEdBQ3BFLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBSUQsSUFBSSxXQUFXLE1BQU07SUFBQztJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtHQUFJLENBQUMsR0FDOUQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFJLFdBQVcsTUFBTTtJQUFDO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0dBQUksQ0FBQyxHQUM5RCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUlELElBQUksV0FBVyxNQUFNO0lBQUM7SUFBTTtJQUFNO0lBQU07SUFBTTtHQUFJLENBQUMsR0FDbEQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFJLFdBQVcsTUFBTTtJQUFDO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0dBQUksQ0FBQyxHQUM5RCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUlELElBQUksV0FBVyxNQUFNO0lBQUM7SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFNO0lBQU07R0FBSSxDQUFDLEdBQzlELE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBSUQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFDRDtFQUVBLElBQ0MsS0FBSyxNQUFNLENBQUMsSUFBTSxFQUFJLENBQUMsS0FDcEI7R0FBQztHQUFLO0dBQUs7RUFBRyxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU8sRUFBRSxLQUN2QztHQUFDO0dBQUs7R0FBSztFQUFHLENBQUMsQ0FBQyxTQUFTLEtBQUssT0FBTyxFQUFFLEdBRTFDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksTUFBTSxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQ0MsS0FBSyxZQUFZLE1BQU0sTUFFdEIsS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDN0MsS0FBSyxZQUFZLFFBQVEsRUFBQyxRQUFRLEVBQUMsQ0FBQyxJQUd4QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQ0MsS0FBSyxZQUFZLE1BQU0sTUFFdEIsS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDN0MsS0FBSyxZQUFZLFFBQVEsRUFBQyxRQUFRLEVBQUMsQ0FBQyxJQUd4QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEtBQUssS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQzlFLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBSUQsSUFBSSxLQUFLLFlBQVksTUFBTSxHQUMxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLE1BQU0sR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksTUFBTSxHQUUxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBSUQsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFNLEVBQUksQ0FBQyxHQUFHO0dBQzdCLE1BQU0sV0FBVyxNQUFNLEtBQUssZUFBZSxLQUFLO0dBQ2hELElBQUksVUFDSCxPQUFPO0VBRVQ7RUFHQSxJQUFJLEtBQUssTUFBTSxDQUFDLElBQU0sRUFBSSxDQUFDLEdBQUc7R0FDN0IsTUFBTSxXQUFXLE1BQU0sS0FBSyxlQUFlLElBQUk7R0FDL0MsSUFBSSxVQUNILE9BQU87RUFFVDtFQUVBLElBQUksS0FBSyxZQUFZLE1BQU0sR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUN0QyxPQUFPLFdBQVcsU0FBUztFQUc1QixJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFDQyxLQUFLLFlBQVksTUFBTSxLQUNwQixLQUFLLFlBQVksTUFBTSxHQUUxQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUN0QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEtBQUssS0FBSyxZQUFZLE1BQU0sR0FDdEQsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFDQyxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsS0FDaEMsS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEtBQ25DLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxLQUNuQyxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FFdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUN0QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLE1BQU0sR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxJQUFJLEtBQUssWUFBWSxNQUFNLEtBQUssS0FBSyxZQUFZLE1BQU0sR0FDdEQsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFLRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQzVDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksT0FBTyxHQUMzQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLE9BQU8sR0FBRyxPQUFPLEdBQ3JDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFDQyxLQUFLLFlBQVksU0FBUyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ2xDLEtBQUssWUFBWSxTQUFTLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDckMsS0FBSyxZQUFZLFNBQVMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUNyQyxLQUFLLFlBQVksU0FBUyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ3JDLEtBQUssWUFBWSxTQUFTLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDckMsS0FBSyxZQUFZLFNBQVMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUNyQyxLQUFLLFlBQVksU0FBUyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ3JDLEtBQUssWUFBWSxTQUFTLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDckMsS0FBSyxZQUFZLFNBQVMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUNyQyxLQUFLLFlBQVksU0FBUyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ3JDLEtBQUssWUFBWSxTQUFTLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FDckMsS0FBSyxZQUFZLFNBQVMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUV4QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUlELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQUc7R0FFekMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxFQUFJLEdBQUc7SUFBQyxRQUFRO0lBQUcsTUFBTSxDQUFDLEdBQUk7R0FBQyxDQUFDLEdBQy9DLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBSUQsSUFBSSxLQUFLLE1BQU0sQ0FBQyxFQUFJLEdBQUc7SUFBQyxRQUFRO0lBQUcsTUFBTSxDQUFDLEdBQUk7R0FBQyxDQUFDLEdBQy9DLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0VBRUY7RUFFQSxJQUFJLEtBQUssWUFBWSxNQUFNLEdBQzFCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FBRztHQUl6QyxNQUFNLHlCQUFBLFVBQXlDLElBQUksS0FBSyxRQUFRLENBQUM7R0FDakUsSUFBSSx5QkFBeUIsS0FBSywwQkFBMEIsSUFDM0QsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFBLFVBRGtELElBQUksS0FBSyxRQUFRLENBQ3ZDLElBQUksSUFDL0IsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFFRjtFQUVBLElBQUksS0FBSyxZQUFZLE1BQU0sR0FDMUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFLRCxJQUFJLEtBQUssWUFBWSxPQUFPLEdBQzNCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBS0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ2xELE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksUUFBUSxHQUM1QixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUNsRCxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQ0MsS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUcsQ0FBQyxNQUMxQyxLQUFLLE9BQU8sT0FBTyxLQUFPLEtBQUssT0FBTyxPQUFPLElBRWpELE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksUUFBUSxHQUM1QixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxZQUFZLElBQUksR0FBRztHQUMzQixNQUFNLFVBQVUsSUFBSUcsV0FBaUIsR0FBRyxRQUFRLENBQUMsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDO0dBQ3BFLElBQUksSUFBQSxPQUFBLFVBQUEsR0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLEtBQUssV0FBVyxPQUFRLFdBQVcsTUFDM0QsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFFRjtFQUVBLElBQUksS0FBSyxZQUFZLFFBQVEsR0FDNUIsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFLRCxJQUFJLEtBQUssWUFBWSxTQUFTLEdBQzdCLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksU0FBUyxHQUFHO0dBQ2hDLE1BQU0sVUFBVSxPQUFPLENBQUM7R0FFeEIsSUFBSSxNQURpQixVQUFVLFVBQVUsSUFBSUEsV0FBaUIsSUFBSSxPQUFPLENBQUMsTUFDM0QsaUJBQ2QsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FHRCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtFQUNEO0VBRUEsSUFDQyxLQUFLLFlBQVksUUFBUSxLQUd2QjtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQUs7RUFBSSxDQUFDLENBQUMsTUFBSyxVQUFTLEtBQUssWUFBWSxPQUFPLEVBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxHQUVsRixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUtELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDOUQsT0FBTyxVQUFVLFNBQVM7RUFHM0IsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUM5RCxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDOUQsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxJQUNDLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQzdDLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ2hELEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ2hELEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEdBRW5ELE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBS0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3BFLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksV0FBVyxHQUMvQixPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQU9ELElBQ0MsS0FBSyxZQUFZLFFBQVEsRUFBQyxRQUFRLEVBQUMsQ0FBQyxNQUNoQyxLQUFLLE9BQU8sS0FBSyxRQUFVLEdBQzlCO0dBR0QsTUFBTSxhQUFhLElBQUlBLFdBQWlCLEdBQUcsUUFBUSxDQUFDLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUs7R0FDakcsUUFBUSxZQUFSO0lBQ0MsS0FBSztJQUNMLEtBQUssUUFDSixPQUFPO0tBQUMsS0FBSztLQUFRLE1BQU07SUFBWTtJQUN4QyxLQUFLLFFBQ0osT0FBTztLQUFDLEtBQUs7S0FBUSxNQUFNO0lBQVk7SUFDeEMsS0FBSyxRQUNKLE9BQU87S0FBQyxLQUFLO0tBQVEsTUFBTTtJQUFxQjtJQUNqRCxLQUFLO0lBQ0wsS0FBSyxRQUNKLE9BQU87S0FBQyxLQUFLO0tBQVEsTUFBTTtJQUFZO0lBQ3hDLEtBQUs7SUFDTCxLQUFLLFFBQ0osT0FBTztLQUFDLEtBQUs7S0FBUSxNQUFNO0lBQXFCO0lBQ2pELEtBQUssTUFDSixPQUFPO0tBQUMsS0FBSztLQUFPLE1BQU07SUFBaUI7SUFDNUMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLLFFBQ0osT0FBTztLQUFDLEtBQUs7S0FBTyxNQUFNO0lBQWE7SUFDeEMsS0FBSyxPQUNKLE9BQU87S0FBQyxLQUFLO0tBQU8sTUFBTTtJQUFXO0lBQ3RDLEtBQUssT0FDSixPQUFPO0tBQUMsS0FBSztLQUFPLE1BQU07SUFBVztJQUN0QyxLQUFLLE9BQ0osT0FBTztLQUFDLEtBQUs7S0FBTyxNQUFNO0lBQWE7SUFDeEMsS0FBSyxPQUNKLE9BQU87S0FBQyxLQUFLO0tBQU8sTUFBTTtJQUFXO0lBQ3RDLEtBQUssT0FDSixPQUFPO0tBQUMsS0FBSztLQUFPLE1BQU07SUFBVztJQUN0QyxLQUFLLE9BQ0osT0FBTztLQUFDLEtBQUs7S0FBTyxNQUFNO0lBQVc7SUFDdEMsS0FBSyxPQUNKLE9BQU87S0FBQyxLQUFLO0tBQU8sTUFBTTtJQUFXO0lBQ3RDLEtBQUssT0FDSixPQUFPO0tBQUMsS0FBSztLQUFPLE1BQU07SUFBbUI7SUFDOUM7S0FDQyxJQUFJLFdBQVcsV0FBVyxJQUFJLEdBQUc7TUFDaEMsSUFBSSxXQUFXLFdBQVcsS0FBSyxHQUM5QixPQUFPO09BQUMsS0FBSztPQUFPLE1BQU07TUFBYTtNQUd4QyxPQUFPO09BQUMsS0FBSztPQUFPLE1BQU07TUFBWTtLQUN2QztLQUVBLE9BQU87TUFBQyxLQUFLO01BQU8sTUFBTTtLQUFXO0dBQ3ZDO0VBQ0Q7RUFJQSxJQUFJLEtBQUssWUFBWSxjQUFjLEdBQ2xDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBTUQsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FBRztHQUN6QyxJQUFJLEtBQUssWUFBWSxRQUFRLEVBQUMsUUFBUSxFQUFDLENBQUMsR0FDdkMsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FHRCxJQUFJLEtBQUssTUFBTTtJQUFDO0lBQU07SUFBTTtHQUFJLEdBQUcsRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUM3QyxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUdELElBQUksS0FBSyxNQUFNO0lBQUM7SUFBTTtJQUFNO0lBQU07R0FBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsR0FDbkQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFJLEtBQUssTUFBTTtJQUFDO0lBQU07SUFBTTtJQUFNO0dBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEdBQ25ELE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0VBRUY7RUFFQSxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEYsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUMxRSxPQUFPLFVBQVUsU0FBUztFQUczQixJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDdEYsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxLQUFLLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtFQUFJLENBQUMsS0FBSyxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBSSxDQUFDLE1BQU0sS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsR0FDekgsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLEdBQUcsRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUNuRyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQUc7R0FHekYsTUFBTSxVQUFVLE9BQU8sRUFBRTtHQUV6QixRQUFRLE1BRFcsVUFBVSxVQUFVLElBQUlBLFdBQWlCLEdBQUcsT0FBTyxDQUFDLEdBQ3ZFO0lBQ0MsS0FBSyxRQUNKLE9BQU87S0FDTixLQUFLO0tBQ0wsTUFBTTtJQUNQO0lBQ0QsS0FBSyxRQUNKLE9BQU87S0FDTixLQUFLO0tBQ0wsTUFBTTtJQUNQO0lBQ0QsS0FBSyxRQUNKLE9BQU87S0FDTixLQUFLO0tBQ0wsTUFBTTtJQUNQO0lBQ0QsS0FBSyxRQUNKLE9BQU87S0FDTixLQUFLO0tBQ0wsTUFBTTtJQUNQO0lBQ0QsU0FDQztHQUNGO0VBQ0Q7RUFFQSxJQUNDLEtBQUssTUFBTSxDQUFDLEtBQU0sRUFBSSxDQUFDLEtBQ3BCLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FFdEYsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTSxDQUFDLEtBQU0sR0FBSSxDQUFDLEdBQUc7R0FDN0IsSUFBSSxLQUFLLFlBQVksVUFBVTtJQUFDLFFBQVE7SUFBRyxVQUFVO0dBQVUsQ0FBQyxHQUMvRCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUdEO0VBQ0Q7RUFFQSxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBRTlELE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBSUQsSUFBSSxLQUFLLFlBQVksTUFBTSxLQUFLLEtBQUssWUFBWSxRQUFRLEVBQUMsUUFBUSxHQUFFLENBQUMsR0FDcEUsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFJRCxNQUFNLFVBQVUsV0FBVyxLQUFLLFFBQVE7R0FBQyxRQUFRLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxJQUFJO0dBQUcsV0FBVztFQUFJLENBQUM7RUFFekcsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtFQUFJLEdBQUcsRUFBQyxRQUFRLEdBQUUsQ0FBQyxHQUNwRCxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUlELElBQUksS0FBSyxZQUFZLFNBQVMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUFLLEtBQUssWUFBWSxNQUFNLEVBQUMsUUFBUSxHQUFFLENBQUMsR0FDaEYsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFLRCxJQUFJLEtBQUssWUFBWSxRQUFRLEdBQUc7R0FDL0IsSUFBSSxLQUFLLFlBQVksU0FBUyxFQUFDLFFBQVEsRUFBQyxDQUFDLEdBQ3hDLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBR0QsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFDLFFBQVEsRUFBQyxDQUFDLEdBQzVDLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0VBRUY7RUFHQSxJQUFJLEtBQUssWUFBWSxpQkFBaUIsR0FDckMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxrQkFBa0IsR0FDdEMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSxxQkFBcUIsR0FDekMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxLQUFLLEtBQUssT0FBTyxVQUFVLElBQUk7R0FDckUsTUFBTSxXQUFXLElBQUksU0FBUyxLQUFLLE9BQU8sTUFBTSxDQUFDLENBQUMsVUFBVSxJQUFJLElBQUk7R0FFcEUsSUFBSSxXQUFXLE1BQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxJQUNyRCxJQUFJO0lBQ0gsTUFBTSxTQUFTLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxLQUFLLE9BQU8sU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDO0lBRy9FLElBRmEsS0FBSyxNQUFNLE1BRWpCLENBQUMsQ0FBQyxPQUNSLE9BQU87S0FDTixLQUFLO0tBQ0wsTUFBTTtJQUNQO0dBRUYsUUFBUSxDQUFDO0VBRVg7RUFFQSxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ2xHLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLFlBQVksUUFBUSxFQUFDLFFBQVEsR0FBRSxDQUFDLEdBQ3hDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBSUQsSUFBSSxLQUFLLE1BQU0sQ0FBQyxFQUFJLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFJLEdBQUcsRUFBQyxRQUFRLElBQUcsQ0FBQyxHQUN6RCxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUlELElBQUksS0FBSyxNQUFNLENBQUMsRUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFJLEdBQUcsRUFBQyxRQUFRLElBQUcsQ0FBQyxHQUN0RSxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLEdBQUcsRUFBQyxRQUFRLEdBQUUsQ0FBQyxHQUM1RSxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxHQUFHLEVBQUMsUUFBUSxJQUFHLENBQUMsR0FDckQsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RJLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDOUcsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssWUFBWSx3QkFBd0IsR0FDNUMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUNDLEtBQUssTUFBTSxDQUFDLElBQU0sRUFBSSxHQUFHLEVBQUMsUUFBUSxHQUFFLENBQUMsTUFFcEMsS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0VBQUksR0FBRyxFQUFDLFFBQVEsRUFBQyxDQUFDLEtBQ3ZDLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtFQUFJLEdBQUcsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUMxQyxLQUFLLE1BQU07R0FBQztHQUFNO0dBQU07RUFBSSxHQUFHLEVBQUMsUUFBUSxFQUFDLENBQUMsSUFHOUMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUM5RyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQU1ELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEtBQzNHLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUM5RyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUlELE1BQU0sVUFBVSxXQUFXLEtBQUssUUFBUTtHQUFDLFFBQVEsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLElBQUk7R0FBRyxXQUFXO0VBQUksQ0FBQztFQUd6RyxJQUFLLEtBQUssWUFBWSxTQUFTLEVBQUMsUUFBUSxJQUFHLENBQUMsTUFBTSxLQUFLLFlBQVksTUFBTSxFQUFDLFFBQVEsSUFBRyxDQUFDLEtBQUssS0FBSyxZQUFZLEtBQUssRUFBQyxRQUFRLElBQUcsQ0FBQyxNQUN6SCxLQUFLLE1BQU07R0FBQztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7RUFBQyxHQUFHLEVBQUMsUUFBUSxJQUFHLENBQUMsS0FBSyx5QkFBeUIsS0FBSyxNQUFNLEdBQ3pGLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBR0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxLQUFNLEdBQUksQ0FBQyxHQUFHO0dBQzdCLE1BQU0sV0FBVztHQUNqQixJQUFJLEtBQUssWUFBWSxVQUFVO0lBQUMsUUFBUTtJQUFHO0dBQVEsQ0FBQyxHQUNuRCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUdELElBQUksS0FBSyxNQUFNLENBQUMsS0FBTSxFQUFJLEdBQUcsRUFBQyxRQUFRLEVBQUMsQ0FBQyxLQUFLLEtBQUssWUFBWSxrQkFBa0I7SUFBQyxRQUFRO0lBQUc7R0FBUSxDQUFDLEdBQ3BHLE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0dBR0QsSUFBSSxLQUFLLFlBQVksNENBQTRDO0lBQUMsUUFBUTtJQUFHO0dBQVEsQ0FBQyxHQUNyRixPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUdEO0VBQ0Q7RUFFQSxJQUFJLEtBQUssWUFBWSw2QkFBNkIsR0FDakQsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFTRCxNQUFNLDhCQUE4QjtFQUNwQyxNQUFNLDhCQUE4QjtFQUNwQyxJQUNDLFVBQVUscUJBQXFCLEtBQzVCLFVBQVUsU0FBUyxRQUFTLE9BQzlCO0dBQ0QsTUFBTSx3QkFBd0IsSUFBSSxXQUFXLDJCQUEyQjtHQUN4RSxNQUFNLFVBQVUsV0FBVyx1QkFBdUI7SUFDakQsVUFBVTtJQUNWLFFBQVE7SUFDUixXQUFXO0dBQ1osQ0FBQztHQUVELElBQUksV0FBVyx1QkFBdUIsY0FBYyxPQUFPLENBQUMsR0FDM0QsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFFRjtDQUNEO0NBR0EsTUFBTSxnQkFBZ0IsV0FBVztFQUNoQyxLQUFLLFNBQVMsSUFBSSxXQUFXLDhCQUE4QjtFQUMzRCxNQUFNLFdBQVcsMEJBQTBCLFVBQVUsU0FBUyxJQUFJO0VBR2xFLE1BQU0sVUFBVSxXQUFXLEtBQUssUUFBUTtHQUFDLFFBQVEsS0FBSyxJQUFJLEdBQUcsUUFBUTtHQUFHLFdBQVc7RUFBSSxDQUFDO0VBRXhGLElBQ0MsS0FBSyxNQUFNO0dBQUM7R0FBSztHQUFLO0dBQUs7RUFBSSxDQUFDLEtBQzdCLEtBQUssTUFBTTtHQUFDO0dBQUs7R0FBSztHQUFLO0VBQUksQ0FBQyxHQUVuQyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJLENBQUMsR0FDNUMsT0FBTztHQUNOLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFHRCxJQUFJLEtBQUssTUFBTTtHQUFDO0dBQU07R0FBTTtHQUFNO0VBQUksQ0FBQyxHQUN0QyxPQUFPO0dBQ04sS0FBSztHQUNMLE1BQU07RUFDUDtFQUdELElBQUksS0FBSyxNQUFNO0dBQUM7R0FBTTtHQUFNO0dBQU07RUFBSSxDQUFDLEdBQ3RDLE9BQU87R0FDTixLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBSUQsTUFBTSxVQUFVLFdBQVcsS0FBSyxRQUFRO0dBQUMsUUFBUSxLQUFLLElBQUksSUFBSSxLQUFLLFFBQVEscUJBQXFCLFFBQVE7R0FBRyxXQUFXO0VBQUksQ0FBQztFQUczSCxJQUFJLEtBQUssT0FBTyxVQUFXLElBQUksS0FBSyxRQUFRLHFCQUMzQyxLQUFLLElBQUksUUFBUSxHQUFHLFNBQVMsS0FBSyxRQUFRLHFCQUFxQixFQUFFLE9BQU87R0FDdkUsTUFBTSxPQUFPLEtBQUssU0FBUyxLQUFLO0dBQ2hDLElBQUksTUFDSCxPQUFPO0VBRVQ7Q0FFRjtDQUVBLE1BQU0sWUFBWSxhQUFhO0VBQzlCLE1BQU0sUUFBUSxNQUFNLEtBQUssVUFBVSxVQUFVLGNBQWNDLFlBQWtCQyxTQUFlO0VBQzVGLE1BQU0sS0FBSyxVQUFVLE9BQU8sRUFBRTtFQUM5QixRQUFRLE9BQVI7R0FDQyxLQUFLLE9BQ0osT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FDRCxLQUFLLE9BQ0osT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7RUFFRjtDQUNEO0NBRUEsTUFBTSxZQUFZLGFBQWE7RUFDOUIsTUFBTSxlQUFlLE1BQU0sS0FBSyxVQUFVLFVBQVUsY0FBY0QsWUFBa0JDLFNBQWU7RUFDbkcsSUFBSSxlQUFlLHFCQUNsQjtFQUdELElBQ0MsbUJBQW1CLEtBQUssU0FBUyxLQUM3QixJQUFLLGVBQWUsS0FBTyw2QkFFL0I7RUFHRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxFQUFFLEdBQUc7R0FDdEMsTUFBTSxXQUFXLE1BQU0sS0FBSyxZQUFZLFdBQVc7R0FDbkQsSUFBSSxVQUNILE9BQU87RUFFVDtDQUNEO0NBRUEsTUFBTSxlQUFlLGFBQWE7RUFDakMsTUFBTSxlQUFlO0dBQ3BCLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFFQSxNQUFNLFdBQVcsY0FBY0QsWUFBa0JDLFVBQUFBLENBQWlCLElBQUksS0FBSyxRQUFRLENBQUM7RUFDcEYsTUFBTSxhQUFhLGNBQWNDLFlBQWtCQyxVQUFBQSxDQUFpQixJQUFJLEtBQUssUUFBUSxDQUFDO0VBRXRGLElBQUksWUFBWSxJQUFJO0dBRW5CLElBQUksYUFBYSxHQUFHO0lBQ25CLElBQUksS0FBSyxZQUFZLE1BQU0sRUFBQyxRQUFRLEVBQUMsQ0FBQyxHQUNyQyxPQUFPO0tBQ04sS0FBSztLQUNMLE1BQU07SUFDUDtJQUdELElBQUksYUFBYSxHQUFHO0tBQ25CLE1BQU0sV0FBVyxjQUFjSCxZQUFrQkMsVUFBQUEsQ0FBaUIsSUFBSSxLQUFLLFFBQVEsQ0FBQztLQUNwRixNQUFNLFdBQVcsY0FBY0QsWUFBa0JDLFVBQUFBLENBQWlCLElBQUksS0FBSyxRQUFRLEVBQUU7S0FFckYsSUFDRSxZQUFZLE1BQVEsWUFBWSxPQUM3QixZQUFZLE1BQVEsWUFBWSxJQUNwQyxPQUFPO01BQ04sS0FBSztNQUNMLE1BQU07S0FDUDtJQUVGO0dBQ0Q7R0FFQSxJQUNDLG1CQUFtQixLQUFLLFNBQVMsS0FDOUIsWUFBWSxtQ0FFZixPQUFPO0dBR1IsTUFBTSxvQkFBb0IsbUJBQW1CLEtBQUssU0FBUyxJQUFJLDhCQUE4QixLQUFLLFVBQVUsU0FBUztHQUVySCxJQUFJO0lBQ0gsTUFBTSxXQUFXLEtBQUssV0FBVyxXQUFXO0tBQzNDLGVBQWU7S0FDZixRQUFRO0lBQ1QsQ0FBQztHQUNGLFNBQVMsT0FBTztJQUNmLElBQUksaUJBQWlCTCxrQkFDcEI7SUFHRCxNQUFNO0dBQ1A7R0FFQSxJQUFJO0dBQ0osSUFBSTtJQUNILFdBQVcsTUFBTSxLQUFLLFlBQVksV0FBVztHQUM5QyxTQUFTLE9BQU87SUFDZixJQUFJLGlCQUFpQkEsa0JBQ3BCO0lBR0QsTUFBTTtHQUNQO0dBRUEsT0FBTyxZQUFZO0VBQ3BCO0VBRUEsSUFBSSxZQUFZLElBQ2YsT0FBTztDQUVUOzs7Ozs7O0NBUUEsU0FBUyxRQUFRO0VBQ2hCLElBQUksS0FBSyxNQUFNLENBQUMsS0FBTSxHQUFJLEdBQUc7R0FBQztHQUFRLE1BQU0sQ0FBQyxLQUFNLEdBQUk7RUFBQyxDQUFDLEdBQUc7R0FFM0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxFQUFJLEdBQUc7SUFBQyxRQUFRLFNBQVM7SUFBRyxNQUFNLENBQUMsRUFBSTtHQUFDLENBQUMsR0FDeEQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFJLEtBQUssTUFBTSxDQUFDLEtBQU0sR0FBSSxHQUFHLEVBQUMsT0FBTSxDQUFDLEdBQ3BDO0dBSUQsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFJLEdBQUc7SUFBQyxRQUFRLFNBQVM7SUFBRyxNQUFNLENBQUMsRUFBSTtHQUFDLENBQUMsR0FDeEQ7R0FJRCxJQUFJLEtBQUssTUFBTSxDQUFDLEdBQUksR0FBRztJQUFDLFFBQVEsU0FBUztJQUFHLE1BQU0sQ0FBQyxHQUFJO0dBQUMsQ0FBQyxHQUN4RDtHQUlELElBQUksS0FBSyxNQUFNLENBQUMsRUFBSSxHQUFHO0lBQUMsUUFBUSxTQUFTO0lBQUcsTUFBTSxDQUFDLEVBQUk7R0FBQyxDQUFDLEdBQ3hEO0dBS0QsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFJLEdBQUc7SUFBQyxRQUFRLFNBQVM7SUFBRyxNQUFNLENBQUMsQ0FBSTtHQUFDLENBQUMsR0FDeEQsT0FBTztJQUNOLEtBQUs7SUFDTCxNQUFNO0dBQ1A7R0FJRCxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUksR0FBRztJQUFDLFFBQVEsU0FBUztJQUFHLE1BQU0sQ0FBQyxDQUFJO0dBQUMsQ0FBQyxHQUN4RCxPQUFPO0lBQ04sS0FBSztJQUNMLE1BQU07R0FDUDtHQUlELElBQUksS0FBSyxNQUFNLENBQUMsQ0FBSSxHQUFHO0lBQUMsUUFBUSxTQUFTO0lBQUcsTUFBTSxDQUFDLENBQUk7R0FBQyxDQUFDLEdBQ3hELE9BQU87SUFDTixLQUFLO0lBQ0wsTUFBTTtHQUNQO0VBRUY7Q0FDRDtBQUNEO0FBRW1DLElBQUksSUFBSSxVQUFVO0FBQ25CLElBQUksSUFBSSxTQUFTOztBQ3I3RG5ELElBQU0sa0JBQWtCO0FBQ3hCLElBQWEscUJBQWIsY0FBd0MsK0JBQStCLFFBQVEsQ0FBQyxDQUFDLENBQ2pGO0FBQ0EsU0FBZ0IsWUFBWSxPQUFPLFdBQVcsMkJBQTJCO0NBQ3JFLElBQUksZ0JBQWdCLEtBQUssS0FBSyxHQUMxQixPQUFPLFNBQVMsT0FBTyxRQUFRO0NBRW5DLE9BQU8saUJBQWlCLEtBQUs7QUFDakM7QUFDQSxTQUFnQixpQkFBaUIsUUFBUTtDQUNyQyxPQUFPO0VBQ0gsYUFBYSxrQkFBa0I7RUFDL0IsaUJBQWlCLGdCQUFnQjtFQUNqQyxNQUFNLE9BQU8sS0FBSztFQUNsQixVQUFVLENBQUM7Q0FDZjtBQUNKOzs7Ozs7QUFNQSxTQUFnQixTQUFTLFdBQVcsV0FBVywyQkFBMkI7Q0FDdEUsSUFBSSxZQUFZO0NBQ2hCLEtBQUssSUFBSSxTQUFTLFVBQVUsUUFBUSxJQUFJLEdBQUcsVUFBVSxHQUFHLFNBQVMsVUFBVSxRQUFRLE1BQU0sU0FBUyxDQUFDLEdBQy9GLEVBQUU7Q0FFTixJQUFJLFlBQVksVUFDWixNQUFNLElBQUksbUJBQW1CLGNBQWMsVUFBVSx1QkFBdUIsVUFBVTtDQUUxRixNQUFNLFFBQVEsVUFBVSxNQUFNLElBQUk7Q0FDbEMsTUFBTSxXQUFXLENBQUM7Q0FDbEIsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN0QixNQUFNLFFBQVEsS0FBSyxNQUFNLGVBQWU7RUFDeEMsSUFBSSxPQUFPO0dBQ1AsTUFBTSxVQUFVLE9BQU8sU0FBUyxNQUFNLElBQUksRUFBRTtHQUM1QyxNQUFNLFVBQVUsT0FBTyxTQUFTLE1BQU0sSUFBSSxFQUFFO0dBQzVDLE1BQU0sS0FBSyxNQUFNLEVBQUUsQ0FBQyxXQUFXLElBQUksT0FBTyxTQUFTLE1BQU0sSUFBSSxFQUFFLElBQUksT0FBTyxTQUFTLE1BQU0sSUFBSSxFQUFFLElBQUk7R0FDbkcsTUFBTSxhQUFhLFVBQVUsS0FBSyxXQUFXLE1BQU87R0FDcEQsTUFBTSxPQUFPLEtBQUssUUFBUSxpQkFBaUIsRUFBRSxDQUFDLENBQUMsS0FBSztHQUNwRCxTQUFTLEtBQUs7SUFBRTtJQUFXO0dBQUssQ0FBQztFQUNyQztDQUNKO0NBQ0EsT0FBTztFQUNILGFBQWEsa0JBQWtCO0VBQy9CLGlCQUFpQixnQkFBZ0I7RUFDakMsTUFBTSxTQUFTLEtBQUksU0FBUSxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSTtFQUMvQztDQUNKO0FBQ0o7O0FDckRBLElBQWEsa0JBQWIsTUFBNkI7Q0FDekIsT0FBTyxpQkFBaUI7Q0FDeEIsT0FBTyxZQUFZLEtBQUs7RUFDcEIsTUFBTSxVQUFVLE9BQU8sU0FBUyxLQUFLLEVBQUU7RUFDdkMsT0FBTyxPQUFPLE1BQU0sT0FBTyxJQUFJLE9BQU87Q0FDMUM7Q0FJQSxPQUFPLGVBQWUsU0FBUztFQUMzQixNQUFNLFFBQVEsUUFBUSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztFQUM3QyxPQUFPO0dBQ0gsSUFBSSxPQUFPLFNBQVMsTUFBTSxJQUFJLEVBQUUsS0FBSztHQUNyQyxJQUFJLE9BQU8sU0FBUyxNQUFNLElBQUksRUFBRSxLQUFLO0VBQ3pDO0NBQ0o7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxVQUFVLFFBQVE7RUFDMUIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztDQUNsQjs7Ozs7Ozs7Q0FRQSxjQUFjLEtBQUssVUFBVTtFQUN6QixNQUFNO0dBQUUsSUFBSSxJQUFJO0dBQUksT0FBTyxJQUFJO0VBQU07RUFDckMsS0FBSyxRQUFRLEtBQUssUUFBUTtFQUUxQixNQUFNLEtBQUssS0FBSyxjQUFjLElBQUksRUFBRTtFQUNwQyxPQUFPLEtBQUs7R0FBRTtHQUFJLE9BQU8sSUFBSTtFQUFNLElBQUk7Q0FDM0M7Ozs7OztDQU1BLGNBQWMsS0FBSztFQUNmLE9BQU8sT0FBTyxPQUFPLEtBQUssUUFBUSxHQUFHLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBQTtDQUNoRTs7Ozs7O0NBTUEsUUFBUSxNQUFNLFdBQVcsQ0FFekI7QUFDSjs7Ozs7QUNoREEsSUFBTSxTQUFTO0NBQ1gsTUFBTTtDQUNOLE1BQU07Q0FDTixRQUFRO0NBQ1IsTUFBTTtBQUNWO0FBQ0EsSUFBYSxnQkFBYixjQUFtQyxnQkFBZ0I7Q0FDL0MsY0FBYztFQUNWLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTTtDQUMxQjtBQUNKOztBQ2JBLElBQWEsd0JBQWIsY0FBMkMsZ0JBQWdCO0NBQ3ZELFlBQVksVUFBVSxRQUFRO0VBQzFCLE1BQU0sZUFBZSxDQUFDO0VBQ3RCLEtBQUssTUFBTSxDQUFDLEtBQUssZUFBZSxPQUFPLFFBQVEsTUFBTSxHQUNqRCxhQUFhLElBQUksWUFBWSxLQUFLO0VBRXRDLE1BQU0sVUFBVSxZQUFZO0NBQ2hDOzs7OztDQUtBLGNBQWMsS0FBSztFQUNmLE9BQU8sTUFBTSxjQUFjLElBQUksWUFBWSxDQUFDO0NBQ2hEO0FBQ0o7Ozs7O0FDWkEsSUFBTSxjQUFjO0NBQ2hCLE9BQU87Q0FDUCxRQUFRO0NBQ1IsU0FBUztDQUNULGdCQUFnQjtDQUNoQixPQUFPO0NBQ1AsTUFBTTtDQUNOLE1BQU07Q0FDTixjQUFjO0NBQ2QsY0FBYztDQUNkLGFBQWE7Q0FDYixTQUFTO0NBQ1QsT0FBTztDQUNQLE1BQU07Q0FDTixZQUFZO0NBQ1osT0FBTztDQUNQLHFCQUFxQjtDQUNyQixvQkFBb0I7Q0FDcEIsVUFBVTtDQUNWLFFBQVE7Q0FDUixXQUFXO0NBQ1gsV0FBVztDQUNYLE1BQU07Q0FDTixZQUFZO0NBQ1osaUJBQWlCO0NBQ2pCLGNBQWM7Q0FDZCxVQUFVO0NBQ1YsUUFBUTtDQUNSLFdBQVc7Q0FFWCxXQUFXO0NBQ1gsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsU0FBUztDQUNULE9BQU87Q0FDUCxPQUFPO0NBQ1AsVUFBVTtDQUNWLFVBQVU7Q0FDVixjQUFjO0NBQ2QsYUFBYTtDQUNiLEtBQUs7Q0FDTCxNQUFNO0NBQ04sT0FBTztDQUNQLGVBQWU7Q0FDZix5QkFBeUI7Q0FDekIsdUJBQXVCO0NBQ3ZCLGdCQUFnQjtDQUNoQixRQUFRO0NBQ1IsVUFBVTtDQUNWLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsV0FBVztDQUNYLGlCQUFpQjtDQUNqQixTQUFTO0NBQ1QsTUFBTTtDQUNOLE1BQU07Q0FDTixxQkFBcUI7Q0FDckIsNEJBQTRCO0NBQzVCLHFCQUFxQjtDQUNyQixzQkFBc0I7Q0FDdEIsMkJBQTJCO0NBQzNCLDRCQUE0QjtDQUM1QixvQkFBb0I7Q0FDcEIsbUJBQW1CO0NBQ25CLG9CQUFvQjtDQUNwQixhQUFhO0NBQ2Isc0JBQXNCO0NBQ3RCLGNBQWM7Q0FDZCxTQUFTO0NBQ1QsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2QixnQkFBZ0I7Q0FDaEIsY0FBYztBQUNsQjtBQUNBLElBQWEsaUJBQWIsY0FBb0Msc0JBQXNCO0NBQ3RELGNBQWM7RUFDVixNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVc7Q0FDaEM7QUFDSjs7Ozs7O0FDN0VBLElBQU0sWUFBWTtDQUNkLE9BQU87Q0FDUCxRQUFRO0NBQ1Isa0JBQWtCO0NBQ2xCLGlCQUFpQjtDQUNqQixXQUFXO0NBQ1gsMEJBQTBCO0NBQzFCLDBCQUEwQjtDQUMxQixhQUFhO0NBQ2Isa0JBQWtCO0NBQ2xCLGFBQWE7Q0FDYixnQkFBZ0I7Q0FDaEIsWUFBWTtDQUNaLGVBQWU7Q0FDZixhQUFhO0NBQ2IscUJBQXFCO0NBQ3JCLHFCQUFxQjtDQUNyQixzQkFBc0I7Q0FDdEIsMkJBQTJCO0NBQzNCLHdCQUF3QjtDQUN4QixhQUFhO0NBQ2IsZ0JBQWdCO0NBQ2hCLGlCQUFpQjtDQUNqQixlQUFlO0NBQ2YsZUFBZTtDQUNmLGNBQWM7Q0FDZCxZQUFZO0NBQ1osZ0JBQWdCO0NBQ2hCLDhCQUE4QjtDQUM5QixlQUFlO0NBQ2Ysa0JBQWtCO0NBQ2xCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsb0JBQW9CO0NBQ3BCLHVCQUF1QjtDQUN2QixlQUFlO0NBQ2YscUJBQXFCO0NBQ3JCLFdBQVc7Q0FDWCxZQUFZO0NBQ1osZ0JBQWdCO0NBQ2hCLDRCQUE0QjtDQUM1QiwwQkFBMEI7Q0FDMUIscUNBQXFDO0NBQ3JDLGFBQWE7Q0FDYixlQUFlO0NBQ2YsV0FBVztDQUNYLFNBQVM7Q0FDVCxnQkFBZ0I7Q0FDaEIsdUJBQXVCO0NBQ3ZCLGNBQWM7Q0FDZCxXQUFXO0NBQ1gsd0JBQXdCO0NBQ3hCLGdDQUFnQztDQUNoQyx3QkFBd0I7Q0FDeEIseUJBQXlCO0NBQ3pCLCtCQUErQjtDQUMvQixnQ0FBZ0M7Q0FDaEMsdUJBQXVCO0NBQ3ZCLHNCQUFzQjtDQUN0Qix1QkFBdUI7Q0FDdkIsZUFBZTtDQUNmLHdCQUF3QjtDQUN4QixnQkFBZ0I7Q0FDaEIsY0FBYztDQUNkLGlCQUFpQjtDQUNqQixNQUFNO0NBQ04sV0FBVztDQUNYLGdCQUFnQjtDQUNoQixjQUFjO0FBQ2xCO0FBQ0EsSUFBYSxlQUFiLE1BQWEscUJBQXFCLGdCQUFnQjtDQUM5QyxPQUFPLFNBQVMsUUFBUTtFQUNwQixNQUFNLFFBQVEsT0FBTyxXQUFXLFdBQVcsU0FBUyxPQUFPLFdBQVcsTUFBTTtFQUM1RSxJQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQ3BDLE9BQU8sRUFBRSxRQUFRLEtBQUEsRUFBVTtFQUUvQixPQUFPLEVBQUUsUUFBUSxRQUFRLEdBQUc7Q0FDaEM7Q0FDQSxjQUFjO0VBQ1YsTUFBTSxDQUFDLEtBQUssR0FBRyxTQUFTO0NBQzVCO0NBQ0EsUUFBUSxLQUFLLFVBQVU7RUFDbkIsSUFBSSxLQUFLLGNBQWMsSUFBSSxFQUFFLENBQUMsRUFBRSxXQUFXLGFBQWEsR0FBRztHQUN2RCxNQUFNLFFBQVEsT0FBTyxJQUFJLFVBQVUsV0FDN0IsSUFBSSxNQUFNLEtBQUssQ0FBQyxDQUFDLE1BQU0seURBQXlELElBQ2hGO0dBQ04sTUFBTSxhQUFhLFFBQVEsR0FBRyxNQUFNLEtBQUssTUFBTSxLQUFLLFFBQVEsT0FBTyxLQUFBO0dBQ25FLE1BQU0sUUFBUSxhQUFhLFFBQVEsVUFBVSxJQUFJLEtBQUE7R0FFakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLFNBQVMsTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLE1BQU0sRUFBRSxHQUFHO0lBQ25FLFNBQVMsV0FBVyxvQ0FBb0MsSUFBSSxJQUFJO0lBQ2hFLElBQUksS0FBSztHQUNiLE9BRUksSUFBSSxRQUFRO0VBRXBCO0VBQ0EsUUFBUSxJQUFJLElBQVo7R0FDSSxLQUFLLGlCQUFpQjtJQUVsQixNQUFNLENBQUMsT0FBTyxVQUFVLElBQUksTUFBTSxNQUFNLEtBQUssQ0FBQztJQUM5QyxNQUFNLFFBQVEsT0FBTyxNQUFNO0lBQzNCLE1BQU0sUUFBUSxRQUFRLEtBQUssTUFBTSxLQUFLLE9BQU8sVUFBVSxLQUFLLEtBQUssU0FBUyxLQUFLLFNBQVM7SUFDeEYsSUFBSSxDQUFDLE9BQ0QsU0FBUyxXQUFXLHFDQUFxQyxRQUFRO0lBRXJFLElBQUksUUFBUTtLQUNSLFFBQVE7S0FDUixRQUFRLFNBQVMsUUFBUSxLQUFNLFFBQVEsS0FBSyxNQUFPLGdCQUFnQixpQkFBaUIsS0FBQTtJQUN4RjtJQUNBO0dBQ0o7R0FDQSxLQUFLLHVCQUF1QjtJQUN4QixNQUFNLE9BQU8sSUFBSSxHQUFHLE1BQU0sS0FBSyxDQUFDO0lBQ2hDLElBQUksUUFBUSxhQUFhLFNBQVMsSUFBSSxLQUFLO0lBQzNDLElBQUksS0FBSyxLQUFLO0lBQ2Q7R0FDSjtFQUNKO0NBQ0o7QUFDSjs7QUNqSUEsSUFBTSxhQUFhO0NBQ2YsT0FBTztDQUNQLGlCQUFpQjtDQUNqQixRQUFRO0NBQ1IsT0FBTztDQUNQLGdCQUFnQjtDQUNoQixNQUFNO0NBQ04sVUFBVTtDQUNWLFVBQVU7Q0FDVixPQUFPO0NBQ1AsT0FBTztDQUNQLGlCQUFpQjtDQUNqQixVQUFVO0NBQ1YsV0FBVztDQUNYLGtCQUFrQjtDQUNsQix3QkFBd0I7QUFDNUI7QUFDQSxJQUFNLHFDQUFxQixJQUFJLElBQUk7Q0FBQztDQUFVO0NBQVk7Q0FBWTtBQUFPLENBQUM7QUFDOUUsSUFBYSxlQUFiLGNBQWtDLGdCQUFnQjtDQUM5QyxjQUFjO0VBQ1YsTUFBTSxDQUFDLEtBQUssR0FBRyxVQUFVO0NBQzdCO0NBQ0EsY0FBYyxLQUFLLFVBQVU7RUFDekIsSUFBSSxtQkFBbUIsSUFBSSxJQUFJLEVBQUUsS0FBSyxPQUFPLElBQUksVUFBVSxVQUN2RCxNQUFNO0dBQ0YsSUFBSSxJQUFJO0dBQ1IsT0FBTyxJQUFJLE1BQ04sTUFBTSxHQUFHLENBQUMsQ0FDVixLQUFJLFVBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUMxQixRQUFPLFVBQVMsTUFBTSxTQUFTLENBQUM7RUFDekM7RUFFSixPQUFPLE1BQU0sY0FBYyxLQUFLLFFBQVE7Q0FDNUM7QUFDSjs7Ozs7QUNqQ0EsSUFBTSxjQUFjO0NBQ2hCLE9BQU87Q0FDUCxRQUFRO0NBQ1IsT0FBTztDQUNQLE1BQU07Q0FDTixTQUFTO0NBQ1QsT0FBTztDQUNQLE9BQU87QUFDWDtBQUNBLElBQWEsaUJBQWIsY0FBb0MsZ0JBQWdCO0NBQ2hELGNBQWM7RUFDVixNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVc7Q0FDaEM7QUFDSjs7Ozs7QUNiQSxJQUFhLGVBQWU7Q0FDeEIsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLGdCQUFnQjtDQUNoQixnQkFBZ0I7Q0FDaEIsZ0JBQWdCO0NBQ2hCLGNBQWM7Q0FDZCxXQUFXO0NBQ1gsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7QUFDVDtBQUNBLElBQWEsa0JBQWIsY0FBcUMsc0JBQXNCO0NBQ3ZELGNBQWM7RUFDVixNQUFNLENBQUMsU0FBUyxHQUFHLFlBQVk7Q0FDbkM7QUFDSjs7Ozs7QUM1Q0EsSUFBYSxlQUFlO0NBRXhCLE1BQU07Q0FDTixNQUFNO0NBQ04sZ0JBQWdCO0NBQ2hCLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTs7OztDQUlOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixlQUFlO0NBQ2YsTUFBTTtDQUVOLE1BQU07Q0FDTixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLGlCQUFpQjtDQUNqQixlQUFlO0NBQ2YsWUFBWTtDQUNaLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sc0JBQXNCO0NBQ3RCLGlDQUFpQztDQUNqQywrQkFBK0I7Ozs7Q0FJL0IsMENBQTBDOzs7O0NBSTFDLHVCQUF1QjtDQUN2QixlQUFlO0NBQ2YsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixnQkFBZ0I7Q0FDaEIsYUFBYTtDQUNiLE1BQU07Q0FDTixhQUFhO0NBQ2IscUJBQXFCO0NBQ3JCLCtCQUErQjtDQUMvQixxQ0FBcUM7Q0FDckMsNkJBQTZCO0NBQzdCLDhCQUE4QjtDQUM5QixvQ0FBb0M7Q0FDcEMscUNBQXFDO0NBQ3JDLDRCQUE0QjtDQUM1QiwyQkFBMkI7Q0FDM0IsNEJBQTRCO0NBQzVCLG9CQUFvQjtDQUNwQixvQkFBb0I7Q0FDcEIsNkJBQTZCO0NBQzdCLHFCQUFxQjtDQUNyQiwrQkFBK0I7Q0FDL0IsTUFBTTtDQUdOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUVOLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLGVBQWU7Q0FDZixZQUFZO0NBQ1osTUFBTTtDQUVOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBRU4scUJBQXFCO0NBQ3JCLGtCQUFrQjtDQUNsQixrQkFBa0I7Q0FFbEIsMEJBQTBCO0NBQzFCLHdCQUF3QjtDQUN4Qiw0QkFBNEI7Q0FDNUIsOEJBQThCO0NBQzlCLHdCQUF3QjtDQUN4Qix3QkFBd0I7Q0FDeEIscUJBQXFCO0NBQ3JCLHNCQUFzQjtDQUN0Qix5QkFBeUI7Q0FDekIsa0NBQWtDO0NBQ2xDLHVCQUF1QjtDQUN2Qix5QkFBeUI7Q0FDekIsMkJBQTJCO0NBQzNCLHNCQUFzQjtDQUN0QixrQkFBa0I7Q0FDbEIsY0FBYztDQUNkLDhCQUE4QjtDQUM5Qiw4QkFBOEI7Q0FDOUIsOEJBQThCO0NBQzlCLDhCQUE4QjtDQUM5Qix1QkFBdUI7Q0FDdkIsNkJBQTZCO0NBQzdCLHFCQUFxQjtDQUNyQixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtBQUNWO0FBQ0EsSUFBYSxrQkFBYixNQUFhLHdCQUF3QixzQkFBc0I7Q0FDdkQsT0FBTyxTQUFTLE1BQU07RUFDbEIsT0FBTztHQUNILFFBQVEsS0FBSztHQUNiLFFBQVEsS0FBSyxTQUFTLEtBQU0sS0FBSyxTQUFTLEtBQUssTUFBTyxnQkFBZ0IsaUJBQWlCLEtBQUE7RUFDM0Y7Q0FDSjtDQUNBLGNBQWM7RUFDVixNQUFNLENBQUMsV0FBVyxTQUFTLEdBQUcsWUFBWTtDQUM5Qzs7Ozs7O0NBTUEsUUFBUSxLQUFLLFVBQVU7RUFDbkIsUUFBUSxJQUFJLElBQVo7R0FDSSxLQUFLO0lBQ0Q7S0FFSSxNQUFNLFFBQVEsSUFBSTtLQUNsQixJQUFJLE1BQU0scUJBQXFCLDBCQUEwQjtNQUNyRCxJQUFJLE1BQU0sSUFBSSxNQUFNO01BQ3BCLElBQUksUUFBUSxhQUFhLE1BQU0sWUFBWSxRQUFRO0tBQ3ZEO0lBQ0o7SUFDQTtHQUNKLEtBQUs7SUFDRDtLQUNJLE1BQU0sWUFBWSxJQUFJO0tBQ3RCLFFBQVEsVUFBVSxrQkFBbEI7TUFFSSxLQUFLO01BQ0wsS0FBSztNQUNMLEtBQUs7T0FDRCxJQUFJLE1BQU0sSUFBSSxVQUFVO09BQ3hCLElBQUksUUFBUSxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsSUFBSSxVQUFVLE1BQU0sQ0FBQyxJQUFJO09BQzdFLElBQUksSUFBSSxVQUFVLE1BQ2QsU0FBUyxXQUFXLHdCQUF3QixVQUFVLGtCQUFrQjtPQUU1RTtNQUNKLFNBQ0ksU0FBUyxXQUFXLGtDQUFrQyxVQUFVLGlCQUFpQixNQUFNLEdBQUcsR0FBRyxHQUFHO0tBQ3hHO0lBQ0o7SUFDQTtHQUNKLEtBQUssUUFDRCxJQUFJLFFBQVEsZ0JBQWdCLFNBQVMsSUFBSSxLQUFLO0VBSXREO0NBQ0o7QUFDSjs7Ozs7QUNoTUEsSUFBTSxhQUFhO0NBQ2YsaUJBQWlCO0NBQ2pCLGdCQUFnQjtDQUNoQixvQkFBb0I7Q0FDcEIsZUFBZTtDQUNmLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIscUJBQXFCO0NBQ3JCLHFCQUFxQjtDQUNyQixnQkFBZ0I7Q0FDaEIsb0JBQW9CO0NBQ3BCLGVBQWU7Q0FDZixxQkFBcUI7Q0FDckIsNkJBQTZCO0NBQzdCLDZCQUE2QjtDQUM3Qiw4QkFBOEI7Q0FDOUIsbUJBQW1CO0NBQ25CLGVBQWU7Q0FDZixpQkFBaUI7Q0FDakIseUJBQXlCO0NBQ3pCLHVCQUF1QjtDQUN2QixTQUFTO0FBQ2I7QUFDQSxJQUFhLG9CQUFiLGNBQXVDLHNCQUFzQjtDQUN6RCxjQUFjO0VBQ1YsTUFBTSxDQUFDLFVBQVUsR0FBRyxVQUFVO0NBQ2xDO0FBQ0o7Ozs7O0FDM0JBLElBQU0sWUFBWTtDQUNkLGNBQWM7Q0FDZCxjQUFjO0NBQ2QsZUFBZTtDQUNmLHFCQUFxQjtDQUNyQixvQkFBb0I7Q0FDcEIsaUJBQWlCO0NBQ2pCLGFBQWE7Q0FDYixnQkFBZ0I7Q0FDaEIsb0JBQW9CO0NBQ3BCLGlCQUFpQjtDQUNqQixjQUFjO0NBQ2QsY0FBYztDQUNkLGFBQWE7Q0FDYixrQkFBa0I7Q0FDbEIsaUJBQWlCO0NBQ2pCLGlCQUFpQjtDQUNqQixrQkFBa0I7Q0FDbEIsZ0JBQWdCO0NBQ2hCLGFBQWE7Q0FDYixrQ0FBa0M7Q0FDbEMsa0NBQWtDO0NBQ2xDLG1DQUFtQztDQUNuQyx5Q0FBeUM7Q0FDekMsb0NBQW9DO0NBQ3BDLHdDQUF3QztDQUN4QyxrQ0FBa0M7Q0FDbEMsc0NBQXNDO0NBQ3RDLFFBQVE7Q0FDUixRQUFRO0NBQ1IsTUFBTTs7OztDQUlOLDhCQUE4QjtDQUM5QixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixRQUFRO0NBQ1IsTUFBTTtDQUNOLE1BQU07Q0FDTixRQUFRO0NBQ1IsTUFBTTtDQUNOLFFBQVE7Q0FDUixRQUFRO0NBQ1IsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixrQ0FBa0M7Q0FDbEMsbUNBQW1DO0NBQ25DLGlDQUFpQztDQUNqQyxrQ0FBa0M7Q0FDbEMsa0NBQWtDO0NBQ2xDLGlDQUFpQztDQUNqQywrQkFBK0I7Q0FDL0IsK0JBQStCO0NBQy9CLFFBQVE7Q0FDUixrQ0FBa0M7Q0FDbEMsc0NBQXNDO0NBQ3RDLE1BQU07Q0FDTixNQUFNO0NBQ04sOEJBQThCO0NBQzlCLCtCQUErQjtDQUMvQix1Q0FBdUM7Q0FDdkMsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixrREFBa0Q7Q0FDbEQsZ0RBQWdEO0NBQ2hELDJEQUEyRDtDQUMzRCxnQ0FBZ0M7Q0FDaEMsa0NBQWtDO0NBQ2xDLE1BQU07Q0FDTixRQUFRO0NBQ1IsaUNBQWlDO0NBQ2pDLFFBQVE7Q0FDUixNQUFNO0NBQ04saUNBQWlDO0NBQ2pDLDhCQUE4QjtDQUM5Qiw4QkFBOEI7Q0FDOUIsK0JBQStCO0NBQy9CLDhDQUE4QztDQUM5QyxzREFBc0Q7Q0FDdEQsOENBQThDO0NBQzlDLCtDQUErQztDQUMvQyxxREFBcUQ7Q0FDckQsc0RBQXNEO0NBQ3RELDZDQUE2QztDQUM3Qyw0Q0FBNEM7Q0FDNUMsNkNBQTZDO0NBQzdDLHFDQUFxQztDQUNyQyw4Q0FBOEM7Q0FDOUMsc0NBQXNDO0NBQ3RDLHFDQUFxQztDQUNyQywrQ0FBK0M7Q0FDL0MsK0NBQStDO0NBQy9DLCtDQUErQztDQUMvQywrQ0FBK0M7Q0FDL0MsaURBQWlEO0NBQ2pELGlEQUFpRDtDQUNqRCx5Q0FBeUM7Q0FDekMsdUNBQXVDO0NBQ3ZDLGtDQUFrQztDQUNsQyx3Q0FBd0M7Q0FFeEMsTUFBTTtDQUNOLHlDQUF5QztDQUN6QyxpQ0FBaUM7Q0FDakMsc0NBQXNDO0NBQ3RDLHNDQUFzQztDQUN0QyxxQ0FBcUM7Q0FFckMsTUFBTTtDQUNOLE1BQU07Q0FDTixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixRQUFRO0NBQ1IsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtBQUNWO0FBQ0EsSUFBYSxVQUFVO0FBQ3ZCLElBQWEsZUFBYixjQUFrQyxzQkFBc0I7Q0FDcEQsY0FBYztFQUNWLE1BQU0sQ0FBQyxPQUFPLEdBQUcsU0FBUztDQUM5QjtDQUNBLFFBQVEsS0FBSyxXQUFXO0VBQ3BCLFFBQVEsSUFBSSxJQUFaO0dBQ0ksS0FBSyxRQUNELElBQUksUUFBUTtJQUNSLFFBQVEsS0FBQTtJQUNSLFFBQVEsT0FBTyxXQUFXLElBQUksS0FBSyxJQUFJO0dBQzNDO0VBRVI7Q0FDSjtBQUNKOzs7Ozs7Ozs7QUNoSkEsSUFBTSxlQUFlO0NBQ2pCLE9BQU87Q0FDUCxRQUFRO0NBQ1IsU0FBUztDQUNULGFBQWE7Q0FDYixnQkFBZ0I7Q0FDaEIsT0FBTztDQUNQLE1BQU07Q0FDTixjQUFjO0NBQ2QsY0FBYztDQUNkLGFBQWE7Q0FDYixTQUFTO0NBQ1QsYUFBYTtDQUNiLGFBQWE7Q0FDYixZQUFZO0NBQ1osT0FBTztDQUNQLHdCQUF3QjtDQUN4QixVQUFVO0NBQ1YsUUFBUTtDQUNSLGdCQUFnQjtDQUNoQixXQUFXO0NBQ1gsV0FBVztDQUNYLE1BQU07Q0FDTixZQUFZO0NBQ1osaUJBQWlCO0NBQ2pCLGNBQWM7Q0FDZCxVQUFVO0NBQ1YsUUFBUTtDQUNSLFdBQVc7Q0FFWCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7Q0FDVixVQUFVO0NBQ1YsU0FBUztDQUNULE9BQU87Q0FDUCxPQUFPO0NBQ1AsY0FBYztDQUNkLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsVUFBVTtDQUNWLGNBQWM7Q0FDZCxZQUFZO0NBQ1osV0FBVztDQUNYLGFBQWE7Q0FDYixRQUFRO0NBQ1IsS0FBSztDQUNMLEtBQUs7Q0FDTCxNQUFNO0NBQ04sT0FBTztDQUNQLGVBQWU7Q0FDZixlQUFlO0NBQ2YsYUFBYTtDQUNiLGdCQUFnQjtDQUNoQixRQUFRO0NBQ1IsVUFBVTtDQUNWLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsV0FBVztDQUNYLGlCQUFpQjtDQUNqQixTQUFTO0NBQ1QsTUFBTTtDQUNOLE1BQU07Q0FDTixxQkFBcUI7Q0FDckIsNEJBQTRCO0NBQzVCLHFCQUFxQjtDQUNyQixzQkFBc0I7Q0FDdEIsMkJBQTJCO0NBQzNCLDRCQUE0QjtDQUM1QixvQkFBb0I7Q0FDcEIsbUJBQW1CO0NBQ25CLG9CQUFvQjtDQUNwQixhQUFhO0NBQ2IseUJBQXlCO0NBQ3pCLGNBQWM7Q0FFZCxTQUFTO0NBQ1QsT0FBTztDQUNQLGFBQWE7Q0FDYixZQUFZO0NBRVosbUJBQW1CO0NBQ25CLGlCQUFpQjtDQUNqQixxQkFBcUI7Q0FDckIsdUJBQXVCO0NBQ3ZCLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsY0FBYztDQUNkLGVBQWU7Q0FDZixrQkFBa0I7Q0FDbEIsMkJBQTJCO0NBQzNCLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsb0JBQW9CO0NBQ3BCLGVBQWU7Q0FDZixXQUFXO0NBQ1gsT0FBTztDQUVQLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUV2QixtQkFBbUI7Q0FDbkIseUJBQXlCO0NBQ3pCLGlCQUFpQjtBQUNyQjtBQUNBLElBQWEsa0JBQWIsTUFBYSx3QkFBd0IsZ0JBQWdCO0NBQ2pELGtCQUFrQjtDQUNsQixPQUFPLFNBQVMsT0FBTyxRQUFRLFVBQVU7RUFDckMsT0FBTztHQUNILFFBQVEsUUFBUSxNQUFNLFlBQVksSUFBSSxLQUFBO0dBQ3RDLFFBQVMsT0FBTyxXQUFXLE1BQU0sSUFBSSxXQUFZLGdCQUFnQjtFQUNyRTtDQUNKO0NBQ0EsY0FBYztFQUNWLE1BQU0sQ0FBQyxRQUFRLEdBQUcsWUFBWTtDQUNsQztDQUNBLGNBQWMsS0FBSyxVQUFVO0VBQ3pCLElBQUksSUFBSSxPQUFPLFFBQVE7R0FDbkIsSUFBSSxPQUFPLElBQUksVUFBVSxZQUFZLElBQUksTUFBTSxLQUFLLENBQUMsQ0FBQyxXQUFXLEdBQzdELE9BQU87R0FFWCxLQUFLLGtCQUFrQjtFQUMzQixPQUNLLElBQUksSUFBSSxPQUFPLHNCQUFzQixLQUFLLGlCQUMzQyxPQUFPO0VBRVgsT0FBTyxNQUFNLGNBQWMsS0FBSyxRQUFRO0NBQzVDO0NBQ0EsUUFBUSxLQUFLO0VBQ1QsSUFBSSxJQUFJLE9BQU8sVUFFWCxJQUFJLFFBQVEsZ0JBQWdCLFNBQVMsS0FBQSxHQUFXLElBQUksT0FBTyxHQUFHO09BRTdELElBQUksSUFBSSxHQUFHLFFBQVEsU0FBUyxNQUFNLEdBQUc7R0FDdEMsTUFBTSxPQUFPLElBQUksR0FBRyxNQUFNLEtBQUssQ0FBQztHQUNoQyxJQUFJLFFBQVEsZ0JBQWdCLFNBQVMsS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDO0dBQzFELElBQUksS0FBSyxLQUFLO0VBQ2xCO0NBQ0o7QUFDSjs7Ozs7O0FDaEpBLElBQWEsaUJBQWlCO0NBQzFCLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0FBQ1Y7QUFDQSxJQUFhLG9CQUFiLGNBQXVDLGdCQUFnQjtDQUNuRCxjQUFjO0VBQ1YsTUFBTSxDQUFDLE1BQU0sR0FBRyxjQUFjO0NBQ2xDO0FBQ0o7O0FDdEJBLElBQWEsb0JBQWIsTUFBK0I7Q0FDM0IsYUFBYSxDQUFDO0NBQ2QsY0FBYztFQUNWO0dBQ0ksSUFBSSxlQUFlO0dBQ25CLElBQUksZ0JBQWdCO0dBQ3BCLElBQUksZ0JBQWdCO0dBQ3BCLElBQUksYUFBYTtHQUNqQixJQUFJLGdCQUFnQjtHQUNwQixJQUFJLGVBQWU7R0FDbkIsSUFBSSxhQUFhO0dBQ2pCLElBQUksa0JBQWtCO0dBQ3RCLElBQUksa0JBQWtCO0dBQ3RCLElBQUksY0FBYztHQUNsQixJQUFJLGFBQWE7RUFDckIsQ0FBQyxDQUFDLFNBQVEsV0FBVTtHQUNoQixLQUFLLGtCQUFrQixNQUFNO0VBQ2pDLENBQUM7Q0FDTDs7Ozs7Ozs7Q0FRQSxPQUFPLFNBQVMsS0FBSyxVQUFVO0VBRTNCLElBRGtCLEtBQUssV0FBVyxVQUU5QixPQUFPLEtBQUssV0FBVyxRQUFRLENBQUMsY0FBYyxLQUFLLFFBQVE7RUFFL0QsTUFBTSxJQUFJLG9CQUFvQixpREFBaUQsU0FBUztDQUM1RjtDQUNBLGtCQUFrQixrQkFBa0I7RUFDaEMsS0FBSyxNQUFNLFdBQVcsaUJBQWlCLFVBQ25DLEtBQUssV0FBVyxXQUFXO0NBRW5DO0FBQ0o7O0FDbERBLElBQU0saUJBQWlCLEVBQ25CLFVBQVUsTUFDZDtBQUNBLElBQU0sYUFBYTtDQUNmLE1BQU07Q0FDTixPQUFPO0NBQ1AsTUFBTTtDQUNOLE9BQU87Q0FDUCxRQUFRO0NBQ1IsU0FBUztFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQUs7Q0FDeEMsYUFBYTtDQUNiLGNBQWM7RUFBRSxVQUFVO0VBQU0sUUFBUTtDQUFLO0NBQzdDLE9BQU87Q0FDUCxNQUFNO0NBQ04sY0FBYztDQUNkLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsU0FBUztFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQU07Q0FDekMsT0FBTztFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQUs7Q0FDdEMsU0FBUztFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQUs7Q0FDeEMsVUFBVTtFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQUs7Q0FDekMsUUFBUTtFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQU07Q0FDeEMsV0FBVztFQUFFLFVBQVU7RUFBTyxRQUFRO0NBQUs7Q0FDM0MsV0FBVztFQUFFLFVBQVU7RUFBTyxRQUFRO0NBQUs7Q0FDM0MsTUFBTTtFQUFFLFVBQVU7RUFBTyxRQUFRO0NBQUs7Q0FDdEMsWUFBWTtFQUFFLFVBQVU7RUFBTyxRQUFRO0NBQUs7Q0FDNUMsaUJBQWlCO0VBQUUsVUFBVTtFQUFPLFFBQVE7Q0FBSztDQUNqRCxjQUFjO0VBQUUsVUFBVTtFQUFPLFFBQVE7Q0FBSztDQUM5QyxVQUFVO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN6QyxRQUFRO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN2QyxXQUFXO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUMxQyxTQUFTO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN4QyxVQUFVO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN6QyxVQUFVO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN6QyxVQUFVO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN6QyxZQUFZO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUMzQyxTQUFTO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN4QyxPQUFPO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN0QyxPQUFPO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN0QyxVQUFVO0NBQ1YsVUFBVSxFQUFFLFVBQVUsS0FBSztDQUMzQixjQUFjO0NBQ2QsYUFBYTtDQUNiLFlBQVk7Q0FDWixhQUFhO0NBQ2IsUUFBUSxFQUFFLFVBQVUsS0FBSztDQUN6QixLQUFLO0NBQ0wsTUFBTTtDQUNOLE9BQU87Q0FDUCxlQUFlO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUM5QyxRQUFRO0NBQ1IsWUFBWTtDQUNaLFVBQVU7Q0FDVixXQUFXO0NBQ1gsYUFBYTtDQUNiLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsWUFBWTtDQUNaLGVBQWU7Q0FDZixhQUFhLEVBQUUsVUFBVSxLQUFLO0NBQzlCLGdCQUFnQjtDQUNoQixRQUFRO0NBQ1IsVUFBVTtDQUNWLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsV0FBVztDQUNYLGlCQUFpQjtDQUNqQixTQUFTO0NBQ1QsU0FBUztDQUNULE1BQU0sRUFBRSxVQUFVLEtBQUs7Q0FDdkIsTUFBTTtDQUNOLHlCQUF5QjtDQUN6QixxQkFBcUI7Q0FDckIscUJBQXFCO0NBQ3JCLHNCQUFzQixFQUFFLFVBQVUsS0FBSztDQUN2QywyQkFBMkIsRUFBRSxVQUFVLEtBQUs7Q0FDNUMsNEJBQTRCO0NBQzVCLG9CQUFvQjtDQUNwQixtQkFBbUI7Q0FDbkIsb0JBQW9CO0NBQ3BCLGFBQWE7Q0FDYixzQkFBc0I7Q0FDdEIsY0FBYztDQUNkLHFCQUFxQjtDQUNyQixTQUFTO0NBQ1Qsd0JBQXdCO0VBQUUsVUFBVTtFQUFNLFFBQVE7Q0FBSztDQUN2RCxjQUFjO0NBQ2QsV0FBVztDQUNYLE9BQU87RUFBRSxVQUFVO0VBQU0sUUFBUTtDQUFNO0NBQ3ZDLEtBQUs7Q0FDTCxlQUFlO0NBQ2YsZ0JBQWdCO0NBQ2hCLG1CQUFtQjtFQUFFLFVBQVU7RUFBTSxRQUFRO0NBQUs7Q0FDbEQsb0JBQW9CO0NBQ3BCLGtCQUFrQjtDQUNsQiwyQkFBMkI7Q0FDM0IsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIseUJBQXlCO0NBQ3pCLHlCQUF5QjtDQUN6QixpQkFBaUI7Q0FDakIsYUFBYSxFQUFFLFVBQVUsS0FBSztDQUM5QixpQkFBaUI7Q0FDakIsVUFBVSxFQUFFLFVBQVUsS0FBSztDQUMzQixTQUFTO0NBQ1QsVUFBVSxFQUFFLFVBQVUsS0FBSztDQUMzQixVQUFVO0NBQ1YsZUFBZTtDQUNmLGVBQWU7Q0FDZixXQUFXO0NBQ1gsY0FBYztDQUNkLE1BQU07Q0FDTixhQUFhO0FBQ2pCOzs7OztBQU1BLFNBQWdCLFlBQVksT0FBTztDQUMvQixPQUFPLFdBQVcsVUFBVSxDQUFDLFdBQVcsTUFBTSxDQUFDO0FBQ25EOzs7OztBQUtBLFNBQWdCLFNBQVMsT0FBTztDQUM1QixPQUFPLENBQUMsV0FBVyxNQUFNLENBQUMsWUFBWSxXQUFXLE1BQU0sQ0FBQyxVQUFVO0FBQ3RFOzs7QUNsSUEsU0FBZ0IsaUJBQWlCLFNBQVM7Q0FDdEMsT0FBTyxZQUFZLEtBQUEsS0FBYSxPQUFPLFNBQVMsT0FBTyxLQUFLLFVBQVUsSUFBSSxVQUFVLEtBQUE7QUFDeEY7O0FBRUEsU0FBZ0IscUJBQXFCLFFBQVE7Q0FDekMsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLFFBQVE7RUFBRSxNQUFNLFVBQVU7RUFBTztDQUFNO0NBQzdDLElBQUksT0FBTyxVQUFVLEtBQUEsR0FDakIsTUFBTSxZQUFZLE9BQU87Q0FFN0IsSUFBSSxPQUFPLGlCQUFpQixLQUFBLEdBQ3hCLE1BQU0sZUFBZSxPQUFPO0NBRWhDLElBQUksT0FBTyxhQUFhLEtBQUEsR0FDcEIsTUFBTSxXQUFXLE9BQU87Q0FFNUIsTUFBTSxVQUFVLGlCQUFpQixPQUFPLE9BQU87Q0FDL0MsSUFBSSxZQUFZLEtBQUEsR0FDWixNQUFNLFVBQVU7Q0FFcEIsSUFBSSxPQUFPLGFBQWEsS0FBQSxHQUNwQixNQUFNLFdBQVcsT0FBTztDQUU1QixJQUFJLE9BQU8sZUFBZSxLQUFBLEdBQ3RCLE1BQU0sb0JBQW9CLE9BQU87Q0FFckMsSUFBSSxPQUFPLHFCQUFxQixLQUFBLEdBQzVCLE1BQU0sV0FBVyxPQUFPO0NBRTVCLElBQUksT0FBTyxrQkFBa0IsS0FBQSxHQUN6QixNQUFNLFdBQVcsT0FBTztDQUU1QixJQUFJLE9BQU8sb0JBQW9CLEtBQUEsR0FDM0IsTUFBTSxrQkFBa0IsT0FBTztDQUVuQyxPQUFPO0FBQ1g7O0FBRUEsU0FBZ0Isc0JBQXNCLFVBQVUsVUFBVTtDQUN0RCxNQUFNLEVBQUUsV0FBVztDQUNuQixJQUFJLFdBQVcsT0FBTztDQUN0QixJQUFJLGFBQWEsS0FBQSxHQUFXO0VBQ3hCLE1BQU0sWUFBWSxPQUFPLFVBQ3BCLFFBQU8sVUFBUyxNQUFNLFNBQVMsVUFBVSxTQUFTLE1BQU0sU0FBUyxVQUFVLEtBQUssQ0FBQyxDQUNqRixLQUFJLFVBQVMsTUFBTSxRQUFRO0VBQ2hDLElBQUksVUFBVSxTQUFTLEtBQ25CLFVBQVUsT0FBTyxhQUFhLGFBQWEsS0FBQSxLQUFhLFdBQVcsS0FBSyxPQUFPLFNBQVMsUUFBUSxDQUFDLEdBQ2pHLFdBQVcsVUFBVSxRQUFRLFNBQVMsa0JBQWtCLEtBQUssSUFBSSxTQUFTLGFBQWEsR0FBRyxDQUFDO09BRTFGLElBQUksQ0FBQyxPQUFPLFVBQ2IsV0FBVyxPQUFPO0NBRTFCO0NBQ0EsSUFBSSxhQUFhLEtBQUEsS0FBYSxPQUFPLFNBQVMsUUFBUSxLQUFLLFdBQVcsR0FBRztFQUNyRSxTQUFTLFVBQVUscUJBQXFCLFFBQVE7RUFDaEQsSUFBSSxPQUFPLGFBQWEsS0FBQSxHQUNwQixTQUFTLFVBQVUsWUFBWSxRQUFRO0VBRTNDLElBQUksYUFBYSxLQUFBLEtBQWEsT0FBTyxjQUFjLFFBQVEsS0FBSyxXQUFXLEdBQUc7R0FDMUUsTUFBTSxVQUFXLElBQUksV0FBWTtHQUNqQyxJQUFJLE9BQU8sU0FBUyxPQUFPLEdBQ3ZCLFNBQVMsVUFBVSxrQkFBa0IsT0FBTztFQUVwRDtDQUNKO0FBQ0o7O0FDekRBLElBQU0sU0FBQSxHQUFRUSxlQUFBQSxRQUFBQSxDQUFVLDBCQUEwQjtBQUNsRCxJQUFNLGNBQWM7Q0FDaEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0o7Ozs7O0FBS0EsSUFBYSxvQkFBYixNQUErQjtDQUMzQixTQUFTO0VBQ0wsVUFBVSxDQUFDO0VBQ1gsV0FBVyxDQUFDO0NBQ2hCO0NBQ0EsU0FBUyxDQUFDO0NBQ1YsU0FBUztFQUNMLE9BQU87R0FBRSxJQUFJO0dBQU0sSUFBSTtFQUFLO0VBQzVCLE1BQU07R0FBRSxJQUFJO0dBQU0sSUFBSTtFQUFLO0VBQzNCLGVBQWU7R0FBRSxJQUFJO0dBQU0sSUFBSTtFQUFLO0NBQ3hDO0NBQ0EsVUFBVSxFQUNOLFVBQVUsQ0FBQyxFQUNmOzs7O0NBSUEsZUFBZSxDQUFDOzs7O0NBSWhCLGlCQUFpQixDQUFDO0NBQ2xCLFlBQVksSUFBSSxrQkFBa0I7Q0FDbEM7Q0FDQSxZQUFZLE1BQU07RUFDZCxLQUFLLE9BQU87RUFDWixJQUFJLFdBQVc7RUFDZixLQUFLLE1BQU0sV0FBVyxhQUNsQixLQUFLLGVBQWUsV0FBVztFQUVuQyxLQUFLLGVBQWUsYUFBYTtFQUNqQyxLQUFLLGVBQWUsUUFBUTtDQUNoQzs7OztDQUlBLFNBQVM7RUFDTCxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVM7Q0FDN0M7Q0FDQSxjQUFjLFlBQVk7RUFDdEIsTUFBTSxvQkFBb0IsV0FBVyxPQUFPLHVCQUF1QixXQUFXLFFBQVEsSUFBSSxVQUFVLFdBQVcsV0FBVztFQUMxSCxJQUFJLGlCQUFpQixXQUFXLE9BQU8sTUFBTSxLQUFBLEdBQ3pDLE9BQU8sV0FBVztFQUV0QixLQUFLLE9BQU8sVUFBVSxLQUFLLFVBQVU7Q0FDekM7Q0FDQSxVQUFVLEtBQUssT0FBTztFQUVsQixLQUFLLFVBQVUsUUFBUSxPQUFPLFVBQVUsYUFBYSxPQUFPLEdBQUcsS0FBSyxPQUFPLE1BQU0sS0FBSyxHQUNsRjtFQUVKLE1BQU0sV0FBVyxJQUFJLEtBQUssT0FBTztFQUVqQyxLQUFLLE9BQU8sT0FBTztFQUNuQixJQUFJLEtBQUssTUFBTSxVQUNYLEtBQUssS0FBSyxTQUFTO0dBQUUsVUFBVTtHQUFNLEtBQUs7SUFBRSxNQUFNO0lBQVUsSUFBSTtJQUFLO0dBQU07RUFBRSxDQUFDO0NBRXRGO0NBQ0EsZUFBZTtFQUNYLEtBQUssVUFBVSxZQUFZLElBQUk7RUFDL0IsS0FBSyxVQUFVLFlBQVksS0FBSztDQUNwQztDQUNBLGdCQUFnQixTQUFTO0VBQ3JCLElBQUksQ0FBQyxLQUFLLE9BQU8sU0FBUyxTQUFTLE9BQU8sR0FDdEMsS0FBSyxPQUFPLFNBQVMsS0FBSyxPQUFPO0NBRXpDO0NBQ0EsTUFBTSxPQUFPLFNBQVMsT0FBTyxPQUFPO0VBQ2hDLE1BQU0sa0JBQWtCLFNBQVMsT0FBTyxLQUFLO0VBQzdDLElBQUksQ0FBQyxLQUFLLE9BQU8sVUFBVTtHQUN2QixLQUFLLGdCQUFnQixPQUFPO0dBQzVCLEtBQUssT0FBTyxXQUFXLENBQUM7RUFDNUI7RUFDQSxLQUFLLE9BQU8sUUFBUSxDQUFDLEtBQUs7R0FBRSxJQUFJO0dBQU87RUFBTSxDQUFDO0VBQzlDLE1BQU0sS0FBSyxTQUFTLFNBQVMsT0FBTyxLQUFLO0NBQzdDO0NBQ0EsV0FBVyxTQUFTO0VBQ2hCLEtBQUssUUFBUSxTQUFTLEtBQUssRUFBRSxTQUFTLFFBQVEsQ0FBQztDQUNuRDtDQUNBLE1BQU0sUUFBUSxTQUFTLEtBQUs7RUFLeEIsUUFBUSxJQUFJLElBQVo7R0FDSSxLQUFLLFVBQ0QsT0FBTyxLQUFLLHdCQUF3QixTQUFTLEtBQUssVUFBVSxTQUFTO0dBQ3pFLEtBQUssZUFDRCxPQUFPLEtBQUssd0JBQXdCLFNBQVMsS0FBSyxlQUFlLGNBQWM7R0FDbkYsS0FBSyxXQUNELE9BQU8sS0FBSyxzQkFBc0IsU0FBUyxLQUFLLFVBQVUsU0FBUztHQUN2RSxLQUFLLGdCQUNELE9BQU8sS0FBSyxzQkFBc0IsU0FBUyxLQUFLLGVBQWUsY0FBYztHQUNqRixLQUFLLFdBQ0QsT0FBTyxLQUFLLGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxNQUFLLFlBQVc7SUFDbEQsSUFBSSxZQUFZLE1BQU07S0FDbEIsSUFBSSxRQUFRO0tBQ1osS0FBSyxjQUFjLFNBQVMsR0FBRztJQUNuQztHQUNKLENBQUM7R0FDTCxLQUFLO0lBQ0QsS0FBSyxPQUFPLE1BQU0sS0FBSyxnQkFBZ0IsWUFBWSxJQUFJLEtBQUs7SUFDNUQsS0FBSyxnQkFBZ0I7S0FBRSxJQUFJO0tBQVMsT0FBTyxFQUFFLEdBQUcsS0FBSyxPQUFPLE1BQU07SUFBRSxDQUFDO0lBQ3JFO0dBQ0osS0FBSztJQUNELEtBQUssT0FBTyxLQUFLLEtBQUssZ0JBQWdCLFlBQVksSUFBSSxLQUFLO0lBQzNELEtBQUssZ0JBQWdCO0tBQUUsSUFBSTtLQUFRLE9BQU8sRUFBRSxHQUFHLEtBQUssT0FBTyxLQUFLO0lBQUUsQ0FBQztJQUNuRTtHQUNKLEtBQUs7SUFDRCxLQUFLLE9BQU8sY0FBYyxLQUFLLGdCQUFnQixZQUFZLElBQUksS0FBSztJQUNwRSxLQUFLLGdCQUFnQjtLQUFFLElBQUk7S0FBaUIsT0FBTyxFQUFFLEdBQUcsS0FBSyxPQUFPLGNBQWM7SUFBRSxDQUFDO0lBQ3JGO0dBQ0osS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLLGlCQUFpQjtJQUNsQixNQUFNLEtBQUssS0FBSyxPQUFPLElBQUksR0FBRyxDQUFDO0lBQy9CLEtBQUssT0FBTyxJQUFJLE1BQU0sZ0JBQWdCLGVBQWUsSUFBSSxLQUFLO0lBQzlELEtBQUssT0FBTyxJQUFJLEdBQUcsQ0FBQyxLQUFLLE1BQU0sT0FBTyxLQUFLLEtBQUssT0FBTyxJQUFJLEdBQUcsQ0FBQztJQUMvRCxLQUFLLGdCQUFnQjtLQUFFLElBQUksSUFBSTtLQUFJLE9BQU8sRUFBRSxHQUFHLEtBQUssT0FBTyxJQUFJLElBQUk7SUFBRSxDQUFDO0lBQ3RFO0dBQ0o7R0FDQSxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7SUFDRCxJQUFJLFFBQVEsT0FBTyxTQUFTLElBQUksT0FBTyxFQUFFO0lBQ3pDO0dBQ0osS0FBSyxRQUFRO0lBRVQsTUFBTSxPQUFPLE9BQU8sU0FBUyxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsR0FBRyxFQUFFO0lBQ3ZELElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBSSxHQUNsQixLQUFLLE9BQU8sT0FBTztJQUV2QjtHQUNKO0dBQ0EsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7SUFDRCxJQUFJLFFBQVEsT0FBTyxJQUFJLFVBQVUsV0FBVyxPQUFPLFNBQVMsSUFBSSxPQUFPLEVBQUUsSUFBSSxJQUFJO0lBQ2pGO0dBQ0osS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztJQUNELElBQUksUUFBUSxRQUFRLElBQUksS0FBSztJQUM3QjtHQUNKLEtBQUs7SUFDRCxJQUFJLFFBQVEsSUFBSSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFJLE1BQUssT0FBTyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ25FO0dBQ0osS0FBSyxtQkFBbUI7SUFDcEIsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSSxNQUFLLE9BQU8sU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0RSxJQUFJLFFBQVE7S0FDUixhQUFhLE9BQU87S0FDcEIsY0FBYyxPQUFPO0lBQ3pCO0lBQ0E7R0FDSjtHQUNBLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7SUFDRCxJQUFJLFFBQVEsSUFBSSxVQUFVLE9BQU8sSUFBSSxVQUFVLEtBQUssSUFBSSxVQUFVO0lBQ2xFO0dBQ0osS0FBSyxRQUFRO0lBRVQsTUFBTSxZQUFZLEtBQUssT0FBTyxJQUFJO0lBQ2xDLElBQUksYUFBYSxVQUFVLFFBQVEsSUFBSSxLQUFLLE1BQU0sSUFDOUM7SUFFSjtHQUNKO0dBQ0EsS0FBSztJQUNELElBQUksT0FBTyxJQUFJLFVBQVUsVUFDckIsSUFBSSxRQUFRLEVBQUUsTUFBTSxJQUFJLE1BQU07SUFFbEMsSUFBSSxJQUFJLE1BQU0sZUFBZSxZQUN6QixLQUFLLGNBQWMsU0FBUztLQUFFLElBQUk7S0FBVyxPQUFPLElBQUksTUFBTSxTQUFTO0lBQUksQ0FBQztJQUVoRjtHQUNKLEtBQUssVUFDRCxJQUFJLE9BQU8sSUFBSSxVQUFVLFVBQ3JCLElBQUksUUFBUSxZQUFZLElBQUksT0FBTyxzQkFBc0IsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBS3JGO0VBQ0EsSUFBSSxJQUFJLFVBQVUsTUFDZCxLQUFLLGNBQWMsU0FBUyxHQUFHO0NBRXZDOzs7OztDQUtBLG1CQUFtQjtFQUNmLE9BQU87R0FDSCxRQUFRLEtBQUs7R0FDYixRQUFRLEtBQUs7R0FDYixTQUFTLEtBQUs7R0FDZCxRQUFRLEtBQUs7RUFDakI7Q0FDSjs7OztDQUlBLHdCQUF3QixTQUFTLEtBQUssWUFBWSxVQUFVO0VBQ3hELElBQUksS0FBSyxhQUFhLGdCQUFnQixLQUFLLGVBQWUsVUFFdEQsT0FBTyxLQUFLLFFBQVEsY0FBYztHQUFFLElBQUk7R0FBVSxPQUFPLElBQUk7RUFBTSxDQUFDO0VBRXhFLElBQUksQ0FBQyxLQUFLLE9BQU8sV0FFYixLQUFLLGNBQWMsY0FBYztHQUFFLElBQUk7R0FBVSxPQUFPLElBQUk7RUFBTSxDQUFDO0VBRXZFLEtBQUssY0FBYyxTQUFTLEdBQUc7Q0FDbkM7Ozs7Q0FJQSxzQkFBc0IsU0FBUyxLQUFLLFlBQVksVUFBVTtFQUN0RCxJQUFJLENBQUMsS0FBSyxPQUFPLGVBQWUsS0FBSyxhQUFhLGdCQUFnQixLQUFLLGVBQWUsWUFDOUU7T0FBQSxDQUFDLEtBQUssT0FBTyxhQUFhLEtBQUssT0FBTyxTQUFTLENBQUMsUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBRzNFLE1BQU0sUUFBUSxhQURFLEtBQUssT0FBTyxhQUFhLENBQUMsRUFBQSxDQUFHLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FDL0IsQ0FBQztJQUNoQyxLQUFLLGNBQWMsY0FBYztLQUFFLElBQUk7S0FBWTtJQUFNLENBQUM7R0FDOUQ7O0VBRUosS0FBSyxjQUFjLFNBQVMsR0FBRztDQUNuQzs7Ozs7Q0FLQSxNQUFNLGVBQWUsU0FBUztFQUMxQixJQUFJLFFBQVEsUUFBUSxRQUFRLEtBQUssU0FBUyxHQUFHO0dBQ3pDLElBQUksQ0FBQyxRQUFRLFFBQVE7SUFDakIsTUFBTSxXQUFXLE1BQU0sbUJBQW1CLFdBQVcsS0FBSyxRQUFRLElBQUksR0FBRyxFQUNyRSxlQUFlLHVCQUF1QixLQUFLLFFBQVEsQ0FBQyxDQUFDLEVBQ3pELENBQUM7SUFDRCxJQUFJLFVBQ0EsUUFBUSxTQUFTLFNBQVM7U0FHMUIsT0FBTztHQUVmO0dBQ0EsUUFBUSxTQUFTLFFBQVEsT0FBTyxrQkFBa0I7R0FDbEQsUUFBUSxRQUFRLFFBQWhCO0lBQ0ksS0FBSyxhQUNELFFBQVEsU0FBUztHQUN6QjtHQUNBLE9BQU87RUFDWDtFQUNBLEtBQUssV0FBVyx5QkFBeUI7RUFDekMsT0FBTztDQUNYOzs7O0NBSUEsTUFBTSxTQUFTLFNBQVMsT0FBTyxPQUFPO0VBRWxDLEtBQU0sWUFBWSxhQUFhLFVBQVUsU0FDcEMsWUFBWSxhQUFhLFVBQVUsVUFDbkMsWUFBWSxhQUFhLFVBQVUsV0FDcEMsVUFBVSxRQUNWLE9BQU8sVUFBVSxVQUFVO0dBQzNCLEtBQUssTUFBTSxDQUFDLE1BQU0sV0FBVyxPQUFPLFFBQVEsS0FBSyxHQUM3QyxJQUFJLE1BQU0sUUFBUSxNQUFNLEdBQ2Y7U0FBQSxNQUFNLFVBQVUsUUFDakIsSUFBSSxPQUFPLFdBQVcsWUFBWSxPQUFPLFNBQVMsR0FDOUMsTUFBTSxLQUFLLFNBQVMsU0FBUyxHQUFHLE1BQU0sR0FBRyxRQUFRLE1BQU07R0FBQTtHQUt2RTtFQUNKO0VBQ0EsTUFBTSxNQUFNO0dBQUUsSUFBSTtHQUFPO0VBQU07RUFDL0IsTUFBTSxhQUFhLEtBQUssVUFBVSxPQUFPLFNBQVMsS0FBSyxJQUFJO0VBQzNELElBQUksWUFBWTtHQUNaLElBQUksTUFBTSxRQUFRLFdBQVcsS0FBSyxHQUM5QixLQUFLLE1BQU0sU0FBUyxXQUFXLE9BQzNCLE1BQU0sS0FBSyxRQUFRLFNBQVM7SUFBRSxJQUFJLFdBQVc7SUFBSTtHQUFNLENBQUM7UUFJNUQsTUFBTSxLQUFLLFFBQVEsU0FBUyxVQUFVO0VBRTlDO0NBQ0o7Ozs7Q0FJQSxjQUFjLFNBQVMsS0FBSztFQUN4QixNQUFNLFVBQVUsSUFBSSxHQUFHLEtBQUssSUFBSSxPQUFPO0VBQ3ZDLE1BQU0sUUFBUSxLQUFLLGFBQWEsSUFBSSxPQUFPO0VBQzNDLE1BQU0sUUFBUSxLQUFLLGVBQWU7RUFDbEMsSUFBSSxZQUFZLElBQUksRUFBRSxHQUFHO0dBQ3JCLElBQUksU0FBUyxPQUFPO0lBQ2hCLEtBQUssT0FBTyxJQUFJLE1BQU0sSUFBSTtJQUMxQixLQUFLLGFBQWEsSUFBSSxNQUFNO0dBQ2hDLE9BRUksT0FBTyxNQUFNLGtDQUFrQyxRQUFRLEdBQUcsSUFBSSxHQUFHLEtBQUssSUFBSSxPQUFPO0VBRXpGLE9BRUksSUFBSSxVQUFVLE9BQU87R0FDakIsSUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLEtBQUssS0FBSyxPQUFPLElBQUksR0FBRyxDQUFDLFFBQVEsSUFBSSxLQUFLLE1BQU0sSUFDaEUsS0FBSyxPQUFPLElBQUksR0FBRyxDQUFDLEtBQUssSUFBSSxLQUFLO1FBR2xDLE9BQU8sTUFBTSwyQkFBMkIsUUFBUSxHQUFHLElBQUksR0FBRyxLQUFLLElBQUksT0FBTztFQUdsRixPQUNLLElBQUksUUFBUSxPQUFPO0dBQ3BCLEtBQUssT0FBTyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUs7R0FDaEMsS0FBSyxhQUFhLElBQUksTUFBTTtFQUNoQyxPQUVJLE9BQU8sTUFBTSw2QkFBNkIsUUFBUSxHQUFHLElBQUksR0FBRyxLQUFLLElBQUksT0FBTztFQUdwRixLQUFLLGdCQUFnQixHQUFHO0NBQzVCO0NBQ0EsZ0JBQWdCLEtBQUs7RUFDakIsSUFBSSxLQUFLLE1BQU0sVUFDWCxLQUFLLEtBQUssU0FBUztHQUFFLFVBQVU7R0FBTSxLQUFLO0lBQUUsTUFBTTtJQUFVLElBQUksSUFBSTtJQUFJLE9BQU8sSUFBSTtHQUFNO0VBQUUsQ0FBQztDQUVwRztBQUNKO0FBQ0EsU0FBZ0IsWUFBWSxTQUFTO0NBQ2pDLElBQUksUUFBUSxTQUFTLEdBQ2pCLE9BQU8sR0FBRyxRQUFRLE1BQU0sR0FBRyxRQUFRLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsS0FBSyxRQUFRLFFBQVEsU0FBUztDQUU1RixPQUFPLFFBQVEsS0FBSyxLQUFLO0FBQzdCIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjldfQ==