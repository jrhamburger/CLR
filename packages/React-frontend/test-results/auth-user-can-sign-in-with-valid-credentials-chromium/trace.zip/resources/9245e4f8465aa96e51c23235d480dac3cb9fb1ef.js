import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Search.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import "/src/styles/Search.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Search.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function Search({ session, onStartQueue }) {
	_s();
	const [searchText, setSearchText] = useState("");
	const [tracks, setTracks] = useState([]);
	const [isSearching, setIsSearching] = useState(false);
	const [searchError, setSearchError] = useState("");
	async function handleSearch(event) {
		event.preventDefault();
		const query = searchText.trim();
		if (!query) {
			return;
		}
		try {
			setIsSearching(true);
			setSearchError("");
			const response = await fetch(`/api/catalog/search?q=${encodeURIComponent(query)}`, { headers: { Authorization: `Bearer ${session.access_token}` } });
			if (!response.ok) {
				throw new Error("Could not search the catalog.");
			}
			const data = await response.json();
			console.table(data.tracks.map((track) => ({
				id: track.id,
				recordingMbid: track.recordingMbid,
				title: track.title,
				artist: track.artist,
				coverArtUrl: track.coverArtUrl
			})));
			setTracks(data.tracks);
		} catch (error) {
			console.error(error);
			setSearchError("Something went wrong while searching.");
		} finally {
			setIsSearching(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Search" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSearch,
			children: [/* @__PURE__ */ _jsxDEV("input", {
				type: "search",
				value: searchText,
				onChange: (event) => setSearchText(event.target.value),
				placeholder: "Search songs or artists"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSearching,
				children: isSearching ? "Searching..." : "Search"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 9
		}, this),
		searchError && /* @__PURE__ */ _jsxDEV("p", { children: searchError }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 25
		}, this),
		/* @__PURE__ */ _jsxDEV("ul", { children: tracks.map((track, index) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
			className: "search-result-card",
			type: "button",
			disabled: !track.audioUrl,
			onClick: () => {
				if (track.audioUrl) {
					onStartQueue([track], 0);
				}
			},
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "search-result-cover-frame",
					children: /* @__PURE__ */ _jsxDEV("img", {
						src: track.coverArtUrl,
						alt: `${track.title} cover art`,
						className: "search-result-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 19
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 17
				}, this),
				track.title,
				" — ",
				track.artist
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 15
		}, this) }, track.id ?? track.recordingMbid, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_s(Search, "lJ2/fn7+hpqmUvdz+zd+7Janqzs=");
_c = Search;
export default Search;
var _c;
$RefreshReg$(_c, "Search");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Search.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Search.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Search.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Search.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTzs7OztBQUVQLFNBQVMsT0FBTyxFQUFFLFNBQVMsZ0JBQWdCOztDQUN6QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxDQUFDLENBQUM7Q0FDdkMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBRWpELGVBQWUsYUFBYSxPQUFPO0VBQ2pDLE1BQU0sZUFBZTtFQUVyQixNQUFNLFFBQVEsV0FBVyxLQUFLO0VBRTlCLElBQUksQ0FBQyxPQUFPO0dBQ1Y7RUFDRjtFQUVBLElBQUk7R0FDRixlQUFlLElBQUk7R0FDbkIsZUFBZSxFQUFFO0dBRWpCLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLHlCQUF5QixtQkFBbUIsS0FBSyxLQUNqRCxFQUNFLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFBUSxlQUNuQyxFQUNGLENBQ0Y7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLCtCQUErQjtHQUNqRDtHQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUVqQyxRQUFRLE1BQ04sS0FBSyxPQUFPLEtBQUssV0FBVztJQUMxQixJQUFJLE1BQU07SUFDVixlQUFlLE1BQU07SUFDckIsT0FBTyxNQUFNO0lBQ2IsUUFBUSxNQUFNO0lBQ2QsYUFBYSxNQUFNO0dBQ3JCLEVBQUUsQ0FDSjtHQUVBLFVBQVUsS0FBSyxNQUFNO0VBQ3ZCLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxLQUFLO0dBQ25CLGVBQWUsdUNBQXVDO0VBQ3hELFVBQVU7R0FDUixlQUFlLEtBQUs7RUFDdEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSxTQUFVOzs7O1dBQ2Qsd0JBQUMsV0FBRDtFQUNFLHdCQUFDLFFBQUQ7R0FBTSxVQUFVO2FBQWhCLENBQ0Usd0JBQUMsU0FBRDtJQUNFLE1BQUs7SUFDTCxPQUFPO0lBQ1AsV0FBVyxVQUNULGNBQWMsTUFBTSxPQUFPLEtBQUs7SUFFbEMsYUFBWTtHQUNiOzs7O2FBRUQsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVO2NBQzdCLGNBQWMsaUJBQWlCO0dBQzFCOzs7O1dBQ0o7Ozs7OztFQUVMLGVBQWUsd0JBQUMsS0FBRCxZQUFJLFlBQWU7Ozs7O0VBRW5DLHdCQUFDLE1BQUQsWUFDRyxPQUFPLEtBQUssT0FBTyxVQUNsQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtHQUNFLFdBQVU7R0FDVixNQUFLO0dBQ0wsVUFBVSxDQUFDLE1BQU07R0FDakIsZUFBZTtJQUNiLElBQUksTUFBTSxVQUFVO0tBQ2xCLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQztJQUN6QjtHQUNGO2FBUkY7SUFVRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFDQSxLQUFLLE1BQU07TUFDWCxLQUFLLEdBQUcsTUFBTSxNQUFNO01BQ3BCLFdBQVU7S0FDWDs7Ozs7SUFDSTs7Ozs7SUFFSixNQUFNO0lBQU07SUFBSSxNQUFNO0dBQ2pCOzs7OztXQUNOLEdBckJLLE1BQU0sTUFBTSxNQUFNOzs7O1NBcUJ2QixDQUNMLEVBQ0M7Ozs7O0NBQ0c7Ozs7U0FDTjs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZWFyY2guanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9TZWFyY2guY3NzXCI7XHJcblxyXG5mdW5jdGlvbiBTZWFyY2goeyBzZXNzaW9uLCBvblN0YXJ0UXVldWUgfSkge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0cmFja3MsIHNldFRyYWNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzU2VhcmNoaW5nLCBzZXRJc1NlYXJjaGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaEVycm9yLCBzZXRTZWFyY2hFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU2VhcmNoKGV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IHF1ZXJ5ID0gc2VhcmNoVGV4dC50cmltKCk7XHJcblxyXG4gICAgaWYgKCFxdWVyeSkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNTZWFyY2hpbmcodHJ1ZSk7XHJcbiAgICAgIHNldFNlYXJjaEVycm9yKFwiXCIpO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9jYXRhbG9nL3NlYXJjaD9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5KX1gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Nlc3Npb24uYWNjZXNzX3Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZCBub3Qgc2VhcmNoIHRoZSBjYXRhbG9nLlwiKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuXHJcbiAgICAgIGNvbnNvbGUudGFibGUoXHJcbiAgICAgICAgZGF0YS50cmFja3MubWFwKCh0cmFjaykgPT4gKHtcclxuICAgICAgICAgIGlkOiB0cmFjay5pZCxcclxuICAgICAgICAgIHJlY29yZGluZ01iaWQ6IHRyYWNrLnJlY29yZGluZ01iaWQsXHJcbiAgICAgICAgICB0aXRsZTogdHJhY2sudGl0bGUsXHJcbiAgICAgICAgICBhcnRpc3Q6IHRyYWNrLmFydGlzdCxcclxuICAgICAgICAgIGNvdmVyQXJ0VXJsOiB0cmFjay5jb3ZlckFydFVybCxcclxuICAgICAgICB9KSlcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldFRyYWNrcyhkYXRhLnRyYWNrcyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgc2V0U2VhcmNoRXJyb3IoXCJTb21ldGhpbmcgd2VudCB3cm9uZyB3aGlsZSBzZWFyY2hpbmcuXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTZWFyY2hpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxoMj5TZWFyY2g8L2gyPlxyXG4gICAgICA8c2VjdGlvbj5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VhcmNofT5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRleHR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgc2V0U2VhcmNoVGV4dChldmVudC50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggc29uZ3Mgb3IgYXJ0aXN0c1wiXHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtpc1NlYXJjaGluZ30+XHJcbiAgICAgICAgICAgIHtpc1NlYXJjaGluZyA/IFwiU2VhcmNoaW5nLi4uXCIgOiBcIlNlYXJjaFwifVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgICB7c2VhcmNoRXJyb3IgJiYgPHA+e3NlYXJjaEVycm9yfTwvcD59XHJcblxyXG4gICAgICAgIDx1bD5cclxuICAgICAgICAgIHt0cmFja3MubWFwKCh0cmFjaywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPGxpIGtleT17dHJhY2suaWQgPz8gdHJhY2sucmVjb3JkaW5nTWJpZH0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNlYXJjaC1yZXN1bHQtY2FyZFwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdHJhY2suYXVkaW9Vcmx9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmICh0cmFjay5hdWRpb1VybCkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9uU3RhcnRRdWV1ZShbdHJhY2tdLCAwKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaC1yZXN1bHQtY292ZXItZnJhbWVcIj5cclxuICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICBzcmM9e3RyYWNrLmNvdmVyQXJ0VXJsfVxyXG4gICAgICAgICAgICAgICAgICBhbHQ9e2Ake3RyYWNrLnRpdGxlfSBjb3ZlciBhcnRgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZWFyY2gtcmVzdWx0LWNvdmVyXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAge3RyYWNrLnRpdGxlfSDigJQge3RyYWNrLmFydGlzdH1cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvdWw+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNlYXJjaDtcclxuIl19