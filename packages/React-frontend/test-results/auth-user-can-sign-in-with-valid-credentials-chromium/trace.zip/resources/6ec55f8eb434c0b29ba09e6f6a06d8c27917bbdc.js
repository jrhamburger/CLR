import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Playlists.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { supabase } from "/src/lib/supabase.js";
import { PlaylistIcon, TrashIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import PlaylistDetail from "/src/components/PlaylistDetail.jsx";
import "/src/styles/Playlists.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Playlists.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function Playlists({ session }) {
	_s();
	const [playlists, setPlaylists] = useState([]);
	const [message, setMessage] = useState("");
	const [selected, setSelected] = useState(null);
	const [newName, setNewName] = useState("");
	useEffect(() => {
		supabase.from("playlists").select("playlist_id, playlist_name, is_public").eq("user_id", session.user.id).then(({ data, error }) => {
			if (error) setMessage(error.message);
			else setPlaylists(data);
		});
	}, [session]);
	function removePlaylist(playlistId) {
		setPlaylists(playlists.filter((p) => p.playlist_id !== playlistId));
		setSelected(null);
	}
	if (selected) {
		return /* @__PURE__ */ _jsxDEV(PlaylistDetail, {
			playlist: selected,
			onBack: () => setSelected(null),
			onDeleted: removePlaylist
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this);
	}
	async function handleCreate(event) {
		event.preventDefault();
		const { data, error } = await supabase.from("playlists").insert({
			user_id: session.user.id,
			playlist_name: newName
		}).select().single();
		if (error) {
			setMessage(error.message);
			return;
		}
		setPlaylists([...playlists, data]);
		setNewName("");
	}
	async function handleDelete(playlist) {
		if (!window.confirm(`Delete "${playlist.playlist_name}"?`)) return;
		const { error } = await supabase.from("playlists").delete().eq("playlist_id", playlist.playlist_id);
		if (error) {
			setMessage(error.message);
			return;
		}
		removePlaylist(playlist.playlist_id);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "Your playlists" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			className: "playlist-create",
			onSubmit: handleCreate,
			children: [/* @__PURE__ */ _jsxDEV("input", {
				type: "text",
				placeholder: "New playlist name",
				value: newName,
				onChange: (event) => setNewName(event.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				children: "Create"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 7
		}, this),
		playlists.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No playlists yet." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 34
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "playlist-grid",
			children: playlists.map((playlist) => /* @__PURE__ */ _jsxDEV("div", {
				className: "playlist-card",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					className: "playlist-open",
					onClick: () => setSelected(playlist),
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "playlist-cover",
						children: /* @__PURE__ */ _jsxDEV(PlaylistIcon, { size: 48 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "playlist-name",
						children: playlist.playlist_name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: "playlist-delete",
					onClick: () => handleDelete(playlist),
					title: "Delete playlist",
					children: /* @__PURE__ */ _jsxDEV(TrashIcon, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 13
				}, this)]
			}, playlist.playlist_id, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this),
		message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 19
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 5
	}, this);
}
_s(Playlists, "zvyH37+7ZgymCix4+0PztA73qCs=");
_c = Playlists;
export default Playlists;
var _c;
$RefreshReg$(_c, "Playlists");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Playlists.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Playlists.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Playlists.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Playlists.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGNBQWMsaUJBQWlCO0FBQ3hDLE9BQU8sb0JBQW9CO0FBQzNCLE9BQU87Ozs7QUFFUCxTQUFTLFVBQVUsRUFBRSxXQUFXOztDQUM5QixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLElBQUk7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FFekMsZ0JBQWdCO0VBQ2QsU0FDRyxLQUFLLFdBQVcsQ0FBQyxDQUNqQixPQUFPLHVDQUF1QyxDQUFDLENBQy9DLEdBQUcsV0FBVyxRQUFRLEtBQUssRUFBRSxDQUFDLENBQzlCLE1BQU0sRUFBRSxNQUFNLFlBQVk7R0FDekIsSUFBSSxPQUFPLFdBQVcsTUFBTSxPQUFPO1FBQzlCLGFBQWEsSUFBSTtFQUN4QixDQUFDO0NBQ0wsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUVaLFNBQVMsZUFBZSxZQUFZO0VBQ2xDLGFBQWEsVUFBVSxRQUFRLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxDQUFDO0VBQ2xFLFlBQVksSUFBSTtDQUNsQjtDQUVBLElBQUksVUFBVTtFQUNaLE9BQ0Usd0JBQUMsZ0JBQUQ7R0FDRSxVQUFVO0dBQ1YsY0FBYyxZQUFZLElBQUk7R0FDOUIsV0FBVztFQUNaOzs7OztDQUVMO0NBRUYsZUFBZSxhQUFhLE9BQU87RUFDakMsTUFBTSxlQUFlO0VBRXJCLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxTQUMzQixLQUFLLFdBQVcsQ0FBQyxDQUNqQixPQUFPO0dBQUUsU0FBUyxRQUFRLEtBQUs7R0FBSSxlQUFlO0VBQVEsQ0FBQyxDQUFDLENBQzVELE9BQU8sQ0FBQyxDQUNSLE9BQU87RUFFVixJQUFJLE9BQU87R0FDVCxXQUFXLE1BQU0sT0FBTztHQUN4QjtFQUNGO0VBRUEsYUFBYSxDQUFDLEdBQUcsV0FBVyxJQUFJLENBQUM7RUFDakMsV0FBVyxFQUFFO0NBQ2Y7Q0FFQSxlQUFlLGFBQWEsVUFBVTtFQUNwQyxJQUFJLENBQUMsT0FBTyxRQUFRLFdBQVcsU0FBUyxjQUFjLEdBQUcsR0FBRztFQUU1RCxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssV0FBVyxDQUFDLENBQ2pCLE9BQU8sQ0FBQyxDQUNSLEdBQUcsZUFBZSxTQUFTLFdBQVc7RUFFekMsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLGVBQWUsU0FBUyxXQUFXO0NBQ3JDO0NBRUUsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7RUFFdEIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7R0FBa0IsVUFBVTthQUE1QyxDQUNFLHdCQUFDLFNBQUQ7SUFDRSxNQUFLO0lBQ0wsYUFBWTtJQUNaLE9BQU87SUFDUCxXQUFXLFVBQVUsV0FBVyxNQUFNLE9BQU8sS0FBSztJQUNsRDtHQUNEOzs7O2FBQ0Qsd0JBQUMsVUFBRDtJQUFRLE1BQUs7Y0FBUztHQUFjOzs7O1dBQ2hDOzs7Ozs7RUFFTCxVQUFVLFdBQVcsS0FBSyx3QkFBQyxLQUFELFlBQUcsb0JBQW9COzs7OztFQUVsRCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLFVBQVUsS0FBSyxhQUNkLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsV0FBVTtLQUFnQixlQUFlLFlBQVksUUFBUTtlQUFyRSxDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7O0tBQ3RCOzs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWlCLFNBQVM7S0FBb0I7Ozs7YUFDeEQ7Ozs7O2NBRVIsd0JBQUMsVUFBRDtLQUNFLFdBQVU7S0FDVixlQUFlLGFBQWEsUUFBUTtLQUNwQyxPQUFNO2VBRU4sd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7SUFDaEI7Ozs7WUFDTDtNQWhCK0IsU0FBUzs7OztVQWdCeEMsQ0FDTjtFQUNFOzs7OztFQUVKLFdBQVcsd0JBQUMsS0FBRCxZQUFJLFFBQVc7Ozs7O0NBQ3hCOzs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBsYXlsaXN0cy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCIuLi9saWIvc3VwYWJhc2VcIjtcclxuaW1wb3J0IHsgUGxheWxpc3RJY29uLCBUcmFzaEljb24gfSBmcm9tIFwiQHBob3NwaG9yLWljb25zL3JlYWN0XCI7XHJcbmltcG9ydCBQbGF5bGlzdERldGFpbCBmcm9tIFwiLi9QbGF5bGlzdERldGFpbFwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvUGxheWxpc3RzLmNzc1wiO1xyXG5cclxuZnVuY3Rpb24gUGxheWxpc3RzKHsgc2Vzc2lvbiB9KSB7XHJcbiAgY29uc3QgW3BsYXlsaXN0cywgc2V0UGxheWxpc3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtuZXdOYW1lLCBzZXROZXdOYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc3VwYWJhc2VcclxuICAgICAgLmZyb20oXCJwbGF5bGlzdHNcIilcclxuICAgICAgLnNlbGVjdChcInBsYXlsaXN0X2lkLCBwbGF5bGlzdF9uYW1lLCBpc19wdWJsaWNcIilcclxuICAgICAgLmVxKFwidXNlcl9pZFwiLCBzZXNzaW9uLnVzZXIuaWQpXHJcbiAgICAgIC50aGVuKCh7IGRhdGEsIGVycm9yIH0pID0+IHtcclxuICAgICAgICBpZiAoZXJyb3IpIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgICAgZWxzZSBzZXRQbGF5bGlzdHMoZGF0YSk7XHJcbiAgICAgIH0pO1xyXG4gIH0sIFtzZXNzaW9uXSk7XHJcblxyXG4gIGZ1bmN0aW9uIHJlbW92ZVBsYXlsaXN0KHBsYXlsaXN0SWQpIHtcclxuICAgIHNldFBsYXlsaXN0cyhwbGF5bGlzdHMuZmlsdGVyKChwKSA9PiBwLnBsYXlsaXN0X2lkICE9PSBwbGF5bGlzdElkKSk7XHJcbiAgICBzZXRTZWxlY3RlZChudWxsKTtcclxuICB9XHJcblxyXG4gIGlmIChzZWxlY3RlZCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPFBsYXlsaXN0RGV0YWlsXHJcbiAgICAgICAgcGxheWxpc3Q9e3NlbGVjdGVkfVxyXG4gICAgICAgIG9uQmFjaz17KCkgPT4gc2V0U2VsZWN0ZWQobnVsbCl9XHJcbiAgICAgICAgb25EZWxldGVkPXtyZW1vdmVQbGF5bGlzdH1cclxuICAgICAgLz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlQ3JlYXRlKGV2ZW50KSB7XHJcbiAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgIC5mcm9tKFwicGxheWxpc3RzXCIpXHJcbiAgICAuaW5zZXJ0KHsgdXNlcl9pZDogc2Vzc2lvbi51c2VyLmlkLCBwbGF5bGlzdF9uYW1lOiBuZXdOYW1lIH0pXHJcbiAgICAuc2VsZWN0KClcclxuICAgIC5zaW5nbGUoKTtcclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgc2V0UGxheWxpc3RzKFsuLi5wbGF5bGlzdHMsIGRhdGFdKTtcclxuICBzZXROZXdOYW1lKFwiXCIpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxldGUocGxheWxpc3QpIHtcclxuICBpZiAoIXdpbmRvdy5jb25maXJtKGBEZWxldGUgXCIke3BsYXlsaXN0LnBsYXlsaXN0X25hbWV9XCI/YCkpIHJldHVybjtcclxuXHJcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcclxuICAgIC5mcm9tKFwicGxheWxpc3RzXCIpXHJcbiAgICAuZGVsZXRlKClcclxuICAgIC5lcShcInBsYXlsaXN0X2lkXCIsIHBsYXlsaXN0LnBsYXlsaXN0X2lkKTtcclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgcmVtb3ZlUGxheWxpc3QocGxheWxpc3QucGxheWxpc3RfaWQpO1xyXG59XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+WW91ciBwbGF5bGlzdHM8L2gyPlxyXG5cclxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwicGxheWxpc3QtY3JlYXRlXCIgb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZX0+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5ldyBwbGF5bGlzdCBuYW1lXCJcclxuICAgICAgICAgIHZhbHVlPXtuZXdOYW1lfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0TmV3TmFtZShldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkNyZWF0ZTwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICB7cGxheWxpc3RzLmxlbmd0aCA9PT0gMCAmJiA8cD5ObyBwbGF5bGlzdHMgeWV0LjwvcD59XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYXlsaXN0LWdyaWRcIj5cclxuICAgICAgICB7cGxheWxpc3RzLm1hcCgocGxheWxpc3QpID0+IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGxheWxpc3QtY2FyZFwiIGtleT17cGxheWxpc3QucGxheWxpc3RfaWR9PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInBsYXlsaXN0LW9wZW5cIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZChwbGF5bGlzdCl9PlxyXG4gICAgICAgICAgICAgIHsvKiBQbGFjZWhvbGRlciB1bnRpbCBwbGF5bGlzdHMgaGF2ZSB0aGVpciBvd24gY292ZXIgaW1hZ2UgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGF5bGlzdC1jb3ZlclwiPlxyXG4gICAgICAgICAgICAgICAgPFBsYXlsaXN0SWNvbiBzaXplPXs0OH0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwbGF5bGlzdC1uYW1lXCI+e3BsYXlsaXN0LnBsYXlsaXN0X25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwbGF5bGlzdC1kZWxldGVcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShwbGF5bGlzdCl9XHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgcGxheWxpc3RcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFRyYXNoSWNvbiBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiA8cD57bWVzc2FnZX08L3A+fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGxheWxpc3RzOyJdfQ==