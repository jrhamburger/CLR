import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NowPlayingPanel.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { CaretLeftIcon, CaretRightIcon, CaretDoubleRightIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import QueueList, { SongCover } from "/src/components/QueueList.jsx";
import "/src/styles/NowPlaying.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlayingPanel.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// Right column. mode is "open" (full), "mini" (covers only) or "hidden"
function NowPlayingPanel({ mode, onChangeMode, currentSong, upNext }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("aside", {
		className: `now-playing-panel ${mode}`,
		children: [mode === "open" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-header",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Now Playing" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onChangeMode("mini"),
						title: "Shrink",
						children: /* @__PURE__ */ _jsxDEV(CaretRightIcon, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 19,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onChangeMode("hidden"),
						title: "Hide",
						children: /* @__PURE__ */ _jsxDEV(CaretDoubleRightIcon, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(SongCover, {
				song: currentSong,
				size: 240
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "panel-song-title",
				children: currentSong?.title ?? "Nothing playing"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("h4", { children: "Up Next" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(QueueList, { songs: upNext }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 13
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 11
		}, this), mode === "mini" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "panel-header mini",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onChangeMode("open"),
					title: "Expand",
					children: /* @__PURE__ */ _jsxDEV(CaretLeftIcon, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onChangeMode("hidden"),
					title: "Hide",
					children: /* @__PURE__ */ _jsxDEV(CaretDoubleRightIcon, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(SongCover, {
				song: currentSong,
				size: 52
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("hr", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(QueueList, {
				songs: upNext,
				compact: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 13
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 7
	}, this), mode === "hidden" && /* @__PURE__ */ _jsxDEV("button", {
		className: "panel-reveal-tab",
		onClick: () => onChangeMode("open"),
		title: "Show Now Playing",
		children: /* @__PURE__ */ _jsxDEV(CaretLeftIcon, { size: 12 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 11
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_c = NowPlayingPanel;
export default NowPlayingPanel;
var _c;
$RefreshReg$(_c, "NowPlayingPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NowPlayingPanel.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlayingPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlayingPanel.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlayingPanel.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxlQUNBLGdCQUNBLDRCQUNLO0FBQ1AsT0FBTyxhQUFhLGlCQUFpQjtBQUNyQyxPQUFPOzs7O0FBR1AsU0FBUyxnQkFBZ0IsRUFBRSxNQUFNLGNBQWMsYUFBYSxVQUFVO0NBQ3BFLE9BQ0UsZ0RBQ0Usd0JBQUMsU0FBRDtFQUFPLFdBQVcscUJBQXFCO1lBQXZDLENBQ0csU0FBUyxVQUNSO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQsWUFBSSxjQUFlOzs7OztLQUNuQix3QkFBQyxVQUFEO01BQVEsZUFBZSxhQUFhLE1BQU07TUFBRyxPQUFNO2dCQUNqRCx3QkFBQyxnQkFBRCxFQUFnQixNQUFNLEdBQUs7Ozs7O0tBQ3JCOzs7OztLQUNSLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLGFBQWEsUUFBUTtNQUFHLE9BQU07Z0JBQ25ELHdCQUFDLHNCQUFELEVBQXNCLE1BQU0sR0FBSzs7Ozs7S0FDM0I7Ozs7O0lBQ0w7Ozs7OztHQUVMLHdCQUFDLFdBQUQ7SUFBVyxNQUFNO0lBQWEsTUFBTTtHQUFNOzs7OztHQUMxQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUNWLGFBQWEsU0FBUztHQUN0Qjs7Ozs7R0FFSCx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7R0FDZix3QkFBQyxXQUFELEVBQVcsT0FBTyxPQUFTOzs7OztFQUMzQjs7OztZQUdILFNBQVMsVUFDUjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsZUFBZSxhQUFhLE1BQU07S0FBRyxPQUFNO2VBQ2pELHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7O0lBQ3BCOzs7O2NBQ1Isd0JBQUMsVUFBRDtLQUFRLGVBQWUsYUFBYSxRQUFRO0tBQUcsT0FBTTtlQUNuRCx3QkFBQyxzQkFBRCxFQUFzQixNQUFNLEdBQUs7Ozs7O0lBQzNCOzs7O1lBQ0w7Ozs7OztHQUVMLHdCQUFDLFdBQUQ7SUFBVyxNQUFNO0lBQWEsTUFBTTtHQUFLOzs7OztHQUN6Qyx3QkFBQyxNQUFELENBQUs7Ozs7O0dBQ0wsd0JBQUMsV0FBRDtJQUFXLE9BQU87SUFBUTtHQUFTOzs7OztFQUNuQzs7OztVQUVDOzs7OztXQUdOLFNBQVMsWUFDUix3QkFBQyxVQUFEO0VBQ0UsV0FBVTtFQUNWLGVBQWUsYUFBYSxNQUFNO0VBQ2xDLE9BQU07WUFFTix3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7OztDQUNwQjs7OztTQUVWOzs7OztBQUVOOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm93UGxheWluZ1BhbmVsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIENhcmV0TGVmdEljb24sXHJcbiAgQ2FyZXRSaWdodEljb24sXHJcbiAgQ2FyZXREb3VibGVSaWdodEljb24sXHJcbn0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xyXG5pbXBvcnQgUXVldWVMaXN0LCB7IFNvbmdDb3ZlciB9IGZyb20gXCIuL1F1ZXVlTGlzdFwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvTm93UGxheWluZy5jc3NcIjtcclxuXHJcbi8vIFJpZ2h0IGNvbHVtbi4gbW9kZSBpcyBcIm9wZW5cIiAoZnVsbCksIFwibWluaVwiIChjb3ZlcnMgb25seSkgb3IgXCJoaWRkZW5cIlxyXG5mdW5jdGlvbiBOb3dQbGF5aW5nUGFuZWwoeyBtb2RlLCBvbkNoYW5nZU1vZGUsIGN1cnJlbnRTb25nLCB1cE5leHQgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8YXNpZGUgY2xhc3NOYW1lPXtgbm93LXBsYXlpbmctcGFuZWwgJHttb2RlfWB9PlxyXG4gICAgICAgIHttb2RlID09PSBcIm9wZW5cIiAmJiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMz5Ob3cgUGxheWluZzwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZU1vZGUoXCJtaW5pXCIpfSB0aXRsZT1cIlNocmlua1wiPlxyXG4gICAgICAgICAgICAgICAgPENhcmV0UmlnaHRJY29uIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb25DaGFuZ2VNb2RlKFwiaGlkZGVuXCIpfSB0aXRsZT1cIkhpZGVcIj5cclxuICAgICAgICAgICAgICAgIDxDYXJldERvdWJsZVJpZ2h0SWNvbiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8U29uZ0NvdmVyIHNvbmc9e2N1cnJlbnRTb25nfSBzaXplPXsyNDB9IC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInBhbmVsLXNvbmctdGl0bGVcIj5cclxuICAgICAgICAgICAgICB7Y3VycmVudFNvbmc/LnRpdGxlID8/IFwiTm90aGluZyBwbGF5aW5nXCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgIDxoND5VcCBOZXh0PC9oND5cclxuICAgICAgICAgICAgPFF1ZXVlTGlzdCBzb25ncz17dXBOZXh0fSAvPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge21vZGUgPT09IFwibWluaVwiICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWwtaGVhZGVyIG1pbmlcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlTW9kZShcIm9wZW5cIil9IHRpdGxlPVwiRXhwYW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2FyZXRMZWZ0SWNvbiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlTW9kZShcImhpZGRlblwiKX0gdGl0bGU9XCJIaWRlXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2FyZXREb3VibGVSaWdodEljb24gc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPFNvbmdDb3ZlciBzb25nPXtjdXJyZW50U29uZ30gc2l6ZT17NTJ9IC8+XHJcbiAgICAgICAgICAgIDxociAvPlxyXG4gICAgICAgICAgICA8UXVldWVMaXN0IHNvbmdzPXt1cE5leHR9IGNvbXBhY3QgLz5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvYXNpZGU+XHJcblxyXG4gICAgICB7LyogU21hbGwgdGFiIG9uIHRoZSByaWdodCBlZGdlIHRvIGJyaW5nIHRoZSBjb2x1bW4gYmFjayAqL31cclxuICAgICAge21vZGUgPT09IFwiaGlkZGVuXCIgJiYgKFxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInBhbmVsLXJldmVhbC10YWJcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2VNb2RlKFwib3BlblwiKX1cclxuICAgICAgICAgIHRpdGxlPVwiU2hvdyBOb3cgUGxheWluZ1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPENhcmV0TGVmdEljb24gc2l6ZT17MTJ9IC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3dQbGF5aW5nUGFuZWw7XHJcbiJdfQ==