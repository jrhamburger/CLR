import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UploadProgress.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import "/src/styles/UploadProgress.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/UploadProgress.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// Counts finished files, not bytes: Supabase's upload() doesn't report byte progress
function UploadProgress({ done, total }) {
	const percent = done / total * 100;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "upload-progress",
		role: "status",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: [
			"Uploading ",
			Math.min(done + 1, total),
			" of ",
			total,
			"…"
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "upload-progress-track",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "upload-progress-fill",
				style: { width: `${percent}%` }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = UploadProgress;
export default UploadProgress;
var _c;
$RefreshReg$(_c, "UploadProgress");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/UploadProgress.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/UploadProgress.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/UploadProgress.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/UploadProgress.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTzs7OztBQUdQLFNBQVMsZUFBZSxFQUFFLE1BQU0sU0FBUztDQUN2QyxNQUFNLFVBQVcsT0FBTyxRQUFTO0NBRWpDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBa0IsTUFBSztZQUF0QyxDQUNFLHdCQUFDLEtBQUQ7R0FBRztHQUFXLEtBQUssSUFBSSxPQUFPLEdBQUcsS0FBSztHQUFFO0dBQUs7R0FBTTtFQUFJOzs7O1lBQ3ZELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBdUIsT0FBTyxFQUFFLE9BQU8sR0FBRyxRQUFRLEdBQUc7R0FBSTs7Ozs7RUFDckU7Ozs7VUFDRjs7Ozs7O0FBRVQ7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJVcGxvYWRQcm9ncmVzcy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL1VwbG9hZFByb2dyZXNzLmNzc1wiO1xyXG5cclxuLy8gQ291bnRzIGZpbmlzaGVkIGZpbGVzLCBub3QgYnl0ZXM6IFN1cGFiYXNlJ3MgdXBsb2FkKCkgZG9lc24ndCByZXBvcnQgYnl0ZSBwcm9ncmVzc1xyXG5mdW5jdGlvbiBVcGxvYWRQcm9ncmVzcyh7IGRvbmUsIHRvdGFsIH0pIHtcclxuICBjb25zdCBwZXJjZW50ID0gKGRvbmUgLyB0b3RhbCkgKiAxMDA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInVwbG9hZC1wcm9ncmVzc1wiIHJvbGU9XCJzdGF0dXNcIj5cclxuICAgICAgPHA+VXBsb2FkaW5nIHtNYXRoLm1pbihkb25lICsgMSwgdG90YWwpfSBvZiB7dG90YWx94oCmPC9wPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInVwbG9hZC1wcm9ncmVzcy10cmFja1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXBsb2FkLXByb2dyZXNzLWZpbGxcIiBzdHlsZT17eyB3aWR0aDogYCR7cGVyY2VudH0lYCB9fSAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVwbG9hZFByb2dyZXNzO1xyXG4iXX0=