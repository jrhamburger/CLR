import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/QueueList.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { MusicNoteIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import "/src/styles/NowPlaying.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/QueueList.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// Album cover for a song, or a placeholder until songs have a coverUrl
export function SongCover({ song, size }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "song-cover",
		style: {
			width: size,
			height: size
		},
		children: song?.coverUrl ? /* @__PURE__ */ _jsxDEV("img", {
			src: song.coverUrl,
			alt: song.title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV(MusicNoteIcon, { size: size / 2.5 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = SongCover;
// compact: only show covers (used by the mini right column)
function QueueList({ songs, compact }) {
	if (songs.length === 0) {
		return compact ? null : /* @__PURE__ */ _jsxDEV("p", {
			className: "queue-empty",
			children: "Nothing up next."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 29
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("ol", {
		className: `queue-list ${compact ? "compact" : ""}`,
		children: songs.map((song, index) => /* @__PURE__ */ _jsxDEV("li", {
			title: song.title,
			children: [/* @__PURE__ */ _jsxDEV(SongCover, {
				song,
				size: compact ? 44 : 48
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 11
			}, this), !compact && /* @__PURE__ */ _jsxDEV("span", {
				className: "queue-title",
				children: song.title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 24
			}, this)]
		}, index, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_c2 = QueueList;
export default QueueList;
var _c, _c2;
$RefreshReg$(_c, "SongCover");
$RefreshReg$(_c2, "QueueList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/QueueList.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/QueueList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/QueueList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/QueueList.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTzs7OztBQUdQLE9BQU8sU0FBUyxVQUFVLEVBQUUsTUFBTSxRQUFRO0NBQ3hDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBYSxPQUFPO0dBQUUsT0FBTztHQUFNLFFBQVE7RUFBSztZQUM1RCxNQUFNLFdBQ0wsd0JBQUMsT0FBRDtHQUFLLEtBQUssS0FBSztHQUFVLEtBQUssS0FBSztFQUFROzs7O2FBRTNDLHdCQUFDLGVBQUQsRUFBZSxNQUFNLE9BQU8sSUFBTTs7Ozs7Q0FFakM7Ozs7O0FBRVQ7OztBQUdBLFNBQVMsVUFBVSxFQUFFLE9BQU8sV0FBVztDQUNyQyxJQUFJLE1BQU0sV0FBVyxHQUFHO0VBQ3RCLE9BQU8sVUFBVSxPQUFPLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQWM7RUFBbUI7Ozs7O0NBQ3hFO0NBRUEsT0FDRSx3QkFBQyxNQUFEO0VBQUksV0FBVyxjQUFjLFVBQVUsWUFBWTtZQUNoRCxNQUFNLEtBQUssTUFBTSxVQUNoQix3QkFBQyxNQUFEO0dBQWdCLE9BQU8sS0FBSzthQUE1QixDQUNFLHdCQUFDLFdBQUQ7SUFBaUI7SUFBTSxNQUFNLFVBQVUsS0FBSztHQUFLOzs7O2FBQ2hELENBQUMsV0FBVyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFlLEtBQUs7R0FBWTs7OztXQUMzRDtLQUhLOzs7O1NBR0wsQ0FDTDtDQUNDOzs7OztBQUVSOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUXVldWVMaXN0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNdXNpY05vdGVJY29uIH0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvTm93UGxheWluZy5jc3NcIjtcclxuXHJcbi8vIEFsYnVtIGNvdmVyIGZvciBhIHNvbmcsIG9yIGEgcGxhY2Vob2xkZXIgdW50aWwgc29uZ3MgaGF2ZSBhIGNvdmVyVXJsXHJcbmV4cG9ydCBmdW5jdGlvbiBTb25nQ292ZXIoeyBzb25nLCBzaXplIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzb25nLWNvdmVyXCIgc3R5bGU9e3sgd2lkdGg6IHNpemUsIGhlaWdodDogc2l6ZSB9fT5cclxuICAgICAge3Nvbmc/LmNvdmVyVXJsID8gKFxyXG4gICAgICAgIDxpbWcgc3JjPXtzb25nLmNvdmVyVXJsfSBhbHQ9e3NvbmcudGl0bGV9IC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPE11c2ljTm90ZUljb24gc2l6ZT17c2l6ZSAvIDIuNX0gLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbi8vIGNvbXBhY3Q6IG9ubHkgc2hvdyBjb3ZlcnMgKHVzZWQgYnkgdGhlIG1pbmkgcmlnaHQgY29sdW1uKVxyXG5mdW5jdGlvbiBRdWV1ZUxpc3QoeyBzb25ncywgY29tcGFjdCB9KSB7XHJcbiAgaWYgKHNvbmdzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIGNvbXBhY3QgPyBudWxsIDogPHAgY2xhc3NOYW1lPVwicXVldWUtZW1wdHlcIj5Ob3RoaW5nIHVwIG5leHQuPC9wPjtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8b2wgY2xhc3NOYW1lPXtgcXVldWUtbGlzdCAke2NvbXBhY3QgPyBcImNvbXBhY3RcIiA6IFwiXCJ9YH0+XHJcbiAgICAgIHtzb25ncy5tYXAoKHNvbmcsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgPGxpIGtleT17aW5kZXh9IHRpdGxlPXtzb25nLnRpdGxlfT5cclxuICAgICAgICAgIDxTb25nQ292ZXIgc29uZz17c29uZ30gc2l6ZT17Y29tcGFjdCA/IDQ0IDogNDh9IC8+XHJcbiAgICAgICAgICB7IWNvbXBhY3QgJiYgPHNwYW4gY2xhc3NOYW1lPVwicXVldWUtdGl0bGVcIj57c29uZy50aXRsZX08L3NwYW4+fVxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgICkpfVxyXG4gICAgPC9vbD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBRdWV1ZUxpc3Q7XHJcbiJdfQ==