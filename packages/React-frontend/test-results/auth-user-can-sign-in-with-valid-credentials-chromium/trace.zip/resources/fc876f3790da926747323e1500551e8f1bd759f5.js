import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=987d57e9";
import { B as require_browser, L as UINT8, O as StringType, U as isRandomAccessTokenizer, V as textDecode, t as BasicParser } from "/node_modules/.vite/deps/BasicParser-CAIs-t7m.js?v=987d57e9";
import { t as APEv2Parser } from "/node_modules/.vite/deps/APEv2Parser-BWD6Dcm_.js?v=987d57e9";
import { d as trimRightNull } from "/node_modules/.vite/deps/Util-DYMxorDw.js?v=987d57e9";
var debug = (0, (/* @__PURE__ */ __toESM(require_browser(), 1)).default)("music-metadata:parser:ID3v1");
/**
* ID3v1 Genre mappings
* Ref: https://de.wikipedia.org/wiki/Liste_der_ID3v1-Genres
*/
var Genres = [
	"Blues",
	"Classic Rock",
	"Country",
	"Dance",
	"Disco",
	"Funk",
	"Grunge",
	"Hip-Hop",
	"Jazz",
	"Metal",
	"New Age",
	"Oldies",
	"Other",
	"Pop",
	"R&B",
	"Rap",
	"Reggae",
	"Rock",
	"Techno",
	"Industrial",
	"Alternative",
	"Ska",
	"Death Metal",
	"Pranks",
	"Soundtrack",
	"Euro-Techno",
	"Ambient",
	"Trip-Hop",
	"Vocal",
	"Jazz+Funk",
	"Fusion",
	"Trance",
	"Classical",
	"Instrumental",
	"Acid",
	"House",
	"Game",
	"Sound Clip",
	"Gospel",
	"Noise",
	"Alt. Rock",
	"Bass",
	"Soul",
	"Punk",
	"Space",
	"Meditative",
	"Instrumental Pop",
	"Instrumental Rock",
	"Ethnic",
	"Gothic",
	"Darkwave",
	"Techno-Industrial",
	"Electronic",
	"Pop-Folk",
	"Eurodance",
	"Dream",
	"Southern Rock",
	"Comedy",
	"Cult",
	"Gangsta Rap",
	"Top 40",
	"Christian Rap",
	"Pop/Funk",
	"Jungle",
	"Native American",
	"Cabaret",
	"New Wave",
	"Psychedelic",
	"Rave",
	"Showtunes",
	"Trailer",
	"Lo-Fi",
	"Tribal",
	"Acid Punk",
	"Acid Jazz",
	"Polka",
	"Retro",
	"Musical",
	"Rock & Roll",
	"Hard Rock",
	"Folk",
	"Folk/Rock",
	"National Folk",
	"Swing",
	"Fast-Fusion",
	"Bebob",
	"Latin",
	"Revival",
	"Celtic",
	"Bluegrass",
	"Avantgarde",
	"Gothic Rock",
	"Progressive Rock",
	"Psychedelic Rock",
	"Symphonic Rock",
	"Slow Rock",
	"Big Band",
	"Chorus",
	"Easy Listening",
	"Acoustic",
	"Humour",
	"Speech",
	"Chanson",
	"Opera",
	"Chamber Music",
	"Sonata",
	"Symphony",
	"Booty Bass",
	"Primus",
	"Porn Groove",
	"Satire",
	"Slow Jam",
	"Club",
	"Tango",
	"Samba",
	"Folklore",
	"Ballad",
	"Power Ballad",
	"Rhythmic Soul",
	"Freestyle",
	"Duet",
	"Punk Rock",
	"Drum Solo",
	"A Cappella",
	"Euro-House",
	"Dance Hall",
	"Goa",
	"Drum & Bass",
	"Club-House",
	"Hardcore",
	"Terror",
	"Indie",
	"BritPop",
	"Negerpunk",
	"Polsk Punk",
	"Beat",
	"Christian Gangsta Rap",
	"Heavy Metal",
	"Black Metal",
	"Crossover",
	"Contemporary Christian",
	"Christian Rock",
	"Merengue",
	"Salsa",
	"Thrash Metal",
	"Anime",
	"JPop",
	"Synthpop",
	"Abstract",
	"Art Rock",
	"Baroque",
	"Bhangra",
	"Big Beat",
	"Breakbeat",
	"Chillout",
	"Downtempo",
	"Dub",
	"EBM",
	"Eclectic",
	"Electro",
	"Electroclash",
	"Emo",
	"Experimental",
	"Garage",
	"Global",
	"IDM",
	"Illbient",
	"Industro-Goth",
	"Jam Band",
	"Krautrock",
	"Leftfield",
	"Lounge",
	"Math Rock",
	"New Romantic",
	"Nu-Breakz",
	"Post-Punk",
	"Post-Rock",
	"Psytrance",
	"Shoegaze",
	"Space Rock",
	"Trop Rock",
	"World Music",
	"Neoclassical",
	"Audiobook",
	"Audio Theatre",
	"Neue Deutsche Welle",
	"Podcast",
	"Indie Rock",
	"G-Funk",
	"Dubstep",
	"Garage Rock",
	"Psybient"
];
/**
* Spec: http://id3.org/ID3v1
* Wiki: https://en.wikipedia.org/wiki/ID3
*/
var Iid3v1Token = {
	len: 128,
	/**
	* @param buf Buffer possibly holding the 128-byte ID3v1/1.1 metadata header
	* @param off Offset in buffer in bytes
	* @returns ID3v1/1.1 header if the first 3 bytes equal 'TAG', otherwise null is returned
	*/
	get: (buf, off) => {
		const header = new Id3v1StringType(3).get(buf, off);
		if (header !== "TAG") return null;
		const zeroByte = UINT8.get(buf, off + 125);
		const track = UINT8.get(buf, off + 126);
		const hasTrack = zeroByte === 0 && track !== 0;
		return {
			header,
			title: new Id3v1StringType(30).get(buf, off + 3),
			artist: new Id3v1StringType(30).get(buf, off + 33),
			album: new Id3v1StringType(30).get(buf, off + 63),
			year: new Id3v1StringType(4).get(buf, off + 93),
			comment: new Id3v1StringType(hasTrack ? 28 : 30).get(buf, off + 97),
			track: hasTrack ? track : void 0,
			genre: UINT8.get(buf, off + 127)
		};
	}
};
var Id3v1StringType = class {
	len;
	stringType;
	constructor(len) {
		this.len = len;
		this.stringType = new StringType(len, "latin1");
	}
	get(buf, off) {
		let value = this.stringType.get(buf, off);
		value = trimRightNull(value);
		value = value.trim();
		return value.length > 0 ? value : void 0;
	}
};
var ID3v1Parser = class ID3v1Parser extends BasicParser {
	apeHeader;
	constructor(metadata, tokenizer, options) {
		super(metadata, tokenizer, options);
		this.apeHeader = options.apeHeader;
	}
	static getGenre(genreIndex) {
		if (genreIndex < Genres.length) return Genres[genreIndex];
	}
	async parse() {
		if (!this.tokenizer.fileInfo.size) {
			debug("Skip checking for ID3v1 because the file-size is unknown");
			return;
		}
		if (this.apeHeader && isRandomAccessTokenizer(this.tokenizer)) {
			this.tokenizer.setPosition(this.apeHeader.offset);
			await new APEv2Parser(this.metadata, this.tokenizer, this.options).parseTags(this.apeHeader.footer);
		}
		const offset = this.tokenizer.fileInfo.size - Iid3v1Token.len;
		if (this.tokenizer.position > offset) {
			debug("Already consumed the last 128 bytes");
			return;
		}
		const header = await this.tokenizer.readToken(Iid3v1Token, offset);
		if (header) {
			debug("ID3v1 header found at: pos=%s", this.tokenizer.fileInfo.size - Iid3v1Token.len);
			for (const id of [
				"title",
				"artist",
				"album",
				"comment",
				"track",
				"year"
			]) if (header[id] && header[id] !== "") await this.addTag(id, header[id]);
			const genre = ID3v1Parser.getGenre(header.genre);
			if (genre) await this.addTag("genre", genre);
		} else debug("ID3v1 header not found at: pos=%s", this.tokenizer.fileInfo.size - Iid3v1Token.len);
	}
	async addTag(id, value) {
		await this.metadata.addTag("ID3v1", id, value);
	}
};
async function hasID3v1Header(tokenizer) {
	if (tokenizer.fileInfo.size >= 128) {
		const tag = /* @__PURE__ */ new Uint8Array(3);
		const position = tokenizer.position;
		await tokenizer.readBuffer(tag, { position: tokenizer.fileInfo.size - 128 });
		tokenizer.setPosition(position);
		return textDecode(tag, "latin1") === "TAG";
	}
	return false;
}
export { ID3v1Parser as n, hasID3v1Header as r, Genres as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSUQzdjFQYXJzZXItRTdFMnVsMkkuanMiLCJuYW1lcyI6WyJpbml0RGVidWciLCJ1dGlsLnRyaW1SaWdodE51bGwiXSwic291cmNlcyI6WyIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvaWQzdjEvSUQzdjFQYXJzZXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdGV4dERlY29kZSB9IGZyb20gJ0Bib3Jld2l0L3RleHQtY29kZWMnO1xuaW1wb3J0IGluaXREZWJ1ZyBmcm9tICdkZWJ1Zyc7XG5pbXBvcnQgeyBpc1JhbmRvbUFjY2Vzc1Rva2VuaXplciB9IGZyb20gJ3N0cnRvazMnO1xuaW1wb3J0IHsgU3RyaW5nVHlwZSwgVUlOVDggfSBmcm9tICd0b2tlbi10eXBlcyc7XG5pbXBvcnQgeyBBUEV2MlBhcnNlciB9IGZyb20gJy4uL2FwZXYyL0FQRXYyUGFyc2VyLmpzJztcbmltcG9ydCB7IEJhc2ljUGFyc2VyIH0gZnJvbSAnLi4vY29tbW9uL0Jhc2ljUGFyc2VyLmpzJztcbmltcG9ydCAqIGFzIHV0aWwgZnJvbSAnLi4vY29tbW9uL1V0aWwuanMnO1xuY29uc3QgZGVidWcgPSBpbml0RGVidWcoJ211c2ljLW1ldGFkYXRhOnBhcnNlcjpJRDN2MScpO1xuLyoqXG4gKiBJRDN2MSBHZW5yZSBtYXBwaW5nc1xuICogUmVmOiBodHRwczovL2RlLndpa2lwZWRpYS5vcmcvd2lraS9MaXN0ZV9kZXJfSUQzdjEtR2VucmVzXG4gKi9cbmV4cG9ydCBjb25zdCBHZW5yZXMgPSBbXG4gICAgJ0JsdWVzJyxcbiAgICAnQ2xhc3NpYyBSb2NrJyxcbiAgICAnQ291bnRyeScsXG4gICAgJ0RhbmNlJyxcbiAgICAnRGlzY28nLFxuICAgICdGdW5rJyxcbiAgICAnR3J1bmdlJyxcbiAgICAnSGlwLUhvcCcsXG4gICAgJ0phenonLFxuICAgICdNZXRhbCcsXG4gICAgJ05ldyBBZ2UnLFxuICAgICdPbGRpZXMnLFxuICAgICdPdGhlcicsXG4gICAgJ1BvcCcsXG4gICAgJ1ImQicsXG4gICAgJ1JhcCcsXG4gICAgJ1JlZ2dhZScsXG4gICAgJ1JvY2snLFxuICAgICdUZWNobm8nLFxuICAgICdJbmR1c3RyaWFsJyxcbiAgICAnQWx0ZXJuYXRpdmUnLFxuICAgICdTa2EnLFxuICAgICdEZWF0aCBNZXRhbCcsXG4gICAgJ1ByYW5rcycsXG4gICAgJ1NvdW5kdHJhY2snLFxuICAgICdFdXJvLVRlY2hubycsXG4gICAgJ0FtYmllbnQnLFxuICAgICdUcmlwLUhvcCcsXG4gICAgJ1ZvY2FsJyxcbiAgICAnSmF6eitGdW5rJyxcbiAgICAnRnVzaW9uJyxcbiAgICAnVHJhbmNlJyxcbiAgICAnQ2xhc3NpY2FsJyxcbiAgICAnSW5zdHJ1bWVudGFsJyxcbiAgICAnQWNpZCcsXG4gICAgJ0hvdXNlJyxcbiAgICAnR2FtZScsXG4gICAgJ1NvdW5kIENsaXAnLFxuICAgICdHb3NwZWwnLFxuICAgICdOb2lzZScsXG4gICAgJ0FsdC4gUm9jaycsXG4gICAgJ0Jhc3MnLFxuICAgICdTb3VsJyxcbiAgICAnUHVuaycsXG4gICAgJ1NwYWNlJyxcbiAgICAnTWVkaXRhdGl2ZScsXG4gICAgJ0luc3RydW1lbnRhbCBQb3AnLFxuICAgICdJbnN0cnVtZW50YWwgUm9jaycsXG4gICAgJ0V0aG5pYycsXG4gICAgJ0dvdGhpYycsXG4gICAgJ0Rhcmt3YXZlJyxcbiAgICAnVGVjaG5vLUluZHVzdHJpYWwnLFxuICAgICdFbGVjdHJvbmljJyxcbiAgICAnUG9wLUZvbGsnLFxuICAgICdFdXJvZGFuY2UnLFxuICAgICdEcmVhbScsXG4gICAgJ1NvdXRoZXJuIFJvY2snLFxuICAgICdDb21lZHknLFxuICAgICdDdWx0JyxcbiAgICAnR2FuZ3N0YSBSYXAnLFxuICAgICdUb3AgNDAnLFxuICAgICdDaHJpc3RpYW4gUmFwJyxcbiAgICAnUG9wL0Z1bmsnLFxuICAgICdKdW5nbGUnLFxuICAgICdOYXRpdmUgQW1lcmljYW4nLFxuICAgICdDYWJhcmV0JyxcbiAgICAnTmV3IFdhdmUnLFxuICAgICdQc3ljaGVkZWxpYycsXG4gICAgJ1JhdmUnLFxuICAgICdTaG93dHVuZXMnLFxuICAgICdUcmFpbGVyJyxcbiAgICAnTG8tRmknLFxuICAgICdUcmliYWwnLFxuICAgICdBY2lkIFB1bmsnLFxuICAgICdBY2lkIEphenonLFxuICAgICdQb2xrYScsXG4gICAgJ1JldHJvJyxcbiAgICAnTXVzaWNhbCcsXG4gICAgJ1JvY2sgJiBSb2xsJyxcbiAgICAnSGFyZCBSb2NrJyxcbiAgICAnRm9saycsXG4gICAgJ0ZvbGsvUm9jaycsXG4gICAgJ05hdGlvbmFsIEZvbGsnLFxuICAgICdTd2luZycsXG4gICAgJ0Zhc3QtRnVzaW9uJyxcbiAgICAnQmVib2InLFxuICAgICdMYXRpbicsXG4gICAgJ1Jldml2YWwnLFxuICAgICdDZWx0aWMnLFxuICAgICdCbHVlZ3Jhc3MnLFxuICAgICdBdmFudGdhcmRlJyxcbiAgICAnR290aGljIFJvY2snLFxuICAgICdQcm9ncmVzc2l2ZSBSb2NrJyxcbiAgICAnUHN5Y2hlZGVsaWMgUm9jaycsXG4gICAgJ1N5bXBob25pYyBSb2NrJyxcbiAgICAnU2xvdyBSb2NrJyxcbiAgICAnQmlnIEJhbmQnLFxuICAgICdDaG9ydXMnLFxuICAgICdFYXN5IExpc3RlbmluZycsXG4gICAgJ0Fjb3VzdGljJyxcbiAgICAnSHVtb3VyJyxcbiAgICAnU3BlZWNoJyxcbiAgICAnQ2hhbnNvbicsXG4gICAgJ09wZXJhJyxcbiAgICAnQ2hhbWJlciBNdXNpYycsXG4gICAgJ1NvbmF0YScsXG4gICAgJ1N5bXBob255JyxcbiAgICAnQm9vdHkgQmFzcycsXG4gICAgJ1ByaW11cycsXG4gICAgJ1Bvcm4gR3Jvb3ZlJyxcbiAgICAnU2F0aXJlJyxcbiAgICAnU2xvdyBKYW0nLFxuICAgICdDbHViJyxcbiAgICAnVGFuZ28nLFxuICAgICdTYW1iYScsXG4gICAgJ0ZvbGtsb3JlJyxcbiAgICAnQmFsbGFkJyxcbiAgICAnUG93ZXIgQmFsbGFkJyxcbiAgICAnUmh5dGhtaWMgU291bCcsXG4gICAgJ0ZyZWVzdHlsZScsXG4gICAgJ0R1ZXQnLFxuICAgICdQdW5rIFJvY2snLFxuICAgICdEcnVtIFNvbG8nLFxuICAgICdBIENhcHBlbGxhJyxcbiAgICAnRXVyby1Ib3VzZScsXG4gICAgJ0RhbmNlIEhhbGwnLFxuICAgICdHb2EnLFxuICAgICdEcnVtICYgQmFzcycsXG4gICAgJ0NsdWItSG91c2UnLFxuICAgICdIYXJkY29yZScsXG4gICAgJ1RlcnJvcicsXG4gICAgJ0luZGllJyxcbiAgICAnQnJpdFBvcCcsXG4gICAgJ05lZ2VycHVuaycsXG4gICAgJ1BvbHNrIFB1bmsnLFxuICAgICdCZWF0JyxcbiAgICAnQ2hyaXN0aWFuIEdhbmdzdGEgUmFwJyxcbiAgICAnSGVhdnkgTWV0YWwnLFxuICAgICdCbGFjayBNZXRhbCcsXG4gICAgJ0Nyb3Nzb3ZlcicsXG4gICAgJ0NvbnRlbXBvcmFyeSBDaHJpc3RpYW4nLFxuICAgICdDaHJpc3RpYW4gUm9jaycsXG4gICAgJ01lcmVuZ3VlJyxcbiAgICAnU2Fsc2EnLFxuICAgICdUaHJhc2ggTWV0YWwnLFxuICAgICdBbmltZScsXG4gICAgJ0pQb3AnLFxuICAgICdTeW50aHBvcCcsXG4gICAgJ0Fic3RyYWN0JyxcbiAgICAnQXJ0IFJvY2snLFxuICAgICdCYXJvcXVlJyxcbiAgICAnQmhhbmdyYScsXG4gICAgJ0JpZyBCZWF0JyxcbiAgICAnQnJlYWtiZWF0JyxcbiAgICAnQ2hpbGxvdXQnLFxuICAgICdEb3dudGVtcG8nLFxuICAgICdEdWInLFxuICAgICdFQk0nLFxuICAgICdFY2xlY3RpYycsXG4gICAgJ0VsZWN0cm8nLFxuICAgICdFbGVjdHJvY2xhc2gnLFxuICAgICdFbW8nLFxuICAgICdFeHBlcmltZW50YWwnLFxuICAgICdHYXJhZ2UnLFxuICAgICdHbG9iYWwnLFxuICAgICdJRE0nLFxuICAgICdJbGxiaWVudCcsXG4gICAgJ0luZHVzdHJvLUdvdGgnLFxuICAgICdKYW0gQmFuZCcsXG4gICAgJ0tyYXV0cm9jaycsXG4gICAgJ0xlZnRmaWVsZCcsXG4gICAgJ0xvdW5nZScsXG4gICAgJ01hdGggUm9jaycsXG4gICAgJ05ldyBSb21hbnRpYycsXG4gICAgJ051LUJyZWFreicsXG4gICAgJ1Bvc3QtUHVuaycsXG4gICAgJ1Bvc3QtUm9jaycsXG4gICAgJ1BzeXRyYW5jZScsXG4gICAgJ1Nob2VnYXplJyxcbiAgICAnU3BhY2UgUm9jaycsXG4gICAgJ1Ryb3AgUm9jaycsXG4gICAgJ1dvcmxkIE11c2ljJyxcbiAgICAnTmVvY2xhc3NpY2FsJyxcbiAgICAnQXVkaW9ib29rJyxcbiAgICAnQXVkaW8gVGhlYXRyZScsXG4gICAgJ05ldWUgRGV1dHNjaGUgV2VsbGUnLFxuICAgICdQb2RjYXN0JyxcbiAgICAnSW5kaWUgUm9jaycsXG4gICAgJ0ctRnVuaycsXG4gICAgJ0R1YnN0ZXAnLFxuICAgICdHYXJhZ2UgUm9jaycsXG4gICAgJ1BzeWJpZW50J1xuXTtcbi8qKlxuICogU3BlYzogaHR0cDovL2lkMy5vcmcvSUQzdjFcbiAqIFdpa2k6IGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0lEM1xuICovXG5jb25zdCBJaWQzdjFUb2tlbiA9IHtcbiAgICBsZW46IDEyOCxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0gYnVmIEJ1ZmZlciBwb3NzaWJseSBob2xkaW5nIHRoZSAxMjgtYnl0ZSBJRDN2MS8xLjEgbWV0YWRhdGEgaGVhZGVyXG4gICAgICogQHBhcmFtIG9mZiBPZmZzZXQgaW4gYnVmZmVyIGluIGJ5dGVzXG4gICAgICogQHJldHVybnMgSUQzdjEvMS4xIGhlYWRlciBpZiB0aGUgZmlyc3QgMyBieXRlcyBlcXVhbCAnVEFHJywgb3RoZXJ3aXNlIG51bGwgaXMgcmV0dXJuZWRcbiAgICAgKi9cbiAgICBnZXQ6IChidWYsIG9mZikgPT4ge1xuICAgICAgICBjb25zdCBoZWFkZXIgPSBuZXcgSWQzdjFTdHJpbmdUeXBlKDMpLmdldChidWYsIG9mZik7XG4gICAgICAgIGlmIChoZWFkZXIgIT09ICdUQUcnKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB6ZXJvQnl0ZSA9IFVJTlQ4LmdldChidWYsIG9mZiArIDEyNSk7XG4gICAgICAgIGNvbnN0IHRyYWNrID0gVUlOVDguZ2V0KGJ1Ziwgb2ZmICsgMTI2KTtcbiAgICAgICAgLy8gSUQzdjEuMSByZXBsYWNlcyB0aGUgZmluYWwgdHdvIGNvbW1lbnQgYnl0ZXMgd2l0aCBhIHplcm8gc2VwYXJhdG9yIGFuZCBhIG5vbnplcm8gdHJhY2sgbnVtYmVyLlxuICAgICAgICBjb25zdCBoYXNUcmFjayA9IHplcm9CeXRlID09PSAwICYmIHRyYWNrICE9PSAwO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGVhZGVyLFxuICAgICAgICAgICAgdGl0bGU6IG5ldyBJZDN2MVN0cmluZ1R5cGUoMzApLmdldChidWYsIG9mZiArIDMpLFxuICAgICAgICAgICAgYXJ0aXN0OiBuZXcgSWQzdjFTdHJpbmdUeXBlKDMwKS5nZXQoYnVmLCBvZmYgKyAzMyksXG4gICAgICAgICAgICBhbGJ1bTogbmV3IElkM3YxU3RyaW5nVHlwZSgzMCkuZ2V0KGJ1Ziwgb2ZmICsgNjMpLFxuICAgICAgICAgICAgeWVhcjogbmV3IElkM3YxU3RyaW5nVHlwZSg0KS5nZXQoYnVmLCBvZmYgKyA5MyksXG4gICAgICAgICAgICBjb21tZW50OiBuZXcgSWQzdjFTdHJpbmdUeXBlKGhhc1RyYWNrID8gMjggOiAzMCkuZ2V0KGJ1Ziwgb2ZmICsgOTcpLFxuICAgICAgICAgICAgdHJhY2s6IGhhc1RyYWNrID8gdHJhY2sgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBnZW5yZTogVUlOVDguZ2V0KGJ1Ziwgb2ZmICsgMTI3KVxuICAgICAgICB9O1xuICAgIH1cbn07XG5jbGFzcyBJZDN2MVN0cmluZ1R5cGUge1xuICAgIGxlbjtcbiAgICBzdHJpbmdUeXBlO1xuICAgIGNvbnN0cnVjdG9yKGxlbikge1xuICAgICAgICB0aGlzLmxlbiA9IGxlbjtcbiAgICAgICAgdGhpcy5zdHJpbmdUeXBlID0gbmV3IFN0cmluZ1R5cGUobGVuLCAnbGF0aW4xJyk7XG4gICAgfVxuICAgIGdldChidWYsIG9mZikge1xuICAgICAgICBsZXQgdmFsdWUgPSB0aGlzLnN0cmluZ1R5cGUuZ2V0KGJ1Ziwgb2ZmKTtcbiAgICAgICAgdmFsdWUgPSB1dGlsLnRyaW1SaWdodE51bGwodmFsdWUpO1xuICAgICAgICB2YWx1ZSA9IHZhbHVlLnRyaW0oKTtcbiAgICAgICAgcmV0dXJuIHZhbHVlLmxlbmd0aCA+IDAgPyB2YWx1ZSA6IHVuZGVmaW5lZDtcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgSUQzdjFQYXJzZXIgZXh0ZW5kcyBCYXNpY1BhcnNlciB7XG4gICAgYXBlSGVhZGVyO1xuICAgIGNvbnN0cnVjdG9yKG1ldGFkYXRhLCB0b2tlbml6ZXIsIG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIobWV0YWRhdGEsIHRva2VuaXplciwgb3B0aW9ucyk7XG4gICAgICAgIHRoaXMuYXBlSGVhZGVyID0gb3B0aW9ucy5hcGVIZWFkZXI7XG4gICAgfVxuICAgIHN0YXRpYyBnZXRHZW5yZShnZW5yZUluZGV4KSB7XG4gICAgICAgIGlmIChnZW5yZUluZGV4IDwgR2VucmVzLmxlbmd0aCkge1xuICAgICAgICAgICAgcmV0dXJuIEdlbnJlc1tnZW5yZUluZGV4XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkOyAvLyBUb0RPOiBnZW5lcmF0ZSB3YXJuaW5nXG4gICAgfVxuICAgIGFzeW5jIHBhcnNlKCkge1xuICAgICAgICBpZiAoIXRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemUpIHtcbiAgICAgICAgICAgIGRlYnVnKCdTa2lwIGNoZWNraW5nIGZvciBJRDN2MSBiZWNhdXNlIHRoZSBmaWxlLXNpemUgaXMgdW5rbm93bicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmFwZUhlYWRlciAmJiBpc1JhbmRvbUFjY2Vzc1Rva2VuaXplcih0aGlzLnRva2VuaXplcikpIHtcbiAgICAgICAgICAgIHRoaXMudG9rZW5pemVyLnNldFBvc2l0aW9uKHRoaXMuYXBlSGVhZGVyLm9mZnNldCk7XG4gICAgICAgICAgICBjb25zdCBhcGVQYXJzZXIgPSBuZXcgQVBFdjJQYXJzZXIodGhpcy5tZXRhZGF0YSwgdGhpcy50b2tlbml6ZXIsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgICAgICBhd2FpdCBhcGVQYXJzZXIucGFyc2VUYWdzKHRoaXMuYXBlSGVhZGVyLmZvb3Rlcik7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb2Zmc2V0ID0gdGhpcy50b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAtIElpZDN2MVRva2VuLmxlbjtcbiAgICAgICAgaWYgKHRoaXMudG9rZW5pemVyLnBvc2l0aW9uID4gb2Zmc2V0KSB7XG4gICAgICAgICAgICBkZWJ1ZygnQWxyZWFkeSBjb25zdW1lZCB0aGUgbGFzdCAxMjggYnl0ZXMnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoZWFkZXIgPSBhd2FpdCB0aGlzLnRva2VuaXplci5yZWFkVG9rZW4oSWlkM3YxVG9rZW4sIG9mZnNldCk7XG4gICAgICAgIGlmIChoZWFkZXIpIHtcbiAgICAgICAgICAgIGRlYnVnKCdJRDN2MSBoZWFkZXIgZm91bmQgYXQ6IHBvcz0lcycsIHRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemUgLSBJaWQzdjFUb2tlbi5sZW4pO1xuICAgICAgICAgICAgY29uc3QgcHJvcHMgPSBbJ3RpdGxlJywgJ2FydGlzdCcsICdhbGJ1bScsICdjb21tZW50JywgJ3RyYWNrJywgJ3llYXInXTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaWQgb2YgcHJvcHMpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGVhZGVyW2lkXSAmJiBoZWFkZXJbaWRdICE9PSAnJykge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmFkZFRhZyhpZCwgaGVhZGVyW2lkXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZ2VucmUgPSBJRDN2MVBhcnNlci5nZXRHZW5yZShoZWFkZXIuZ2VucmUpO1xuICAgICAgICAgICAgaWYgKGdlbnJlKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5hZGRUYWcoJ2dlbnJlJywgZ2VucmUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZGVidWcoJ0lEM3YxIGhlYWRlciBub3QgZm91bmQgYXQ6IHBvcz0lcycsIHRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemUgLSBJaWQzdjFUb2tlbi5sZW4pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIGFkZFRhZyhpZCwgdmFsdWUpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5tZXRhZGF0YS5hZGRUYWcoJ0lEM3YxJywgaWQsIHZhbHVlKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFzSUQzdjFIZWFkZXIodG9rZW5pemVyKSB7XG4gICAgaWYgKHRva2VuaXplci5maWxlSW5mby5zaXplID49IDEyOCkge1xuICAgICAgICBjb25zdCB0YWcgPSBuZXcgVWludDhBcnJheSgzKTtcbiAgICAgICAgY29uc3QgcG9zaXRpb24gPSB0b2tlbml6ZXIucG9zaXRpb247XG4gICAgICAgIGF3YWl0IHRva2VuaXplci5yZWFkQnVmZmVyKHRhZywgeyBwb3NpdGlvbjogdG9rZW5pemVyLmZpbGVJbmZvLnNpemUgLSAxMjggfSk7XG4gICAgICAgIHRva2VuaXplci5zZXRQb3NpdGlvbihwb3NpdGlvbik7IC8vIFJlc3RvcmUgdG9rZW5pemVyIHBvc2l0aW9uXG4gICAgICAgIHJldHVybiB0ZXh0RGVjb2RlKHRhZywgJ2xhdGluMScpID09PSAnVEFHJztcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7O0FBT0EsSUFBTSxTQUFBLElBQVFBLGdCLDRCQUFBQSxFQUFBQSxDQUFBQSxRQUFBQSxDQUFVLDZCQUE2Qjs7Ozs7QUFLckQsSUFBYSxTQUFTO0NBQ2xCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNKOzs7OztBQUtBLElBQU0sY0FBYztDQUNoQixLQUFLOzs7Ozs7Q0FNTCxNQUFNLEtBQUssUUFBUTtFQUNmLE1BQU0sU0FBUyxJQUFJLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRztFQUNsRCxJQUFJLFdBQVcsT0FDWCxPQUFPO0VBRVgsTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztFQUN6QyxNQUFNLFFBQVEsTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBRXRDLE1BQU0sV0FBVyxhQUFhLEtBQUssVUFBVTtFQUM3QyxPQUFPO0dBQ0g7R0FDQSxPQUFPLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUM7R0FDL0MsUUFBUSxJQUFJLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO0dBQ2pELE9BQU8sSUFBSSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUNoRCxNQUFNLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7R0FDOUMsU0FBUyxJQUFJLGdCQUFnQixXQUFXLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUNsRSxPQUFPLFdBQVcsUUFBUSxLQUFBO0dBQzFCLE9BQU8sTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQ25DO0NBQ0o7QUFDSjtBQUNBLElBQU0sa0JBQU4sTUFBc0I7Q0FDbEI7Q0FDQTtDQUNBLFlBQVksS0FBSztFQUNiLEtBQUssTUFBTTtFQUNYLEtBQUssYUFBYSxJQUFJLFdBQVcsS0FBSyxRQUFRO0NBQ2xEO0NBQ0EsSUFBSSxLQUFLLEtBQUs7RUFDVixJQUFJLFFBQVEsS0FBSyxXQUFXLElBQUksS0FBSyxHQUFHO0VBQ3hDLFFBQVFDLGNBQW1CLEtBQUs7RUFDaEMsUUFBUSxNQUFNLEtBQUs7RUFDbkIsT0FBTyxNQUFNLFNBQVMsSUFBSSxRQUFRLEtBQUE7Q0FDdEM7QUFDSjtBQUNBLElBQWEsY0FBYixNQUFhLG9CQUFvQixZQUFZO0NBQ3pDO0NBQ0EsWUFBWSxVQUFVLFdBQVcsU0FBUztFQUN0QyxNQUFNLFVBQVUsV0FBVyxPQUFPO0VBQ2xDLEtBQUssWUFBWSxRQUFRO0NBQzdCO0NBQ0EsT0FBTyxTQUFTLFlBQVk7RUFDeEIsSUFBSSxhQUFhLE9BQU8sUUFDcEIsT0FBTyxPQUFPO0NBR3RCO0NBQ0EsTUFBTSxRQUFRO0VBQ1YsSUFBSSxDQUFDLEtBQUssVUFBVSxTQUFTLE1BQU07R0FDL0IsTUFBTSwwREFBMEQ7R0FDaEU7RUFDSjtFQUNBLElBQUksS0FBSyxhQUFhLHdCQUF3QixLQUFLLFNBQVMsR0FBRztHQUMzRCxLQUFLLFVBQVUsWUFBWSxLQUFLLFVBQVUsTUFBTTtHQUVoRCxNQUFNLElBRGdCLFlBQVksS0FBSyxVQUFVLEtBQUssV0FBVyxLQUFLLE9BQ3hELENBQUMsQ0FBQyxVQUFVLEtBQUssVUFBVSxNQUFNO0VBQ25EO0VBQ0EsTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTLE9BQU8sWUFBWTtFQUMxRCxJQUFJLEtBQUssVUFBVSxXQUFXLFFBQVE7R0FDbEMsTUFBTSxxQ0FBcUM7R0FDM0M7RUFDSjtFQUNBLE1BQU0sU0FBUyxNQUFNLEtBQUssVUFBVSxVQUFVLGFBQWEsTUFBTTtFQUNqRSxJQUFJLFFBQVE7R0FDUixNQUFNLGlDQUFpQyxLQUFLLFVBQVUsU0FBUyxPQUFPLFlBQVksR0FBRztHQUVyRixLQUFLLE1BQU0sTUFBTTtJQURGO0lBQVM7SUFBVTtJQUFTO0lBQVc7SUFBUztHQUMxQyxHQUNqQixJQUFJLE9BQU8sT0FBTyxPQUFPLFFBQVEsSUFDN0IsTUFBTSxLQUFLLE9BQU8sSUFBSSxPQUFPLEdBQUc7R0FHeEMsTUFBTSxRQUFRLFlBQVksU0FBUyxPQUFPLEtBQUs7R0FDL0MsSUFBSSxPQUNBLE1BQU0sS0FBSyxPQUFPLFNBQVMsS0FBSztFQUV4QyxPQUVJLE1BQU0scUNBQXFDLEtBQUssVUFBVSxTQUFTLE9BQU8sWUFBWSxHQUFHO0NBRWpHO0NBQ0EsTUFBTSxPQUFPLElBQUksT0FBTztFQUNwQixNQUFNLEtBQUssU0FBUyxPQUFPLFNBQVMsSUFBSSxLQUFLO0NBQ2pEO0FBQ0o7QUFDQSxlQUFzQixlQUFlLFdBQVc7Q0FDNUMsSUFBSSxVQUFVLFNBQVMsUUFBUSxLQUFLO0VBQ2hDLE1BQU0sc0JBQU0sSUFBSSxXQUFXLENBQUM7RUFDNUIsTUFBTSxXQUFXLFVBQVU7RUFDM0IsTUFBTSxVQUFVLFdBQVcsS0FBSyxFQUFFLFVBQVUsVUFBVSxTQUFTLE9BQU8sSUFBSSxDQUFDO0VBQzNFLFVBQVUsWUFBWSxRQUFRO0VBQzlCLE9BQU8sV0FBVyxLQUFLLFFBQVEsTUFBTTtDQUN6QztDQUNBLE9BQU87QUFDWCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=