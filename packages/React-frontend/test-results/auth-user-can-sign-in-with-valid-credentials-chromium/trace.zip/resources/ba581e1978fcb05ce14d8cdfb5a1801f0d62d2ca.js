import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ChatConversation.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { CaretLeftIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import { fetchConversation, sendMessage, subscribeToIncoming } from "/src/lib/socials.js";
import Avatar from "/src/components/Avatar.jsx";
import "/src/styles/Socials.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ChatConversation.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function formatTime(timestamp) {
	return new Date(timestamp).toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
}
function ChatConversation({ userId, friend, onBack, onSent }) {
	_s();
	const friendId = friend.friend_id;
	const friendName = friend.users?.user_name;
	const [messages, setMessages] = useState([]);
	const [loading, setLoading] = useState(true);
	const [draft, setDraft] = useState("");
	const [sending, setSending] = useState(false);
	const [message, setMessage] = useState("");
	const listRef = useRef(null);
	useEffect(() => {
		fetchConversation(userId, friendId).then(({ data, error }) => {
			setLoading(false);
			if (error) setMessage(error.message);
			else setMessages(data);
		});
		return subscribeToIncoming(`chat-${userId}-${friendId}`, userId, (incoming) => {
			if (incoming.from_user !== friendId) return;
			setMessages((current) => [...current, incoming]);
		});
	}, [userId, friendId]);
	// Keep the newest message in view
	useEffect(() => {
		if (listRef.current) {
			listRef.current.scrollTop = listRef.current.scrollHeight;
		}
	}, [messages]);
	async function handleSend(event) {
		event.preventDefault();
		const body = draft.trim();
		if (!body) return;
		setSending(true);
		const { data, error } = await sendMessage(userId, friendId, body);
		setSending(false);
		if (error) {
			setMessage(`Couldn't send: ${error.message}`);
			return;
		}
		setMessage("");
		setDraft("");
		setMessages((current) => [...current, data]);
		onSent(data);
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "socials-section chat",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "chat-header",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: "socials-button chat-back",
						onClick: onBack,
						title: "Back to chats",
						children: [/* @__PURE__ */ _jsxDEV(CaretLeftIcon, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 11
						}, this), "Back"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Avatar, {
						userName: friendName,
						userId: friendId
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "socials-name",
						children: friendName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "chat-messages",
				ref: listRef,
				children: [
					loading && /* @__PURE__ */ _jsxDEV("p", {
						className: "socials-empty",
						children: "Loading…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 21
					}, this),
					!loading && messages.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
						className: "socials-empty",
						children: ["No messages yet — say hi to ", friendName]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this),
					messages.map((msg) => /* @__PURE__ */ _jsxDEV("div", {
						className: msg.from_user === userId ? "chat-bubble chat-bubble--mine" : "chat-bubble",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: msg.body }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "chat-time",
							children: formatTime(msg.created_at)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 13
						}, this)]
					}, msg.id, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 11
					}, this))
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "socials-message",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 19
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				className: "chat-compose",
				onSubmit: handleSend,
				children: [/* @__PURE__ */ _jsxDEV("input", {
					className: "socials-search chat-input",
					type: "text",
					placeholder: `Message ${friendName}`,
					value: draft,
					maxLength: 2e3,
					onChange: (event) => setDraft(event.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					className: "socials-button socials-button--primary",
					disabled: !draft.trim() || sending,
					children: "Send"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 5
	}, this);
}
_s(ChatConversation, "a5GQsEb2OEbn+s5fm/ka7rmPAa4=");
_c = ChatConversation;
export default ChatConversation;
var _c;
$RefreshReg$(_c, "ChatConversation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ChatConversation.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ChatConversation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ChatConversation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ChatConversation.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUFTLHFCQUFxQjtBQUM5QixTQUNFLG1CQUNBLGFBQ0EsMkJBQ0s7QUFDUCxPQUFPLFlBQVk7QUFDbkIsT0FBTzs7OztBQUVQLFNBQVMsV0FBVyxXQUFXO0NBQzdCLE9BQU8sSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUc7RUFDaEQsTUFBTTtFQUNOLFFBQVE7Q0FDVixDQUFDO0FBQ0g7QUFFQSxTQUFTLGlCQUFpQixFQUFFLFFBQVEsUUFBUSxRQUFRLFVBQVU7O0NBQzVELE1BQU0sV0FBVyxPQUFPO0NBQ3hCLE1BQU0sYUFBYSxPQUFPLE9BQU87Q0FFakMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUMsQ0FBQztDQUMzQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLFVBQVUsT0FBTyxJQUFJO0NBRTNCLGdCQUFnQjtFQUNkLGtCQUFrQixRQUFRLFFBQVEsQ0FBQyxDQUFDLE1BQ2pDLEVBQUUsTUFBTSxZQUFZO0dBQ25CLFdBQVcsS0FBSztHQUNoQixJQUFJLE9BQU8sV0FBVyxNQUFNLE9BQU87UUFDOUIsWUFBWSxJQUFJO0VBQ3ZCLENBQ0Y7RUFFQSxPQUFPLG9CQUNMLFFBQVEsT0FBTyxHQUFHLFlBQ2xCLFNBQ0MsYUFBYTtHQUNaLElBQUksU0FBUyxjQUFjLFVBQVU7R0FDckMsYUFBYSxZQUFZLENBQUMsR0FBRyxTQUFTLFFBQVEsQ0FBQztFQUNqRCxDQUNGO0NBQ0YsR0FBRyxDQUFDLFFBQVEsUUFBUSxDQUFDOztDQUdyQixnQkFBZ0I7RUFDZCxJQUFJLFFBQVEsU0FBUztHQUNuQixRQUFRLFFBQVEsWUFBWSxRQUFRLFFBQVE7RUFDOUM7Q0FDRixHQUFHLENBQUMsUUFBUSxDQUFDO0NBRWIsZUFBZSxXQUFXLE9BQU87RUFDL0IsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sT0FBTyxNQUFNLEtBQUs7RUFDeEIsSUFBSSxDQUFDLE1BQU07RUFFWCxXQUFXLElBQUk7RUFDZixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sWUFDNUIsUUFDQSxVQUNBLElBQ0Y7RUFDQSxXQUFXLEtBQUs7RUFFaEIsSUFBSSxPQUFPO0dBQ1QsV0FBVyxrQkFBa0IsTUFBTSxTQUFTO0dBQzVDO0VBQ0Y7RUFFQSxXQUFXLEVBQUU7RUFDYixTQUFTLEVBQUU7RUFDWCxhQUFhLFlBQVksQ0FBQyxHQUFHLFNBQVMsSUFBSSxDQUFDO0VBQzNDLE9BQU8sSUFBSTtDQUNiO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFEO01BQ0UsV0FBVTtNQUNWLFNBQVM7TUFDVCxPQUFNO2dCQUhSLENBSUUsd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7OztnQkFBQyxNQUVyQjs7Ozs7O0tBQ1Isd0JBQUMsUUFBRDtNQUFRLFVBQVU7TUFBWSxRQUFRO0tBQVc7Ozs7O0tBQ2pELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnQjtLQUFpQjs7Ozs7SUFDOUM7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWdCLEtBQUs7Y0FBcEM7S0FDRyxXQUFXLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnQjtLQUFXOzs7OztLQUVuRCxDQUFDLFdBQVcsU0FBUyxXQUFXLEtBQy9CLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiLENBQTZCLGdDQUNFLFVBQzVCOzs7Ozs7S0FHSixTQUFTLEtBQUssUUFDYix3QkFBQyxPQUFEO01BRUUsV0FDRSxJQUFJLGNBQWMsU0FDZCxrQ0FDQTtnQkFMUixDQU9FLHdCQUFDLFFBQUQsWUFBTyxJQUFJLEtBQVc7Ozs7Z0JBQ3RCLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLFdBQVcsSUFBSSxVQUFVO01BQ3RCOzs7O2NBQ0g7UUFWRSxJQUFJOzs7O1lBVU4sQ0FDTjtJQUNFOzs7Ozs7R0FFSixXQUFXLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW1CO0dBQVc7Ozs7O0dBRXZELHdCQUFDLFFBQUQ7SUFBTSxXQUFVO0lBQWUsVUFBVTtjQUF6QyxDQUNFLHdCQUFDLFNBQUQ7S0FDRSxXQUFVO0tBQ1YsTUFBSztLQUNMLGFBQWEsV0FBVztLQUN4QixPQUFPO0tBQ1AsV0FBVztLQUNYLFdBQVcsVUFBVSxTQUFTLE1BQU0sT0FBTyxLQUFLO0lBQ2pEOzs7O2NBQ0Qsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsVUFBVSxDQUFDLE1BQU0sS0FBSyxLQUFLO2VBQVM7SUFFOUI7Ozs7WUFDSjs7Ozs7O0VBQ0M7Ozs7OztBQUViOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoYXRDb252ZXJzYXRpb24uanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDYXJldExlZnRJY29uIH0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIGZldGNoQ29udmVyc2F0aW9uLFxyXG4gIHNlbmRNZXNzYWdlLFxyXG4gIHN1YnNjcmliZVRvSW5jb21pbmdcclxufSBmcm9tIFwiLi4vbGliL3NvY2lhbHNcIjtcclxuaW1wb3J0IEF2YXRhciBmcm9tIFwiLi9BdmF0YXJcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL1NvY2lhbHMuY3NzXCI7XHJcblxyXG5mdW5jdGlvbiBmb3JtYXRUaW1lKHRpbWVzdGFtcCkge1xyXG4gIHJldHVybiBuZXcgRGF0ZSh0aW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZyhbXSwge1xyXG4gICAgaG91cjogXCJudW1lcmljXCIsXHJcbiAgICBtaW51dGU6IFwiMi1kaWdpdFwiXHJcbiAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIENoYXRDb252ZXJzYXRpb24oeyB1c2VySWQsIGZyaWVuZCwgb25CYWNrLCBvblNlbnQgfSkge1xyXG4gIGNvbnN0IGZyaWVuZElkID0gZnJpZW5kLmZyaWVuZF9pZDtcclxuICBjb25zdCBmcmllbmROYW1lID0gZnJpZW5kLnVzZXJzPy51c2VyX25hbWU7XHJcblxyXG4gIGNvbnN0IFttZXNzYWdlcywgc2V0TWVzc2FnZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtkcmFmdCwgc2V0RHJhZnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbmRpbmcsIHNldFNlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IGxpc3RSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaENvbnZlcnNhdGlvbih1c2VySWQsIGZyaWVuZElkKS50aGVuKFxyXG4gICAgICAoeyBkYXRhLCBlcnJvciB9KSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgaWYgKGVycm9yKSBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICAgIGVsc2Ugc2V0TWVzc2FnZXMoZGF0YSk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHN1YnNjcmliZVRvSW5jb21pbmcoXHJcbiAgICAgIGBjaGF0LSR7dXNlcklkfS0ke2ZyaWVuZElkfWAsXHJcbiAgICAgIHVzZXJJZCxcclxuICAgICAgKGluY29taW5nKSA9PiB7XHJcbiAgICAgICAgaWYgKGluY29taW5nLmZyb21fdXNlciAhPT0gZnJpZW5kSWQpIHJldHVybjtcclxuICAgICAgICBzZXRNZXNzYWdlcygoY3VycmVudCkgPT4gWy4uLmN1cnJlbnQsIGluY29taW5nXSk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgfSwgW3VzZXJJZCwgZnJpZW5kSWRdKTtcclxuXHJcbiAgLy8gS2VlcCB0aGUgbmV3ZXN0IG1lc3NhZ2UgaW4gdmlld1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAobGlzdFJlZi5jdXJyZW50KSB7XHJcbiAgICAgIGxpc3RSZWYuY3VycmVudC5zY3JvbGxUb3AgPSBsaXN0UmVmLmN1cnJlbnQuc2Nyb2xsSGVpZ2h0O1xyXG4gICAgfVxyXG4gIH0sIFttZXNzYWdlc10pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTZW5kKGV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgYm9keSA9IGRyYWZ0LnRyaW0oKTtcclxuICAgIGlmICghYm9keSkgcmV0dXJuO1xyXG5cclxuICAgIHNldFNlbmRpbmcodHJ1ZSk7XHJcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzZW5kTWVzc2FnZShcclxuICAgICAgdXNlcklkLFxyXG4gICAgICBmcmllbmRJZCxcclxuICAgICAgYm9keVxyXG4gICAgKTtcclxuICAgIHNldFNlbmRpbmcoZmFsc2UpO1xyXG5cclxuICAgIGlmIChlcnJvcikge1xyXG4gICAgICBzZXRNZXNzYWdlKGBDb3VsZG4ndCBzZW5kOiAke2Vycm9yLm1lc3NhZ2V9YCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRNZXNzYWdlKFwiXCIpO1xyXG4gICAgc2V0RHJhZnQoXCJcIik7XHJcbiAgICBzZXRNZXNzYWdlcygoY3VycmVudCkgPT4gWy4uLmN1cnJlbnQsIGRhdGFdKTtcclxuICAgIG9uU2VudChkYXRhKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzb2NpYWxzLXNlY3Rpb24gY2hhdFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYXQtaGVhZGVyXCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwic29jaWFscy1idXR0b24gY2hhdC1iYWNrXCJcclxuICAgICAgICAgIG9uQ2xpY2s9e29uQmFja31cclxuICAgICAgICAgIHRpdGxlPVwiQmFjayB0byBjaGF0c1wiPlxyXG4gICAgICAgICAgPENhcmV0TGVmdEljb24gc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICBCYWNrXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPEF2YXRhciB1c2VyTmFtZT17ZnJpZW5kTmFtZX0gdXNlcklkPXtmcmllbmRJZH0gLz5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzb2NpYWxzLW5hbWVcIj57ZnJpZW5kTmFtZX08L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGF0LW1lc3NhZ2VzXCIgcmVmPXtsaXN0UmVmfT5cclxuICAgICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLWVtcHR5XCI+TG9hZGluZ+KApjwvcD59XHJcblxyXG4gICAgICAgIHshbG9hZGluZyAmJiBtZXNzYWdlcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwic29jaWFscy1lbXB0eVwiPlxyXG4gICAgICAgICAgICBObyBtZXNzYWdlcyB5ZXQg4oCUIHNheSBoaSB0byB7ZnJpZW5kTmFtZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7bWVzc2FnZXMubWFwKChtc2cpID0+IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXttc2cuaWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgbXNnLmZyb21fdXNlciA9PT0gdXNlcklkXHJcbiAgICAgICAgICAgICAgICA/IFwiY2hhdC1idWJibGUgY2hhdC1idWJibGUtLW1pbmVcIlxyXG4gICAgICAgICAgICAgICAgOiBcImNoYXQtYnViYmxlXCJcclxuICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgPHNwYW4+e21zZy5ib2R5fTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2hhdC10aW1lXCI+XHJcbiAgICAgICAgICAgICAge2Zvcm1hdFRpbWUobXNnLmNyZWF0ZWRfYXQpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLW1lc3NhZ2VcIj57bWVzc2FnZX08L3A+fVxyXG5cclxuICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiY2hhdC1jb21wb3NlXCIgb25TdWJtaXQ9e2hhbmRsZVNlbmR9PlxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwic29jaWFscy1zZWFyY2ggY2hhdC1pbnB1dFwiXHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj17YE1lc3NhZ2UgJHtmcmllbmROYW1lfWB9XHJcbiAgICAgICAgICB2YWx1ZT17ZHJhZnR9XHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezIwMDB9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXREcmFmdChldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvbiBzb2NpYWxzLWJ1dHRvbi0tcHJpbWFyeVwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17IWRyYWZ0LnRyaW0oKSB8fCBzZW5kaW5nfT5cclxuICAgICAgICAgIFNlbmRcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoYXRDb252ZXJzYXRpb247XHJcbiJdfQ==