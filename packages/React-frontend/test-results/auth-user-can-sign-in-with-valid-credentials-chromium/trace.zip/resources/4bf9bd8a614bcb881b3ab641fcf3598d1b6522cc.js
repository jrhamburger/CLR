import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MiniPlayer.jsx");const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=beb472b4";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import MusicControls from "/src/components/MusicControls.jsx";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MiniPlayer.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function MiniPlayer({ queue, modes, controls }) {
	_s();
	const audioRef = useRef(null);
	const [isPlaying, setIsPlaying] = useState(false);
	const [currentTime, setCurrentTime] = useState(0);
	const [duration, setDuration] = useState(0);
	const { tracks: currentQueue, order: playOrder, position: playPosition } = queue;
	const { isShuffle, isRepeating } = modes;
	const { nextTrack, previousTrack, toggleShuffle, toggleRepeat } = controls;
	const currentTrackIndex = playOrder[playPosition];
	const currentSong = currentQueue[currentTrackIndex];
	useEffect(() => {
		if (!currentSong || !audioRef.current) return;
		setCurrentTime(0);
		audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
	}, [currentSong]);
	function togglePlay() {
		if (!audioRef.current || !currentSong) return;
		if (audioRef.current.paused) {
			audioRef.current.play();
		} else {
			audioRef.current.pause();
		}
	}
	function seekSong(event) {
		const newTime = Number(event.target.value);
		if (!audioRef.current) return;
		audioRef.current.currentTime = newTime;
		setCurrentTime(newTime);
	}
	function onToggleSeekRight() {
		const newTime = Math.min(audioRef.current.currentTime + 5, audioRef.current.duration);
		audioRef.current.currentTime = newTime;
		setCurrentTime(newTime);
	}
	function onToggleSeekLeft() {
		if (!audioRef.current || !currentSong) return;
		const newTime = Math.max(audioRef.current.currentTime - 5, 0);
		audioRef.current.currentTime = newTime;
		setCurrentTime(newTime);
	}
	function onToggleNext() {
		if (!currentSong) return;
		nextTrack();
	}
	function onTogglePrevious() {
		if (!audioRef.current || !currentSong) return;
		const restartThreshold = 3;
		if (audioRef.current.currentTime > restartThreshold) {
			audioRef.current.currentTime = 0;
			setCurrentTime(0);
			return;
		}
		previousTrack();
	}
	function onToggleShuffle() {
		if (!currentSong) return;
		toggleShuffle();
	}
	function onToggleRepeat() {
		toggleRepeat();
	}
	function onEnded() {
		if (!audioRef.current || !currentSong) return;
		nextTrack();
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "player",
		children: [currentSong && /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("audio", {
			ref: audioRef,
			src: currentSong.audioUrl,
			onPlay: () => setIsPlaying(true),
			onPause: () => setIsPlaying(false),
			onEnded: () => onEnded(),
			onTimeUpdate: () => setCurrentTime(audioRef.current.currentTime),
			onLoadedMetadata: () => setDuration(audioRef.current.duration)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 120,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(MusicControls, {
			isShuffle,
			isPlaying,
			isRepeating,
			currentTime,
			duration,
			onTogglePlay: togglePlay,
			onSeek: seekSong,
			onToggleSeekRight,
			onToggleSeekLeft,
			onToggleNext,
			onTogglePrevious,
			onToggleShuffle,
			onToggleRepeat
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 117,
		columnNumber: 5
	}, this);
}
_s(MiniPlayer, "DPoN16ZDAaZQEcofQsu/e/gM/d0=");
_c = MiniPlayer;
export default MiniPlayer;
var _c;
$RefreshReg$(_c, "MiniPlayer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MiniPlayer.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MiniPlayer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MiniPlayer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MiniPlayer.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsUUFBUSxVQUFVLGlCQUFpQjtBQUM1QyxPQUFPLG1CQUFtQjs7OztBQUUxQixTQUFTLFdBQVcsRUFBRSxPQUFPLE9BQU8sWUFBWTs7Q0FDOUMsTUFBTSxXQUFXLE9BQU8sSUFBSTtDQUM1QixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FFMUMsTUFBTSxFQUNKLFFBQVEsY0FDUixPQUFPLFdBQ1AsVUFBVSxpQkFDUjtDQUVKLE1BQU0sRUFBRSxXQUFXLGdCQUFnQjtDQUVuQyxNQUFNLEVBQ0osV0FDQSxlQUNBLGVBQ0EsaUJBQ0U7Q0FFSixNQUFNLG9CQUFvQixVQUFVO0NBQ3BDLE1BQU0sY0FBYyxhQUFhO0NBRWpDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxTQUFTO0VBRXZDLGVBQWUsQ0FBQztFQUVoQixTQUFTLFFBQ04sS0FBSyxDQUFDLENBQ04sV0FBVyxhQUFhLElBQUksQ0FBQyxDQUFDLENBQzlCLFlBQVksYUFBYSxLQUFLLENBQUM7Q0FDcEMsR0FBRyxDQUFDLFdBQVcsQ0FBQztDQUVoQixTQUFTLGFBQWE7RUFDcEIsSUFBSSxDQUFDLFNBQVMsV0FBVyxDQUFDLGFBQWE7RUFFdkMsSUFBSSxTQUFTLFFBQVEsUUFBUTtHQUMzQixTQUFTLFFBQVEsS0FBSztFQUN4QixPQUFPO0dBQ0wsU0FBUyxRQUFRLE1BQU07RUFDekI7Q0FDRjtDQUVBLFNBQVMsU0FBUyxPQUFPO0VBQ3ZCLE1BQU0sVUFBVSxPQUFPLE1BQU0sT0FBTyxLQUFLO0VBRXpDLElBQUksQ0FBQyxTQUFTLFNBQVM7RUFFdkIsU0FBUyxRQUFRLGNBQWM7RUFDL0IsZUFBZSxPQUFPO0NBQ3hCO0NBRUEsU0FBUyxvQkFBb0I7RUFDM0IsTUFBTSxVQUFVLEtBQUssSUFDbkIsU0FBUyxRQUFRLGNBQWMsR0FDL0IsU0FBUyxRQUFRLFFBQ25CO0VBRUEsU0FBUyxRQUFRLGNBQWM7RUFDL0IsZUFBZSxPQUFPO0NBQ3hCO0NBRUEsU0FBUyxtQkFBbUI7RUFDMUIsSUFBSSxDQUFDLFNBQVMsV0FBVyxDQUFDLGFBQWE7RUFFdkMsTUFBTSxVQUFVLEtBQUssSUFDbkIsU0FBUyxRQUFRLGNBQWMsR0FDL0IsQ0FDRjtFQUVBLFNBQVMsUUFBUSxjQUFjO0VBQy9CLGVBQWUsT0FBTztDQUN4QjtDQUVBLFNBQVMsZUFBZTtFQUN0QixJQUFJLENBQUMsYUFBYTtFQUVsQixVQUFVO0NBQ1o7Q0FFQSxTQUFTLG1CQUFtQjtFQUMxQixJQUFJLENBQUMsU0FBUyxXQUFXLENBQUMsYUFBYTtFQUV2QyxNQUFNLG1CQUFtQjtFQUV6QixJQUFJLFNBQVMsUUFBUSxjQUFjLGtCQUFrQjtHQUNuRCxTQUFTLFFBQVEsY0FBYztHQUMvQixlQUFlLENBQUM7R0FDaEI7RUFDRjtFQUVBLGNBQWM7Q0FDaEI7Q0FFQSxTQUFTLGtCQUFrQjtFQUN6QixJQUFJLENBQUMsYUFBYTtFQUVsQixjQUFjO0NBQ2hCO0NBRUEsU0FBUyxpQkFBaUI7RUFDeEIsYUFBYTtDQUNmO0NBRUEsU0FBUyxVQUFVO0VBQ2pCLElBQUksQ0FBQyxTQUFTLFdBQVcsQ0FBQyxhQUFhO0VBQ3ZDLFVBQVU7Q0FDWjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEIsQ0FDRyxlQUNDLCtDQUNFLHdCQUFDLFNBQUQ7R0FDRSxLQUFLO0dBQ0wsS0FBSyxZQUFZO0dBQ2pCLGNBQWMsYUFBYSxJQUFJO0dBQy9CLGVBQWUsYUFBYSxLQUFLO0dBQ2pDLGVBQWUsUUFBUTtHQUN2QixvQkFDRSxlQUFlLFNBQVMsUUFBUSxXQUFXO0dBRTdDLHdCQUNFLFlBQVksU0FBUyxRQUFRLFFBQVE7RUFFeEM7Ozs7V0FDRDs7OztZQUdKLHdCQUFDLGVBQUQ7R0FDYTtHQUNBO0dBQ0U7R0FDQTtHQUNIO0dBQ1YsY0FBYztHQUNkLFFBQVE7R0FDVztHQUNEO0dBQ0o7R0FDSTtHQUNEO0dBQ0Q7RUFDakI7Ozs7VUFDRzs7Ozs7O0FBRVY7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWluaVBsYXllci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbW90aW9uIH0gZnJvbSBcImZyYW1lci1tb3Rpb25cIjtcclxuaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBNdXNpY0NvbnRyb2xzIGZyb20gXCIuL011c2ljQ29udHJvbHNcIjtcclxuXHJcbmZ1bmN0aW9uIE1pbmlQbGF5ZXIoeyBxdWV1ZSwgbW9kZXMsIGNvbnRyb2xzIH0pIHtcclxuICBjb25zdCBhdWRpb1JlZiA9IHVzZVJlZihudWxsKTtcclxuICBjb25zdCBbaXNQbGF5aW5nLCBzZXRJc1BsYXlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VGltZSwgc2V0Q3VycmVudFRpbWVdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2R1cmF0aW9uLCBzZXREdXJhdGlvbl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgdHJhY2tzOiBjdXJyZW50UXVldWUsXHJcbiAgICBvcmRlcjogcGxheU9yZGVyLFxyXG4gICAgcG9zaXRpb246IHBsYXlQb3NpdGlvblxyXG4gIH0gPSBxdWV1ZTtcclxuXHJcbiAgY29uc3QgeyBpc1NodWZmbGUsIGlzUmVwZWF0aW5nIH0gPSBtb2RlcztcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgbmV4dFRyYWNrLFxyXG4gICAgcHJldmlvdXNUcmFjayxcclxuICAgIHRvZ2dsZVNodWZmbGUsXHJcbiAgICB0b2dnbGVSZXBlYXRcclxuICB9ID0gY29udHJvbHM7XHJcblxyXG4gIGNvbnN0IGN1cnJlbnRUcmFja0luZGV4ID0gcGxheU9yZGVyW3BsYXlQb3NpdGlvbl07XHJcbiAgY29uc3QgY3VycmVudFNvbmcgPSBjdXJyZW50UXVldWVbY3VycmVudFRyYWNrSW5kZXhdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFjdXJyZW50U29uZyB8fCAhYXVkaW9SZWYuY3VycmVudCkgcmV0dXJuO1xyXG5cclxuICAgIHNldEN1cnJlbnRUaW1lKDApO1xyXG5cclxuICAgIGF1ZGlvUmVmLmN1cnJlbnRcclxuICAgICAgLnBsYXkoKVxyXG4gICAgICAudGhlbigoKSA9PiBzZXRJc1BsYXlpbmcodHJ1ZSkpXHJcbiAgICAgIC5jYXRjaCgoKSA9PiBzZXRJc1BsYXlpbmcoZmFsc2UpKTtcclxuICB9LCBbY3VycmVudFNvbmddKTtcclxuXHJcbiAgZnVuY3Rpb24gdG9nZ2xlUGxheSgpIHtcclxuICAgIGlmICghYXVkaW9SZWYuY3VycmVudCB8fCAhY3VycmVudFNvbmcpIHJldHVybjtcclxuXHJcbiAgICBpZiAoYXVkaW9SZWYuY3VycmVudC5wYXVzZWQpIHtcclxuICAgICAgYXVkaW9SZWYuY3VycmVudC5wbGF5KCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhdWRpb1JlZi5jdXJyZW50LnBhdXNlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBzZWVrU29uZyhldmVudCkge1xyXG4gICAgY29uc3QgbmV3VGltZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xyXG5cclxuICAgIGlmICghYXVkaW9SZWYuY3VycmVudCkgcmV0dXJuO1xyXG5cclxuICAgIGF1ZGlvUmVmLmN1cnJlbnQuY3VycmVudFRpbWUgPSBuZXdUaW1lO1xyXG4gICAgc2V0Q3VycmVudFRpbWUobmV3VGltZSk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBvblRvZ2dsZVNlZWtSaWdodCgpIHtcclxuICAgIGNvbnN0IG5ld1RpbWUgPSBNYXRoLm1pbihcclxuICAgICAgYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSArIDUsXHJcbiAgICAgIGF1ZGlvUmVmLmN1cnJlbnQuZHVyYXRpb25cclxuICAgICk7XHJcblxyXG4gICAgYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IG5ld1RpbWU7XHJcbiAgICBzZXRDdXJyZW50VGltZShuZXdUaW1lKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG9uVG9nZ2xlU2Vla0xlZnQoKSB7XHJcbiAgICBpZiAoIWF1ZGlvUmVmLmN1cnJlbnQgfHwgIWN1cnJlbnRTb25nKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgbmV3VGltZSA9IE1hdGgubWF4KFxyXG4gICAgICBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lIC0gNSxcclxuICAgICAgMFxyXG4gICAgKTtcclxuXHJcbiAgICBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lID0gbmV3VGltZTtcclxuICAgIHNldEN1cnJlbnRUaW1lKG5ld1RpbWUpO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gb25Ub2dnbGVOZXh0KCkge1xyXG4gICAgaWYgKCFjdXJyZW50U29uZykgcmV0dXJuO1xyXG5cclxuICAgIG5leHRUcmFjaygpO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gb25Ub2dnbGVQcmV2aW91cygpIHtcclxuICAgIGlmICghYXVkaW9SZWYuY3VycmVudCB8fCAhY3VycmVudFNvbmcpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCByZXN0YXJ0VGhyZXNob2xkID0gMztcclxuXHJcbiAgICBpZiAoYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA+IHJlc3RhcnRUaHJlc2hvbGQpIHtcclxuICAgICAgYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IDA7XHJcbiAgICAgIHNldEN1cnJlbnRUaW1lKDApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgcHJldmlvdXNUcmFjaygpO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gb25Ub2dnbGVTaHVmZmxlKCkge1xyXG4gICAgaWYgKCFjdXJyZW50U29uZykgcmV0dXJuO1xyXG5cclxuICAgIHRvZ2dsZVNodWZmbGUoKTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG9uVG9nZ2xlUmVwZWF0KCkge1xyXG4gICAgdG9nZ2xlUmVwZWF0KCk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBvbkVuZGVkKCkge1xyXG4gICAgaWYgKCFhdWRpb1JlZi5jdXJyZW50IHx8ICFjdXJyZW50U29uZykgcmV0dXJuO1xyXG4gICAgbmV4dFRyYWNrKCk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwicGxheWVyXCI+XHJcbiAgICAgIHtjdXJyZW50U29uZyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxhdWRpb1xyXG4gICAgICAgICAgICByZWY9e2F1ZGlvUmVmfVxyXG4gICAgICAgICAgICBzcmM9e2N1cnJlbnRTb25nLmF1ZGlvVXJsfVxyXG4gICAgICAgICAgICBvblBsYXk9eygpID0+IHNldElzUGxheWluZyh0cnVlKX1cclxuICAgICAgICAgICAgb25QYXVzZT17KCkgPT4gc2V0SXNQbGF5aW5nKGZhbHNlKX1cclxuICAgICAgICAgICAgb25FbmRlZD17KCkgPT4gb25FbmRlZCgpfVxyXG4gICAgICAgICAgICBvblRpbWVVcGRhdGU9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0Q3VycmVudFRpbWUoYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkxvYWRlZE1ldGFkYXRhPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldER1cmF0aW9uKGF1ZGlvUmVmLmN1cnJlbnQuZHVyYXRpb24pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8TXVzaWNDb250cm9sc1xyXG4gICAgICAgIGlzU2h1ZmZsZT17aXNTaHVmZmxlfVxyXG4gICAgICAgIGlzUGxheWluZz17aXNQbGF5aW5nfVxyXG4gICAgICAgIGlzUmVwZWF0aW5nPXtpc1JlcGVhdGluZ31cclxuICAgICAgICBjdXJyZW50VGltZT17Y3VycmVudFRpbWV9XHJcbiAgICAgICAgZHVyYXRpb249e2R1cmF0aW9ufVxyXG4gICAgICAgIG9uVG9nZ2xlUGxheT17dG9nZ2xlUGxheX1cclxuICAgICAgICBvblNlZWs9e3NlZWtTb25nfVxyXG4gICAgICAgIG9uVG9nZ2xlU2Vla1JpZ2h0PXtvblRvZ2dsZVNlZWtSaWdodH1cclxuICAgICAgICBvblRvZ2dsZVNlZWtMZWZ0PXtvblRvZ2dsZVNlZWtMZWZ0fVxyXG4gICAgICAgIG9uVG9nZ2xlTmV4dD17b25Ub2dnbGVOZXh0fVxyXG4gICAgICAgIG9uVG9nZ2xlUHJldmlvdXM9e29uVG9nZ2xlUHJldmlvdXN9XHJcbiAgICAgICAgb25Ub2dnbGVTaHVmZmxlPXtvblRvZ2dsZVNodWZmbGV9XHJcbiAgICAgICAgb25Ub2dnbGVSZXBlYXQ9e29uVG9nZ2xlUmVwZWF0fVxyXG4gICAgICAvPlxyXG4gICAgPC9tYWluPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1pbmlQbGF5ZXI7XHJcbiJdfQ==