import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProfileMenu.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { UserCircleIcon, UserIcon, GearIcon, QuestionIcon, SignOutIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import "/src/styles/ProfileMenu.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ProfileMenu.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
// Menu items without an onClick don't do anything yet
function ProfileMenu({ onSignOut }) {
	_s();
	const [isOpen, setIsOpen] = useState(false);
	const menuRef = useRef(null);
	// Close the popup when clicking anywhere outside it
	useEffect(() => {
		if (!isOpen) return;
		function handleClickOutside(event) {
			if (!menuRef.current.contains(event.target)) setIsOpen(false);
		}
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, [isOpen]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "profile-menu",
		ref: menuRef,
		children: [isOpen && /* @__PURE__ */ _jsxDEV("div", {
			className: "profile-popup",
			children: [
				/* @__PURE__ */ _jsxDEV("button", { children: [/* @__PURE__ */ _jsxDEV(UserIcon, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 19
				}, this), " Account"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", { children: [/* @__PURE__ */ _jsxDEV(GearIcon, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 19
				}, this), " Settings"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", { children: [/* @__PURE__ */ _jsxDEV(QuestionIcon, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 19
				}, this), " Help"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("hr", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onSignOut,
					children: [/* @__PURE__ */ _jsxDEV(SignOutIcon, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 39
					}, this), " Sign out"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			className: "profile-button",
			onClick: () => setIsOpen(!isOpen),
			title: "Profile",
			children: /* @__PURE__ */ _jsxDEV(UserCircleIcon, { size: 32 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_s(ProfileMenu, "6EEQ+lFwTCIEZHkaArwCh3wUowQ=");
_c = ProfileMenu;
export default ProfileMenu;
var _c;
$RefreshReg$(_c, "ProfileMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProfileMenu.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ProfileMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ProfileMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ProfileMenu.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsY0FBYztBQUM1QyxTQUNFLGdCQUNBLFVBQ0EsVUFDQSxjQUNBLG1CQUNLO0FBQ1AsT0FBTzs7Ozs7QUFHUCxTQUFTLFlBQVksRUFBRSxhQUFhOztDQUNsQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLFVBQVUsT0FBTyxJQUFJOztDQUczQixnQkFBZ0I7RUFDZCxJQUFJLENBQUMsUUFBUTtFQUViLFNBQVMsbUJBQW1CLE9BQU87R0FDakMsSUFBSSxDQUFDLFFBQVEsUUFBUSxTQUFTLE1BQU0sTUFBTSxHQUFHLFVBQVUsS0FBSztFQUM5RDtFQUVBLFNBQVMsaUJBQWlCLGFBQWEsa0JBQWtCO0VBQ3pELGFBQWEsU0FBUyxvQkFBb0IsYUFBYSxrQkFBa0I7Q0FDM0UsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBZSxLQUFLO1lBQW5DLENBQ0csVUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7Y0FBQyxVQUFnQjs7Ozs7SUFDOUMsd0JBQUMsVUFBRCxhQUFRLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7Y0FBQyxXQUFpQjs7Ozs7SUFDL0Msd0JBQUMsVUFBRCxhQUFRLHdCQUFDLGNBQUQsRUFBYyxNQUFNLEdBQUs7Ozs7Y0FBQyxPQUFhOzs7OztJQUMvQyx3QkFBQyxNQUFELENBQUs7Ozs7O0lBQ0wsd0JBQUMsVUFBRDtLQUFRLFNBQVM7ZUFBakIsQ0FBNEIsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7OztlQUFDLFdBQWlCOzs7Ozs7R0FDbkU7Ozs7O1lBR1Asd0JBQUMsVUFBRDtHQUNFLFdBQVU7R0FDVixlQUFlLFVBQVUsQ0FBQyxNQUFNO0dBQ2hDLE9BQU07YUFFTix3QkFBQyxnQkFBRCxFQUFnQixNQUFNLEdBQUs7Ozs7O0VBQ3JCOzs7O1VBQ0w7Ozs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2ZpbGVNZW51LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBVc2VyQ2lyY2xlSWNvbixcclxuICBVc2VySWNvbixcclxuICBHZWFySWNvbixcclxuICBRdWVzdGlvbkljb24sXHJcbiAgU2lnbk91dEljb24sXHJcbn0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvUHJvZmlsZU1lbnUuY3NzXCI7XHJcblxyXG4vLyBNZW51IGl0ZW1zIHdpdGhvdXQgYW4gb25DbGljayBkb24ndCBkbyBhbnl0aGluZyB5ZXRcclxuZnVuY3Rpb24gUHJvZmlsZU1lbnUoeyBvblNpZ25PdXQgfSkge1xyXG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgbWVudVJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgLy8gQ2xvc2UgdGhlIHBvcHVwIHdoZW4gY2xpY2tpbmcgYW55d2hlcmUgb3V0c2lkZSBpdFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuO1xyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZUNsaWNrT3V0c2lkZShldmVudCkge1xyXG4gICAgICBpZiAoIW1lbnVSZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQpKSBzZXRJc09wZW4oZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XHJcbiAgfSwgW2lzT3Blbl0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLW1lbnVcIiByZWY9e21lbnVSZWZ9PlxyXG4gICAgICB7aXNPcGVuICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcG9wdXBcIj5cclxuICAgICAgICAgIDxidXR0b24+PFVzZXJJY29uIHNpemU9ezE4fSAvPiBBY2NvdW50PC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uPjxHZWFySWNvbiBzaXplPXsxOH0gLz4gU2V0dGluZ3M8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24+PFF1ZXN0aW9uSWNvbiBzaXplPXsxOH0gLz4gSGVscDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGhyIC8+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uU2lnbk91dH0+PFNpZ25PdXRJY29uIHNpemU9ezE4fSAvPiBTaWduIG91dDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIGNsYXNzTmFtZT1cInByb2ZpbGUtYnV0dG9uXCJcclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc09wZW4oIWlzT3Blbil9XHJcbiAgICAgICAgdGl0bGU9XCJQcm9maWxlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxVc2VyQ2lyY2xlSWNvbiBzaXplPXszMn0gLz5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9maWxlTWVudTtcclxuIl19