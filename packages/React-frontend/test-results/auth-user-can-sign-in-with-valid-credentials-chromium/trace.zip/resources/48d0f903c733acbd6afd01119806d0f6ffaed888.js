import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NowPlaying.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import QueueList, { SongCover } from "/src/components/QueueList.jsx";
import "/src/styles/NowPlaying.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlaying.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// Full-page version of the right column
function NowPlaying({ currentSong, upNext }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "now-playing-page",
		children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Now Playing" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "now-playing-content",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "now-playing-current",
				children: [/* @__PURE__ */ _jsxDEV(SongCover, {
					song: currentSong,
					size: 360
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "now-playing-title",
					children: currentSong?.title ?? "Nothing playing"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "now-playing-queue",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Up Next" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(QueueList, { songs: upNext }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = NowPlaying;
export default NowPlaying;
var _c;
$RefreshReg$(_c, "NowPlaying");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NowPlaying.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlaying.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlaying.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/NowPlaying.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxhQUFhLGlCQUFpQjtBQUNyQyxPQUFPOzs7O0FBR1AsU0FBUyxXQUFXLEVBQUUsYUFBYSxVQUFVO0NBQzNDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxjQUFlOzs7O1lBRW5CLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsV0FBRDtLQUFXLE1BQU07S0FBYSxNQUFNO0lBQU07Ozs7Y0FDMUMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixhQUFhLFNBQVM7SUFDdEI7Ozs7WUFDQTs7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7Y0FDZix3QkFBQyxXQUFELEVBQVcsT0FBTyxPQUFTOzs7O1lBQ3hCOzs7OztXQUNGOzs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5vd1BsYXlpbmcuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBRdWV1ZUxpc3QsIHsgU29uZ0NvdmVyIH0gZnJvbSBcIi4vUXVldWVMaXN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9Ob3dQbGF5aW5nLmNzc1wiO1xyXG5cclxuLy8gRnVsbC1wYWdlIHZlcnNpb24gb2YgdGhlIHJpZ2h0IGNvbHVtblxyXG5mdW5jdGlvbiBOb3dQbGF5aW5nKHsgY3VycmVudFNvbmcsIHVwTmV4dCB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmctcGFnZVwiPlxyXG4gICAgICA8aDI+Tm93IFBsYXlpbmc8L2gyPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZy1jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZy1jdXJyZW50XCI+XHJcbiAgICAgICAgICA8U29uZ0NvdmVyIHNvbmc9e2N1cnJlbnRTb25nfSBzaXplPXszNjB9IC8+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJub3ctcGxheWluZy10aXRsZVwiPlxyXG4gICAgICAgICAgICB7Y3VycmVudFNvbmc/LnRpdGxlID8/IFwiTm90aGluZyBwbGF5aW5nXCJ9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmctcXVldWVcIj5cclxuICAgICAgICAgIDxoMz5VcCBOZXh0PC9oMz5cclxuICAgICAgICAgIDxRdWV1ZUxpc3Qgc29uZ3M9e3VwTmV4dH0gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3dQbGF5aW5nO1xyXG4iXX0=