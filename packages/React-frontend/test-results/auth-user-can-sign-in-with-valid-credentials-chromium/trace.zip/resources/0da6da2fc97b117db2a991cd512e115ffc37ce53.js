import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=987d57e9";
import { a as fromBlob, o as fromBuffer, s as fromWebStream, t as APEv2Parser } from "/node_modules/.vite/deps/APEv2Parser-BWD6Dcm_.js?v=987d57e9";
import { B as require_browser, U as isRandomAccessTokenizer, V as textDecode, _ as makeUnexpectedFileContentError, a as getMaxMemoryAllocation, d as CouldNotDetermineFileTypeError, f as FieldDecodingError, g as makeParseError, h as UnsupportedFileTypeError, i as getMaxChapterCount, m as UnexpectedFileContentError, o as getMaxMetadataEntries, p as InternalParserError, s as getTokenizerOptions } from "/node_modules/.vite/deps/BasicParser-CAIs-t7m.js?v=987d57e9";
import { r as hasID3v1Header } from "/node_modules/.vite/deps/ID3v1Parser-E7E2ul2I.js?v=987d57e9";
import { i as fileTypeFromBuffer, n as createAudioTrackInfo, r as finalizeContainerInfo, t as MetadataCollector } from "/node_modules/.vite/deps/MetadataCollector-BIswQFLt.js?v=987d57e9";
import { r as LyricsContentType, s as TimestampFormat } from "/node_modules/.vite/deps/ID3v2Token-DBHkmIVj.js?v=987d57e9";
import { t as TrackType } from "/node_modules/.vite/deps/type-BPo7WUg5.js?v=987d57e9";
async function getLyricsHeaderLength(tokenizer) {
	const fileSize = tokenizer.fileInfo.size;
	if (fileSize >= 143) {
		const buf = /* @__PURE__ */ new Uint8Array(15);
		const position = tokenizer.position;
		await tokenizer.readBuffer(buf, { position: fileSize - 143 });
		tokenizer.setPosition(position);
		const txt = textDecode(buf, "latin1");
		if (txt.substring(6) === "LYRICS200") return Number.parseInt(txt.substring(0, 6), 10) + 15;
	}
	return 0;
}
// node_modules/content-type/dist/index.js
/*!
* content-type
* Copyright(c) 2015 Douglas Christopher Wilson
* MIT Licensed
*/
var SP = 32;
var HTAB = 9;
var SEMI = 59;
var EQ = 61;
var DQUOTE = 34;
var BSLASH = 92;
var COMMA = 44;
var LOWER_CASE = 1;
var OWS = 2;
var SEMI_FLAG = 4;
var COMMA_FLAG = 8;
var TOKEN_FLAG = 16;
var NON_ASCII = 65280;
var CASE_FLAGS = 65281;
/**
* Character flags used to normalize HTTP field values while scanning.
* Out-of-range reads intentionally coerce to zero in bitwise expressions.
*/
var CHAR_MAP = /* @__PURE__ */ new Uint8Array(256);
CHAR_MAP[HTAB] |= OWS;
CHAR_MAP[SP] |= OWS;
CHAR_MAP[SEMI] |= SEMI_FLAG;
CHAR_MAP[COMMA] |= COMMA_FLAG;
for (let code = 128; code <= 255; code++) CHAR_MAP[code] |= LOWER_CASE;
for (const char of "!#$%&'*+-.^_`|~") CHAR_MAP[char.charCodeAt(0)] |= TOKEN_FLAG;
for (let code = 48; code <= 57; code++) CHAR_MAP[code] |= TOKEN_FLAG;
for (let code = 65; code <= 90; code++) CHAR_MAP[code] |= 17;
for (let code = 97; code <= 122; code++) CHAR_MAP[code] |= TOKEN_FLAG;
/**
* Null object perf optimization. Faster than `Object.create(null)` and `{ __proto__: null }`.
*/
var NullObject = /* @__PURE__ */ (() => {
	const C = function() {};
	C.prototype = Object.create(null);
	return C;
})();
/**
* Parse a `Content-Type` header.
*/
function parse$1(header, options) {
	const stopFlags = SEMI_FLAG | (options?.comma === true ? COMMA_FLAG : 0);
	const len = header.length;
	let valueStart = options?.start ?? 0;
	while ((CHAR_MAP[header.charCodeAt(valueStart)] & OWS) !== 0) valueStart++;
	let index = valueStart;
	let typeFlags = 0;
	let whitespace = -1;
	let stop = options?.parameters === false ? COMMA_FLAG : 0;
	while (index < len) {
		const code = header.charCodeAt(index);
		const flags = CHAR_MAP[code];
		if ((flags & stopFlags) !== 0) {
			stop |= flags & COMMA_FLAG;
			break;
		}
		if ((flags & OWS) !== 0) {
			if (whitespace === -1) whitespace = index;
		} else whitespace = -1;
		typeFlags |= code & NON_ASCII | flags;
		index++;
	}
	const valueEnd = whitespace === -1 ? index : whitespace;
	const value = header.slice(valueStart, valueEnd);
	const type = (typeFlags & CASE_FLAGS) === 0 ? value : value.toLowerCase();
	if (index === len || stop !== 0) return {
		type,
		index,
		parameters: new NullObject()
	};
	return parseParameters(header, type, index, len, stopFlags);
}
/**
* Parses the parameters of a `Content-Type` header starting at the given index.
*/
function parseParameters(header, type, index, len, stopFlags) {
	const parameters = new NullObject();
	parameter: while (index < len) {
		index++;
		while ((CHAR_MAP[header.charCodeAt(index)] & OWS) !== 0) index++;
		const keyStart = index;
		let keyFlags = 0;
		let keyWhitespace = -1;
		while (index < len) {
			const code = header.charCodeAt(index);
			const flags = CHAR_MAP[code];
			if ((flags & stopFlags) !== 0) {
				if ((flags & COMMA_FLAG) !== 0) break parameter;
				continue parameter;
			}
			if (code === EQ) {
				const keyEnd = keyWhitespace === -1 ? index : keyWhitespace;
				const value = header.slice(keyStart, keyEnd);
				const key = (keyFlags & CASE_FLAGS) === 0 ? value : value.toLowerCase();
				index++;
				while ((CHAR_MAP[header.charCodeAt(index)] & OWS) !== 0) index++;
				if (index < len && header.charCodeAt(index) === DQUOTE) {
					const quotedStart = ++index;
					let escaped = false;
					while (index < len) {
						const code = header.charCodeAt(index);
						if (code === DQUOTE) {
							if (parameters[key] === void 0) parameters[key] = escaped ? unescapeQuotedPairs(header, quotedStart, index) : header.slice(quotedStart, index);
							index++;
							let stop = 0;
							while (index < len) {
								const flags = CHAR_MAP[header.charCodeAt(index)];
								if ((flags & stopFlags) !== 0) {
									stop = flags & COMMA_FLAG;
									break;
								}
								index++;
							}
							if (stop !== 0) break parameter;
							continue parameter;
						}
						if (code === BSLASH && index + 1 < len) {
							escaped = true;
							index += 2;
							continue;
						}
						index++;
					}
					continue parameter;
				}
				const valueStart = index;
				let stop = 0;
				let valueWhitespace = -1;
				while (index < len) {
					const flags = CHAR_MAP[header.charCodeAt(index)];
					if ((flags & stopFlags) !== 0) {
						stop = flags & COMMA_FLAG;
						break;
					}
					if ((flags & OWS) !== 0) {
						if (valueWhitespace === -1) valueWhitespace = index;
					} else valueWhitespace = -1;
					index++;
				}
				if (parameters[key] === void 0) {
					const valueEnd = valueWhitespace === -1 ? index : valueWhitespace;
					parameters[key] = header.slice(valueStart, valueEnd);
				}
				if (stop !== 0) break parameter;
				continue parameter;
			}
			if ((flags & OWS) !== 0) {
				if (keyWhitespace === -1) keyWhitespace = index;
			} else keyWhitespace = -1;
			keyFlags |= code & NON_ASCII | flags;
			index++;
		}
	}
	return {
		type,
		index,
		parameters
	};
}
/**
* Remove backslashes from quoted pairs in a known-terminated quoted string body.
*/
function unescapeQuotedPairs(str, start, end) {
	let result = "";
	for (let index = start; index < end; index++) if (str.charCodeAt(index) === BSLASH) {
		result += str.slice(start, index);
		start = ++index;
	}
	return result + str.slice(start, end);
}
// node_modules/media-typer/dist/index.js
var import_browser = /* @__PURE__ */ __toESM(require_browser(), 1);
var typeRegExp = /^[A-Za-z0-9][A-Za-z0-9!#$&^_-]{0,126}\/[A-Za-z0-9][A-Za-z0-9!#$&^_.+-]{0,126}$/;
/**
* Parse media type to object.
*/
function parse(str) {
	if (!typeRegExp.test(str)) throw new TypeError(`Invalid media type: ${str}`);
	const slashIndex = str.indexOf("/");
	const type = str.slice(0, slashIndex).toLowerCase();
	let subtype = str.slice(slashIndex + 1).toLowerCase();
	let suffix;
	const index = subtype.lastIndexOf("+");
	if (index !== -1) {
		suffix = subtype.slice(index + 1);
		subtype = subtype.slice(0, index);
	}
	return {
		type,
		subtype,
		suffix
	};
}
// node_modules/music-metadata/lib/aiff/AiffLoader.js
var aiffParserLoader = {
	parserType: "aiff",
	extensions: [
		".aif",
		"aiff",
		"aifc"
	],
	mimeTypes: [
		"audio/aiff",
		"audio/aif",
		"audio/aifc",
		"application/aiff"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/AiffParser-Bvepiihj.js?v=987d57e9")).AIFFParser;
	}
};
// node_modules/music-metadata/lib/apev2/Apev2Loader.js
var apeParserLoader = {
	parserType: "apev2",
	extensions: [".ape"],
	mimeTypes: ["audio/ape", "audio/monkeys-audio"],
	async load() {
		return (await import("/node_modules/.vite/deps/APEv2Parser-BWD6Dcm_.js?v=987d57e9").then((n) => n.n)).APEv2Parser;
	}
};
// node_modules/music-metadata/lib/asf/AsfLoader.js
var asfParserLoader = {
	parserType: "asf",
	extensions: [
		".asf",
		".wma",
		".wmv"
	],
	mimeTypes: [
		"audio/ms-wma",
		"video/ms-wmv",
		"audio/ms-asf",
		"video/ms-asf",
		"application/vnd.ms-asf"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/AsfParser-MbpDSEZI.js?v=987d57e9")).AsfParser;
	}
};
// node_modules/music-metadata/lib/caf/CafLoader.js
var cafParserLoader = {
	parserType: "caf",
	extensions: [".caf", ".caff"],
	mimeTypes: ["audio/caf", "application/caf"],
	async load() {
		return (await import("/node_modules/.vite/deps/CafParser-Bj6K-uNT.js?v=987d57e9")).CafParser;
	}
};
// node_modules/music-metadata/lib/dsdiff/DsdiffLoader.js
var dsdiffParserLoader = {
	parserType: "dsdiff",
	extensions: [".dff"],
	mimeTypes: [
		"audio/dsf",
		"audio/dsd",
		"audio/dff"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/DsdiffParser-Bt-PQpVw.js?v=987d57e9")).DsdiffParser;
	}
};
// node_modules/music-metadata/lib/dsf/DsfLoader.js
var dsfParserLoader = {
	parserType: "dsf",
	extensions: [".dsf"],
	mimeTypes: ["audio/dsf"],
	async load() {
		return (await import("/node_modules/.vite/deps/DsfParser-jQTn11kh.js?v=987d57e9")).DsfParser;
	}
};
// node_modules/music-metadata/lib/flac/FlacLoader.js
var flacParserLoader = {
	parserType: "flac",
	extensions: [".flac"],
	mimeTypes: ["audio/flac"],
	async load() {
		return (await import("/node_modules/.vite/deps/FlacParser-C9n17dhz.js?v=987d57e9").then((n) => n.n)).FlacParser;
	}
};
// node_modules/music-metadata/lib/matroska/MatroskaLoader.js
var matroskaParserLoader = {
	parserType: "matroska",
	extensions: [
		".mka",
		".mkv",
		".mk3d",
		".mks",
		"webm"
	],
	mimeTypes: [
		"audio/matroska",
		"video/matroska",
		"audio/webm",
		"video/webm"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/MatroskaParser-DvjA1NH8.js?v=987d57e9")).MatroskaParser;
	}
};
// node_modules/music-metadata/lib/mp4/Mp4Loader.js
var mp4ParserLoader = {
	parserType: "mp4",
	extensions: [
		".mp4",
		".m4a",
		".m4b",
		".m4pa",
		"m4v",
		"m4r",
		"3gp",
		".mov",
		".movie",
		".qt"
	],
	mimeTypes: [
		"audio/mp4",
		"audio/m4a",
		"video/m4v",
		"video/mp4",
		"video/quicktime"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/MP4Parser-fzN5EXdB.js?v=987d57e9")).MP4Parser;
	}
};
// node_modules/music-metadata/lib/mpeg/MpegLoader.js
var mpegParserLoader = {
	parserType: "mpeg",
	extensions: [
		".mp1",
		".mp2",
		".mp3",
		".m2a",
		".aac",
		"aacp"
	],
	mimeTypes: [
		"audio/mpeg",
		"audio/mp3",
		"audio/aacs",
		"audio/aacp"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/MpegParser-C299oP0y.js?v=987d57e9")).MpegParser;
	}
};
// node_modules/music-metadata/lib/musepack/MusepackLoader.js
var musepackParserLoader = {
	parserType: "musepack",
	extensions: [".mpc"],
	mimeTypes: ["audio/musepack"],
	async load() {
		return (await import("/node_modules/.vite/deps/MusepackParser-DJwuM5Eu.js?v=987d57e9")).MusepackParser;
	}
};
// node_modules/music-metadata/lib/ogg/OggLoader.js
var oggParserLoader = {
	parserType: "ogg",
	extensions: [
		".ogg",
		".ogv",
		".oga",
		".ogm",
		".ogx",
		".opus",
		".spx"
	],
	mimeTypes: [
		"application/ogg",
		"audio/ogg",
		"audio/opus",
		"audio/speex",
		"video/ogg"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/OggParser-waIC4uRv.js?v=987d57e9")).OggParser;
	}
};
// node_modules/music-metadata/lib/wav/WaveLoader.js
var riffParserLoader = {
	parserType: "riff",
	extensions: [
		".wav",
		"wave",
		".bwf"
	],
	mimeTypes: [
		"audio/vnd.wave",
		"audio/wav",
		"audio/wave"
	],
	async load() {
		return (await import("/node_modules/.vite/deps/WaveParser-Be61cwtQ.js?v=987d57e9")).WaveParser;
	}
};
// node_modules/music-metadata/lib/wavpack/WavPackLoader.js
var wavpackParserLoader = {
	parserType: "wavpack",
	extensions: [".wv", ".wvp"],
	mimeTypes: ["audio/wavpack"],
	async load() {
		return (await import("/node_modules/.vite/deps/WavPackParser-BuHNBxwF.js?v=987d57e9")).WavPackParser;
	}
};
// node_modules/music-metadata/lib/ParserFactory.js
var debug = (0, import_browser.default)("music-metadata:parser:factory");
function parseHttpContentType(contentType) {
	const type = parse$1(contentType);
	const mime = parse(type.type);
	return {
		type: mime.type,
		subtype: mime.subtype,
		suffix: mime.suffix,
		parameters: type.parameters
	};
}
var ParserFactory = class {
	parsers = [];
	constructor() {
		[
			flacParserLoader,
			mpegParserLoader,
			apeParserLoader,
			mp4ParserLoader,
			matroskaParserLoader,
			riffParserLoader,
			oggParserLoader,
			asfParserLoader,
			aiffParserLoader,
			wavpackParserLoader,
			musepackParserLoader,
			dsfParserLoader,
			dsdiffParserLoader,
			cafParserLoader
		].forEach((parser) => {
			this.registerParser(parser);
		});
	}
	registerParser(parser) {
		this.parsers.push(parser);
	}
	async parse(tokenizer, parserLoader, opts = {}) {
		const maxBufferSize = getMaxMemoryAllocation(opts);
		getMaxMetadataEntries(opts);
		getMaxChapterCount(opts);
		if (isRandomAccessTokenizer(tokenizer)) {
			debug("tokenizer supports random-access, scanning for appending headers");
			await scanAppendingHeaders(tokenizer, opts);
		} else debug("tokenizer does not support random-access, cannot scan for appending headers");
		if (!parserLoader) {
			const buf = /* @__PURE__ */ new Uint8Array(4100);
			if (tokenizer.fileInfo.mimeType) parserLoader = this.findLoaderForContentType(tokenizer.fileInfo.mimeType);
			if (!parserLoader && tokenizer.fileInfo.path) parserLoader = this.findLoaderForExtension(tokenizer.fileInfo.path);
			if (!parserLoader) {
				debug("Guess parser on content...");
				await tokenizer.peekBuffer(buf, { mayBeLess: true });
				const guessedType = await fileTypeFromBuffer(buf, {
					mpegOffsetTolerance: 10,
					maxBufferSize
				});
				if (!guessedType?.mime) throw new CouldNotDetermineFileTypeError("Failed to determine audio format");
				debug(`Guessed file type is mime=${guessedType.mime}, extension=${guessedType.ext}`);
				parserLoader = this.findLoaderForContentType(guessedType.mime);
				if (!parserLoader) throw new UnsupportedFileTypeError(`Guessed MIME-type not supported: ${guessedType.mime}`);
			}
		}
		debug(`Loading ${parserLoader.parserType} parser...`);
		const metadata = new MetadataCollector(opts);
		const parser = new (await (parserLoader.load()))(metadata, tokenizer, opts);
		debug(`Parser ${parserLoader.parserType} loaded`);
		await parser.parse();
		if (metadata.format.trackInfo.length === 0 && metadata.format.hasAudio === true) metadata.addStreamInfo(createAudioTrackInfo(metadata.format));
		if (metadata.format.trackInfo) {
			if (metadata.format.hasAudio === void 0) metadata.setFormat("hasAudio", !!metadata.format.trackInfo.find((track) => track.type === TrackType.audio));
			if (metadata.format.hasVideo === void 0) metadata.setFormat("hasVideo", !!metadata.format.trackInfo.find((track) => track.type === TrackType.video));
		}
		finalizeContainerInfo(metadata, tokenizer.fileInfo.size);
		return metadata.toCommonMetadata();
	}
	/**
	* @param filePath - Path, filename or extension to audio file
	* @return Parser submodule name
	*/
	findLoaderForExtension(filePath) {
		if (!filePath) return;
		const extension = getExtension(filePath).toLocaleLowerCase() || filePath;
		return this.parsers.find((parser) => parser.extensions.indexOf(extension) !== -1);
	}
	findLoaderForContentType(httpContentType) {
		let mime;
		if (!httpContentType) return;
		try {
			mime = parseHttpContentType(httpContentType);
		} catch (_err) {
			debug(`Invalid HTTP Content-Type header value: ${httpContentType}`);
			return;
		}
		const subType = mime.subtype.indexOf("x-") === 0 ? mime.subtype.substring(2) : mime.subtype;
		return this.parsers.find((parser) => parser.mimeTypes.find((loader) => loader.indexOf(`${mime.type}/${subType}`) !== -1));
	}
	getSupportedMimeTypes() {
		const mimeTypeSet = /* @__PURE__ */ new Set();
		this.parsers.forEach((loader) => {
			loader.mimeTypes.forEach((mimeType) => {
				mimeTypeSet.add(mimeType);
				mimeTypeSet.add(mimeType.replace("/", "/x-"));
			});
		});
		return Array.from(mimeTypeSet);
	}
};
function getExtension(fname) {
	const i = fname.lastIndexOf(".");
	return i === -1 ? "" : fname.substring(i);
}
// node_modules/music-metadata/lib/core.js
/**
* Primary entry point, Node.js specific entry point is MusepackParser.ts
*/
/**
* Parse Web API File
* Requires Blob to be able to stream using a ReadableStreamBYOBReader, only available since Node.js ≥ 20
* @param blob - Blob to parse
* @param options - Parsing options
* @returns Metadata
*/
async function parseBlob(blob, options = {}) {
	const tokenizer = fromBlob(blob, getTokenizerOptions(options));
	try {
		return await parseFromTokenizer(tokenizer, options);
	} finally {
		await tokenizer.close();
	}
}
/**
* Parse audio from Web Stream.Readable
* @param webStream - WebStream to read the audio track from
* @param options - Parsing options
* @param fileInfo - File information object or MIME-type string
* @returns Metadata
*/
async function parseWebStream(webStream, fileInfo, options = {}) {
	const tokenizer = fromWebStream(webStream, getTokenizerOptions(options, typeof fileInfo === "string" ? { mimeType: fileInfo } : fileInfo));
	try {
		return await parseFromTokenizer(tokenizer, options);
	} finally {
		await tokenizer.close();
	}
}
/**
* Parse audio from memory
* @param uint8Array - Uint8Array holding audio data
* @param fileInfo - File information object or MIME-type string
* @param options - Parsing options
* @returns Metadata
* Ref: https://github.com/Borewit/strtok3/blob/e6938c81ff685074d5eb3064a11c0b03ca934c1d/src/index.ts#L15
*/
async function parseBuffer(uint8Array, fileInfo, options = {}) {
	return parseFromTokenizer(fromBuffer(uint8Array, getTokenizerOptions(options, typeof fileInfo === "string" ? { mimeType: fileInfo } : fileInfo)), options);
}
/**
* Parse audio from ITokenizer source
* @param tokenizer - Audio source implementing the tokenizer interface
* @param options - Parsing options
* @returns Metadata
*/
function parseFromTokenizer(tokenizer, options) {
	return new ParserFactory().parse(tokenizer, void 0, options);
}
/**
* Create a dictionary ordered by their tag id (key)
* @param nativeTags list of tags
* @returns tags indexed by id
*/
function orderTags(nativeTags) {
	const tags = Object.create(null);
	for (const { id, value } of nativeTags) (tags[id] ||= []).push(value);
	return tags;
}
/**
* Convert rating to 1-5 star rating
* @param rating Normalized rating [0..1] (common.rating[n].rating)
* @returns Number of stars: 1, 2, 3, 4 or 5 stars
*/
function ratingToStars(rating) {
	return rating === void 0 ? 0 : 1 + Math.round(rating * 4);
}
/**
* Select most likely cover image.
* @param pictures Usually metadata.common.picture
* @return Cover image, if any, otherwise null
*/
function selectCover(pictures) {
	return pictures?.find((picture) => picture.type && [
		"front",
		"cover",
		"cover (front)"
	].includes(picture.type.toLowerCase())) ?? pictures?.[0] ?? null;
}
async function scanAppendingHeaders(tokenizer, options = {}) {
	let apeOffset = tokenizer.fileInfo.size;
	if (await hasID3v1Header(tokenizer)) {
		apeOffset -= 128;
		const lyricsLen = await getLyricsHeaderLength(tokenizer);
		apeOffset -= lyricsLen;
	}
	options.apeHeader = await APEv2Parser.findApeFooterOffset(tokenizer, apeOffset);
}
/**
* Implementation only available when loaded as Node.js
* This method will throw an Error, always.
*/
async function parseFile(_filePath, _options = {}) {
	throw new Error("This function require a Node engine. To load Web API File objects use parseBlob instead.");
}
/**
* Implementation only available when loaded as Node.js
* This method will throw an Error, always.
*/
async function parseStream(_stream, _fileInfo, _options = {}) {
	throw new Error("This function require a Node engine.");
}
/**
* Return a list of supported mime-types
*/
function getSupportedMimeTypes() {
	return new ParserFactory().getSupportedMimeTypes();
}
export { CouldNotDetermineFileTypeError, FieldDecodingError, InternalParserError, LyricsContentType, TimestampFormat, TrackType, UnexpectedFileContentError, UnsupportedFileTypeError, getSupportedMimeTypes, makeParseError, makeUnexpectedFileContentError, orderTags, parseBlob, parseBuffer, parseFile, parseFromTokenizer, parseStream, parseWebStream, ratingToStars, scanAppendingHeaders, selectCover };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXVzaWMtbWV0YWRhdGEuanMiLCJuYW1lcyI6WyJwYXJzZSIsImluaXREZWJ1ZyIsInBhcnNlQ29udGVudFR5cGUiLCJtaW1lVHlwZVBhcnNlIl0sInNvdXJjZXMiOlsiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2x5cmljczMvTHlyaWNzMy5qcyIsIi4uLy4uL2NvbnRlbnQtdHlwZS9kaXN0L2luZGV4LmpzIiwiLi4vLi4vbWVkaWEtdHlwZXIvZGlzdC9pbmRleC5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9haWZmL0FpZmZMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvYXBldjIvQXBldjJMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvYXNmL0FzZkxvYWRlci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jYWYvQ2FmTG9hZGVyLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2RzZGlmZi9Ec2RpZmZMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvZHNmL0RzZkxvYWRlci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9mbGFjL0ZsYWNMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvbWF0cm9za2EvTWF0cm9za2FMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvbXA0L01wNExvYWRlci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9tcGVnL01wZWdMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvbXVzZXBhY2svTXVzZXBhY2tMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvb2dnL09nZ0xvYWRlci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi93YXYvV2F2ZUxvYWRlci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi93YXZwYWNrL1dhdlBhY2tMb2FkZXIuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvUGFyc2VyRmFjdG9yeS5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb3JlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHRleHREZWNvZGUgfSBmcm9tICdAYm9yZXdpdC90ZXh0LWNvZGVjJztcbmV4cG9ydCBjb25zdCBlbmRUYWcyID0gJ0xZUklDUzIwMCc7XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0THlyaWNzSGVhZGVyTGVuZ3RoKHRva2VuaXplcikge1xuICAgIGNvbnN0IGZpbGVTaXplID0gdG9rZW5pemVyLmZpbGVJbmZvLnNpemU7XG4gICAgaWYgKGZpbGVTaXplID49IDE0Mykge1xuICAgICAgICBjb25zdCBidWYgPSBuZXcgVWludDhBcnJheSgxNSk7XG4gICAgICAgIGNvbnN0IHBvc2l0aW9uID0gdG9rZW5pemVyLnBvc2l0aW9uO1xuICAgICAgICBhd2FpdCB0b2tlbml6ZXIucmVhZEJ1ZmZlcihidWYsIHsgcG9zaXRpb246IGZpbGVTaXplIC0gMTQzIH0pO1xuICAgICAgICB0b2tlbml6ZXIuc2V0UG9zaXRpb24ocG9zaXRpb24pOyAvLyBSZXN0b3JlIHBvc2l0aW9uXG4gICAgICAgIGNvbnN0IHR4dCA9IHRleHREZWNvZGUoYnVmLCAnbGF0aW4xJyk7XG4gICAgICAgIGNvbnN0IHRhZyA9IHR4dC5zdWJzdHJpbmcoNik7XG4gICAgICAgIGlmICh0YWcgPT09IGVuZFRhZzIpIHtcbiAgICAgICAgICAgIHJldHVybiBOdW1iZXIucGFyc2VJbnQodHh0LnN1YnN0cmluZygwLCA2KSwgMTApICsgMTU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIDA7XG59XG4iLCIvKiFcbiAqIGNvbnRlbnQtdHlwZVxuICogQ29weXJpZ2h0KGMpIDIwMTUgRG91Z2xhcyBDaHJpc3RvcGhlciBXaWxzb25cbiAqIE1JVCBMaWNlbnNlZFxuICovXG5jb25zdCBTUCA9IDMyOyAvLyBcIiBcIlxuY29uc3QgSFRBQiA9IDk7IC8vIFwiXFx0XCJcbmNvbnN0IFNFTUkgPSA1OTsgLy8gXCI7XCJcbmNvbnN0IEVRID0gNjE7IC8vIFwiPVwiXG5jb25zdCBEUVVPVEUgPSAzNDsgLy8gJ1wiJ1xuY29uc3QgQlNMQVNIID0gOTI7IC8vIFwiXFxcXFwiXG5jb25zdCBDT01NQSA9IDQ0OyAvLyBcIixcIlxuY29uc3QgTE9XRVJfQ0FTRSA9IDE7XG5jb25zdCBPV1MgPSAyO1xuY29uc3QgU0VNSV9GTEFHID0gNDtcbmNvbnN0IENPTU1BX0ZMQUcgPSA4O1xuY29uc3QgVE9LRU5fRkxBRyA9IDE2O1xuY29uc3QgTk9OX0FTQ0lJID0gMHhmZjAwO1xuY29uc3QgQ0FTRV9GTEFHUyA9IExPV0VSX0NBU0UgfCBOT05fQVNDSUk7XG4vKipcbiAqIENoYXJhY3RlciBmbGFncyB1c2VkIHRvIG5vcm1hbGl6ZSBIVFRQIGZpZWxkIHZhbHVlcyB3aGlsZSBzY2FubmluZy5cbiAqIE91dC1vZi1yYW5nZSByZWFkcyBpbnRlbnRpb25hbGx5IGNvZXJjZSB0byB6ZXJvIGluIGJpdHdpc2UgZXhwcmVzc2lvbnMuXG4gKi9cbmNvbnN0IENIQVJfTUFQID0gbmV3IFVpbnQ4QXJyYXkoMHgxMDApO1xuQ0hBUl9NQVBbSFRBQl0gfD0gT1dTO1xuQ0hBUl9NQVBbU1BdIHw9IE9XUztcbkNIQVJfTUFQW1NFTUldIHw9IFNFTUlfRkxBRztcbkNIQVJfTUFQW0NPTU1BXSB8PSBDT01NQV9GTEFHO1xuZm9yIChsZXQgY29kZSA9IDB4ODAgLyogbm9uLUFTQ0lJICovOyBjb2RlIDw9IDB4ZmY7IGNvZGUrKykge1xuICAgIENIQVJfTUFQW2NvZGVdIHw9IExPV0VSX0NBU0U7XG59XG5mb3IgKGNvbnN0IGNoYXIgb2YgXCIhIyQlJicqKy0uXl9gfH5cIikge1xuICAgIENIQVJfTUFQW2NoYXIuY2hhckNvZGVBdCgwKV0gfD0gVE9LRU5fRkxBRztcbn1cbmZvciAobGV0IGNvZGUgPSAweDMwIC8qIDAgKi87IGNvZGUgPD0gMHgzOSAvKiA5ICovOyBjb2RlKyspIHtcbiAgICBDSEFSX01BUFtjb2RlXSB8PSBUT0tFTl9GTEFHO1xufVxuZm9yIChsZXQgY29kZSA9IDB4NDEgLyogQSAqLzsgY29kZSA8PSAweDVhIC8qIFogKi87IGNvZGUrKykge1xuICAgIENIQVJfTUFQW2NvZGVdIHw9IExPV0VSX0NBU0UgfCBUT0tFTl9GTEFHO1xufVxuZm9yIChsZXQgY29kZSA9IDB4NjEgLyogYSAqLzsgY29kZSA8PSAweDdhIC8qIHogKi87IGNvZGUrKykge1xuICAgIENIQVJfTUFQW2NvZGVdIHw9IFRPS0VOX0ZMQUc7XG59XG4vKipcbiAqIE51bGwgb2JqZWN0IHBlcmYgb3B0aW1pemF0aW9uLiBGYXN0ZXIgdGhhbiBgT2JqZWN0LmNyZWF0ZShudWxsKWAgYW5kIGB7IF9fcHJvdG9fXzogbnVsbCB9YC5cbiAqL1xuY29uc3QgTnVsbE9iamVjdCA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4ge1xuICAgIGNvbnN0IEMgPSBmdW5jdGlvbiAoKSB7IH07XG4gICAgQy5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHJldHVybiBDO1xufSkoKTtcbi8qKlxuICogVmFsaWRhdGUgYSB0eXBlIHN0cmluZyBhZ2FpbnN0IFJGQyA5MTEwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNUeXBlVmFsaWQodHlwZSwgc3RhcnQgPSAwLCBlbmQgPSB0eXBlLmxlbmd0aCkge1xuICAgIGxldCBoYXNTbGFzaCA9IGZhbHNlO1xuICAgIGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSB0eXBlLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICBpZiAoY29kZSA9PT0gNDcgLyogLyAqLykge1xuICAgICAgICAgICAgaWYgKGhhc1NsYXNoIHx8IGluZGV4ID09PSBzdGFydCB8fCBpbmRleCA+PSBlbmQgLSAxKVxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIGhhc1NsYXNoID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICghaXNUb2tlbkNvZGUoY29kZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gaGFzU2xhc2g7XG59XG4vKipcbiAqIFZhbGlkYXRlIGEgdG9rZW4gYWdhaW5zdCBSRkMgOTExMC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVG9rZW5WYWxpZCh0b2tlbiwgc3RhcnQgPSAwLCBlbmQgPSB0b2tlbi5sZW5ndGgpIHtcbiAgICBpZiAoc3RhcnQgPj0gZW5kKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgZm9yIChsZXQgaW5kZXggPSBzdGFydDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcbiAgICAgICAgaWYgKCFpc1Rva2VuQ29kZSh0b2tlbi5jaGFyQ29kZUF0KGluZGV4KSkpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuLyoqXG4gKiBDaGVjayB3aGV0aGVyIGEgY2hhcmFjdGVyIGNvZGUgYmVsb25ncyB0byB0aGUgdG9rZW4gcHJvZHVjdGlvbiBpbiBSRkMgOTExMC5cbiAqL1xuZnVuY3Rpb24gaXNUb2tlbkNvZGUoY29kZSkge1xuICAgIHJldHVybiAoQ0hBUl9NQVBbY29kZV0gJiBUT0tFTl9GTEFHKSAhPT0gMDtcbn1cbi8qKlxuICogU2VyaWFsaXplIGEgcGFyYW1ldGVyIHZhbHVlLlxuICovXG5mdW5jdGlvbiBwYXJhbWV0ZXJWYWx1ZShzdHIpIHtcbiAgICBjb25zdCBsZW4gPSBzdHIubGVuZ3RoO1xuICAgIGlmIChsZW4gPT09IDApXG4gICAgICAgIHJldHVybiAnXCJcIic7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICB3aGlsZSAoaW5kZXggPCBsZW4gJiYgaXNUb2tlbkNvZGUoc3RyLmNoYXJDb2RlQXQoaW5kZXgpKSlcbiAgICAgICAgaW5kZXgrKztcbiAgICBpZiAoaW5kZXggPT09IGxlbilcbiAgICAgICAgcmV0dXJuIHN0cjtcbiAgICBsZXQgcmVzdWx0ID0gJ1wiJztcbiAgICBsZXQgc3RhcnQgPSAwO1xuICAgIHdoaWxlIChpbmRleCA8IGxlbikge1xuICAgICAgICBjb25zdCBjb2RlID0gc3RyLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICBpZiAoY29kZSAhPT0gSFRBQiAmJiAoY29kZSA8IFNQIHx8IGNvZGUgPT09IDEyNyB8fCBjb2RlID4gMjU1KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCBwYXJhbWV0ZXIgdmFsdWU6ICR7c3RyfWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb2RlID09PSAzNCAvKiBcIiAqLyB8fCBjb2RlID09PSA5MiAvKiBcXFxcICovKSB7XG4gICAgICAgICAgICByZXN1bHQgKz0gYCR7c3RyLnNsaWNlKHN0YXJ0LCBpbmRleCl9XFxcXGA7XG4gICAgICAgICAgICBzdGFydCA9IGluZGV4O1xuICAgICAgICB9XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBgJHtyZXN1bHR9JHtzdHIuc2xpY2Uoc3RhcnQpfVwiYDtcbn1cbi8qKlxuICogRm9ybWF0IGFuIG9iamVjdCBpbnRvIGEgYENvbnRlbnQtVHlwZWAgaGVhZGVyLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0KG9iaikge1xuICAgIGNvbnN0IHsgdHlwZSwgcGFyYW1ldGVycyB9ID0gb2JqO1xuICAgIGlmICghdHlwZSB8fCAhaXNUeXBlVmFsaWQodHlwZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCB0eXBlOiAke3R5cGV9YCk7XG4gICAgfVxuICAgIGxldCByZXN1bHQgPSB0eXBlO1xuICAgIGlmIChwYXJhbWV0ZXJzKSB7XG4gICAgICAgIGZvciAoY29uc3QgcGFyYW0gb2YgT2JqZWN0LmtleXMocGFyYW1ldGVycykpIHtcbiAgICAgICAgICAgIGlmICghaXNUb2tlblZhbGlkKHBhcmFtKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYEludmFsaWQgcGFyYW1ldGVyIG5hbWU6ICR7cGFyYW19YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQgKz0gYDsgJHtwYXJhbX09JHtwYXJhbWV0ZXJWYWx1ZShwYXJhbWV0ZXJzW3BhcmFtXSl9YDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4gKiBQYXJzZSBhIGBDb250ZW50LVR5cGVgIGhlYWRlci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlKGhlYWRlciwgb3B0aW9ucykge1xuICAgIGNvbnN0IHN0b3BGbGFncyA9IFNFTUlfRkxBRyB8IChvcHRpb25zPy5jb21tYSA9PT0gdHJ1ZSA/IENPTU1BX0ZMQUcgOiAwKTtcbiAgICBjb25zdCBsZW4gPSBoZWFkZXIubGVuZ3RoO1xuICAgIGxldCB2YWx1ZVN0YXJ0ID0gb3B0aW9ucz8uc3RhcnQgPz8gMDtcbiAgICB3aGlsZSAoKENIQVJfTUFQW2hlYWRlci5jaGFyQ29kZUF0KHZhbHVlU3RhcnQpXSAmIE9XUykgIT09IDApIHtcbiAgICAgICAgdmFsdWVTdGFydCsrO1xuICAgIH1cbiAgICBsZXQgaW5kZXggPSB2YWx1ZVN0YXJ0O1xuICAgIGxldCB0eXBlRmxhZ3MgPSAwO1xuICAgIGxldCB3aGl0ZXNwYWNlID0gLTE7XG4gICAgbGV0IHN0b3AgPSBvcHRpb25zPy5wYXJhbWV0ZXJzID09PSBmYWxzZSA/IENPTU1BX0ZMQUcgOiAwO1xuICAgIHdoaWxlIChpbmRleCA8IGxlbikge1xuICAgICAgICBjb25zdCBjb2RlID0gaGVhZGVyLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICBjb25zdCBmbGFncyA9IENIQVJfTUFQW2NvZGVdO1xuICAgICAgICBpZiAoKGZsYWdzICYgc3RvcEZsYWdzKSAhPT0gMCkge1xuICAgICAgICAgICAgc3RvcCB8PSBmbGFncyAmIENPTU1BX0ZMQUc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBpZiAoKGZsYWdzICYgT1dTKSAhPT0gMCkge1xuICAgICAgICAgICAgaWYgKHdoaXRlc3BhY2UgPT09IC0xKVxuICAgICAgICAgICAgICAgIHdoaXRlc3BhY2UgPSBpbmRleDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHdoaXRlc3BhY2UgPSAtMTtcbiAgICAgICAgfVxuICAgICAgICB0eXBlRmxhZ3MgfD0gKGNvZGUgJiBOT05fQVNDSUkpIHwgZmxhZ3M7XG4gICAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlRW5kID0gd2hpdGVzcGFjZSA9PT0gLTEgPyBpbmRleCA6IHdoaXRlc3BhY2U7XG4gICAgY29uc3QgdmFsdWUgPSBoZWFkZXIuc2xpY2UodmFsdWVTdGFydCwgdmFsdWVFbmQpO1xuICAgIGNvbnN0IHR5cGUgPSAodHlwZUZsYWdzICYgQ0FTRV9GTEFHUykgPT09IDAgPyB2YWx1ZSA6IHZhbHVlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGluZGV4ID09PSBsZW4gfHwgc3RvcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4geyB0eXBlLCBpbmRleCwgcGFyYW1ldGVyczogbmV3IE51bGxPYmplY3QoKSB9O1xuICAgIH1cbiAgICByZXR1cm4gcGFyc2VQYXJhbWV0ZXJzKGhlYWRlciwgdHlwZSwgaW5kZXgsIGxlbiwgc3RvcEZsYWdzKTtcbn1cbi8qKlxuICogUGFyc2VzIHRoZSBwYXJhbWV0ZXJzIG9mIGEgYENvbnRlbnQtVHlwZWAgaGVhZGVyIHN0YXJ0aW5nIGF0IHRoZSBnaXZlbiBpbmRleC5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQYXJhbWV0ZXJzKGhlYWRlciwgdHlwZSwgaW5kZXgsIGxlbiwgc3RvcEZsYWdzKSB7XG4gICAgY29uc3QgcGFyYW1ldGVycyA9IG5ldyBOdWxsT2JqZWN0KCk7XG4gICAgcGFyYW1ldGVyOiB3aGlsZSAoaW5kZXggPCBsZW4pIHtcbiAgICAgICAgaW5kZXgrKzsgLy8gU2tpcCBvdmVyIDtcbiAgICAgICAgd2hpbGUgKChDSEFSX01BUFtoZWFkZXIuY2hhckNvZGVBdChpbmRleCldICYgT1dTKSAhPT0gMCkge1xuICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBrZXlTdGFydCA9IGluZGV4O1xuICAgICAgICBsZXQga2V5RmxhZ3MgPSAwO1xuICAgICAgICBsZXQga2V5V2hpdGVzcGFjZSA9IC0xO1xuICAgICAgICB3aGlsZSAoaW5kZXggPCBsZW4pIHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGUgPSBoZWFkZXIuY2hhckNvZGVBdChpbmRleCk7XG4gICAgICAgICAgICBjb25zdCBmbGFncyA9IENIQVJfTUFQW2NvZGVdO1xuICAgICAgICAgICAgaWYgKChmbGFncyAmIHN0b3BGbGFncykgIT09IDApIHtcbiAgICAgICAgICAgICAgICBpZiAoKGZsYWdzICYgQ09NTUFfRkxBRykgIT09IDApXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrIHBhcmFtZXRlcjtcbiAgICAgICAgICAgICAgICBjb250aW51ZSBwYXJhbWV0ZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY29kZSA9PT0gRVEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXlFbmQgPSBrZXlXaGl0ZXNwYWNlID09PSAtMSA/IGluZGV4IDoga2V5V2hpdGVzcGFjZTtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGhlYWRlci5zbGljZShrZXlTdGFydCwga2V5RW5kKTtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXkgPSAoa2V5RmxhZ3MgJiBDQVNFX0ZMQUdTKSA9PT0gMCA/IHZhbHVlIDogdmFsdWUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgICAgIHdoaWxlICgoQ0hBUl9NQVBbaGVhZGVyLmNoYXJDb2RlQXQoaW5kZXgpXSAmIE9XUykgIT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4IDwgbGVuICYmIGhlYWRlci5jaGFyQ29kZUF0KGluZGV4KSA9PT0gRFFVT1RFKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHF1b3RlZFN0YXJ0ID0gKytpbmRleDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVzY2FwZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGluZGV4IDwgbGVuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2RlID0gaGVhZGVyLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvZGUgPT09IERRVU9URSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXJhbWV0ZXJzW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbWV0ZXJzW2tleV0gPSBlc2NhcGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVuZXNjYXBlUXVvdGVkUGFpcnMoaGVhZGVyLCBxdW90ZWRTdGFydCwgaW5kZXgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGhlYWRlci5zbGljZShxdW90ZWRTdGFydCwgaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdG9wID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBEaXNjYXJkIGNoYXJhY3RlcnMgYmV0d2VlbiBxdW90ZSBhbmQgZGVsaW1pdGVyLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChpbmRleCA8IGxlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2RlID0gaGVhZGVyLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmbGFncyA9IENIQVJfTUFQW2NvZGVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKGZsYWdzICYgc3RvcEZsYWdzKSAhPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RvcCA9IGZsYWdzICYgQ09NTUFfRkxBRztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdG9wICE9PSAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhayBwYXJhbWV0ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWUgcGFyYW1ldGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvZGUgPT09IEJTTEFTSCAmJiBpbmRleCArIDEgPCBsZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlc2NhcGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCArPSAyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZSBwYXJhbWV0ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlU3RhcnQgPSBpbmRleDtcbiAgICAgICAgICAgICAgICBsZXQgc3RvcCA9IDA7XG4gICAgICAgICAgICAgICAgbGV0IHZhbHVlV2hpdGVzcGFjZSA9IC0xO1xuICAgICAgICAgICAgICAgIHdoaWxlIChpbmRleCA8IGxlbikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2RlID0gaGVhZGVyLmNoYXJDb2RlQXQoaW5kZXgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmbGFncyA9IENIQVJfTUFQW2NvZGVdO1xuICAgICAgICAgICAgICAgICAgICBpZiAoKGZsYWdzICYgc3RvcEZsYWdzKSAhPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RvcCA9IGZsYWdzICYgQ09NTUFfRkxBRztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICgoZmxhZ3MgJiBPV1MpICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWVXaGl0ZXNwYWNlID09PSAtMSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVdoaXRlc3BhY2UgPSBpbmRleDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlV2hpdGVzcGFjZSA9IC0xO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwYXJhbWV0ZXJzW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZUVuZCA9IHZhbHVlV2hpdGVzcGFjZSA9PT0gLTEgPyBpbmRleCA6IHZhbHVlV2hpdGVzcGFjZTtcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1ldGVyc1trZXldID0gaGVhZGVyLnNsaWNlKHZhbHVlU3RhcnQsIHZhbHVlRW5kKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHN0b3AgIT09IDApXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrIHBhcmFtZXRlcjtcbiAgICAgICAgICAgICAgICBjb250aW51ZSBwYXJhbWV0ZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoKGZsYWdzICYgT1dTKSAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGlmIChrZXlXaGl0ZXNwYWNlID09PSAtMSlcbiAgICAgICAgICAgICAgICAgICAga2V5V2hpdGVzcGFjZSA9IGluZGV4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAga2V5V2hpdGVzcGFjZSA9IC0xO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAga2V5RmxhZ3MgfD0gKGNvZGUgJiBOT05fQVNDSUkpIHwgZmxhZ3M7XG4gICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IHR5cGUsIGluZGV4LCBwYXJhbWV0ZXJzIH07XG59XG4vKipcbiAqIFJlbW92ZSBiYWNrc2xhc2hlcyBmcm9tIHF1b3RlZCBwYWlycyBpbiBhIGtub3duLXRlcm1pbmF0ZWQgcXVvdGVkIHN0cmluZyBib2R5LlxuICovXG5mdW5jdGlvbiB1bmVzY2FwZVF1b3RlZFBhaXJzKHN0ciwgc3RhcnQsIGVuZCkge1xuICAgIGxldCByZXN1bHQgPSBcIlwiO1xuICAgIGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG4gICAgICAgIGlmIChzdHIuY2hhckNvZGVBdChpbmRleCkgPT09IEJTTEFTSCkge1xuICAgICAgICAgICAgcmVzdWx0ICs9IHN0ci5zbGljZShzdGFydCwgaW5kZXgpO1xuICAgICAgICAgICAgc3RhcnQgPSArK2luZGV4O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQgKyBzdHIuc2xpY2Uoc3RhcnQsIGVuZCk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCIvKipcbiAqIFJlZ0V4cCB0byBtYXRjaCB0eXBlIGluIFJGQyA2ODM4XG4gKlxuICogdHlwZS1uYW1lID0gcmVzdHJpY3RlZC1uYW1lXG4gKiBzdWJ0eXBlLW5hbWUgPSByZXN0cmljdGVkLW5hbWVcbiAqIHJlc3RyaWN0ZWQtbmFtZSA9IHJlc3RyaWN0ZWQtbmFtZS1maXJzdCAqMTI2cmVzdHJpY3RlZC1uYW1lLWNoYXJzXG4gKiByZXN0cmljdGVkLW5hbWUtZmlyc3QgID0gQUxQSEEgLyBESUdJVFxuICogcmVzdHJpY3RlZC1uYW1lLWNoYXJzICA9IEFMUEhBIC8gRElHSVQgLyBcIiFcIiAvIFwiI1wiIC9cbiAqICAgICAgICAgICAgICAgICAgICAgICAgICBcIiRcIiAvIFwiJlwiIC8gXCItXCIgLyBcIl5cIiAvIFwiX1wiXG4gKiByZXN0cmljdGVkLW5hbWUtY2hhcnMgPS8gXCIuXCIgOyBDaGFyYWN0ZXJzIGJlZm9yZSBmaXJzdCBkb3QgYWx3YXlzXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDsgc3BlY2lmeSBhIGZhY2V0IG5hbWVcbiAqIHJlc3RyaWN0ZWQtbmFtZS1jaGFycyA9LyBcIitcIiA7IENoYXJhY3RlcnMgYWZ0ZXIgbGFzdCBwbHVzIGFsd2F5c1xuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICA7IHNwZWNpZnkgYSBzdHJ1Y3R1cmVkIHN5bnRheCBzdWZmaXhcbiAqIEFMUEhBID0gICV4NDEtNUEgLyAleDYxLTdBICAgOyBBLVogLyBhLXpcbiAqIERJR0lUID0gICV4MzAtMzkgICAgICAgICAgICAgOyAwLTlcbiAqL1xuY29uc3Qgc3VidHlwZU5hbWVSZWdFeHAgPSAvXltBLVphLXowLTldW0EtWmEtejAtOSEjJCZeXy4rLV17MCwxMjZ9JC87XG5jb25zdCB0eXBlTmFtZVJlZ0V4cCA9IC9eW0EtWmEtejAtOV1bQS1aYS16MC05ISMkJl5fLV17MCwxMjZ9JC87XG5jb25zdCB0eXBlUmVnRXhwID0gL15bQS1aYS16MC05XVtBLVphLXowLTkhIyQmXl8tXXswLDEyNn1cXC9bQS1aYS16MC05XVtBLVphLXowLTkhIyQmXl8uKy1dezAsMTI2fSQvO1xuLyoqXG4gKiBGb3JtYXQgb2JqZWN0IHRvIG1lZGlhIHR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXQob2JqKSB7XG4gICAgY29uc3QgeyB0eXBlLCBzdWJ0eXBlLCBzdWZmaXggfSA9IG9iajtcbiAgICBpZiAoIXR5cGUgfHwgIXR5cGVOYW1lUmVnRXhwLnRlc3QodHlwZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCB0eXBlOiAke3R5cGV9YCk7XG4gICAgfVxuICAgIGlmICghc3VidHlwZSB8fCAhc3VidHlwZU5hbWVSZWdFeHAudGVzdChzdWJ0eXBlKSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIHN1YnR5cGU6ICR7c3VidHlwZX1gKTtcbiAgICB9XG4gICAgbGV0IHN0ciA9IHR5cGUgKyBcIi9cIiArIHN1YnR5cGU7XG4gICAgaWYgKHN1ZmZpeCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmICghdHlwZU5hbWVSZWdFeHAudGVzdChzdWZmaXgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIHN1ZmZpeDogJHtzdWZmaXh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgc3RyICs9IFwiK1wiICsgc3VmZml4O1xuICAgIH1cbiAgICByZXR1cm4gc3RyO1xufVxuLyoqXG4gKiBQYXJzZSBtZWRpYSB0eXBlIHRvIG9iamVjdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlKHN0cikge1xuICAgIGlmICghdHlwZVJlZ0V4cC50ZXN0KHN0cikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCBtZWRpYSB0eXBlOiAke3N0cn1gKTtcbiAgICB9XG4gICAgY29uc3Qgc2xhc2hJbmRleCA9IHN0ci5pbmRleE9mKFwiL1wiKTtcbiAgICBjb25zdCB0eXBlID0gc3RyLnNsaWNlKDAsIHNsYXNoSW5kZXgpLnRvTG93ZXJDYXNlKCk7XG4gICAgbGV0IHN1YnR5cGUgPSBzdHIuc2xpY2Uoc2xhc2hJbmRleCArIDEpLnRvTG93ZXJDYXNlKCk7XG4gICAgbGV0IHN1ZmZpeDtcbiAgICBjb25zdCBpbmRleCA9IHN1YnR5cGUubGFzdEluZGV4T2YoXCIrXCIpO1xuICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgc3VmZml4ID0gc3VidHlwZS5zbGljZShpbmRleCArIDEpO1xuICAgICAgICBzdWJ0eXBlID0gc3VidHlwZS5zbGljZSgwLCBpbmRleCk7XG4gICAgfVxuICAgIHJldHVybiB7IHR5cGUsIHN1YnR5cGUsIHN1ZmZpeCB9O1xufVxuLyoqXG4gKiBUZXN0IG1lZGlhIHR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXN0KHN0cikge1xuICAgIHJldHVybiB0eXBlUmVnRXhwLnRlc3Qoc3RyKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImV4cG9ydCBjb25zdCBhaWZmUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdhaWZmJyxcbiAgICBleHRlbnNpb25zOiBbJy5haWYnLCAnYWlmZicsICdhaWZjJ10sXG4gICAgbWltZVR5cGVzOiBbJ2F1ZGlvL2FpZmYnLCAnYXVkaW8vYWlmJywgJ2F1ZGlvL2FpZmMnLCAnYXBwbGljYXRpb24vYWlmZiddLFxuICAgIGFzeW5jIGxvYWQoKSB7XG4gICAgICAgIHJldHVybiAoYXdhaXQgaW1wb3J0KCcuL0FpZmZQYXJzZXIuanMnKSkuQUlGRlBhcnNlcjtcbiAgICB9XG59O1xuIiwiZXhwb3J0IGNvbnN0IGFwZVBhcnNlckxvYWRlciA9IHtcbiAgICBwYXJzZXJUeXBlOiAnYXBldjInLFxuICAgIGV4dGVuc2lvbnM6IFsnLmFwZSddLFxuICAgIG1pbWVUeXBlczogWydhdWRpby9hcGUnLCAnYXVkaW8vbW9ua2V5cy1hdWRpbyddLFxuICAgIGFzeW5jIGxvYWQoKSB7XG4gICAgICAgIHJldHVybiAoYXdhaXQgaW1wb3J0KCcuL0FQRXYyUGFyc2VyLmpzJykpLkFQRXYyUGFyc2VyO1xuICAgIH1cbn07XG4iLCJleHBvcnQgY29uc3QgYXNmUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdhc2YnLFxuICAgIGV4dGVuc2lvbnM6IFsnLmFzZicsICcud21hJywgJy53bXYnXSxcbiAgICBtaW1lVHlwZXM6IFsnYXVkaW8vbXMtd21hJywgJ3ZpZGVvL21zLXdtdicsICdhdWRpby9tcy1hc2YnLCAndmlkZW8vbXMtYXNmJywgJ2FwcGxpY2F0aW9uL3ZuZC5tcy1hc2YnXSxcbiAgICBhc3luYyBsb2FkKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IGltcG9ydCgnLi9Bc2ZQYXJzZXIuanMnKSkuQXNmUGFyc2VyO1xuICAgIH1cbn07XG4iLCJleHBvcnQgY29uc3QgY2FmUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdjYWYnLFxuICAgIGV4dGVuc2lvbnM6IFsnLmNhZicsICcuY2FmZiddLFxuICAgIG1pbWVUeXBlczogWydhdWRpby9jYWYnLCAnYXBwbGljYXRpb24vY2FmJ10sXG4gICAgYXN5bmMgbG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCBpbXBvcnQoJy4vQ2FmUGFyc2VyLmpzJykpLkNhZlBhcnNlcjtcbiAgICB9XG59O1xuIiwiZXhwb3J0IGNvbnN0IGRzZGlmZlBhcnNlckxvYWRlciA9IHtcbiAgICBwYXJzZXJUeXBlOiAnZHNkaWZmJyxcbiAgICBleHRlbnNpb25zOiBbJy5kZmYnXSxcbiAgICBtaW1lVHlwZXM6IFsnYXVkaW8vZHNmJywgJ2F1ZGlvL2RzZCcsICdhdWRpby9kZmYnXSxcbiAgICBhc3luYyBsb2FkKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IGltcG9ydCgnLi9Ec2RpZmZQYXJzZXIuanMnKSkuRHNkaWZmUGFyc2VyO1xuICAgIH1cbn07XG4iLCJleHBvcnQgY29uc3QgZHNmUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdkc2YnLFxuICAgIGV4dGVuc2lvbnM6IFsnLmRzZiddLFxuICAgIG1pbWVUeXBlczogWydhdWRpby9kc2YnXSxcbiAgICBhc3luYyBsb2FkKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IGltcG9ydCgnLi9Ec2ZQYXJzZXIuanMnKSkuRHNmUGFyc2VyO1xuICAgIH1cbn07XG4iLCJleHBvcnQgY29uc3QgZmxhY1BhcnNlckxvYWRlciA9IHtcbiAgICBwYXJzZXJUeXBlOiAnZmxhYycsXG4gICAgZXh0ZW5zaW9uczogWycuZmxhYyddLFxuICAgIG1pbWVUeXBlczogWydhdWRpby9mbGFjJ10sXG4gICAgYXN5bmMgbG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCBpbXBvcnQoJy4vRmxhY1BhcnNlci5qcycpKS5GbGFjUGFyc2VyO1xuICAgIH1cbn07XG4iLCJleHBvcnQgY29uc3QgbWF0cm9za2FQYXJzZXJMb2FkZXIgPSB7XG4gICAgcGFyc2VyVHlwZTogJ21hdHJvc2thJyxcbiAgICBleHRlbnNpb25zOiBbJy5ta2EnLCAnLm1rdicsICcubWszZCcsICcubWtzJywgJ3dlYm0nXSxcbiAgICBtaW1lVHlwZXM6IFsnYXVkaW8vbWF0cm9za2EnLCAndmlkZW8vbWF0cm9za2EnLCAnYXVkaW8vd2VibScsICd2aWRlby93ZWJtJ10sXG4gICAgYXN5bmMgbG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCBpbXBvcnQoJy4vTWF0cm9za2FQYXJzZXIuanMnKSkuTWF0cm9za2FQYXJzZXI7XG4gICAgfVxufTtcbiIsImV4cG9ydCBjb25zdCBtcDRQYXJzZXJMb2FkZXIgPSB7XG4gICAgcGFyc2VyVHlwZTogJ21wNCcsXG4gICAgZXh0ZW5zaW9uczogWycubXA0JywgJy5tNGEnLCAnLm00YicsICcubTRwYScsICdtNHYnLCAnbTRyJywgJzNncCcsICcubW92JywgJy5tb3ZpZScsICcucXQnXSxcbiAgICBtaW1lVHlwZXM6IFsnYXVkaW8vbXA0JywgJ2F1ZGlvL200YScsICd2aWRlby9tNHYnLCAndmlkZW8vbXA0JywgJ3ZpZGVvL3F1aWNrdGltZSddLFxuICAgIGFzeW5jIGxvYWQoKSB7XG4gICAgICAgIHJldHVybiAoYXdhaXQgaW1wb3J0KCcuL01QNFBhcnNlci5qcycpKS5NUDRQYXJzZXI7XG4gICAgfVxufTtcbiIsImV4cG9ydCBjb25zdCBtcGVnUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdtcGVnJyxcbiAgICBleHRlbnNpb25zOiBbJy5tcDEnLCAnLm1wMicsICcubXAzJywgJy5tMmEnLCAnLmFhYycsICdhYWNwJ10sXG4gICAgbWltZVR5cGVzOiBbJ2F1ZGlvL21wZWcnLCAnYXVkaW8vbXAzJywgJ2F1ZGlvL2FhY3MnLCAnYXVkaW8vYWFjcCddLFxuICAgIGFzeW5jIGxvYWQoKSB7XG4gICAgICAgIHJldHVybiAoYXdhaXQgaW1wb3J0KCcuL01wZWdQYXJzZXIuanMnKSkuTXBlZ1BhcnNlcjtcbiAgICB9XG59O1xuIiwiZXhwb3J0IGNvbnN0IG11c2VwYWNrUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICdtdXNlcGFjaycsXG4gICAgZXh0ZW5zaW9uczogWycubXBjJ10sXG4gICAgbWltZVR5cGVzOiBbJ2F1ZGlvL211c2VwYWNrJ10sXG4gICAgYXN5bmMgbG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCBpbXBvcnQoJy4vTXVzZXBhY2tQYXJzZXIuanMnKSkuTXVzZXBhY2tQYXJzZXI7XG4gICAgfVxufTtcbiIsImV4cG9ydCBjb25zdCBvZ2dQYXJzZXJMb2FkZXIgPSB7XG4gICAgcGFyc2VyVHlwZTogJ29nZycsXG4gICAgZXh0ZW5zaW9uczogWycub2dnJywgJy5vZ3YnLCAnLm9nYScsICcub2dtJywgJy5vZ3gnLCAnLm9wdXMnLCAnLnNweCddLFxuICAgIG1pbWVUeXBlczogWydhcHBsaWNhdGlvbi9vZ2cnLCAnYXVkaW8vb2dnJywgJ2F1ZGlvL29wdXMnLCAnYXVkaW8vc3BlZXgnLCAndmlkZW8vb2dnJ10sIC8vIFJGQyA1MzM0LCBSRkMgNzg0NSwgUkZDIDY3MTYsIFJGQyA1NTc0XG4gICAgYXN5bmMgbG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIChhd2FpdCBpbXBvcnQoJy4vT2dnUGFyc2VyLmpzJykpLk9nZ1BhcnNlcjtcbiAgICB9XG59O1xuIiwiZXhwb3J0IGNvbnN0IHJpZmZQYXJzZXJMb2FkZXIgPSB7XG4gICAgcGFyc2VyVHlwZTogJ3JpZmYnLFxuICAgIGV4dGVuc2lvbnM6IFsnLndhdicsICd3YXZlJywgJy5id2YnXSxcbiAgICBtaW1lVHlwZXM6IFsnYXVkaW8vdm5kLndhdmUnLCAnYXVkaW8vd2F2JywgJ2F1ZGlvL3dhdmUnXSxcbiAgICBhc3luYyBsb2FkKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IGltcG9ydCgnLi9XYXZlUGFyc2VyLmpzJykpLldhdmVQYXJzZXI7XG4gICAgfVxufTtcbiIsImV4cG9ydCBjb25zdCB3YXZwYWNrUGFyc2VyTG9hZGVyID0ge1xuICAgIHBhcnNlclR5cGU6ICd3YXZwYWNrJyxcbiAgICBleHRlbnNpb25zOiBbJy53dicsICcud3ZwJ10sXG4gICAgbWltZVR5cGVzOiBbJ2F1ZGlvL3dhdnBhY2snXSxcbiAgICBhc3luYyBsb2FkKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IGltcG9ydCgnLi9XYXZQYWNrUGFyc2VyLmpzJykpLldhdlBhY2tQYXJzZXI7XG4gICAgfVxufTtcbiIsImltcG9ydCB7IHBhcnNlIGFzIHBhcnNlQ29udGVudFR5cGUgfSBmcm9tICdjb250ZW50LXR5cGUnO1xuaW1wb3J0IGluaXREZWJ1ZyBmcm9tICdkZWJ1Zyc7XG5pbXBvcnQgeyBmaWxlVHlwZUZyb21CdWZmZXIgfSBmcm9tICdmaWxlLXR5cGUnO1xuaW1wb3J0IHsgcGFyc2UgYXMgbWltZVR5cGVQYXJzZSB9IGZyb20gJ21lZGlhLXR5cGVyJztcbmltcG9ydCB7IGlzUmFuZG9tQWNjZXNzVG9rZW5pemVyIH0gZnJvbSAnc3RydG9rMyc7XG5pbXBvcnQgeyBhaWZmUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9haWZmL0FpZmZMb2FkZXIuanMnO1xuaW1wb3J0IHsgYXBlUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9hcGV2Mi9BcGV2MkxvYWRlci5qcyc7XG5pbXBvcnQgeyBhc2ZQYXJzZXJMb2FkZXIgfSBmcm9tICcuL2FzZi9Bc2ZMb2FkZXIuanMnO1xuaW1wb3J0IHsgY2FmUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9jYWYvQ2FmTG9hZGVyLmpzJztcbmltcG9ydCB7IGdldE1heENoYXB0ZXJDb3VudCwgZ2V0TWF4TWVtb3J5QWxsb2NhdGlvbiwgZ2V0TWF4TWV0YWRhdGFFbnRyaWVzIH0gZnJvbSAnLi9jb21tb24vQWxsb2NhdGlvbi5qcyc7XG5pbXBvcnQgeyBNZXRhZGF0YUNvbGxlY3RvciB9IGZyb20gJy4vY29tbW9uL01ldGFkYXRhQ29sbGVjdG9yLmpzJztcbmltcG9ydCB7IGNyZWF0ZUF1ZGlvVHJhY2tJbmZvLCBmaW5hbGl6ZUNvbnRhaW5lckluZm8gfSBmcm9tICcuL2NvbW1vbi9UcmFja0luZm8uanMnO1xuaW1wb3J0IHsgc2NhbkFwcGVuZGluZ0hlYWRlcnMgfSBmcm9tICcuL2NvcmUuanMnO1xuaW1wb3J0IHsgZHNkaWZmUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9kc2RpZmYvRHNkaWZmTG9hZGVyLmpzJztcbmltcG9ydCB7IGRzZlBhcnNlckxvYWRlciB9IGZyb20gJy4vZHNmL0RzZkxvYWRlci5qcyc7XG5pbXBvcnQgeyBmbGFjUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9mbGFjL0ZsYWNMb2FkZXIuanMnO1xuaW1wb3J0IHsgbWF0cm9za2FQYXJzZXJMb2FkZXIgfSBmcm9tICcuL21hdHJvc2thL01hdHJvc2thTG9hZGVyLmpzJztcbmltcG9ydCB7IG1wNFBhcnNlckxvYWRlciB9IGZyb20gJy4vbXA0L01wNExvYWRlci5qcyc7XG5pbXBvcnQgeyBtcGVnUGFyc2VyTG9hZGVyIH0gZnJvbSAnLi9tcGVnL01wZWdMb2FkZXIuanMnO1xuaW1wb3J0IHsgbXVzZXBhY2tQYXJzZXJMb2FkZXIgfSBmcm9tICcuL211c2VwYWNrL011c2VwYWNrTG9hZGVyLmpzJztcbmltcG9ydCB7IG9nZ1BhcnNlckxvYWRlciB9IGZyb20gJy4vb2dnL09nZ0xvYWRlci5qcyc7XG5pbXBvcnQgeyBDb3VsZE5vdERldGVybWluZUZpbGVUeXBlRXJyb3IsIFVuc3VwcG9ydGVkRmlsZVR5cGVFcnJvciB9IGZyb20gJy4vUGFyc2VFcnJvci5qcyc7XG5pbXBvcnQgeyBUcmFja1R5cGUgfSBmcm9tICcuL3R5cGUuanMnO1xuaW1wb3J0IHsgcmlmZlBhcnNlckxvYWRlciB9IGZyb20gJy4vd2F2L1dhdmVMb2FkZXIuanMnO1xuaW1wb3J0IHsgd2F2cGFja1BhcnNlckxvYWRlciB9IGZyb20gJy4vd2F2cGFjay9XYXZQYWNrTG9hZGVyLmpzJztcbmNvbnN0IGRlYnVnID0gaW5pdERlYnVnKCdtdXNpYy1tZXRhZGF0YTpwYXJzZXI6ZmFjdG9yeScpO1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlSHR0cENvbnRlbnRUeXBlKGNvbnRlbnRUeXBlKSB7XG4gICAgY29uc3QgdHlwZSA9IHBhcnNlQ29udGVudFR5cGUoY29udGVudFR5cGUpO1xuICAgIGNvbnN0IG1pbWUgPSBtaW1lVHlwZVBhcnNlKHR5cGUudHlwZSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogbWltZS50eXBlLFxuICAgICAgICBzdWJ0eXBlOiBtaW1lLnN1YnR5cGUsXG4gICAgICAgIHN1ZmZpeDogbWltZS5zdWZmaXgsXG4gICAgICAgIHBhcmFtZXRlcnM6IHR5cGUucGFyYW1ldGVyc1xuICAgIH07XG59XG5leHBvcnQgY2xhc3MgUGFyc2VyRmFjdG9yeSB7XG4gICAgcGFyc2VycyA9IFtdO1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBbXG4gICAgICAgICAgICBmbGFjUGFyc2VyTG9hZGVyLFxuICAgICAgICAgICAgbXBlZ1BhcnNlckxvYWRlcixcbiAgICAgICAgICAgIGFwZVBhcnNlckxvYWRlcixcbiAgICAgICAgICAgIG1wNFBhcnNlckxvYWRlcixcbiAgICAgICAgICAgIG1hdHJvc2thUGFyc2VyTG9hZGVyLFxuICAgICAgICAgICAgcmlmZlBhcnNlckxvYWRlcixcbiAgICAgICAgICAgIG9nZ1BhcnNlckxvYWRlcixcbiAgICAgICAgICAgIGFzZlBhcnNlckxvYWRlcixcbiAgICAgICAgICAgIGFpZmZQYXJzZXJMb2FkZXIsXG4gICAgICAgICAgICB3YXZwYWNrUGFyc2VyTG9hZGVyLFxuICAgICAgICAgICAgbXVzZXBhY2tQYXJzZXJMb2FkZXIsXG4gICAgICAgICAgICBkc2ZQYXJzZXJMb2FkZXIsXG4gICAgICAgICAgICBkc2RpZmZQYXJzZXJMb2FkZXIsXG4gICAgICAgICAgICBjYWZQYXJzZXJMb2FkZXJcbiAgICAgICAgXS5mb3JFYWNoKHBhcnNlciA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUGFyc2VyKHBhcnNlcik7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZWdpc3RlclBhcnNlcihwYXJzZXIpIHtcbiAgICAgICAgdGhpcy5wYXJzZXJzLnB1c2gocGFyc2VyKTtcbiAgICB9XG4gICAgYXN5bmMgcGFyc2UodG9rZW5pemVyLCBwYXJzZXJMb2FkZXIsIG9wdHMgPSB7fSkge1xuICAgICAgICBjb25zdCBtYXhCdWZmZXJTaXplID0gZ2V0TWF4TWVtb3J5QWxsb2NhdGlvbihvcHRzKTtcbiAgICAgICAgZ2V0TWF4TWV0YWRhdGFFbnRyaWVzKG9wdHMpO1xuICAgICAgICBnZXRNYXhDaGFwdGVyQ291bnQob3B0cyk7XG4gICAgICAgIGlmIChpc1JhbmRvbUFjY2Vzc1Rva2VuaXplcih0b2tlbml6ZXIpKSB7XG4gICAgICAgICAgICBkZWJ1ZygndG9rZW5pemVyIHN1cHBvcnRzIHJhbmRvbS1hY2Nlc3MsIHNjYW5uaW5nIGZvciBhcHBlbmRpbmcgaGVhZGVycycpO1xuICAgICAgICAgICAgYXdhaXQgc2NhbkFwcGVuZGluZ0hlYWRlcnModG9rZW5pemVyLCBvcHRzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGRlYnVnKCd0b2tlbml6ZXIgZG9lcyBub3Qgc3VwcG9ydCByYW5kb20tYWNjZXNzLCBjYW5ub3Qgc2NhbiBmb3IgYXBwZW5kaW5nIGhlYWRlcnMnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXBhcnNlckxvYWRlcikge1xuICAgICAgICAgICAgY29uc3QgYnVmID0gbmV3IFVpbnQ4QXJyYXkoNDEwMCk7XG4gICAgICAgICAgICBpZiAodG9rZW5pemVyLmZpbGVJbmZvLm1pbWVUeXBlKSB7XG4gICAgICAgICAgICAgICAgcGFyc2VyTG9hZGVyID0gdGhpcy5maW5kTG9hZGVyRm9yQ29udGVudFR5cGUodG9rZW5pemVyLmZpbGVJbmZvLm1pbWVUeXBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFyc2VyTG9hZGVyICYmIHRva2VuaXplci5maWxlSW5mby5wYXRoKSB7XG4gICAgICAgICAgICAgICAgcGFyc2VyTG9hZGVyID0gdGhpcy5maW5kTG9hZGVyRm9yRXh0ZW5zaW9uKHRva2VuaXplci5maWxlSW5mby5wYXRoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghcGFyc2VyTG9hZGVyKSB7XG4gICAgICAgICAgICAgICAgLy8gUGFyc2VyIGNvdWxkIG5vdCBiZSBkZXRlcm1pbmVkIG9uIE1JTUUtdHlwZSBvciBleHRlbnNpb25cbiAgICAgICAgICAgICAgICBkZWJ1ZygnR3Vlc3MgcGFyc2VyIG9uIGNvbnRlbnQuLi4nKTtcbiAgICAgICAgICAgICAgICBhd2FpdCB0b2tlbml6ZXIucGVla0J1ZmZlcihidWYsIHsgbWF5QmVMZXNzOiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgIGNvbnN0IGd1ZXNzZWRUeXBlID0gYXdhaXQgZmlsZVR5cGVGcm9tQnVmZmVyKGJ1ZiwgeyBtcGVnT2Zmc2V0VG9sZXJhbmNlOiAxMCwgbWF4QnVmZmVyU2l6ZSB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIWd1ZXNzZWRUeXBlPy5taW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBDb3VsZE5vdERldGVybWluZUZpbGVUeXBlRXJyb3IoJ0ZhaWxlZCB0byBkZXRlcm1pbmUgYXVkaW8gZm9ybWF0Jyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGRlYnVnKGBHdWVzc2VkIGZpbGUgdHlwZSBpcyBtaW1lPSR7Z3Vlc3NlZFR5cGUubWltZX0sIGV4dGVuc2lvbj0ke2d1ZXNzZWRUeXBlLmV4dH1gKTtcbiAgICAgICAgICAgICAgICBwYXJzZXJMb2FkZXIgPSB0aGlzLmZpbmRMb2FkZXJGb3JDb250ZW50VHlwZShndWVzc2VkVHlwZS5taW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoIXBhcnNlckxvYWRlcikge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVW5zdXBwb3J0ZWRGaWxlVHlwZUVycm9yKGBHdWVzc2VkIE1JTUUtdHlwZSBub3Qgc3VwcG9ydGVkOiAke2d1ZXNzZWRUeXBlLm1pbWV9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIFBhcnNlciBmb3VuZCwgZXhlY3V0ZSBwYXJzZXJcbiAgICAgICAgZGVidWcoYExvYWRpbmcgJHtwYXJzZXJMb2FkZXIucGFyc2VyVHlwZX0gcGFyc2VyLi4uYCk7XG4gICAgICAgIGNvbnN0IG1ldGFkYXRhID0gbmV3IE1ldGFkYXRhQ29sbGVjdG9yKG9wdHMpO1xuICAgICAgICBjb25zdCBQYXJzZXJJbXBsID0gYXdhaXQgcGFyc2VyTG9hZGVyLmxvYWQoKTtcbiAgICAgICAgY29uc3QgcGFyc2VyID0gbmV3IFBhcnNlckltcGwobWV0YWRhdGEsIHRva2VuaXplciwgb3B0cyk7XG4gICAgICAgIGRlYnVnKGBQYXJzZXIgJHtwYXJzZXJMb2FkZXIucGFyc2VyVHlwZX0gbG9hZGVkYCk7XG4gICAgICAgIGF3YWl0IHBhcnNlci5wYXJzZSgpO1xuICAgICAgICAvLyBBdWRpby1vbmx5IHBhcnNlcnMgZGVzY3JpYmUgdGhlaXIgc2luZ2xlIHN0cmVhbSB0aHJvdWdoIHRoZSBmb3JtYXQgZmllbGRzLlxuICAgICAgICAvLyBDb250YWluZXIgcGFyc2VycyBzdXBwbHkgdGhlaXIgb3duIHRyYWNrczsgbmV2ZXIgY29weSBhZ2dyZWdhdGUgZmllbGRzIHRvIHRoZW0uXG4gICAgICAgIGlmIChtZXRhZGF0YS5mb3JtYXQudHJhY2tJbmZvLmxlbmd0aCA9PT0gMCAmJiBtZXRhZGF0YS5mb3JtYXQuaGFzQXVkaW8gPT09IHRydWUpIHtcbiAgICAgICAgICAgIG1ldGFkYXRhLmFkZFN0cmVhbUluZm8oY3JlYXRlQXVkaW9UcmFja0luZm8obWV0YWRhdGEuZm9ybWF0KSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGFkYXRhLmZvcm1hdC50cmFja0luZm8pIHtcbiAgICAgICAgICAgIGlmIChtZXRhZGF0YS5mb3JtYXQuaGFzQXVkaW8gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIG1ldGFkYXRhLnNldEZvcm1hdCgnaGFzQXVkaW8nLCAhIW1ldGFkYXRhLmZvcm1hdC50cmFja0luZm8uZmluZCh0cmFjayA9PiB0cmFjay50eXBlID09PSBUcmFja1R5cGUuYXVkaW8pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChtZXRhZGF0YS5mb3JtYXQuaGFzVmlkZW8gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIG1ldGFkYXRhLnNldEZvcm1hdCgnaGFzVmlkZW8nLCAhIW1ldGFkYXRhLmZvcm1hdC50cmFja0luZm8uZmluZCh0cmFjayA9PiB0cmFjay50eXBlID09PSBUcmFja1R5cGUudmlkZW8pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmaW5hbGl6ZUNvbnRhaW5lckluZm8obWV0YWRhdGEsIHRva2VuaXplci5maWxlSW5mby5zaXplKTtcbiAgICAgICAgcmV0dXJuIG1ldGFkYXRhLnRvQ29tbW9uTWV0YWRhdGEoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHBhcmFtIGZpbGVQYXRoIC0gUGF0aCwgZmlsZW5hbWUgb3IgZXh0ZW5zaW9uIHRvIGF1ZGlvIGZpbGVcbiAgICAgKiBAcmV0dXJuIFBhcnNlciBzdWJtb2R1bGUgbmFtZVxuICAgICAqL1xuICAgIGZpbmRMb2FkZXJGb3JFeHRlbnNpb24oZmlsZVBhdGgpIHtcbiAgICAgICAgaWYgKCFmaWxlUGF0aCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGV4dGVuc2lvbiA9IGdldEV4dGVuc2lvbihmaWxlUGF0aCkudG9Mb2NhbGVMb3dlckNhc2UoKSB8fCBmaWxlUGF0aDtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2Vycy5maW5kKHBhcnNlciA9PiBwYXJzZXIuZXh0ZW5zaW9ucy5pbmRleE9mKGV4dGVuc2lvbikgIT09IC0xKTtcbiAgICB9XG4gICAgZmluZExvYWRlckZvckNvbnRlbnRUeXBlKGh0dHBDb250ZW50VHlwZSkge1xuICAgICAgICBsZXQgbWltZTtcbiAgICAgICAgaWYgKCFodHRwQ29udGVudFR5cGUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbWltZSA9IHBhcnNlSHR0cENvbnRlbnRUeXBlKGh0dHBDb250ZW50VHlwZSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKF9lcnIpIHtcbiAgICAgICAgICAgIGRlYnVnKGBJbnZhbGlkIEhUVFAgQ29udGVudC1UeXBlIGhlYWRlciB2YWx1ZTogJHtodHRwQ29udGVudFR5cGV9YCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3ViVHlwZSA9IG1pbWUuc3VidHlwZS5pbmRleE9mKCd4LScpID09PSAwID8gbWltZS5zdWJ0eXBlLnN1YnN0cmluZygyKSA6IG1pbWUuc3VidHlwZTtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2Vycy5maW5kKHBhcnNlciA9PiBwYXJzZXIubWltZVR5cGVzLmZpbmQobG9hZGVyID0+IGxvYWRlci5pbmRleE9mKGAke21pbWUudHlwZX0vJHtzdWJUeXBlfWApICE9PSAtMSkpO1xuICAgIH1cbiAgICBnZXRTdXBwb3J0ZWRNaW1lVHlwZXMoKSB7XG4gICAgICAgIGNvbnN0IG1pbWVUeXBlU2V0ID0gbmV3IFNldCgpO1xuICAgICAgICB0aGlzLnBhcnNlcnMuZm9yRWFjaChsb2FkZXIgPT4ge1xuICAgICAgICAgICAgbG9hZGVyLm1pbWVUeXBlcy5mb3JFYWNoKG1pbWVUeXBlID0+IHtcbiAgICAgICAgICAgICAgICBtaW1lVHlwZVNldC5hZGQobWltZVR5cGUpO1xuICAgICAgICAgICAgICAgIG1pbWVUeXBlU2V0LmFkZChtaW1lVHlwZS5yZXBsYWNlKCcvJywgJy94LScpKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20obWltZVR5cGVTZXQpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGdldEV4dGVuc2lvbihmbmFtZSkge1xuICAgIGNvbnN0IGkgPSBmbmFtZS5sYXN0SW5kZXhPZignLicpO1xuICAgIHJldHVybiBpID09PSAtMSA/ICcnIDogZm5hbWUuc3Vic3RyaW5nKGkpO1xufVxuIiwiLyoqXG4gKiBQcmltYXJ5IGVudHJ5IHBvaW50LCBOb2RlLmpzIHNwZWNpZmljIGVudHJ5IHBvaW50IGlzIE11c2VwYWNrUGFyc2VyLnRzXG4gKi9cbmltcG9ydCB7IGZyb21CbG9iLCBmcm9tQnVmZmVyLCBmcm9tV2ViU3RyZWFtIH0gZnJvbSAnc3RydG9rMyc7XG5pbXBvcnQgeyBBUEV2MlBhcnNlciB9IGZyb20gJy4vYXBldjIvQVBFdjJQYXJzZXIuanMnO1xuaW1wb3J0IHsgZ2V0VG9rZW5pemVyT3B0aW9ucyB9IGZyb20gJy4vY29tbW9uL0FsbG9jYXRpb24uanMnO1xuaW1wb3J0IHsgaGFzSUQzdjFIZWFkZXIgfSBmcm9tICcuL2lkM3YxL0lEM3YxUGFyc2VyLmpzJztcbmltcG9ydCB7IGdldEx5cmljc0hlYWRlckxlbmd0aCB9IGZyb20gJy4vbHlyaWNzMy9MeXJpY3MzLmpzJztcbmltcG9ydCB7IFBhcnNlckZhY3RvcnkgfSBmcm9tICcuL1BhcnNlckZhY3RvcnkuanMnO1xuZXhwb3J0ICogZnJvbSAnLi9QYXJzZUVycm9yLmpzJztcbmV4cG9ydCB7IENvdWxkTm90RGV0ZXJtaW5lRmlsZVR5cGVFcnJvciwgVW5zdXBwb3J0ZWRGaWxlVHlwZUVycm9yIH0gZnJvbSAnLi9QYXJzZUVycm9yLmpzJztcbmV4cG9ydCB7IEx5cmljc0NvbnRlbnRUeXBlLCBUaW1lc3RhbXBGb3JtYXQsIFRyYWNrVHlwZSB9IGZyb20gJy4vdHlwZS5qcyc7XG4vKipcbiAqIFBhcnNlIFdlYiBBUEkgRmlsZVxuICogUmVxdWlyZXMgQmxvYiB0byBiZSBhYmxlIHRvIHN0cmVhbSB1c2luZyBhIFJlYWRhYmxlU3RyZWFtQllPQlJlYWRlciwgb25seSBhdmFpbGFibGUgc2luY2UgTm9kZS5qcyDiiaUgMjBcbiAqIEBwYXJhbSBibG9iIC0gQmxvYiB0byBwYXJzZVxuICogQHBhcmFtIG9wdGlvbnMgLSBQYXJzaW5nIG9wdGlvbnNcbiAqIEByZXR1cm5zIE1ldGFkYXRhXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwYXJzZUJsb2IoYmxvYiwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgdG9rZW5pemVyID0gZnJvbUJsb2IoYmxvYiwgZ2V0VG9rZW5pemVyT3B0aW9ucyhvcHRpb25zKSk7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBhcnNlRnJvbVRva2VuaXplcih0b2tlbml6ZXIsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBmaW5hbGx5IHtcbiAgICAgICAgYXdhaXQgdG9rZW5pemVyLmNsb3NlKCk7XG4gICAgfVxufVxuLyoqXG4gKiBQYXJzZSBhdWRpbyBmcm9tIFdlYiBTdHJlYW0uUmVhZGFibGVcbiAqIEBwYXJhbSB3ZWJTdHJlYW0gLSBXZWJTdHJlYW0gdG8gcmVhZCB0aGUgYXVkaW8gdHJhY2sgZnJvbVxuICogQHBhcmFtIG9wdGlvbnMgLSBQYXJzaW5nIG9wdGlvbnNcbiAqIEBwYXJhbSBmaWxlSW5mbyAtIEZpbGUgaW5mb3JtYXRpb24gb2JqZWN0IG9yIE1JTUUtdHlwZSBzdHJpbmdcbiAqIEByZXR1cm5zIE1ldGFkYXRhXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwYXJzZVdlYlN0cmVhbSh3ZWJTdHJlYW0sIGZpbGVJbmZvLCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB0b2tlbml6ZXIgPSBmcm9tV2ViU3RyZWFtKHdlYlN0cmVhbSwgZ2V0VG9rZW5pemVyT3B0aW9ucyhvcHRpb25zLCB0eXBlb2YgZmlsZUluZm8gPT09ICdzdHJpbmcnID8geyBtaW1lVHlwZTogZmlsZUluZm8gfSA6IGZpbGVJbmZvKSk7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IHBhcnNlRnJvbVRva2VuaXplcih0b2tlbml6ZXIsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBmaW5hbGx5IHtcbiAgICAgICAgYXdhaXQgdG9rZW5pemVyLmNsb3NlKCk7XG4gICAgfVxufVxuLyoqXG4gKiBQYXJzZSBhdWRpbyBmcm9tIG1lbW9yeVxuICogQHBhcmFtIHVpbnQ4QXJyYXkgLSBVaW50OEFycmF5IGhvbGRpbmcgYXVkaW8gZGF0YVxuICogQHBhcmFtIGZpbGVJbmZvIC0gRmlsZSBpbmZvcm1hdGlvbiBvYmplY3Qgb3IgTUlNRS10eXBlIHN0cmluZ1xuICogQHBhcmFtIG9wdGlvbnMgLSBQYXJzaW5nIG9wdGlvbnNcbiAqIEByZXR1cm5zIE1ldGFkYXRhXG4gKiBSZWY6IGh0dHBzOi8vZ2l0aHViLmNvbS9Cb3Jld2l0L3N0cnRvazMvYmxvYi9lNjkzOGM4MWZmNjg1MDc0ZDVlYjMwNjRhMTFjMGIwM2NhOTM0YzFkL3NyYy9pbmRleC50cyNMMTVcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBhcnNlQnVmZmVyKHVpbnQ4QXJyYXksIGZpbGVJbmZvLCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB0b2tlbml6ZXIgPSBmcm9tQnVmZmVyKHVpbnQ4QXJyYXksIGdldFRva2VuaXplck9wdGlvbnMob3B0aW9ucywgdHlwZW9mIGZpbGVJbmZvID09PSAnc3RyaW5nJyA/IHsgbWltZVR5cGU6IGZpbGVJbmZvIH0gOiBmaWxlSW5mbykpO1xuICAgIHJldHVybiBwYXJzZUZyb21Ub2tlbml6ZXIodG9rZW5pemVyLCBvcHRpb25zKTtcbn1cbi8qKlxuICogUGFyc2UgYXVkaW8gZnJvbSBJVG9rZW5pemVyIHNvdXJjZVxuICogQHBhcmFtIHRva2VuaXplciAtIEF1ZGlvIHNvdXJjZSBpbXBsZW1lbnRpbmcgdGhlIHRva2VuaXplciBpbnRlcmZhY2VcbiAqIEBwYXJhbSBvcHRpb25zIC0gUGFyc2luZyBvcHRpb25zXG4gKiBAcmV0dXJucyBNZXRhZGF0YVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VGcm9tVG9rZW5pemVyKHRva2VuaXplciwgb3B0aW9ucykge1xuICAgIGNvbnN0IHBhcnNlckZhY3RvcnkgPSBuZXcgUGFyc2VyRmFjdG9yeSgpO1xuICAgIHJldHVybiBwYXJzZXJGYWN0b3J5LnBhcnNlKHRva2VuaXplciwgdW5kZWZpbmVkLCBvcHRpb25zKTtcbn1cbi8qKlxuICogQ3JlYXRlIGEgZGljdGlvbmFyeSBvcmRlcmVkIGJ5IHRoZWlyIHRhZyBpZCAoa2V5KVxuICogQHBhcmFtIG5hdGl2ZVRhZ3MgbGlzdCBvZiB0YWdzXG4gKiBAcmV0dXJucyB0YWdzIGluZGV4ZWQgYnkgaWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9yZGVyVGFncyhuYXRpdmVUYWdzKSB7XG4gICAgY29uc3QgdGFncyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgZm9yIChjb25zdCB7IGlkLCB2YWx1ZSB9IG9mIG5hdGl2ZVRhZ3MpIHtcbiAgICAgICAgKHRhZ3NbaWRdIHx8PSBbXSkucHVzaCh2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiB0YWdzO1xufVxuLyoqXG4gKiBDb252ZXJ0IHJhdGluZyB0byAxLTUgc3RhciByYXRpbmdcbiAqIEBwYXJhbSByYXRpbmcgTm9ybWFsaXplZCByYXRpbmcgWzAuLjFdIChjb21tb24ucmF0aW5nW25dLnJhdGluZylcbiAqIEByZXR1cm5zIE51bWJlciBvZiBzdGFyczogMSwgMiwgMywgNCBvciA1IHN0YXJzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByYXRpbmdUb1N0YXJzKHJhdGluZykge1xuICAgIHJldHVybiByYXRpbmcgPT09IHVuZGVmaW5lZCA/IDAgOiAxICsgTWF0aC5yb3VuZChyYXRpbmcgKiA0KTtcbn1cbi8qKlxuICogU2VsZWN0IG1vc3QgbGlrZWx5IGNvdmVyIGltYWdlLlxuICogQHBhcmFtIHBpY3R1cmVzIFVzdWFsbHkgbWV0YWRhdGEuY29tbW9uLnBpY3R1cmVcbiAqIEByZXR1cm4gQ292ZXIgaW1hZ2UsIGlmIGFueSwgb3RoZXJ3aXNlIG51bGxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENvdmVyKHBpY3R1cmVzKSB7XG4gICAgcmV0dXJuIChwaWN0dXJlcz8uZmluZChwaWN0dXJlID0+IHBpY3R1cmUudHlwZSAmJiBbJ2Zyb250JywgJ2NvdmVyJywgJ2NvdmVyIChmcm9udCknXS5pbmNsdWRlcyhwaWN0dXJlLnR5cGUudG9Mb3dlckNhc2UoKSkpID8/XG4gICAgICAgIHBpY3R1cmVzPy5bMF0gPz9cbiAgICAgICAgbnVsbCk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2NhbkFwcGVuZGluZ0hlYWRlcnModG9rZW5pemVyLCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgYXBlT2Zmc2V0ID0gdG9rZW5pemVyLmZpbGVJbmZvLnNpemU7XG4gICAgaWYgKGF3YWl0IGhhc0lEM3YxSGVhZGVyKHRva2VuaXplcikpIHtcbiAgICAgICAgYXBlT2Zmc2V0IC09IDEyODtcbiAgICAgICAgY29uc3QgbHlyaWNzTGVuID0gYXdhaXQgZ2V0THlyaWNzSGVhZGVyTGVuZ3RoKHRva2VuaXplcik7XG4gICAgICAgIGFwZU9mZnNldCAtPSBseXJpY3NMZW47XG4gICAgfVxuICAgIG9wdGlvbnMuYXBlSGVhZGVyID0gYXdhaXQgQVBFdjJQYXJzZXIuZmluZEFwZUZvb3Rlck9mZnNldCh0b2tlbml6ZXIsIGFwZU9mZnNldCk7XG59XG4vKipcbiAqIEltcGxlbWVudGF0aW9uIG9ubHkgYXZhaWxhYmxlIHdoZW4gbG9hZGVkIGFzIE5vZGUuanNcbiAqIFRoaXMgbWV0aG9kIHdpbGwgdGhyb3cgYW4gRXJyb3IsIGFsd2F5cy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBhcnNlRmlsZShfZmlsZVBhdGgsIF9vcHRpb25zID0ge30pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoaXMgZnVuY3Rpb24gcmVxdWlyZSBhIE5vZGUgZW5naW5lLiBUbyBsb2FkIFdlYiBBUEkgRmlsZSBvYmplY3RzIHVzZSBwYXJzZUJsb2IgaW5zdGVhZC4nKTtcbn1cbi8qKlxuICogSW1wbGVtZW50YXRpb24gb25seSBhdmFpbGFibGUgd2hlbiBsb2FkZWQgYXMgTm9kZS5qc1xuICogVGhpcyBtZXRob2Qgd2lsbCB0aHJvdyBhbiBFcnJvciwgYWx3YXlzLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGFyc2VTdHJlYW0oX3N0cmVhbSwgX2ZpbGVJbmZvLCBfb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdUaGlzIGZ1bmN0aW9uIHJlcXVpcmUgYSBOb2RlIGVuZ2luZS4nKTtcbn1cbi8qKlxuICogUmV0dXJuIGEgbGlzdCBvZiBzdXBwb3J0ZWQgbWltZS10eXBlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3VwcG9ydGVkTWltZVR5cGVzKCkge1xuICAgIHJldHVybiBuZXcgUGFyc2VyRmFjdG9yeSgpLmdldFN1cHBvcnRlZE1pbWVUeXBlcygpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBRUEsZUFBc0Isc0JBQXNCLFdBQVc7Q0FDbkQsTUFBTSxXQUFXLFVBQVUsU0FBUztDQUNwQyxJQUFJLFlBQVksS0FBSztFQUNqQixNQUFNLHNCQUFNLElBQUksV0FBVyxFQUFFO0VBQzdCLE1BQU0sV0FBVyxVQUFVO0VBQzNCLE1BQU0sVUFBVSxXQUFXLEtBQUssRUFBRSxVQUFVLFdBQVcsSUFBSSxDQUFDO0VBQzVELFVBQVUsWUFBWSxRQUFRO0VBQzlCLE1BQU0sTUFBTSxXQUFXLEtBQUssUUFBUTtFQUVwQyxJQURZLElBQUksVUFBVSxDQUNwQixNQUFBLGFBQ0YsT0FBTyxPQUFPLFNBQVMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSTtDQUUxRDtDQUNBLE9BQU87QUFDWDs7Ozs7OztBQ1hBLElBQU0sS0FBSztBQUNYLElBQU0sT0FBTztBQUNiLElBQU0sT0FBTztBQUNiLElBQU0sS0FBSztBQUNYLElBQU0sU0FBUztBQUNmLElBQU0sU0FBUztBQUNmLElBQU0sUUFBUTtBQUNkLElBQU0sYUFBYTtBQUNuQixJQUFNLE1BQU07QUFDWixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sYUFBYTtBQUNuQixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhOzs7OztBQUtuQixJQUFNLDJCQUFXLElBQUksV0FBVyxHQUFLO0FBQ3JDLFNBQVMsU0FBUztBQUNsQixTQUFTLE9BQU87QUFDaEIsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsVUFBVTtBQUNuQixLQUFLLElBQUksT0FBTyxLQUFzQixRQUFRLEtBQU0sUUFDaEQsU0FBUyxTQUFTO0FBRXRCLEtBQUssTUFBTSxRQUFRLG1CQUNmLFNBQVMsS0FBSyxXQUFXLENBQUMsTUFBTTtBQUVwQyxLQUFLLElBQUksT0FBTyxJQUFjLFFBQVEsSUFBYyxRQUNoRCxTQUFTLFNBQVM7QUFFdEIsS0FBSyxJQUFJLE9BQU8sSUFBYyxRQUFRLElBQWMsUUFDaEQsU0FBUyxTQUFTO0FBRXRCLEtBQUssSUFBSSxPQUFPLElBQWMsUUFBUSxLQUFjLFFBQ2hELFNBQVMsU0FBUzs7OztBQUt0QixJQUFNLGFBQTZCLHVCQUFPO0NBQ3RDLE1BQU0sSUFBSSxXQUFZLENBQUU7Q0FDeEIsRUFBRSxZQUFZLE9BQU8sT0FBTyxJQUFJO0NBQ2hDLE9BQU87QUFDWCxFQUFBLENBQUc7Ozs7QUFzRkgsU0FBZ0JBLFFBQU0sUUFBUSxTQUFTO0NBQ25DLE1BQU0sWUFBWSxhQUFhLFNBQVMsVUFBVSxPQUFPLGFBQWE7Q0FDdEUsTUFBTSxNQUFNLE9BQU87Q0FDbkIsSUFBSSxhQUFhLFNBQVMsU0FBUztDQUNuQyxRQUFRLFNBQVMsT0FBTyxXQUFXLFVBQVUsS0FBSyxTQUFTLEdBQ3ZEO0NBRUosSUFBSSxRQUFRO0NBQ1osSUFBSSxZQUFZO0NBQ2hCLElBQUksYUFBYTtDQUNqQixJQUFJLE9BQU8sU0FBUyxlQUFlLFFBQVEsYUFBYTtDQUN4RCxPQUFPLFFBQVEsS0FBSztFQUNoQixNQUFNLE9BQU8sT0FBTyxXQUFXLEtBQUs7RUFDcEMsTUFBTSxRQUFRLFNBQVM7RUFDdkIsS0FBSyxRQUFRLGVBQWUsR0FBRztHQUMzQixRQUFRLFFBQVE7R0FDaEI7RUFDSjtFQUNBLEtBQUssUUFBUSxTQUFTLEdBQ2Q7T0FBQSxlQUFlLElBQ2YsYUFBYTtFQUFBLE9BR2pCLGFBQWE7RUFFakIsYUFBYyxPQUFPLFlBQWE7RUFDbEM7Q0FDSjtDQUNBLE1BQU0sV0FBVyxlQUFlLEtBQUssUUFBUTtDQUM3QyxNQUFNLFFBQVEsT0FBTyxNQUFNLFlBQVksUUFBUTtDQUMvQyxNQUFNLFFBQVEsWUFBWSxnQkFBZ0IsSUFBSSxRQUFRLE1BQU0sWUFBWTtDQUN4RSxJQUFJLFVBQVUsT0FBTyxTQUFTLEdBQzFCLE9BQU87RUFBRTtFQUFNO0VBQU8sWUFBWSxJQUFJLFdBQVc7Q0FBRTtDQUV2RCxPQUFPLGdCQUFnQixRQUFRLE1BQU0sT0FBTyxLQUFLLFNBQVM7QUFDOUQ7Ozs7QUFJQSxTQUFTLGdCQUFnQixRQUFRLE1BQU0sT0FBTyxLQUFLLFdBQVc7Q0FDMUQsTUFBTSxhQUFhLElBQUksV0FBVztDQUNsQyxXQUFXLE9BQU8sUUFBUSxLQUFLO0VBQzNCO0VBQ0EsUUFBUSxTQUFTLE9BQU8sV0FBVyxLQUFLLEtBQUssU0FBUyxHQUNsRDtFQUVKLE1BQU0sV0FBVztFQUNqQixJQUFJLFdBQVc7RUFDZixJQUFJLGdCQUFnQjtFQUNwQixPQUFPLFFBQVEsS0FBSztHQUNoQixNQUFNLE9BQU8sT0FBTyxXQUFXLEtBQUs7R0FDcEMsTUFBTSxRQUFRLFNBQVM7R0FDdkIsS0FBSyxRQUFRLGVBQWUsR0FBRztJQUMzQixLQUFLLFFBQVEsZ0JBQWdCLEdBQ3pCLE1BQU07SUFDVixTQUFTO0dBQ2I7R0FDQSxJQUFJLFNBQVMsSUFBSTtJQUNiLE1BQU0sU0FBUyxrQkFBa0IsS0FBSyxRQUFRO0lBQzlDLE1BQU0sUUFBUSxPQUFPLE1BQU0sVUFBVSxNQUFNO0lBQzNDLE1BQU0sT0FBTyxXQUFXLGdCQUFnQixJQUFJLFFBQVEsTUFBTSxZQUFZO0lBQ3RFO0lBQ0EsUUFBUSxTQUFTLE9BQU8sV0FBVyxLQUFLLEtBQUssU0FBUyxHQUNsRDtJQUVKLElBQUksUUFBUSxPQUFPLE9BQU8sV0FBVyxLQUFLLE1BQU0sUUFBUTtLQUNwRCxNQUFNLGNBQWMsRUFBRTtLQUN0QixJQUFJLFVBQVU7S0FDZCxPQUFPLFFBQVEsS0FBSztNQUNoQixNQUFNLE9BQU8sT0FBTyxXQUFXLEtBQUs7TUFDcEMsSUFBSSxTQUFTLFFBQVE7T0FDakIsSUFBSSxXQUFXLFNBQVMsS0FBQSxHQUNwQixXQUFXLE9BQU8sVUFDWixvQkFBb0IsUUFBUSxhQUFhLEtBQUssSUFDOUMsT0FBTyxNQUFNLGFBQWEsS0FBSztPQUV6QztPQUNBLElBQUksT0FBTztPQUVYLE9BQU8sUUFBUSxLQUFLO1FBRWhCLE1BQU0sUUFBUSxTQURELE9BQU8sV0FBVyxLQUNSO1FBQ3ZCLEtBQUssUUFBUSxlQUFlLEdBQUc7U0FDM0IsT0FBTyxRQUFRO1NBQ2Y7UUFDSjtRQUNBO09BQ0o7T0FDQSxJQUFJLFNBQVMsR0FDVCxNQUFNO09BQ1YsU0FBUztNQUNiO01BQ0EsSUFBSSxTQUFTLFVBQVUsUUFBUSxJQUFJLEtBQUs7T0FDcEMsVUFBVTtPQUNWLFNBQVM7T0FDVDtNQUNKO01BQ0E7S0FDSjtLQUNBLFNBQVM7SUFDYjtJQUNBLE1BQU0sYUFBYTtJQUNuQixJQUFJLE9BQU87SUFDWCxJQUFJLGtCQUFrQjtJQUN0QixPQUFPLFFBQVEsS0FBSztLQUVoQixNQUFNLFFBQVEsU0FERCxPQUFPLFdBQVcsS0FDUjtLQUN2QixLQUFLLFFBQVEsZUFBZSxHQUFHO01BQzNCLE9BQU8sUUFBUTtNQUNmO0tBQ0o7S0FDQSxLQUFLLFFBQVEsU0FBUyxHQUNkO1VBQUEsb0JBQW9CLElBQ3BCLGtCQUFrQjtLQUFBLE9BR3RCLGtCQUFrQjtLQUV0QjtJQUNKO0lBQ0EsSUFBSSxXQUFXLFNBQVMsS0FBQSxHQUFXO0tBQy9CLE1BQU0sV0FBVyxvQkFBb0IsS0FBSyxRQUFRO0tBQ2xELFdBQVcsT0FBTyxPQUFPLE1BQU0sWUFBWSxRQUFRO0lBQ3ZEO0lBQ0EsSUFBSSxTQUFTLEdBQ1QsTUFBTTtJQUNWLFNBQVM7R0FDYjtHQUNBLEtBQUssUUFBUSxTQUFTLEdBQ2Q7UUFBQSxrQkFBa0IsSUFDbEIsZ0JBQWdCO0dBQUEsT0FHcEIsZ0JBQWdCO0dBRXBCLFlBQWEsT0FBTyxZQUFhO0dBQ2pDO0VBQ0o7Q0FDSjtDQUNBLE9BQU87RUFBRTtFQUFNO0VBQU87Q0FBVztBQUNyQzs7OztBQUlBLFNBQVMsb0JBQW9CLEtBQUssT0FBTyxLQUFLO0NBQzFDLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxRQUFRLE9BQU8sUUFBUSxLQUFLLFNBQ2pDLElBQUksSUFBSSxXQUFXLEtBQUssTUFBTSxRQUFRO0VBQ2xDLFVBQVUsSUFBSSxNQUFNLE9BQU8sS0FBSztFQUNoQyxRQUFRLEVBQUU7Q0FDZDtDQUVKLE9BQU8sU0FBUyxJQUFJLE1BQU0sT0FBTyxHQUFHO0FBQ3hDOzs7QUMvUUEsSUFBTSxhQUFhOzs7O0FBd0JuQixTQUFnQixNQUFNLEtBQUs7Q0FDdkIsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLEdBQ3BCLE1BQU0sSUFBSSxVQUFVLHVCQUF1QixLQUFLO0NBRXBELE1BQU0sYUFBYSxJQUFJLFFBQVEsR0FBRztDQUNsQyxNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsVUFBVSxDQUFDLENBQUMsWUFBWTtDQUNsRCxJQUFJLFVBQVUsSUFBSSxNQUFNLGFBQWEsQ0FBQyxDQUFDLENBQUMsWUFBWTtDQUNwRCxJQUFJO0NBQ0osTUFBTSxRQUFRLFFBQVEsWUFBWSxHQUFHO0NBQ3JDLElBQUksVUFBVSxJQUFJO0VBQ2QsU0FBUyxRQUFRLE1BQU0sUUFBUSxDQUFDO0VBQ2hDLFVBQVUsUUFBUSxNQUFNLEdBQUcsS0FBSztDQUNwQztDQUNBLE9BQU87RUFBRTtFQUFNO0VBQVM7Q0FBTztBQUNuQzs7QUN4REEsSUFBYSxtQkFBbUI7Q0FDNUIsWUFBWTtDQUNaLFlBQVk7RUFBQztFQUFRO0VBQVE7Q0FBTTtDQUNuQyxXQUFXO0VBQUM7RUFBYztFQUFhO0VBQWM7Q0FBa0I7Q0FDdkUsTUFBTSxPQUFPO0VBQ1QsUUFBUSxNQUFNLE9BQU8sNEJBQUEsQ0FBb0I7Q0FDN0M7QUFDSjs7QUNQQSxJQUFhLGtCQUFrQjtDQUMzQixZQUFZO0NBQ1osWUFBWSxDQUFDLE1BQU07Q0FDbkIsV0FBVyxDQUFDLGFBQWEscUJBQXFCO0NBQzlDLE1BQU0sT0FBTztFQUNULFFBQVEsTUFBTSxPQUFPLDRCQUFtQixDQUFBLE1BQUEsTUFBQSxFQUFBLENBQUEsRUFBQSxDQUFFO0NBQzlDO0FBQ0o7O0FDUEEsSUFBYSxrQkFBa0I7Q0FDM0IsWUFBWTtDQUNaLFlBQVk7RUFBQztFQUFRO0VBQVE7Q0FBTTtDQUNuQyxXQUFXO0VBQUM7RUFBZ0I7RUFBZ0I7RUFBZ0I7RUFBZ0I7Q0FBd0I7Q0FDcEcsTUFBTSxPQUFPO0VBQ1QsUUFBUSxNQUFNLE9BQU8sMkJBQUEsQ0FBbUI7Q0FDNUM7QUFDSjs7QUNQQSxJQUFhLGtCQUFrQjtDQUMzQixZQUFZO0NBQ1osWUFBWSxDQUFDLFFBQVEsT0FBTztDQUM1QixXQUFXLENBQUMsYUFBYSxpQkFBaUI7Q0FDMUMsTUFBTSxPQUFPO0VBQ1QsUUFBUSxNQUFNLE9BQU8sMkJBQUEsQ0FBbUI7Q0FDNUM7QUFDSjs7QUNQQSxJQUFhLHFCQUFxQjtDQUM5QixZQUFZO0NBQ1osWUFBWSxDQUFDLE1BQU07Q0FDbkIsV0FBVztFQUFDO0VBQWE7RUFBYTtDQUFXO0NBQ2pELE1BQU0sT0FBTztFQUNULFFBQVEsTUFBTSxPQUFPLDhCQUFBLENBQXNCO0NBQy9DO0FBQ0o7O0FDUEEsSUFBYSxrQkFBa0I7Q0FDM0IsWUFBWTtDQUNaLFlBQVksQ0FBQyxNQUFNO0NBQ25CLFdBQVcsQ0FBQyxXQUFXO0NBQ3ZCLE1BQU0sT0FBTztFQUNULFFBQVEsTUFBTSxPQUFPLDJCQUFBLENBQW1CO0NBQzVDO0FBQ0o7O0FDUEEsSUFBYSxtQkFBbUI7Q0FDNUIsWUFBWTtDQUNaLFlBQVksQ0FBQyxPQUFPO0NBQ3BCLFdBQVcsQ0FBQyxZQUFZO0NBQ3hCLE1BQU0sT0FBTztFQUNULFFBQVEsTUFBTSxPQUFPLDJCQUFrQixDQUFBLE1BQUEsTUFBQSxFQUFBLENBQUEsRUFBQSxDQUFFO0NBQzdDO0FBQ0o7O0FDUEEsSUFBYSx1QkFBdUI7Q0FDaEMsWUFBWTtDQUNaLFlBQVk7RUFBQztFQUFRO0VBQVE7RUFBUztFQUFRO0NBQU07Q0FDcEQsV0FBVztFQUFDO0VBQWtCO0VBQWtCO0VBQWM7Q0FBWTtDQUMxRSxNQUFNLE9BQU87RUFDVCxRQUFRLE1BQU0sT0FBTyxnQ0FBQSxDQUF3QjtDQUNqRDtBQUNKOztBQ1BBLElBQWEsa0JBQWtCO0NBQzNCLFlBQVk7Q0FDWixZQUFZO0VBQUM7RUFBUTtFQUFRO0VBQVE7RUFBUztFQUFPO0VBQU87RUFBTztFQUFRO0VBQVU7Q0FBSztDQUMxRixXQUFXO0VBQUM7RUFBYTtFQUFhO0VBQWE7RUFBYTtDQUFpQjtDQUNqRixNQUFNLE9BQU87RUFDVCxRQUFRLE1BQU0sT0FBTywyQkFBQSxDQUFtQjtDQUM1QztBQUNKOztBQ1BBLElBQWEsbUJBQW1CO0NBQzVCLFlBQVk7Q0FDWixZQUFZO0VBQUM7RUFBUTtFQUFRO0VBQVE7RUFBUTtFQUFRO0NBQU07Q0FDM0QsV0FBVztFQUFDO0VBQWM7RUFBYTtFQUFjO0NBQVk7Q0FDakUsTUFBTSxPQUFPO0VBQ1QsUUFBUSxNQUFNLE9BQU8sNEJBQUEsQ0FBb0I7Q0FDN0M7QUFDSjs7QUNQQSxJQUFhLHVCQUF1QjtDQUNoQyxZQUFZO0NBQ1osWUFBWSxDQUFDLE1BQU07Q0FDbkIsV0FBVyxDQUFDLGdCQUFnQjtDQUM1QixNQUFNLE9BQU87RUFDVCxRQUFRLE1BQU0sT0FBTyxnQ0FBQSxDQUF3QjtDQUNqRDtBQUNKOztBQ1BBLElBQWEsa0JBQWtCO0NBQzNCLFlBQVk7Q0FDWixZQUFZO0VBQUM7RUFBUTtFQUFRO0VBQVE7RUFBUTtFQUFRO0VBQVM7Q0FBTTtDQUNwRSxXQUFXO0VBQUM7RUFBbUI7RUFBYTtFQUFjO0VBQWU7Q0FBVztDQUNwRixNQUFNLE9BQU87RUFDVCxRQUFRLE1BQU0sT0FBTywyQkFBQSxDQUFtQjtDQUM1QztBQUNKOztBQ1BBLElBQWEsbUJBQW1CO0NBQzVCLFlBQVk7Q0FDWixZQUFZO0VBQUM7RUFBUTtFQUFRO0NBQU07Q0FDbkMsV0FBVztFQUFDO0VBQWtCO0VBQWE7Q0FBWTtDQUN2RCxNQUFNLE9BQU87RUFDVCxRQUFRLE1BQU0sT0FBTyw0QkFBQSxDQUFvQjtDQUM3QztBQUNKOztBQ1BBLElBQWEsc0JBQXNCO0NBQy9CLFlBQVk7Q0FDWixZQUFZLENBQUMsT0FBTyxNQUFNO0NBQzFCLFdBQVcsQ0FBQyxlQUFlO0NBQzNCLE1BQU0sT0FBTztFQUNULFFBQVEsTUFBTSxPQUFPLCtCQUFBLENBQXVCO0NBQ2hEO0FBQ0o7O0FDa0JBLElBQU0sU0FBQSxHQUFRQyxlQUFBQSxRQUFBQSxDQUFVLCtCQUErQjtBQUN2RCxTQUFnQixxQkFBcUIsYUFBYTtDQUM5QyxNQUFNLE9BQU9DLFFBQWlCLFdBQVc7Q0FDekMsTUFBTSxPQUFPQyxNQUFjLEtBQUssSUFBSTtDQUNwQyxPQUFPO0VBQ0gsTUFBTSxLQUFLO0VBQ1gsU0FBUyxLQUFLO0VBQ2QsUUFBUSxLQUFLO0VBQ2IsWUFBWSxLQUFLO0NBQ3JCO0FBQ0o7QUFDQSxJQUFhLGdCQUFiLE1BQTJCO0NBQ3ZCLFVBQVUsQ0FBQztDQUNYLGNBQWM7RUFDVjtHQUNJO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDSixDQUFDLENBQUMsU0FBUSxXQUFVO0dBQ2hCLEtBQUssZUFBZSxNQUFNO0VBQzlCLENBQUM7Q0FDTDtDQUNBLGVBQWUsUUFBUTtFQUNuQixLQUFLLFFBQVEsS0FBSyxNQUFNO0NBQzVCO0NBQ0EsTUFBTSxNQUFNLFdBQVcsY0FBYyxPQUFPLENBQUMsR0FBRztFQUM1QyxNQUFNLGdCQUFnQix1QkFBdUIsSUFBSTtFQUNqRCxzQkFBc0IsSUFBSTtFQUMxQixtQkFBbUIsSUFBSTtFQUN2QixJQUFJLHdCQUF3QixTQUFTLEdBQUc7R0FDcEMsTUFBTSxrRUFBa0U7R0FDeEUsTUFBTSxxQkFBcUIsV0FBVyxJQUFJO0VBQzlDLE9BRUksTUFBTSw2RUFBNkU7RUFFdkYsSUFBSSxDQUFDLGNBQWM7R0FDZixNQUFNLHNCQUFNLElBQUksV0FBVyxJQUFJO0dBQy9CLElBQUksVUFBVSxTQUFTLFVBQ25CLGVBQWUsS0FBSyx5QkFBeUIsVUFBVSxTQUFTLFFBQVE7R0FFNUUsSUFBSSxDQUFDLGdCQUFnQixVQUFVLFNBQVMsTUFDcEMsZUFBZSxLQUFLLHVCQUF1QixVQUFVLFNBQVMsSUFBSTtHQUV0RSxJQUFJLENBQUMsY0FBYztJQUVmLE1BQU0sNEJBQTRCO0lBQ2xDLE1BQU0sVUFBVSxXQUFXLEtBQUssRUFBRSxXQUFXLEtBQUssQ0FBQztJQUNuRCxNQUFNLGNBQWMsTUFBTSxtQkFBbUIsS0FBSztLQUFFLHFCQUFxQjtLQUFJO0lBQWMsQ0FBQztJQUM1RixJQUFJLENBQUMsYUFBYSxNQUNkLE1BQU0sSUFBSSwrQkFBK0Isa0NBQWtDO0lBRS9FLE1BQU0sNkJBQTZCLFlBQVksS0FBSyxjQUFjLFlBQVksS0FBSztJQUNuRixlQUFlLEtBQUsseUJBQXlCLFlBQVksSUFBSTtJQUM3RCxJQUFJLENBQUMsY0FDRCxNQUFNLElBQUkseUJBQXlCLG9DQUFvQyxZQUFZLE1BQU07R0FFakc7RUFDSjtFQUVBLE1BQU0sV0FBVyxhQUFhLFdBQVcsV0FBVztFQUNwRCxNQUFNLFdBQVcsSUFBSSxrQkFBa0IsSUFBSTtFQUUzQyxNQUFNLFNBQVMsS0FBSSxPQURNLGFBQWEsS0FBSyxJQUNiLFVBQVUsV0FBVyxJQUFJO0VBQ3ZELE1BQU0sVUFBVSxhQUFhLFdBQVcsUUFBUTtFQUNoRCxNQUFNLE9BQU8sTUFBTTtFQUduQixJQUFJLFNBQVMsT0FBTyxVQUFVLFdBQVcsS0FBSyxTQUFTLE9BQU8sYUFBYSxNQUN2RSxTQUFTLGNBQWMscUJBQXFCLFNBQVMsTUFBTSxDQUFDO0VBRWhFLElBQUksU0FBUyxPQUFPLFdBQVc7R0FDM0IsSUFBSSxTQUFTLE9BQU8sYUFBYSxLQUFBLEdBQzdCLFNBQVMsVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLE9BQU8sVUFBVSxNQUFLLFVBQVMsTUFBTSxTQUFTLFVBQVUsS0FBSyxDQUFDO0dBRTVHLElBQUksU0FBUyxPQUFPLGFBQWEsS0FBQSxHQUM3QixTQUFTLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPLFVBQVUsTUFBSyxVQUFTLE1BQU0sU0FBUyxVQUFVLEtBQUssQ0FBQztFQUVoSDtFQUNBLHNCQUFzQixVQUFVLFVBQVUsU0FBUyxJQUFJO0VBQ3ZELE9BQU8sU0FBUyxpQkFBaUI7Q0FDckM7Ozs7O0NBS0EsdUJBQXVCLFVBQVU7RUFDN0IsSUFBSSxDQUFDLFVBQ0Q7RUFFSixNQUFNLFlBQVksYUFBYSxRQUFRLENBQUMsQ0FBQyxrQkFBa0IsS0FBSztFQUNoRSxPQUFPLEtBQUssUUFBUSxNQUFLLFdBQVUsT0FBTyxXQUFXLFFBQVEsU0FBUyxNQUFNLEVBQUU7Q0FDbEY7Q0FDQSx5QkFBeUIsaUJBQWlCO0VBQ3RDLElBQUk7RUFDSixJQUFJLENBQUMsaUJBQ0Q7RUFFSixJQUFJO0dBQ0EsT0FBTyxxQkFBcUIsZUFBZTtFQUMvQyxTQUNPLE1BQU07R0FDVCxNQUFNLDJDQUEyQyxpQkFBaUI7R0FDbEU7RUFDSjtFQUNBLE1BQU0sVUFBVSxLQUFLLFFBQVEsUUFBUSxJQUFJLE1BQU0sSUFBSSxLQUFLLFFBQVEsVUFBVSxDQUFDLElBQUksS0FBSztFQUNwRixPQUFPLEtBQUssUUFBUSxNQUFLLFdBQVUsT0FBTyxVQUFVLE1BQUssV0FBVSxPQUFPLFFBQVEsR0FBRyxLQUFLLEtBQUssR0FBRyxTQUFTLE1BQU0sRUFBRSxDQUFDO0NBQ3hIO0NBQ0Esd0JBQXdCO0VBQ3BCLE1BQU0sOEJBQWMsSUFBSSxJQUFJO0VBQzVCLEtBQUssUUFBUSxTQUFRLFdBQVU7R0FDM0IsT0FBTyxVQUFVLFNBQVEsYUFBWTtJQUNqQyxZQUFZLElBQUksUUFBUTtJQUN4QixZQUFZLElBQUksU0FBUyxRQUFRLEtBQUssS0FBSyxDQUFDO0dBQ2hELENBQUM7RUFDTCxDQUFDO0VBQ0QsT0FBTyxNQUFNLEtBQUssV0FBVztDQUNqQztBQUNKO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDekIsTUFBTSxJQUFJLE1BQU0sWUFBWSxHQUFHO0NBQy9CLE9BQU8sTUFBTSxLQUFLLEtBQUssTUFBTSxVQUFVLENBQUM7QUFDNUM7Ozs7Ozs7Ozs7OztBQzNJQSxlQUFzQixVQUFVLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDaEQsTUFBTSxZQUFZLFNBQVMsTUFBTSxvQkFBb0IsT0FBTyxDQUFDO0NBQzdELElBQUk7RUFDQSxPQUFPLE1BQU0sbUJBQW1CLFdBQVcsT0FBTztDQUN0RCxVQUNRO0VBQ0osTUFBTSxVQUFVLE1BQU07Q0FDMUI7QUFDSjs7Ozs7Ozs7QUFRQSxlQUFzQixlQUFlLFdBQVcsVUFBVSxVQUFVLENBQUMsR0FBRztDQUNwRSxNQUFNLFlBQVksY0FBYyxXQUFXLG9CQUFvQixTQUFTLE9BQU8sYUFBYSxXQUFXLEVBQUUsVUFBVSxTQUFTLElBQUksUUFBUSxDQUFDO0NBQ3pJLElBQUk7RUFDQSxPQUFPLE1BQU0sbUJBQW1CLFdBQVcsT0FBTztDQUN0RCxVQUNRO0VBQ0osTUFBTSxVQUFVLE1BQU07Q0FDMUI7QUFDSjs7Ozs7Ozs7O0FBU0EsZUFBc0IsWUFBWSxZQUFZLFVBQVUsVUFBVSxDQUFDLEdBQUc7Q0FFbEUsT0FBTyxtQkFEVyxXQUFXLFlBQVksb0JBQW9CLFNBQVMsT0FBTyxhQUFhLFdBQVcsRUFBRSxVQUFVLFNBQVMsSUFBSSxRQUFRLENBQ3BHLEdBQUcsT0FBTztBQUNoRDs7Ozs7OztBQU9BLFNBQWdCLG1CQUFtQixXQUFXLFNBQVM7Q0FFbkQsT0FBTyxJQURtQixjQUNQLENBQUMsQ0FBQyxNQUFNLFdBQVcsS0FBQSxHQUFXLE9BQU87QUFDNUQ7Ozs7OztBQU1BLFNBQWdCLFVBQVUsWUFBWTtDQUNsQyxNQUFNLE9BQU8sT0FBTyxPQUFPLElBQUk7Q0FDL0IsS0FBSyxNQUFNLEVBQUUsSUFBSSxXQUFXLFlBQ3hCLENBQUMsS0FBSyxRQUFRLENBQUMsRUFBQSxDQUFHLEtBQUssS0FBSztDQUVoQyxPQUFPO0FBQ1g7Ozs7OztBQU1BLFNBQWdCLGNBQWMsUUFBUTtDQUNsQyxPQUFPLFdBQVcsS0FBQSxJQUFZLElBQUksSUFBSSxLQUFLLE1BQU0sU0FBUyxDQUFDO0FBQy9EOzs7Ozs7QUFNQSxTQUFnQixZQUFZLFVBQVU7Q0FDbEMsT0FBUSxVQUFVLE1BQUssWUFBVyxRQUFRLFFBQVE7RUFBQztFQUFTO0VBQVM7Q0FBZSxDQUFDLENBQUMsU0FBUyxRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsS0FDdEgsV0FBVyxNQUNYO0FBQ1I7QUFDQSxlQUFzQixxQkFBcUIsV0FBVyxVQUFVLENBQUMsR0FBRztDQUNoRSxJQUFJLFlBQVksVUFBVSxTQUFTO0NBQ25DLElBQUksTUFBTSxlQUFlLFNBQVMsR0FBRztFQUNqQyxhQUFhO0VBQ2IsTUFBTSxZQUFZLE1BQU0sc0JBQXNCLFNBQVM7RUFDdkQsYUFBYTtDQUNqQjtDQUNBLFFBQVEsWUFBWSxNQUFNLFlBQVksb0JBQW9CLFdBQVcsU0FBUztBQUNsRjs7Ozs7QUFLQSxlQUFzQixVQUFVLFdBQVcsV0FBVyxDQUFDLEdBQUc7Q0FDdEQsTUFBTSxJQUFJLE1BQU0sMEZBQTBGO0FBQzlHOzs7OztBQUtBLGVBQXNCLFlBQVksU0FBUyxXQUFXLFdBQVcsQ0FBQyxHQUFHO0NBQ2pFLE1BQU0sSUFBSSxNQUFNLHNDQUFzQztBQUMxRDs7OztBQUlBLFNBQWdCLHdCQUF3QjtDQUNwQyxPQUFPLElBQUksY0FBYyxDQUFDLENBQUMsc0JBQXNCO0FBQ3JEIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMThdfQ==