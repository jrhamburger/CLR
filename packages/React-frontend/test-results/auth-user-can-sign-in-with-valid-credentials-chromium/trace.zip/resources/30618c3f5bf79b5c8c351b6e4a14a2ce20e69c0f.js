import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=987d57e9";
import { A as UINT16_LE, B as require_browser, G as EndOfStreamError, H as textEncode, O as StringType, P as UINT32_LE, R as Uint8ArrayType, V as textDecode, W as AbortError, _ as makeUnexpectedFileContentError, c as readBuffer, f as FieldDecodingError, o as getMaxMetadataEntries, p as InternalParserError, s as getTokenizerOptions, t as BasicParser } from "/node_modules/.vite/deps/BasicParser-CAIs-t7m.js?v=987d57e9";
import { i as findZero, t as a2hex } from "/node_modules/.vite/deps/Util-DYMxorDw.js?v=987d57e9";
// node_modules/strtok3/lib/AbortSignal.js
/** Reject an already-cancelled operation before acquiring tokenizer resources. */
function throwIfAborted(signal) {
	if (signal?.aborted) throw new AbortError();
}
// node_modules/strtok3/lib/BufferSizeError.js
/** Thrown before a dynamically sized tokenizer buffer exceeds its configured limit. */
var BufferSizeError = class extends RangeError {
	/**
	* Create an error describing an allocation that exceeds the configured limit.
	* @param requestedSize - Requested buffer size in bytes
	* @param maxBufferSize - Configured maximum buffer size in bytes
	*/
	constructor(requestedSize, maxBufferSize) {
		super(`Requested buffer size ${requestedSize} exceeds maxBufferSize ${maxBufferSize}`);
		this.requestedSize = requestedSize;
		this.maxBufferSize = maxBufferSize;
		this.name = "BufferSizeError";
	}
};
/**
* Validate options before acquiring file handles or stream readers.
* @param options - Tokenizer options containing the optional allocation limit
* @returns Configured buffer limit in bytes, or Infinity when the limit is disabled
* @throws RangeError if maxBufferSize is neither a positive safe integer nor Infinity
*/
function getMaxBufferSize(options) {
	const limit = options?.maxBufferSize ?? Number.POSITIVE_INFINITY;
	if (limit !== Number.POSITIVE_INFINITY && (!Number.isSafeInteger(limit) || limit <= 0)) throw new RangeError("maxBufferSize must be a positive safe integer or Infinity");
	return limit;
}
// node_modules/strtok3/lib/stream/AbstractStreamReader.js
var AbstractStreamReader = class {
	constructor() {
		this.endOfStream = false;
		this.interrupted = false;
		/**
		* Store peeked data
		* @type {Array}
		*/
		this.peekQueue = [];
	}
	async peek(uint8Array, mayBeLess = false) {
		const bytesRead = await this.read(uint8Array, mayBeLess);
		this.peekQueue.push(uint8Array.subarray(0, bytesRead));
		return bytesRead;
	}
	async read(buffer, mayBeLess = false) {
		if (buffer.length === 0) return 0;
		let bytesRead = this.readFromPeekBuffer(buffer);
		if (!this.endOfStream) bytesRead += await this.readRemainderFromStream(buffer.subarray(bytesRead), mayBeLess);
		if (bytesRead === 0 && !mayBeLess) throw new EndOfStreamError();
		return bytesRead;
	}
	/**
	* Read chunk from stream
	* @param buffer - Target Uint8Array (or Buffer) to store data read from stream in
	* @returns Number of bytes read
	*/
	readFromPeekBuffer(buffer) {
		let remaining = buffer.length;
		let bytesRead = 0;
		while (this.peekQueue.length > 0 && remaining > 0) {
			const peekData = this.peekQueue.pop();
			if (!peekData) throw new Error("peekData should be defined");
			const lenCopy = Math.min(peekData.length, remaining);
			buffer.set(peekData.subarray(0, lenCopy), bytesRead);
			bytesRead += lenCopy;
			remaining -= lenCopy;
			if (lenCopy < peekData.length) this.peekQueue.push(peekData.subarray(lenCopy));
		}
		return bytesRead;
	}
	async readRemainderFromStream(buffer, mayBeLess) {
		let bytesRead = 0;
		while (bytesRead < buffer.length && !this.endOfStream) {
			if (this.interrupted) throw new AbortError();
			const chunkLen = await this.readFromStream(buffer.subarray(bytesRead), mayBeLess);
			if (chunkLen === 0) break;
			bytesRead += chunkLen;
		}
		if (!mayBeLess && bytesRead < buffer.length) throw new EndOfStreamError();
		return bytesRead;
	}
};
// node_modules/strtok3/lib/stream/WebStreamReader.js
var WebStreamReader = class extends AbstractStreamReader {
	constructor(reader) {
		super();
		this.reader = reader;
	}
	async abort() {
		return this.close();
	}
	async close() {
		this.reader.releaseLock();
	}
};
// node_modules/strtok3/lib/stream/WebStreamByobReader.js
/**
* Read from a WebStream using a BYOB reader
* Reference: https://nodejs.org/api/webstreams.html#class-readablestreambyobreader
*/
var WebStreamByobReader = class extends WebStreamReader {
	/**
	* Read from stream
	* @param buffer - Target Uint8Array (or Buffer) to store data read from stream in
	* @param mayBeLess - If true, may fill the buffer partially
	* @protected Bytes read
	*/
	async readFromStream(buffer, mayBeLess) {
		if (buffer.length === 0) return 0;
		const result = await this.reader.read(new Uint8Array(buffer.length), { min: mayBeLess ? void 0 : buffer.length });
		if (result.done) this.endOfStream = result.done;
		if (result.value) {
			buffer.set(result.value);
			return result.value.length;
		}
		return 0;
	}
};
// node_modules/strtok3/lib/stream/WebStreamDefaultReader.js
var WebStreamDefaultReader = class extends AbstractStreamReader {
	constructor(reader) {
		super();
		this.reader = reader;
		this.buffer = null;
	}
	/**
	* Copy chunk to target, and store the remainder in this.buffer
	*/
	writeChunk(target, chunk) {
		const written = Math.min(chunk.length, target.length);
		target.set(chunk.subarray(0, written));
		if (written < chunk.length) this.buffer = chunk.subarray(written);
		else this.buffer = null;
		return written;
	}
	/**
	* Read from stream
	* @param buffer - Target Uint8Array (or Buffer) to store data read from stream in
	* @param mayBeLess - If true, may fill the buffer partially
	* @protected Bytes read
	*/
	async readFromStream(buffer, mayBeLess) {
		if (buffer.length === 0) return 0;
		let totalBytesRead = 0;
		if (this.buffer) totalBytesRead += this.writeChunk(buffer, this.buffer);
		while (totalBytesRead < buffer.length && !this.endOfStream) {
			const result = await this.reader.read();
			if (result.done) {
				this.endOfStream = true;
				break;
			}
			if (result.value) totalBytesRead += this.writeChunk(buffer.subarray(totalBytesRead), result.value);
		}
		if (!mayBeLess && totalBytesRead === 0 && this.endOfStream) throw new EndOfStreamError();
		return totalBytesRead;
	}
	abort() {
		this.interrupted = true;
		return this.reader.cancel();
	}
	async close() {
		try {
			await this.abort();
		} finally {
			this.reader.releaseLock();
		}
	}
};
// node_modules/strtok3/lib/stream/WebStreamReaderFactory.js
function makeWebStreamReader(stream) {
	try {
		const reader = stream.getReader({ mode: "byob" });
		if (reader instanceof ReadableStreamDefaultReader) return new WebStreamDefaultReader(reader);
		return new WebStreamByobReader(reader);
	} catch (error) {
		if (error instanceof TypeError) return new WebStreamDefaultReader(stream.getReader());
		throw error;
	}
}
// node_modules/strtok3/lib/AbstractTokenizer.js
/**
* Core tokenizer
*/
var AbstractTokenizer = class {
	/**
	* Constructor
	* @param options Tokenizer options
	* @protected
	*/
	constructor(options) {
		this.numBuffer = /* @__PURE__ */ new Uint8Array(10);
		/**
		* Tokenizer-stream position
		*/
		this.position = 0;
		this.maxBufferSize = getMaxBufferSize(options);
		throwIfAborted(options?.abortSignal);
		this.onClose = options?.onClose;
		if (options?.abortSignal) this.addAbortListener(options.abortSignal, () => {
			this.abort().catch(() => {});
		});
	}
	addAbortListener(signal, listener) {
		this.abortSignal = signal;
		this.abortListener = listener;
		signal.addEventListener("abort", listener, { once: true });
	}
	removeAbortListener() {
		if (this.abortListener) this.abortSignal?.removeEventListener("abort", this.abortListener);
		this.abortSignal = void 0;
		this.abortListener = void 0;
	}
	/**
	* Read a token from the tokenizer-stream
	* @param token - The token to read
	* @param position - If provided, the desired position in the tokenizer-stream
	* @returns Promise with token data
	*/
	async readToken(token, position = this.position) {
		this.validateTokenRead(token.len, position);
		const uint8Array = new Uint8Array(token.len);
		if (await this.readBuffer(uint8Array, { position }) < token.len) throw new EndOfStreamError();
		return token.get(uint8Array, 0);
	}
	/**
	* Peek a token from the tokenizer-stream.
	* @param token - Token to peek from the tokenizer-stream.
	* @param position - Offset where to begin reading within the file. If position is null, data will be read from the current file position.
	* @returns Promise with token data
	*/
	async peekToken(token, position = this.position) {
		const peekPosition = position ?? this.position;
		this.validateTokenRead(token.len, peekPosition, true);
		const uint8Array = new Uint8Array(token.len);
		if (await this.peekBuffer(uint8Array, { position: peekPosition }) < token.len) throw new EndOfStreamError();
		return token.get(uint8Array, 0);
	}
	/**
	* Read a numeric token from the stream
	* @param token - Numeric token
	* @returns Promise with number
	*/
	async readNumber(token) {
		if (await this.readBuffer(this.numBuffer, { length: token.len }) < token.len) throw new EndOfStreamError();
		return token.get(this.numBuffer, 0);
	}
	/**
	* Read a numeric token from the stream
	* @param token - Numeric token
	* @returns Promise with number
	*/
	async peekNumber(token) {
		if (await this.peekBuffer(this.numBuffer, { length: token.len }) < token.len) throw new EndOfStreamError();
		return token.get(this.numBuffer, 0);
	}
	/**
	* Ignore number of bytes, advances the pointer in under tokenizer-stream.
	* @param length - Number of bytes to ignore.  Must be ≥ 0.
	* @return resolves the number of bytes ignored, equals length if this available, otherwise the number of bytes available
	*/
	async ignore(length) {
		if (length < 0) throw new RangeError("ignore length must be ≥ 0 bytes");
		this.validateLength(length, "ignore length");
		this.validateLength(this.position + length, "end position");
		if (this.fileInfo.size !== void 0) {
			const bytesLeft = Math.max(0, this.fileInfo.size - this.position);
			if (length > bytesLeft) {
				this.position += bytesLeft;
				return bytesLeft;
			}
		}
		this.position += length;
		return length;
	}
	close() {
		if (!this.closePromise) {
			this.removeAbortListener();
			this.closePromise = Promise.resolve().then(() => this.closeOnce());
		}
		return this.closePromise;
	}
	/** Perform cleanup once, sharing completion and the first error across close calls. */
	async closeOnce() {
		await this.abort();
		await this.onClose?.();
	}
	/**
	* Validate a byte length or position before using it in buffer calculations.
	* @param value - Value that must be a non-negative safe integer
	* @param name - Label used in the validation error
	* @throws RangeError if the value is negative or not a safe integer
	*/
	validateLength(value, name) {
		if (!Number.isSafeInteger(value) || value < 0) throw new RangeError(`${name} must be a non-negative safe integer`);
	}
	/**
	* Validate a requested buffer size against the configured allocation limit.
	* @param length - Requested buffer size in bytes
	* @throws RangeError if the length is negative or not a safe integer
	* @throws BufferSizeError if the length exceeds maxBufferSize
	*/
	validateBufferSize(length) {
		this.validateLength(length, "buffer length");
		if (length > this.maxBufferSize) throw new BufferSizeError(length, this.maxBufferSize);
	}
	/**
	* Validate a token request before allocating a buffer or consuming input.
	* @param length - Token length in bytes
	* @param position - Byte offset where the token starts
	* @param peek - Whether to include skipped stream bytes in the lookahead limit
	* @throws RangeError if a length or position is negative or not a safe integer
	* @throws BufferSizeError if the token buffer or stream lookahead exceeds maxBufferSize
	* @throws Error if a stream request starts before the current position
	* @throws EndOfStreamError if the token extends beyond the known input size
	*/
	validateTokenRead(length, position, peek = false) {
		this.validateBufferSize(length);
		this.validateLength(position, "position");
		this.validateLength(position + length, "end position");
		if (!this.supportsRandomAccess() && position < this.position) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
		if (peek && !this.supportsRandomAccess()) this.validateBufferSize(length + position - this.position);
		if (this.fileInfo.size !== void 0 && length > this.fileInfo.size - position) throw new EndOfStreamError();
	}
	/**
	* Apply defaults and validate buffer read or peek options.
	* @param uint8Array - Target buffer whose length is the default read length
	* @param options - Requested length, position and partial-read behavior
	* @returns Validated options with an explicit length, position and mayBeLess flag
	* @throws RangeError if a length or position is invalid, or the length exceeds the target buffer
	* @throws Error if a stream request starts before the current position
	*/
	normalizeOptions(uint8Array, options) {
		const length = options?.length ?? uint8Array.length;
		const position = options?.position ?? this.position;
		this.validateLength(length, "length");
		this.validateLength(position, "position");
		this.validateLength(position + length, "end position");
		if (length > uint8Array.length) throw new RangeError("length must not exceed the target buffer length");
		if (!this.supportsRandomAccess() && position < this.position) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
		return {
			length,
			position,
			mayBeLess: options?.mayBeLess ?? false
		};
	}
	abort() {
		this.removeAbortListener();
		return Promise.resolve();
	}
};
// node_modules/strtok3/lib/BlobTokenizer.js
var BlobTokenizer = class extends AbstractTokenizer {
	/**
	* Construct BufferTokenizer
	* @param blob - Uint8Array to tokenize
	* @param options Tokenizer options
	*/
	constructor(blob, options) {
		super(options);
		this.blob = blob;
		this.fileInfo = {
			...options?.fileInfo ?? {},
			size: blob.size,
			mimeType: blob.type
		};
	}
	/**
	* Read buffer from tokenizer
	* @param uint8Array - Uint8Array to tokenize
	* @param options - Read behaviour options
	* @returns {Promise<number>}
	*/
	async readBuffer(uint8Array, options) {
		const normOptions = this.normalizeOptions(uint8Array, options);
		const bytesRead = await this.peekBuffer(uint8Array, normOptions);
		this.position = normOptions.position + bytesRead;
		return bytesRead;
	}
	/**
	* Peek (read ahead) buffer from tokenizer
	* @param buffer
	* @param options - Read behaviour options
	* @returns {Promise<number>}
	*/
	async peekBuffer(buffer, options) {
		const normOptions = this.normalizeOptions(buffer, options);
		const bytes2read = Math.max(0, Math.min(this.blob.size - normOptions.position, normOptions.length));
		if (!normOptions.mayBeLess && bytes2read < normOptions.length) throw new EndOfStreamError();
		for (let offset = 0; offset < bytes2read;) {
			const chunkLength = Math.min(this.maxBufferSize, bytes2read - offset);
			const position = normOptions.position + offset;
			const arrayBuffer = await this.blob.slice(position, position + chunkLength).arrayBuffer();
			buffer.set(new Uint8Array(arrayBuffer), offset);
			offset += chunkLength;
		}
		return bytes2read;
	}
	close() {
		return super.close();
	}
	supportsRandomAccess() {
		return true;
	}
	setPosition(position) {
		this.validateLength(position, "position");
		this.position = position;
	}
};
// node_modules/strtok3/lib/BufferTokenizer.js
var BufferTokenizer = class extends AbstractTokenizer {
	/**
	* Construct BufferTokenizer
	* @param uint8Array - Uint8Array to tokenize
	* @param options Tokenizer options
	*/
	constructor(uint8Array, options) {
		super(options);
		this.uint8Array = uint8Array;
		this.fileInfo = {
			...options?.fileInfo ?? {},
			size: uint8Array.length
		};
	}
	/**
	* Read buffer from tokenizer
	* @param uint8Array - Uint8Array to tokenize
	* @param options - Read behaviour options
	* @returns {Promise<number>}
	*/
	async readBuffer(uint8Array, options) {
		const normOptions = this.normalizeOptions(uint8Array, options);
		const bytesRead = await this.peekBuffer(uint8Array, normOptions);
		this.position = normOptions.position + bytesRead;
		return bytesRead;
	}
	/**
	* Peek (read ahead) buffer from tokenizer
	* @param uint8Array
	* @param options - Read behaviour options
	* @returns {Promise<number>}
	*/
	async peekBuffer(uint8Array, options) {
		const normOptions = this.normalizeOptions(uint8Array, options);
		const bytes2read = Math.max(0, Math.min(this.uint8Array.length - normOptions.position, normOptions.length));
		if (!normOptions.mayBeLess && bytes2read < normOptions.length) throw new EndOfStreamError();
		uint8Array.set(this.uint8Array.subarray(normOptions.position, normOptions.position + bytes2read));
		return bytes2read;
	}
	close() {
		return super.close();
	}
	supportsRandomAccess() {
		return true;
	}
	setPosition(position) {
		this.validateLength(position, "position");
		this.position = position;
	}
};
// node_modules/strtok3/lib/ReadStreamTokenizer.js
var ignoreChunkSize = 256e3;
var ReadStreamTokenizer = class extends AbstractTokenizer {
	/**
	* Constructor
	* @param streamReader stream-reader to read from
	* @param options Tokenizer options
	*/
	constructor(streamReader, options) {
		super(options);
		this.streamReader = streamReader;
		this.fileInfo = options?.fileInfo ?? {};
	}
	/**
	* Read buffer from tokenizer
	* @param uint8Array - Target Uint8Array to fill with data read from the tokenizer-stream
	* @param options - Read behaviour options
	* @returns Promise with number of bytes read
	*/
	async readBuffer(uint8Array, options) {
		const normOptions = this.normalizeOptions(uint8Array, options);
		const skipBytes = normOptions.position - this.position;
		if (skipBytes > 0) {
			await this.ignore(skipBytes);
			return this.readBuffer(uint8Array, options);
		}
		if (skipBytes < 0) throw new Error("`options.position` must be equal or greater than `tokenizer.position`");
		if (normOptions.length === 0) return 0;
		let bytesRead = 0;
		while (bytesRead < normOptions.length) {
			const chunkLength = Math.min(this.maxBufferSize, normOptions.length - bytesRead);
			const count = await this.streamReader.read(uint8Array.subarray(bytesRead, bytesRead + chunkLength), true);
			bytesRead += count;
			this.position += count;
			if (count < chunkLength) break;
		}
		if (!normOptions.mayBeLess && bytesRead < normOptions.length) throw new EndOfStreamError();
		return bytesRead;
	}
	/**
	* Peek (read ahead) buffer from tokenizer
	* @param uint8Array - Uint8Array (or Buffer) to write data to
	* @param options - Read behaviour options
	* @returns Promise with number of bytes peeked
	*/
	async peekBuffer(uint8Array, options) {
		const normOptions = this.normalizeOptions(uint8Array, options);
		if (normOptions.length === 0) return 0;
		if (this.fileInfo.size !== void 0 && normOptions.position >= this.fileInfo.size) {
			if (normOptions.mayBeLess) return 0;
			throw new EndOfStreamError();
		}
		const lookaheadSize = normOptions.length + normOptions.position - this.position;
		this.validateBufferSize(lookaheadSize);
		let bytesRead = 0;
		if (normOptions.position) {
			const skipBytes = normOptions.position - this.position;
			if (skipBytes > 0) {
				const skipBuffer = new Uint8Array(normOptions.length + skipBytes);
				bytesRead = await this.peekBuffer(skipBuffer, { mayBeLess: normOptions.mayBeLess });
				const bytesPeeked = Math.max(0, bytesRead - skipBytes);
				uint8Array.set(skipBuffer.subarray(skipBytes, skipBytes + bytesPeeked));
				return bytesPeeked;
			}
			if (skipBytes < 0) throw new Error("Cannot peek from a negative offset in a stream");
		}
		if (normOptions.length > 0) {
			try {
				const peekBuffer = new Uint8Array(normOptions.length);
				bytesRead = await this.streamReader.peek(peekBuffer, true);
				uint8Array.set(peekBuffer.subarray(0, bytesRead));
			} catch (err) {
				if (options?.mayBeLess && err instanceof EndOfStreamError) return 0;
				throw err;
			}
			if (!normOptions.mayBeLess && bytesRead < normOptions.length) throw new EndOfStreamError();
		}
		return bytesRead;
	}
	/**
	* @param length Number of bytes to ignore. Must be ≥ 0.
	*/
	async ignore(length) {
		if (length < 0) throw new RangeError("ignore length must be ≥ 0 bytes");
		this.validateLength(length, "ignore length");
		this.validateLength(this.position + length, "end position");
		if (length > 0 && this.fileInfo.size !== void 0 && length > this.fileInfo.size - this.position) throw new EndOfStreamError();
		const bufSize = Math.min(ignoreChunkSize, this.maxBufferSize, length);
		const buf = new Uint8Array(bufSize);
		let totBytesRead = 0;
		while (totBytesRead < length) {
			const remaining = length - totBytesRead;
			const bytesRead = await this.readBuffer(buf, { length: Math.min(bufSize, remaining) });
			if (bytesRead < 0) return bytesRead;
			totBytesRead += bytesRead;
		}
		return totBytesRead;
	}
	abort() {
		this.removeAbortListener();
		return this.streamReader.abort();
	}
	async close() {
		this.removeAbortListener();
		return this.streamReader.close();
	}
	supportsRandomAccess() {
		return false;
	}
};
// node_modules/strtok3/lib/core.js
/**
* Construct ReadStreamTokenizer from given ReadableStream (WebStream API).
* Will set fileSize, if provided given Stream has set the .path property/
* @param webStream - Read from Node.js Stream.Readable (must be a byte stream)
* @param options - Tokenizer options
* @returns ReadStreamTokenizer
*/
function fromWebStream(webStream, options) {
	getMaxBufferSize(options);
	throwIfAborted(options?.abortSignal);
	return new ReadStreamTokenizer(makeWebStreamReader(webStream), options);
}
/**
* Construct ReadStreamTokenizer from given Buffer.
* @param uint8Array - Uint8Array to tokenize
* @param options - Tokenizer options
* @returns BufferTokenizer
*/
function fromBuffer(uint8Array, options) {
	return new BufferTokenizer(uint8Array, options);
}
/**
* Construct ReadStreamTokenizer from given Blob.
* @param blob - Uint8Array to tokenize
* @param options - Tokenizer options
* @returns BufferTokenizer
*/
function fromBlob(blob, options) {
	return new BlobTokenizer(blob, options);
}
// node_modules/music-metadata/lib/common/FourCC.js
var import_browser = /* @__PURE__ */ __toESM(require_browser(), 1);
var validFourCC = /^[\x21-\x7e©][\x20-\x7e\x00()]{3}/;
/**
* Token for read FourCC
* Ref: https://en.wikipedia.org/wiki/FourCC
*/
var FourCcToken = {
	len: 4,
	get: (buf, off) => {
		const id = textDecode(buf.subarray(off, off + FourCcToken.len), "latin1");
		if (!id.match(validFourCC)) throw new FieldDecodingError(`FourCC contains invalid characters: ${a2hex(id)} "${id}"`);
		return id;
	},
	put: (buffer, offset, id) => {
		const str = textEncode(id, "latin1");
		if (str.length !== 4) throw new InternalParserError("Invalid length");
		buffer.set(str, offset);
		return offset + 4;
	}
};
// node_modules/music-metadata/lib/apev2/APEv2Token.js
var DataType = {
	text_utf8: 0,
	binary: 1,
	external_info: 2,
	reserved: 3
};
/**
* APE_DESCRIPTOR: defines the sizes (and offsets) of all the pieces, as well as the MD5 checksum
*/
var DescriptorParser = {
	len: 52,
	get: (buf, off) => {
		return {
			ID: FourCcToken.get(buf, off),
			version: UINT32_LE.get(buf, off + 4) / 1e3,
			descriptorBytes: UINT32_LE.get(buf, off + 8),
			headerBytes: UINT32_LE.get(buf, off + 12),
			seekTableBytes: UINT32_LE.get(buf, off + 16),
			headerDataBytes: UINT32_LE.get(buf, off + 20),
			apeFrameDataBytes: UINT32_LE.get(buf, off + 24),
			apeFrameDataBytesHigh: UINT32_LE.get(buf, off + 28),
			terminatingDataBytes: UINT32_LE.get(buf, off + 32),
			fileMD5: new Uint8ArrayType(16).get(buf, off + 36)
		};
	}
};
/**
* APE_HEADER: describes all of the necessary information about the APE file
*/
var Header = {
	len: 24,
	get: (buf, off) => {
		return {
			compressionLevel: UINT16_LE.get(buf, off),
			formatFlags: UINT16_LE.get(buf, off + 2),
			blocksPerFrame: UINT32_LE.get(buf, off + 4),
			finalFrameBlocks: UINT32_LE.get(buf, off + 8),
			totalFrames: UINT32_LE.get(buf, off + 12),
			bitsPerSample: UINT16_LE.get(buf, off + 16),
			channel: UINT16_LE.get(buf, off + 18),
			sampleRate: UINT32_LE.get(buf, off + 20)
		};
	}
};
/**
* APE Tag Header/Footer Version 2.0
* TAG: describes all the properties of the file [optional]
*/
var TagFooter = {
	len: 32,
	get: (buf, off) => {
		return {
			ID: new StringType(8, "ascii").get(buf, off),
			version: UINT32_LE.get(buf, off + 8),
			size: UINT32_LE.get(buf, off + 12),
			fields: UINT32_LE.get(buf, off + 16),
			flags: parseTagFlags(UINT32_LE.get(buf, off + 20))
		};
	}
};
/**
* APE Tag v2.0 Item Header
*/
var TagItemHeader = {
	len: 8,
	get: (buf, off) => {
		return {
			size: UINT32_LE.get(buf, off),
			flags: parseTagFlags(UINT32_LE.get(buf, off + 4))
		};
	}
};
function parseTagFlags(flags) {
	return {
		containsHeader: isBitSet(flags, 31),
		containsFooter: isBitSet(flags, 30),
		isHeader: isBitSet(flags, 29),
		readOnly: isBitSet(flags, 0),
		dataType: (flags & 6) >> 1
	};
}
/**
* @param num {number}
* @param bit 0 is least significant bit (LSB)
* @return {boolean} true if bit is 1; otherwise false
*/
function isBitSet(num, bit) {
	return (num & 1 << bit) !== 0;
}
// node_modules/music-metadata/lib/apev2/APEv2Parser.js
var APEv2Parser_exports = /* @__PURE__ */ __exportAll({ APEv2Parser: () => APEv2Parser });
var debug = (0, import_browser.default)("music-metadata:parser:APEv2");
var tagFormat = "APEv2";
var preamble = "APETAGEX";
var ApeContentError = class extends makeUnexpectedFileContentError("APEv2") {};
function tryParseApeHeader(metadata, tokenizer, options) {
	return new APEv2Parser(metadata, tokenizer, options).tryParseApeHeader();
}
var APEv2Parser = class APEv2Parser extends BasicParser {
	/**
	* Calculate the media file duration
	* @param ah ApeHeader
	* @return {number} duration in seconds
	*/
	static calculateDuration(ah) {
		let duration = ah.totalFrames > 1 ? ah.blocksPerFrame * (ah.totalFrames - 1) : 0;
		duration += ah.finalFrameBlocks;
		return duration / ah.sampleRate;
	}
	/**
	* Calculates the APEv1 / APEv2 first field offset
	* @param tokenizer
	* @param offset
	*/
	static async findApeFooterOffset(tokenizer, offset) {
		const apeBuf = new Uint8Array(TagFooter.len);
		const position = tokenizer.position;
		if (offset <= TagFooter.len) {
			debug(`Offset is too small to read APE footer: offset=${offset}`);
			return;
		}
		if (offset > TagFooter.len) {
			await tokenizer.readBuffer(apeBuf, { position: offset - TagFooter.len });
			tokenizer.setPosition(position);
			const tagFooter = TagFooter.get(apeBuf, 0);
			if (tagFooter.ID === "APETAGEX") {
				if (tagFooter.flags.isHeader) debug(`APE Header found at offset=${offset - TagFooter.len}`);
				else {
					debug(`APE Footer found at offset=${offset - TagFooter.len}`);
					offset -= tagFooter.size;
				}
				return {
					footer: tagFooter,
					offset
				};
			}
		}
	}
	static parseTagFooter(metadata, buffer, options) {
		const footer = TagFooter.get(buffer, buffer.length - TagFooter.len);
		if (footer.ID !== preamble) throw new ApeContentError("Unexpected APEv2 Footer ID preamble value");
		return new APEv2Parser(metadata, fromBuffer(buffer, getTokenizerOptions(options)), options).parseTags(footer);
	}
	ape = {};
	/**
	* Parse APEv1 / APEv2 header if header signature found
	*/
	async tryParseApeHeader() {
		if (this.tokenizer.fileInfo.size && this.tokenizer.fileInfo.size - this.tokenizer.position < TagFooter.len) {
			debug("No APEv2 header found, end-of-file reached");
			return;
		}
		const footer = await this.tokenizer.peekToken(TagFooter);
		if (footer.ID === preamble) {
			await this.tokenizer.ignore(TagFooter.len);
			return this.parseTags(footer);
		}
		debug(`APEv2 header not found at offset=${this.tokenizer.position}`);
		if (this.tokenizer.fileInfo.size) {
			const remaining = this.tokenizer.fileInfo.size - this.tokenizer.position;
			const buffer = await this.readTagValue(remaining);
			return APEv2Parser.parseTagFooter(this.metadata, buffer, this.options);
		}
	}
	async parse() {
		const descriptor = await this.tokenizer.readToken(DescriptorParser);
		if (descriptor.ID !== "MAC ") throw new ApeContentError("Unexpected descriptor ID");
		this.ape.descriptor = descriptor;
		const lenExp = descriptor.descriptorBytes - DescriptorParser.len;
		const header = await (lenExp > 0 ? this.parseDescriptorExpansion(lenExp) : this.parseHeader());
		this.metadata.setAudioOnly();
		await this.tokenizer.ignore(header.forwardBytes);
		return this.tryParseApeHeader();
	}
	async parseTags(footer) {
		if (footer.fields > getMaxMetadataEntries(this.options)) throw new ApeContentError(`Tag item count ${footer.fields} exceeds entry limit ${getMaxMetadataEntries(this.options)}`);
		const keyBuffer = /* @__PURE__ */ new Uint8Array(256);
		let bytesRemaining = footer.size - TagFooter.len;
		debug(`Parse APE tags at offset=${this.tokenizer.position}, size=${bytesRemaining}`);
		for (let i = 0; i < footer.fields; i++) {
			if (bytesRemaining < TagItemHeader.len) {
				this.metadata.addWarning(`APEv2 Tag-header: ${footer.fields - i} items remaining, but no more tag data to read.`);
				break;
			}
			const tagItemHeader = await this.tokenizer.readToken(TagItemHeader);
			bytesRemaining -= TagItemHeader.len;
			if (tagItemHeader.size >= bytesRemaining) throw new ApeContentError(`Invalid tag item size: ${tagItemHeader.size}`);
			const keyBytes = await this.tokenizer.peekBuffer(keyBuffer, {
				length: Math.min(keyBuffer.length, bytesRemaining - tagItemHeader.size),
				mayBeLess: true
			});
			let zero = keyBuffer.subarray(0, keyBytes).indexOf(0);
			if (zero === -1) throw new ApeContentError("Unterminated tag item key");
			const key = await this.tokenizer.readToken(new StringType(zero, "ascii"));
			await this.tokenizer.ignore(1);
			bytesRemaining -= key.length + 1;
			if (this.tokenizer.fileInfo.size !== void 0 && tagItemHeader.size > this.tokenizer.fileInfo.size - this.tokenizer.position) throw new ApeContentError(`Invalid tag item size: ${tagItemHeader.size}`);
			bytesRemaining -= tagItemHeader.size;
			switch (tagItemHeader.flags.dataType) {
				case DataType.text_utf8: {
					const value = textDecode(await this.readTagValue(tagItemHeader.size), "utf-8");
					let valueCount = 1;
					for (let offset = value.indexOf("\0"); offset >= 0; offset = value.indexOf("\0", offset + 1)) ++valueCount;
					if (valueCount > getMaxMetadataEntries(this.options)) throw new ApeContentError(`Text value count ${valueCount} exceeds entry limit ${getMaxMetadataEntries(this.options)}`);
					const values = value.split(/\x00/g);
					await Promise.all(values.map((val) => this.metadata.addTag(tagFormat, key, val)));
					break;
				}
				case DataType.binary:
					if (this.options.skipCovers) await this.tokenizer.ignore(tagItemHeader.size);
					else {
						const picData = await this.readTagValue(tagItemHeader.size);
						zero = findZero(picData);
						const description = textDecode(picData.subarray(0, zero), "utf-8");
						const data = picData.subarray(zero + 1);
						await this.metadata.addTag(tagFormat, key, {
							description,
							data
						});
					}
					break;
				case DataType.external_info:
					debug(`Ignore external info ${key}`);
					await this.tokenizer.ignore(tagItemHeader.size);
					break;
				case DataType.reserved:
					debug(`Ignore external info ${key}`);
					this.metadata.addWarning(`APEv2 header declares a reserved datatype for "${key}"`);
					await this.tokenizer.ignore(tagItemHeader.size);
			}
		}
	}
	async readTagValue(size) {
		return readBuffer(this.tokenizer, size, this.options, void 0, (message) => new ApeContentError(message));
	}
	async parseDescriptorExpansion(lenExp) {
		await this.tokenizer.ignore(lenExp);
		return this.parseHeader();
	}
	async parseHeader() {
		const header = await this.tokenizer.readToken(Header);
		this.metadata.setFormat("lossless", true);
		this.metadata.setFormat("container", "Monkey's Audio");
		this.metadata.setFormat("codec", "Monkey's Audio");
		this.metadata.setFormat("bitsPerSample", header.bitsPerSample);
		this.metadata.setFormat("sampleRate", header.sampleRate);
		this.metadata.setFormat("numberOfChannels", header.channel);
		this.metadata.setFormat("duration", APEv2Parser.calculateDuration(header));
		if (!this.ape.descriptor) throw new ApeContentError("Missing APE descriptor");
		return { forwardBytes: this.ape.descriptor.seekTableBytes + this.ape.descriptor.headerDataBytes + this.ape.descriptor.apeFrameDataBytes + this.ape.descriptor.terminatingDataBytes };
	}
};
export { fromBlob as a, FourCcToken as i, APEv2Parser_exports as n, fromBuffer as o, tryParseApeHeader as r, fromWebStream as s, APEv2Parser as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQVBFdjJQYXJzZXItQldENkRjbV8uanMiLCJuYW1lcyI6WyJ1dGlsLmEyaGV4IiwiVG9rZW4uVWludDhBcnJheVR5cGUiLCJUb2tlbi5TdHJpbmdUeXBlIiwiaW5pdERlYnVnIiwic3RydG9rMy5mcm9tQnVmZmVyIiwidXRpbC5maW5kWmVybyJdLCJzb3VyY2VzIjpbIi4uLy4uL3N0cnRvazMvbGliL0Fib3J0U2lnbmFsLmpzIiwiLi4vLi4vc3RydG9rMy9saWIvQnVmZmVyU2l6ZUVycm9yLmpzIiwiLi4vLi4vc3RydG9rMy9saWIvc3RyZWFtL0Fic3RyYWN0U3RyZWFtUmVhZGVyLmpzIiwiLi4vLi4vc3RydG9rMy9saWIvc3RyZWFtL1dlYlN0cmVhbVJlYWRlci5qcyIsIi4uLy4uL3N0cnRvazMvbGliL3N0cmVhbS9XZWJTdHJlYW1CeW9iUmVhZGVyLmpzIiwiLi4vLi4vc3RydG9rMy9saWIvc3RyZWFtL1dlYlN0cmVhbURlZmF1bHRSZWFkZXIuanMiLCIuLi8uLi9zdHJ0b2szL2xpYi9zdHJlYW0vV2ViU3RyZWFtUmVhZGVyRmFjdG9yeS5qcyIsIi4uLy4uL3N0cnRvazMvbGliL0Fic3RyYWN0VG9rZW5pemVyLmpzIiwiLi4vLi4vc3RydG9rMy9saWIvQmxvYlRva2VuaXplci5qcyIsIi4uLy4uL3N0cnRvazMvbGliL0J1ZmZlclRva2VuaXplci5qcyIsIi4uLy4uL3N0cnRvazMvbGliL1JlYWRTdHJlYW1Ub2tlbml6ZXIuanMiLCIuLi8uLi9zdHJ0b2szL2xpYi9jb3JlLmpzIiwiLi4vLi4vbXVzaWMtbWV0YWRhdGEvbGliL2NvbW1vbi9Gb3VyQ0MuanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvYXBldjIvQVBFdjJUb2tlbi5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9hcGV2Mi9BUEV2MlBhcnNlci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBYm9ydEVycm9yIH0gZnJvbSAnLi9zdHJlYW0vRXJyb3JzLmpzJztcbi8qKiBSZWplY3QgYW4gYWxyZWFkeS1jYW5jZWxsZWQgb3BlcmF0aW9uIGJlZm9yZSBhY3F1aXJpbmcgdG9rZW5pemVyIHJlc291cmNlcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0aHJvd0lmQWJvcnRlZChzaWduYWwpIHtcbiAgICBpZiAoc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgIHRocm93IG5ldyBBYm9ydEVycm9yKCk7XG4gICAgfVxufVxuIiwiLyoqIFRocm93biBiZWZvcmUgYSBkeW5hbWljYWxseSBzaXplZCB0b2tlbml6ZXIgYnVmZmVyIGV4Y2VlZHMgaXRzIGNvbmZpZ3VyZWQgbGltaXQuICovXG5leHBvcnQgY2xhc3MgQnVmZmVyU2l6ZUVycm9yIGV4dGVuZHMgUmFuZ2VFcnJvciB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGFuIGVycm9yIGRlc2NyaWJpbmcgYW4gYWxsb2NhdGlvbiB0aGF0IGV4Y2VlZHMgdGhlIGNvbmZpZ3VyZWQgbGltaXQuXG4gICAgICogQHBhcmFtIHJlcXVlc3RlZFNpemUgLSBSZXF1ZXN0ZWQgYnVmZmVyIHNpemUgaW4gYnl0ZXNcbiAgICAgKiBAcGFyYW0gbWF4QnVmZmVyU2l6ZSAtIENvbmZpZ3VyZWQgbWF4aW11bSBidWZmZXIgc2l6ZSBpbiBieXRlc1xuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKHJlcXVlc3RlZFNpemUsIG1heEJ1ZmZlclNpemUpIHtcbiAgICAgICAgc3VwZXIoYFJlcXVlc3RlZCBidWZmZXIgc2l6ZSAke3JlcXVlc3RlZFNpemV9IGV4Y2VlZHMgbWF4QnVmZmVyU2l6ZSAke21heEJ1ZmZlclNpemV9YCk7XG4gICAgICAgIHRoaXMucmVxdWVzdGVkU2l6ZSA9IHJlcXVlc3RlZFNpemU7XG4gICAgICAgIHRoaXMubWF4QnVmZmVyU2l6ZSA9IG1heEJ1ZmZlclNpemU7XG4gICAgICAgIHRoaXMubmFtZSA9ICdCdWZmZXJTaXplRXJyb3InO1xuICAgIH1cbn1cbi8qKlxuICogVmFsaWRhdGUgb3B0aW9ucyBiZWZvcmUgYWNxdWlyaW5nIGZpbGUgaGFuZGxlcyBvciBzdHJlYW0gcmVhZGVycy5cbiAqIEBwYXJhbSBvcHRpb25zIC0gVG9rZW5pemVyIG9wdGlvbnMgY29udGFpbmluZyB0aGUgb3B0aW9uYWwgYWxsb2NhdGlvbiBsaW1pdFxuICogQHJldHVybnMgQ29uZmlndXJlZCBidWZmZXIgbGltaXQgaW4gYnl0ZXMsIG9yIEluZmluaXR5IHdoZW4gdGhlIGxpbWl0IGlzIGRpc2FibGVkXG4gKiBAdGhyb3dzIFJhbmdlRXJyb3IgaWYgbWF4QnVmZmVyU2l6ZSBpcyBuZWl0aGVyIGEgcG9zaXRpdmUgc2FmZSBpbnRlZ2VyIG5vciBJbmZpbml0eVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWF4QnVmZmVyU2l6ZShvcHRpb25zKSB7XG4gICAgY29uc3QgbGltaXQgPSBvcHRpb25zPy5tYXhCdWZmZXJTaXplID8/IE51bWJlci5QT1NJVElWRV9JTkZJTklUWTtcbiAgICBpZiAobGltaXQgIT09IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSAmJiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKGxpbWl0KSB8fCBsaW1pdCA8PSAwKSkge1xuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignbWF4QnVmZmVyU2l6ZSBtdXN0IGJlIGEgcG9zaXRpdmUgc2FmZSBpbnRlZ2VyIG9yIEluZmluaXR5Jyk7XG4gICAgfVxuICAgIHJldHVybiBsaW1pdDtcbn1cbiIsImltcG9ydCB7IEFib3J0RXJyb3IsIEVuZE9mU3RyZWFtRXJyb3IgfSBmcm9tICcuL0Vycm9ycy5qcyc7XG5leHBvcnQgY2xhc3MgQWJzdHJhY3RTdHJlYW1SZWFkZXIge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLmVuZE9mU3RyZWFtID0gZmFsc2U7XG4gICAgICAgIHRoaXMuaW50ZXJydXB0ZWQgPSBmYWxzZTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFN0b3JlIHBlZWtlZCBkYXRhXG4gICAgICAgICAqIEB0eXBlIHtBcnJheX1cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMucGVla1F1ZXVlID0gW107XG4gICAgfVxuICAgIGFzeW5jIHBlZWsodWludDhBcnJheSwgbWF5QmVMZXNzID0gZmFsc2UpIHtcbiAgICAgICAgY29uc3QgYnl0ZXNSZWFkID0gYXdhaXQgdGhpcy5yZWFkKHVpbnQ4QXJyYXksIG1heUJlTGVzcyk7XG4gICAgICAgIHRoaXMucGVla1F1ZXVlLnB1c2godWludDhBcnJheS5zdWJhcnJheSgwLCBieXRlc1JlYWQpKTsgLy8gUHV0IHJlYWQgZGF0YSBiYWNrIHRvIHBlZWsgYnVmZmVyXG4gICAgICAgIHJldHVybiBieXRlc1JlYWQ7XG4gICAgfVxuICAgIGFzeW5jIHJlYWQoYnVmZmVyLCBtYXlCZUxlc3MgPSBmYWxzZSkge1xuICAgICAgICBpZiAoYnVmZmVyLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGJ5dGVzUmVhZCA9IHRoaXMucmVhZEZyb21QZWVrQnVmZmVyKGJ1ZmZlcik7XG4gICAgICAgIGlmICghdGhpcy5lbmRPZlN0cmVhbSkge1xuICAgICAgICAgICAgYnl0ZXNSZWFkICs9IGF3YWl0IHRoaXMucmVhZFJlbWFpbmRlckZyb21TdHJlYW0oYnVmZmVyLnN1YmFycmF5KGJ5dGVzUmVhZCksIG1heUJlTGVzcyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJ5dGVzUmVhZCA9PT0gMCAmJiAhbWF5QmVMZXNzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRW5kT2ZTdHJlYW1FcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBieXRlc1JlYWQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJlYWQgY2h1bmsgZnJvbSBzdHJlYW1cbiAgICAgKiBAcGFyYW0gYnVmZmVyIC0gVGFyZ2V0IFVpbnQ4QXJyYXkgKG9yIEJ1ZmZlcikgdG8gc3RvcmUgZGF0YSByZWFkIGZyb20gc3RyZWFtIGluXG4gICAgICogQHJldHVybnMgTnVtYmVyIG9mIGJ5dGVzIHJlYWRcbiAgICAgKi9cbiAgICByZWFkRnJvbVBlZWtCdWZmZXIoYnVmZmVyKSB7XG4gICAgICAgIGxldCByZW1haW5pbmcgPSBidWZmZXIubGVuZ3RoO1xuICAgICAgICBsZXQgYnl0ZXNSZWFkID0gMDtcbiAgICAgICAgLy8gY29uc3VtZSBwZWVrZWQgZGF0YSBmaXJzdFxuICAgICAgICB3aGlsZSAodGhpcy5wZWVrUXVldWUubGVuZ3RoID4gMCAmJiByZW1haW5pbmcgPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBwZWVrRGF0YSA9IHRoaXMucGVla1F1ZXVlLnBvcCgpOyAvLyBGcm9udCBvZiBxdWV1ZVxuICAgICAgICAgICAgaWYgKCFwZWVrRGF0YSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigncGVla0RhdGEgc2hvdWxkIGJlIGRlZmluZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGxlbkNvcHkgPSBNYXRoLm1pbihwZWVrRGF0YS5sZW5ndGgsIHJlbWFpbmluZyk7XG4gICAgICAgICAgICBidWZmZXIuc2V0KHBlZWtEYXRhLnN1YmFycmF5KDAsIGxlbkNvcHkpLCBieXRlc1JlYWQpO1xuICAgICAgICAgICAgYnl0ZXNSZWFkICs9IGxlbkNvcHk7XG4gICAgICAgICAgICByZW1haW5pbmcgLT0gbGVuQ29weTtcbiAgICAgICAgICAgIGlmIChsZW5Db3B5IDwgcGVla0RhdGEubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgLy8gcmVtYWluZGVyIGJhY2sgdG8gcXVldWVcbiAgICAgICAgICAgICAgICB0aGlzLnBlZWtRdWV1ZS5wdXNoKHBlZWtEYXRhLnN1YmFycmF5KGxlbkNvcHkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnl0ZXNSZWFkO1xuICAgIH1cbiAgICBhc3luYyByZWFkUmVtYWluZGVyRnJvbVN0cmVhbShidWZmZXIsIG1heUJlTGVzcykge1xuICAgICAgICBsZXQgYnl0ZXNSZWFkID0gMDtcbiAgICAgICAgLy8gQ29udGludWUgcmVhZGluZyBmcm9tIHN0cmVhbSBpZiByZXF1aXJlZFxuICAgICAgICB3aGlsZSAoYnl0ZXNSZWFkIDwgYnVmZmVyLmxlbmd0aCAmJiAhdGhpcy5lbmRPZlN0cmVhbSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuaW50ZXJydXB0ZWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgQWJvcnRFcnJvcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2h1bmtMZW4gPSBhd2FpdCB0aGlzLnJlYWRGcm9tU3RyZWFtKGJ1ZmZlci5zdWJhcnJheShieXRlc1JlYWQpLCBtYXlCZUxlc3MpO1xuICAgICAgICAgICAgaWYgKGNodW5rTGVuID09PSAwKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBieXRlc1JlYWQgKz0gY2h1bmtMZW47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFtYXlCZUxlc3MgJiYgYnl0ZXNSZWFkIDwgYnVmZmVyLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnl0ZXNSZWFkO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEFic3RyYWN0U3RyZWFtUmVhZGVyIH0gZnJvbSAnLi9BYnN0cmFjdFN0cmVhbVJlYWRlci5qcyc7XG5leHBvcnQgY2xhc3MgV2ViU3RyZWFtUmVhZGVyIGV4dGVuZHMgQWJzdHJhY3RTdHJlYW1SZWFkZXIge1xuICAgIGNvbnN0cnVjdG9yKHJlYWRlcikge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnJlYWRlciA9IHJlYWRlcjtcbiAgICB9XG4gICAgYXN5bmMgYWJvcnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNsb3NlKCk7XG4gICAgfVxuICAgIGFzeW5jIGNsb3NlKCkge1xuICAgICAgICB0aGlzLnJlYWRlci5yZWxlYXNlTG9jaygpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFdlYlN0cmVhbVJlYWRlciB9IGZyb20gJy4vV2ViU3RyZWFtUmVhZGVyLmpzJztcbi8qKlxuICogUmVhZCBmcm9tIGEgV2ViU3RyZWFtIHVzaW5nIGEgQllPQiByZWFkZXJcbiAqIFJlZmVyZW5jZTogaHR0cHM6Ly9ub2RlanMub3JnL2FwaS93ZWJzdHJlYW1zLmh0bWwjY2xhc3MtcmVhZGFibGVzdHJlYW1ieW9icmVhZGVyXG4gKi9cbmV4cG9ydCBjbGFzcyBXZWJTdHJlYW1CeW9iUmVhZGVyIGV4dGVuZHMgV2ViU3RyZWFtUmVhZGVyIHtcbiAgICAvKipcbiAgICAgKiBSZWFkIGZyb20gc3RyZWFtXG4gICAgICogQHBhcmFtIGJ1ZmZlciAtIFRhcmdldCBVaW50OEFycmF5IChvciBCdWZmZXIpIHRvIHN0b3JlIGRhdGEgcmVhZCBmcm9tIHN0cmVhbSBpblxuICAgICAqIEBwYXJhbSBtYXlCZUxlc3MgLSBJZiB0cnVlLCBtYXkgZmlsbCB0aGUgYnVmZmVyIHBhcnRpYWxseVxuICAgICAqIEBwcm90ZWN0ZWQgQnl0ZXMgcmVhZFxuICAgICAqL1xuICAgIGFzeW5jIHJlYWRGcm9tU3RyZWFtKGJ1ZmZlciwgbWF5QmVMZXNzKSB7XG4gICAgICAgIGlmIChidWZmZXIubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLnJlYWRlci5yZWFkKG5ldyBVaW50OEFycmF5KGJ1ZmZlci5sZW5ndGgpLCB7XG4gICAgICAgICAgICBtaW46IG1heUJlTGVzcyA/IHVuZGVmaW5lZCA6IGJ1ZmZlci5sZW5ndGhcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChyZXN1bHQuZG9uZSkge1xuICAgICAgICAgICAgdGhpcy5lbmRPZlN0cmVhbSA9IHJlc3VsdC5kb25lO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQudmFsdWUpIHtcbiAgICAgICAgICAgIGJ1ZmZlci5zZXQocmVzdWx0LnZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQudmFsdWUubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEFic3RyYWN0U3RyZWFtUmVhZGVyIH0gZnJvbSAnLi9BYnN0cmFjdFN0cmVhbVJlYWRlci5qcyc7XG5pbXBvcnQgeyBFbmRPZlN0cmVhbUVycm9yIH0gZnJvbSAnLi9FcnJvcnMuanMnO1xuZXhwb3J0IGNsYXNzIFdlYlN0cmVhbURlZmF1bHRSZWFkZXIgZXh0ZW5kcyBBYnN0cmFjdFN0cmVhbVJlYWRlciB7XG4gICAgY29uc3RydWN0b3IocmVhZGVyKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucmVhZGVyID0gcmVhZGVyO1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IG51bGw7IC8vIEludGVybmFsIGJ1ZmZlciB0byBzdG9yZSBleGNlc3MgZGF0YVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb3B5IGNodW5rIHRvIHRhcmdldCwgYW5kIHN0b3JlIHRoZSByZW1haW5kZXIgaW4gdGhpcy5idWZmZXJcbiAgICAgKi9cbiAgICB3cml0ZUNodW5rKHRhcmdldCwgY2h1bmspIHtcbiAgICAgICAgY29uc3Qgd3JpdHRlbiA9IE1hdGgubWluKGNodW5rLmxlbmd0aCwgdGFyZ2V0Lmxlbmd0aCk7XG4gICAgICAgIHRhcmdldC5zZXQoY2h1bmsuc3ViYXJyYXkoMCwgd3JpdHRlbikpO1xuICAgICAgICAvLyBBZGp1c3QgdGhlIHJlbWFpbmRlciBvZiB0aGUgYnVmZmVyXG4gICAgICAgIGlmICh3cml0dGVuIDwgY2h1bmsubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aGlzLmJ1ZmZlciA9IGNodW5rLnN1YmFycmF5KHdyaXR0ZW4pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5idWZmZXIgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB3cml0dGVuO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZWFkIGZyb20gc3RyZWFtXG4gICAgICogQHBhcmFtIGJ1ZmZlciAtIFRhcmdldCBVaW50OEFycmF5IChvciBCdWZmZXIpIHRvIHN0b3JlIGRhdGEgcmVhZCBmcm9tIHN0cmVhbSBpblxuICAgICAqIEBwYXJhbSBtYXlCZUxlc3MgLSBJZiB0cnVlLCBtYXkgZmlsbCB0aGUgYnVmZmVyIHBhcnRpYWxseVxuICAgICAqIEBwcm90ZWN0ZWQgQnl0ZXMgcmVhZFxuICAgICAqL1xuICAgIGFzeW5jIHJlYWRGcm9tU3RyZWFtKGJ1ZmZlciwgbWF5QmVMZXNzKSB7XG4gICAgICAgIGlmIChidWZmZXIubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgdG90YWxCeXRlc1JlYWQgPSAwO1xuICAgICAgICAvLyBTZXJ2ZSBmcm9tIHRoZSBpbnRlcm5hbCBidWZmZXIgZmlyc3RcbiAgICAgICAgaWYgKHRoaXMuYnVmZmVyKSB7XG4gICAgICAgICAgICB0b3RhbEJ5dGVzUmVhZCArPSB0aGlzLndyaXRlQ2h1bmsoYnVmZmVyLCB0aGlzLmJ1ZmZlcik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQ29udGludWUgcmVhZGluZyBmcm9tIHRoZSBzdHJlYW0gaWYgbW9yZSBkYXRhIGlzIG5lZWRlZFxuICAgICAgICB3aGlsZSAodG90YWxCeXRlc1JlYWQgPCBidWZmZXIubGVuZ3RoICYmICF0aGlzLmVuZE9mU3RyZWFtKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLnJlYWRlci5yZWFkKCk7XG4gICAgICAgICAgICBpZiAocmVzdWx0LmRvbmUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmVuZE9mU3RyZWFtID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXN1bHQudmFsdWUpIHtcbiAgICAgICAgICAgICAgICB0b3RhbEJ5dGVzUmVhZCArPSB0aGlzLndyaXRlQ2h1bmsoYnVmZmVyLnN1YmFycmF5KHRvdGFsQnl0ZXNSZWFkKSwgcmVzdWx0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIW1heUJlTGVzcyAmJiB0b3RhbEJ5dGVzUmVhZCA9PT0gMCAmJiB0aGlzLmVuZE9mU3RyZWFtKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRW5kT2ZTdHJlYW1FcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3RhbEJ5dGVzUmVhZDtcbiAgICB9XG4gICAgYWJvcnQoKSB7XG4gICAgICAgIHRoaXMuaW50ZXJydXB0ZWQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gdGhpcy5yZWFkZXIuY2FuY2VsKCk7XG4gICAgfVxuICAgIGFzeW5jIGNsb3NlKCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5hYm9ydCgpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgdGhpcy5yZWFkZXIucmVsZWFzZUxvY2soKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IFdlYlN0cmVhbUJ5b2JSZWFkZXIgfSBmcm9tICcuL1dlYlN0cmVhbUJ5b2JSZWFkZXIuanMnO1xuaW1wb3J0IHsgV2ViU3RyZWFtRGVmYXVsdFJlYWRlciB9IGZyb20gJy4vV2ViU3RyZWFtRGVmYXVsdFJlYWRlci5qcyc7XG5leHBvcnQgZnVuY3Rpb24gbWFrZVdlYlN0cmVhbVJlYWRlcihzdHJlYW0pIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZWFkZXIgPSBzdHJlYW0uZ2V0UmVhZGVyKHsgbW9kZTogJ2J5b2InIH0pO1xuICAgICAgICBpZiAocmVhZGVyIGluc3RhbmNlb2YgUmVhZGFibGVTdHJlYW1EZWZhdWx0UmVhZGVyKSB7XG4gICAgICAgICAgICAvLyBGYWxsYmFjayB0byBkZWZhdWx0IHJlYWRlciBpbiBjYXNlIGBtb2RlOiBieW9iYCBpcyBpZ25vcmVkXG4gICAgICAgICAgICByZXR1cm4gbmV3IFdlYlN0cmVhbURlZmF1bHRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IFdlYlN0cmVhbUJ5b2JSZWFkZXIocmVhZGVyKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFR5cGVFcnJvcikge1xuICAgICAgICAgICAgLy8gRmFsbGJhY2sgdG8gZGVmYXVsdCByZWFkZXIgaW4gY2FzZSBgbW9kZTogYnlvYmAgcmVqZWN0ZWQgYnkgYSBgVHlwZUVycm9yYFxuICAgICAgICAgICAgcmV0dXJuIG5ldyBXZWJTdHJlYW1EZWZhdWx0UmVhZGVyKHN0cmVhbS5nZXRSZWFkZXIoKSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgdGhyb3dJZkFib3J0ZWQgfSBmcm9tICcuL0Fib3J0U2lnbmFsLmpzJztcbmltcG9ydCB7IEJ1ZmZlclNpemVFcnJvciwgZ2V0TWF4QnVmZmVyU2l6ZSB9IGZyb20gJy4vQnVmZmVyU2l6ZUVycm9yLmpzJztcbmltcG9ydCB7IEVuZE9mU3RyZWFtRXJyb3IgfSBmcm9tICcuL3N0cmVhbS9pbmRleC5qcyc7XG4vKipcbiAqIENvcmUgdG9rZW5pemVyXG4gKi9cbmV4cG9ydCBjbGFzcyBBYnN0cmFjdFRva2VuaXplciB7XG4gICAgLyoqXG4gICAgICogQ29uc3RydWN0b3JcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyBUb2tlbml6ZXIgb3B0aW9uc1xuICAgICAqIEBwcm90ZWN0ZWRcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgICAgIHRoaXMubnVtQnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoMTApOyAvLyBJbmNsdWRlcyB0aGUgODAtYml0IGZsb2F0aW5nLXBvaW50IHRva2Vucy5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRva2VuaXplci1zdHJlYW0gcG9zaXRpb25cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMucG9zaXRpb24gPSAwO1xuICAgICAgICB0aGlzLm1heEJ1ZmZlclNpemUgPSBnZXRNYXhCdWZmZXJTaXplKG9wdGlvbnMpO1xuICAgICAgICB0aHJvd0lmQWJvcnRlZChvcHRpb25zPy5hYm9ydFNpZ25hbCk7XG4gICAgICAgIHRoaXMub25DbG9zZSA9IG9wdGlvbnM/Lm9uQ2xvc2U7XG4gICAgICAgIGlmIChvcHRpb25zPy5hYm9ydFNpZ25hbCkge1xuICAgICAgICAgICAgdGhpcy5hZGRBYm9ydExpc3RlbmVyKG9wdGlvbnMuYWJvcnRTaWduYWwsICgpID0+IHtcbiAgICAgICAgICAgICAgICB2b2lkIHRoaXMuYWJvcnQoKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFNpZ25hbCBldmVudHMgY2Fubm90IHByb3BhZ2F0ZSBjYW5jZWxsYXRpb24gZXJyb3JzOyBleHBsaWNpdCBhYm9ydC9jbG9zZSBjYWxscyBzdGlsbCByZWplY3QuXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhZGRBYm9ydExpc3RlbmVyKHNpZ25hbCwgbGlzdGVuZXIpIHtcbiAgICAgICAgdGhpcy5hYm9ydFNpZ25hbCA9IHNpZ25hbDtcbiAgICAgICAgdGhpcy5hYm9ydExpc3RlbmVyID0gbGlzdGVuZXI7XG4gICAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIGxpc3RlbmVyLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgfVxuICAgIHJlbW92ZUFib3J0TGlzdGVuZXIoKSB7XG4gICAgICAgIGlmICh0aGlzLmFib3J0TGlzdGVuZXIpIHtcbiAgICAgICAgICAgIHRoaXMuYWJvcnRTaWduYWw/LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgdGhpcy5hYm9ydExpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFib3J0U2lnbmFsID0gdW5kZWZpbmVkO1xuICAgICAgICB0aGlzLmFib3J0TGlzdGVuZXIgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJlYWQgYSB0b2tlbiBmcm9tIHRoZSB0b2tlbml6ZXItc3RyZWFtXG4gICAgICogQHBhcmFtIHRva2VuIC0gVGhlIHRva2VuIHRvIHJlYWRcbiAgICAgKiBAcGFyYW0gcG9zaXRpb24gLSBJZiBwcm92aWRlZCwgdGhlIGRlc2lyZWQgcG9zaXRpb24gaW4gdGhlIHRva2VuaXplci1zdHJlYW1cbiAgICAgKiBAcmV0dXJucyBQcm9taXNlIHdpdGggdG9rZW4gZGF0YVxuICAgICAqL1xuICAgIGFzeW5jIHJlYWRUb2tlbih0b2tlbiwgcG9zaXRpb24gPSB0aGlzLnBvc2l0aW9uKSB7XG4gICAgICAgIHRoaXMudmFsaWRhdGVUb2tlblJlYWQodG9rZW4ubGVuLCBwb3NpdGlvbik7XG4gICAgICAgIGNvbnN0IHVpbnQ4QXJyYXkgPSBuZXcgVWludDhBcnJheSh0b2tlbi5sZW4pO1xuICAgICAgICBjb25zdCBsZW4gPSBhd2FpdCB0aGlzLnJlYWRCdWZmZXIodWludDhBcnJheSwgeyBwb3NpdGlvbiB9KTtcbiAgICAgICAgaWYgKGxlbiA8IHRva2VuLmxlbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG9rZW4uZ2V0KHVpbnQ4QXJyYXksIDApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQZWVrIGEgdG9rZW4gZnJvbSB0aGUgdG9rZW5pemVyLXN0cmVhbS5cbiAgICAgKiBAcGFyYW0gdG9rZW4gLSBUb2tlbiB0byBwZWVrIGZyb20gdGhlIHRva2VuaXplci1zdHJlYW0uXG4gICAgICogQHBhcmFtIHBvc2l0aW9uIC0gT2Zmc2V0IHdoZXJlIHRvIGJlZ2luIHJlYWRpbmcgd2l0aGluIHRoZSBmaWxlLiBJZiBwb3NpdGlvbiBpcyBudWxsLCBkYXRhIHdpbGwgYmUgcmVhZCBmcm9tIHRoZSBjdXJyZW50IGZpbGUgcG9zaXRpb24uXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIHRva2VuIGRhdGFcbiAgICAgKi9cbiAgICBhc3luYyBwZWVrVG9rZW4odG9rZW4sIHBvc2l0aW9uID0gdGhpcy5wb3NpdGlvbikge1xuICAgICAgICBjb25zdCBwZWVrUG9zaXRpb24gPSBwb3NpdGlvbiA/PyB0aGlzLnBvc2l0aW9uO1xuICAgICAgICB0aGlzLnZhbGlkYXRlVG9rZW5SZWFkKHRva2VuLmxlbiwgcGVla1Bvc2l0aW9uLCB0cnVlKTtcbiAgICAgICAgY29uc3QgdWludDhBcnJheSA9IG5ldyBVaW50OEFycmF5KHRva2VuLmxlbik7XG4gICAgICAgIGNvbnN0IGxlbiA9IGF3YWl0IHRoaXMucGVla0J1ZmZlcih1aW50OEFycmF5LCB7IHBvc2l0aW9uOiBwZWVrUG9zaXRpb24gfSk7XG4gICAgICAgIGlmIChsZW4gPCB0b2tlbi5sZW4pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFbmRPZlN0cmVhbUVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRva2VuLmdldCh1aW50OEFycmF5LCAwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmVhZCBhIG51bWVyaWMgdG9rZW4gZnJvbSB0aGUgc3RyZWFtXG4gICAgICogQHBhcmFtIHRva2VuIC0gTnVtZXJpYyB0b2tlblxuICAgICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCBudW1iZXJcbiAgICAgKi9cbiAgICBhc3luYyByZWFkTnVtYmVyKHRva2VuKSB7XG4gICAgICAgIGNvbnN0IGxlbiA9IGF3YWl0IHRoaXMucmVhZEJ1ZmZlcih0aGlzLm51bUJ1ZmZlciwgeyBsZW5ndGg6IHRva2VuLmxlbiB9KTtcbiAgICAgICAgaWYgKGxlbiA8IHRva2VuLmxlbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG9rZW4uZ2V0KHRoaXMubnVtQnVmZmVyLCAwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmVhZCBhIG51bWVyaWMgdG9rZW4gZnJvbSB0aGUgc3RyZWFtXG4gICAgICogQHBhcmFtIHRva2VuIC0gTnVtZXJpYyB0b2tlblxuICAgICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCBudW1iZXJcbiAgICAgKi9cbiAgICBhc3luYyBwZWVrTnVtYmVyKHRva2VuKSB7XG4gICAgICAgIGNvbnN0IGxlbiA9IGF3YWl0IHRoaXMucGVla0J1ZmZlcih0aGlzLm51bUJ1ZmZlciwgeyBsZW5ndGg6IHRva2VuLmxlbiB9KTtcbiAgICAgICAgaWYgKGxlbiA8IHRva2VuLmxlbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG9rZW4uZ2V0KHRoaXMubnVtQnVmZmVyLCAwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogSWdub3JlIG51bWJlciBvZiBieXRlcywgYWR2YW5jZXMgdGhlIHBvaW50ZXIgaW4gdW5kZXIgdG9rZW5pemVyLXN0cmVhbS5cbiAgICAgKiBAcGFyYW0gbGVuZ3RoIC0gTnVtYmVyIG9mIGJ5dGVzIHRvIGlnbm9yZS4gIE11c3QgYmUg4omlIDAuXG4gICAgICogQHJldHVybiByZXNvbHZlcyB0aGUgbnVtYmVyIG9mIGJ5dGVzIGlnbm9yZWQsIGVxdWFscyBsZW5ndGggaWYgdGhpcyBhdmFpbGFibGUsIG90aGVyd2lzZSB0aGUgbnVtYmVyIG9mIGJ5dGVzIGF2YWlsYWJsZVxuICAgICAqL1xuICAgIGFzeW5jIGlnbm9yZShsZW5ndGgpIHtcbiAgICAgICAgaWYgKGxlbmd0aCA8IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdpZ25vcmUgbGVuZ3RoIG11c3QgYmUg4omlIDAgYnl0ZXMnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKGxlbmd0aCwgJ2lnbm9yZSBsZW5ndGgnKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZUxlbmd0aCh0aGlzLnBvc2l0aW9uICsgbGVuZ3RoLCAnZW5kIHBvc2l0aW9uJyk7XG4gICAgICAgIGlmICh0aGlzLmZpbGVJbmZvLnNpemUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY29uc3QgYnl0ZXNMZWZ0ID0gTWF0aC5tYXgoMCwgdGhpcy5maWxlSW5mby5zaXplIC0gdGhpcy5wb3NpdGlvbik7XG4gICAgICAgICAgICBpZiAobGVuZ3RoID4gYnl0ZXNMZWZ0KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wb3NpdGlvbiArPSBieXRlc0xlZnQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGJ5dGVzTGVmdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnBvc2l0aW9uICs9IGxlbmd0aDtcbiAgICAgICAgcmV0dXJuIGxlbmd0aDtcbiAgICB9XG4gICAgY2xvc2UoKSB7XG4gICAgICAgIGlmICghdGhpcy5jbG9zZVByb21pc2UpIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlQWJvcnRMaXN0ZW5lcigpO1xuICAgICAgICAgICAgLy8gQ2FjaGUgY29tcGxldGlvbiBiZWZvcmUgaW52b2tpbmcgY2xlYW51cCBob29rcyBvciBjYWxsZXIgY2FsbGJhY2tzLlxuICAgICAgICAgICAgdGhpcy5jbG9zZVByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHRoaXMuY2xvc2VPbmNlKCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLmNsb3NlUHJvbWlzZTtcbiAgICB9XG4gICAgLyoqIFBlcmZvcm0gY2xlYW51cCBvbmNlLCBzaGFyaW5nIGNvbXBsZXRpb24gYW5kIHRoZSBmaXJzdCBlcnJvciBhY3Jvc3MgY2xvc2UgY2FsbHMuICovXG4gICAgYXN5bmMgY2xvc2VPbmNlKCkge1xuICAgICAgICBhd2FpdCB0aGlzLmFib3J0KCk7XG4gICAgICAgIGF3YWl0IHRoaXMub25DbG9zZT8uKCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFZhbGlkYXRlIGEgYnl0ZSBsZW5ndGggb3IgcG9zaXRpb24gYmVmb3JlIHVzaW5nIGl0IGluIGJ1ZmZlciBjYWxjdWxhdGlvbnMuXG4gICAgICogQHBhcmFtIHZhbHVlIC0gVmFsdWUgdGhhdCBtdXN0IGJlIGEgbm9uLW5lZ2F0aXZlIHNhZmUgaW50ZWdlclxuICAgICAqIEBwYXJhbSBuYW1lIC0gTGFiZWwgdXNlZCBpbiB0aGUgdmFsaWRhdGlvbiBlcnJvclxuICAgICAqIEB0aHJvd3MgUmFuZ2VFcnJvciBpZiB0aGUgdmFsdWUgaXMgbmVnYXRpdmUgb3Igbm90IGEgc2FmZSBpbnRlZ2VyXG4gICAgICovXG4gICAgdmFsaWRhdGVMZW5ndGgodmFsdWUsIG5hbWUpIHtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcih2YWx1ZSkgfHwgdmFsdWUgPCAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGEgbm9uLW5lZ2F0aXZlIHNhZmUgaW50ZWdlcmApO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFZhbGlkYXRlIGEgcmVxdWVzdGVkIGJ1ZmZlciBzaXplIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgYWxsb2NhdGlvbiBsaW1pdC5cbiAgICAgKiBAcGFyYW0gbGVuZ3RoIC0gUmVxdWVzdGVkIGJ1ZmZlciBzaXplIGluIGJ5dGVzXG4gICAgICogQHRocm93cyBSYW5nZUVycm9yIGlmIHRoZSBsZW5ndGggaXMgbmVnYXRpdmUgb3Igbm90IGEgc2FmZSBpbnRlZ2VyXG4gICAgICogQHRocm93cyBCdWZmZXJTaXplRXJyb3IgaWYgdGhlIGxlbmd0aCBleGNlZWRzIG1heEJ1ZmZlclNpemVcbiAgICAgKi9cbiAgICB2YWxpZGF0ZUJ1ZmZlclNpemUobGVuZ3RoKSB7XG4gICAgICAgIHRoaXMudmFsaWRhdGVMZW5ndGgobGVuZ3RoLCAnYnVmZmVyIGxlbmd0aCcpO1xuICAgICAgICBpZiAobGVuZ3RoID4gdGhpcy5tYXhCdWZmZXJTaXplKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQnVmZmVyU2l6ZUVycm9yKGxlbmd0aCwgdGhpcy5tYXhCdWZmZXJTaXplKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBWYWxpZGF0ZSBhIHRva2VuIHJlcXVlc3QgYmVmb3JlIGFsbG9jYXRpbmcgYSBidWZmZXIgb3IgY29uc3VtaW5nIGlucHV0LlxuICAgICAqIEBwYXJhbSBsZW5ndGggLSBUb2tlbiBsZW5ndGggaW4gYnl0ZXNcbiAgICAgKiBAcGFyYW0gcG9zaXRpb24gLSBCeXRlIG9mZnNldCB3aGVyZSB0aGUgdG9rZW4gc3RhcnRzXG4gICAgICogQHBhcmFtIHBlZWsgLSBXaGV0aGVyIHRvIGluY2x1ZGUgc2tpcHBlZCBzdHJlYW0gYnl0ZXMgaW4gdGhlIGxvb2thaGVhZCBsaW1pdFxuICAgICAqIEB0aHJvd3MgUmFuZ2VFcnJvciBpZiBhIGxlbmd0aCBvciBwb3NpdGlvbiBpcyBuZWdhdGl2ZSBvciBub3QgYSBzYWZlIGludGVnZXJcbiAgICAgKiBAdGhyb3dzIEJ1ZmZlclNpemVFcnJvciBpZiB0aGUgdG9rZW4gYnVmZmVyIG9yIHN0cmVhbSBsb29rYWhlYWQgZXhjZWVkcyBtYXhCdWZmZXJTaXplXG4gICAgICogQHRocm93cyBFcnJvciBpZiBhIHN0cmVhbSByZXF1ZXN0IHN0YXJ0cyBiZWZvcmUgdGhlIGN1cnJlbnQgcG9zaXRpb25cbiAgICAgKiBAdGhyb3dzIEVuZE9mU3RyZWFtRXJyb3IgaWYgdGhlIHRva2VuIGV4dGVuZHMgYmV5b25kIHRoZSBrbm93biBpbnB1dCBzaXplXG4gICAgICovXG4gICAgdmFsaWRhdGVUb2tlblJlYWQobGVuZ3RoLCBwb3NpdGlvbiwgcGVlayA9IGZhbHNlKSB7XG4gICAgICAgIHRoaXMudmFsaWRhdGVCdWZmZXJTaXplKGxlbmd0aCk7XG4gICAgICAgIHRoaXMudmFsaWRhdGVMZW5ndGgocG9zaXRpb24sICdwb3NpdGlvbicpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKHBvc2l0aW9uICsgbGVuZ3RoLCAnZW5kIHBvc2l0aW9uJyk7XG4gICAgICAgIGlmICghdGhpcy5zdXBwb3J0c1JhbmRvbUFjY2VzcygpICYmIHBvc2l0aW9uIDwgdGhpcy5wb3NpdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdgb3B0aW9ucy5wb3NpdGlvbmAgbXVzdCBiZSBlcXVhbCBvciBncmVhdGVyIHRoYW4gYHRva2VuaXplci5wb3NpdGlvbmAnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGVlayAmJiAhdGhpcy5zdXBwb3J0c1JhbmRvbUFjY2VzcygpKSB7XG4gICAgICAgICAgICB0aGlzLnZhbGlkYXRlQnVmZmVyU2l6ZShsZW5ndGggKyBwb3NpdGlvbiAtIHRoaXMucG9zaXRpb24pO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmZpbGVJbmZvLnNpemUgIT09IHVuZGVmaW5lZCAmJiBsZW5ndGggPiB0aGlzLmZpbGVJbmZvLnNpemUgLSBwb3NpdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBBcHBseSBkZWZhdWx0cyBhbmQgdmFsaWRhdGUgYnVmZmVyIHJlYWQgb3IgcGVlayBvcHRpb25zLlxuICAgICAqIEBwYXJhbSB1aW50OEFycmF5IC0gVGFyZ2V0IGJ1ZmZlciB3aG9zZSBsZW5ndGggaXMgdGhlIGRlZmF1bHQgcmVhZCBsZW5ndGhcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIFJlcXVlc3RlZCBsZW5ndGgsIHBvc2l0aW9uIGFuZCBwYXJ0aWFsLXJlYWQgYmVoYXZpb3JcbiAgICAgKiBAcmV0dXJucyBWYWxpZGF0ZWQgb3B0aW9ucyB3aXRoIGFuIGV4cGxpY2l0IGxlbmd0aCwgcG9zaXRpb24gYW5kIG1heUJlTGVzcyBmbGFnXG4gICAgICogQHRocm93cyBSYW5nZUVycm9yIGlmIGEgbGVuZ3RoIG9yIHBvc2l0aW9uIGlzIGludmFsaWQsIG9yIHRoZSBsZW5ndGggZXhjZWVkcyB0aGUgdGFyZ2V0IGJ1ZmZlclxuICAgICAqIEB0aHJvd3MgRXJyb3IgaWYgYSBzdHJlYW0gcmVxdWVzdCBzdGFydHMgYmVmb3JlIHRoZSBjdXJyZW50IHBvc2l0aW9uXG4gICAgICovXG4gICAgbm9ybWFsaXplT3B0aW9ucyh1aW50OEFycmF5LCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGxlbmd0aCA9IG9wdGlvbnM/Lmxlbmd0aCA/PyB1aW50OEFycmF5Lmxlbmd0aDtcbiAgICAgICAgY29uc3QgcG9zaXRpb24gPSBvcHRpb25zPy5wb3NpdGlvbiA/PyB0aGlzLnBvc2l0aW9uO1xuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKGxlbmd0aCwgJ2xlbmd0aCcpO1xuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKHBvc2l0aW9uLCAncG9zaXRpb24nKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZUxlbmd0aChwb3NpdGlvbiArIGxlbmd0aCwgJ2VuZCBwb3NpdGlvbicpO1xuICAgICAgICBpZiAobGVuZ3RoID4gdWludDhBcnJheS5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdsZW5ndGggbXVzdCBub3QgZXhjZWVkIHRoZSB0YXJnZXQgYnVmZmVyIGxlbmd0aCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy5zdXBwb3J0c1JhbmRvbUFjY2VzcygpICYmIHBvc2l0aW9uIDwgdGhpcy5wb3NpdGlvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdgb3B0aW9ucy5wb3NpdGlvbmAgbXVzdCBiZSBlcXVhbCBvciBncmVhdGVyIHRoYW4gYHRva2VuaXplci5wb3NpdGlvbmAnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBsZW5ndGgsIHBvc2l0aW9uLCBtYXlCZUxlc3M6IG9wdGlvbnM/Lm1heUJlTGVzcyA/PyBmYWxzZSB9O1xuICAgIH1cbiAgICBhYm9ydCgpIHtcbiAgICAgICAgdGhpcy5yZW1vdmVBYm9ydExpc3RlbmVyKCk7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTsgLy8gSWdub3JlIGFib3J0IHNpZ25hbFxuICAgIH1cbn1cbiIsImltcG9ydCB7IEFic3RyYWN0VG9rZW5pemVyIH0gZnJvbSAnLi9BYnN0cmFjdFRva2VuaXplci5qcyc7XG5pbXBvcnQgeyBFbmRPZlN0cmVhbUVycm9yIH0gZnJvbSAnLi9zdHJlYW0vaW5kZXguanMnO1xuZXhwb3J0IGNsYXNzIEJsb2JUb2tlbml6ZXIgZXh0ZW5kcyBBYnN0cmFjdFRva2VuaXplciB7XG4gICAgLyoqXG4gICAgICogQ29uc3RydWN0IEJ1ZmZlclRva2VuaXplclxuICAgICAqIEBwYXJhbSBibG9iIC0gVWludDhBcnJheSB0byB0b2tlbml6ZVxuICAgICAqIEBwYXJhbSBvcHRpb25zIFRva2VuaXplciBvcHRpb25zXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoYmxvYiwgb3B0aW9ucykge1xuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5ibG9iID0gYmxvYjtcbiAgICAgICAgdGhpcy5maWxlSW5mbyA9IHsgLi4uKG9wdGlvbnM/LmZpbGVJbmZvID8/IHt9KSwgLi4ueyBzaXplOiBibG9iLnNpemUsIG1pbWVUeXBlOiBibG9iLnR5cGUgfSB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZWFkIGJ1ZmZlciBmcm9tIHRva2VuaXplclxuICAgICAqIEBwYXJhbSB1aW50OEFycmF5IC0gVWludDhBcnJheSB0byB0b2tlbml6ZVxuICAgICAqIEBwYXJhbSBvcHRpb25zIC0gUmVhZCBiZWhhdmlvdXIgb3B0aW9uc1xuICAgICAqIEByZXR1cm5zIHtQcm9taXNlPG51bWJlcj59XG4gICAgICovXG4gICAgYXN5bmMgcmVhZEJ1ZmZlcih1aW50OEFycmF5LCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IG5vcm1PcHRpb25zID0gdGhpcy5ub3JtYWxpemVPcHRpb25zKHVpbnQ4QXJyYXksIG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBieXRlc1JlYWQgPSBhd2FpdCB0aGlzLnBlZWtCdWZmZXIodWludDhBcnJheSwgbm9ybU9wdGlvbnMpO1xuICAgICAgICB0aGlzLnBvc2l0aW9uID0gbm9ybU9wdGlvbnMucG9zaXRpb24gKyBieXRlc1JlYWQ7XG4gICAgICAgIHJldHVybiBieXRlc1JlYWQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFBlZWsgKHJlYWQgYWhlYWQpIGJ1ZmZlciBmcm9tIHRva2VuaXplclxuICAgICAqIEBwYXJhbSBidWZmZXJcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIFJlYWQgYmVoYXZpb3VyIG9wdGlvbnNcbiAgICAgKiBAcmV0dXJucyB7UHJvbWlzZTxudW1iZXI+fVxuICAgICAqL1xuICAgIGFzeW5jIHBlZWtCdWZmZXIoYnVmZmVyLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IG5vcm1PcHRpb25zID0gdGhpcy5ub3JtYWxpemVPcHRpb25zKGJ1ZmZlciwgb3B0aW9ucyk7XG4gICAgICAgIGNvbnN0IGJ5dGVzMnJlYWQgPSBNYXRoLm1heCgwLCBNYXRoLm1pbih0aGlzLmJsb2Iuc2l6ZSAtIG5vcm1PcHRpb25zLnBvc2l0aW9uLCBub3JtT3B0aW9ucy5sZW5ndGgpKTtcbiAgICAgICAgaWYgKCFub3JtT3B0aW9ucy5tYXlCZUxlc3MgJiYgYnl0ZXMycmVhZCA8IG5vcm1PcHRpb25zLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBvZmZzZXQgPSAwOyBvZmZzZXQgPCBieXRlczJyZWFkOykge1xuICAgICAgICAgICAgY29uc3QgY2h1bmtMZW5ndGggPSBNYXRoLm1pbih0aGlzLm1heEJ1ZmZlclNpemUsIGJ5dGVzMnJlYWQgLSBvZmZzZXQpO1xuICAgICAgICAgICAgY29uc3QgcG9zaXRpb24gPSBub3JtT3B0aW9ucy5wb3NpdGlvbiArIG9mZnNldDtcbiAgICAgICAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgdGhpcy5ibG9iLnNsaWNlKHBvc2l0aW9uLCBwb3NpdGlvbiArIGNodW5rTGVuZ3RoKS5hcnJheUJ1ZmZlcigpO1xuICAgICAgICAgICAgYnVmZmVyLnNldChuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlciksIG9mZnNldCk7XG4gICAgICAgICAgICBvZmZzZXQgKz0gY2h1bmtMZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGJ5dGVzMnJlYWQ7XG4gICAgfVxuICAgIGNsb3NlKCkge1xuICAgICAgICByZXR1cm4gc3VwZXIuY2xvc2UoKTtcbiAgICB9XG4gICAgc3VwcG9ydHNSYW5kb21BY2Nlc3MoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBzZXRQb3NpdGlvbihwb3NpdGlvbikge1xuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKHBvc2l0aW9uLCAncG9zaXRpb24nKTtcbiAgICAgICAgdGhpcy5wb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEFic3RyYWN0VG9rZW5pemVyIH0gZnJvbSAnLi9BYnN0cmFjdFRva2VuaXplci5qcyc7XG5pbXBvcnQgeyBFbmRPZlN0cmVhbUVycm9yIH0gZnJvbSAnLi9zdHJlYW0vaW5kZXguanMnO1xuZXhwb3J0IGNsYXNzIEJ1ZmZlclRva2VuaXplciBleHRlbmRzIEFic3RyYWN0VG9rZW5pemVyIHtcbiAgICAvKipcbiAgICAgKiBDb25zdHJ1Y3QgQnVmZmVyVG9rZW5pemVyXG4gICAgICogQHBhcmFtIHVpbnQ4QXJyYXkgLSBVaW50OEFycmF5IHRvIHRva2VuaXplXG4gICAgICogQHBhcmFtIG9wdGlvbnMgVG9rZW5pemVyIG9wdGlvbnNcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3Rvcih1aW50OEFycmF5LCBvcHRpb25zKSB7XG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLnVpbnQ4QXJyYXkgPSB1aW50OEFycmF5O1xuICAgICAgICB0aGlzLmZpbGVJbmZvID0geyAuLi4ob3B0aW9ucz8uZmlsZUluZm8gPz8ge30pLCAuLi57IHNpemU6IHVpbnQ4QXJyYXkubGVuZ3RoIH0gfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmVhZCBidWZmZXIgZnJvbSB0b2tlbml6ZXJcbiAgICAgKiBAcGFyYW0gdWludDhBcnJheSAtIFVpbnQ4QXJyYXkgdG8gdG9rZW5pemVcbiAgICAgKiBAcGFyYW0gb3B0aW9ucyAtIFJlYWQgYmVoYXZpb3VyIG9wdGlvbnNcbiAgICAgKiBAcmV0dXJucyB7UHJvbWlzZTxudW1iZXI+fVxuICAgICAqL1xuICAgIGFzeW5jIHJlYWRCdWZmZXIodWludDhBcnJheSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBub3JtT3B0aW9ucyA9IHRoaXMubm9ybWFsaXplT3B0aW9ucyh1aW50OEFycmF5LCBvcHRpb25zKTtcbiAgICAgICAgY29uc3QgYnl0ZXNSZWFkID0gYXdhaXQgdGhpcy5wZWVrQnVmZmVyKHVpbnQ4QXJyYXksIG5vcm1PcHRpb25zKTtcbiAgICAgICAgdGhpcy5wb3NpdGlvbiA9IG5vcm1PcHRpb25zLnBvc2l0aW9uICsgYnl0ZXNSZWFkO1xuICAgICAgICByZXR1cm4gYnl0ZXNSZWFkO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQZWVrIChyZWFkIGFoZWFkKSBidWZmZXIgZnJvbSB0b2tlbml6ZXJcbiAgICAgKiBAcGFyYW0gdWludDhBcnJheVxuICAgICAqIEBwYXJhbSBvcHRpb25zIC0gUmVhZCBiZWhhdmlvdXIgb3B0aW9uc1xuICAgICAqIEByZXR1cm5zIHtQcm9taXNlPG51bWJlcj59XG4gICAgICovXG4gICAgYXN5bmMgcGVla0J1ZmZlcih1aW50OEFycmF5LCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IG5vcm1PcHRpb25zID0gdGhpcy5ub3JtYWxpemVPcHRpb25zKHVpbnQ4QXJyYXksIG9wdGlvbnMpO1xuICAgICAgICBjb25zdCBieXRlczJyZWFkID0gTWF0aC5tYXgoMCwgTWF0aC5taW4odGhpcy51aW50OEFycmF5Lmxlbmd0aCAtIG5vcm1PcHRpb25zLnBvc2l0aW9uLCBub3JtT3B0aW9ucy5sZW5ndGgpKTtcbiAgICAgICAgaWYgKCFub3JtT3B0aW9ucy5tYXlCZUxlc3MgJiYgYnl0ZXMycmVhZCA8IG5vcm1PcHRpb25zLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICB1aW50OEFycmF5LnNldCh0aGlzLnVpbnQ4QXJyYXkuc3ViYXJyYXkobm9ybU9wdGlvbnMucG9zaXRpb24sIG5vcm1PcHRpb25zLnBvc2l0aW9uICsgYnl0ZXMycmVhZCkpO1xuICAgICAgICByZXR1cm4gYnl0ZXMycmVhZDtcbiAgICB9XG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHJldHVybiBzdXBlci5jbG9zZSgpO1xuICAgIH1cbiAgICBzdXBwb3J0c1JhbmRvbUFjY2VzcygpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHNldFBvc2l0aW9uKHBvc2l0aW9uKSB7XG4gICAgICAgIHRoaXMudmFsaWRhdGVMZW5ndGgocG9zaXRpb24sICdwb3NpdGlvbicpO1xuICAgICAgICB0aGlzLnBvc2l0aW9uID0gcG9zaXRpb247XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQWJzdHJhY3RUb2tlbml6ZXIgfSBmcm9tICcuL0Fic3RyYWN0VG9rZW5pemVyLmpzJztcbmltcG9ydCB7IEVuZE9mU3RyZWFtRXJyb3IgfSBmcm9tICcuL3N0cmVhbS9pbmRleC5qcyc7XG5jb25zdCBpZ25vcmVDaHVua1NpemUgPSAyNTYwMDA7XG5leHBvcnQgY2xhc3MgUmVhZFN0cmVhbVRva2VuaXplciBleHRlbmRzIEFic3RyYWN0VG9rZW5pemVyIHtcbiAgICAvKipcbiAgICAgKiBDb25zdHJ1Y3RvclxuICAgICAqIEBwYXJhbSBzdHJlYW1SZWFkZXIgc3RyZWFtLXJlYWRlciB0byByZWFkIGZyb21cbiAgICAgKiBAcGFyYW0gb3B0aW9ucyBUb2tlbml6ZXIgb3B0aW9uc1xuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKHN0cmVhbVJlYWRlciwgb3B0aW9ucykge1xuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5zdHJlYW1SZWFkZXIgPSBzdHJlYW1SZWFkZXI7XG4gICAgICAgIHRoaXMuZmlsZUluZm8gPSBvcHRpb25zPy5maWxlSW5mbyA/PyB7fTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmVhZCBidWZmZXIgZnJvbSB0b2tlbml6ZXJcbiAgICAgKiBAcGFyYW0gdWludDhBcnJheSAtIFRhcmdldCBVaW50OEFycmF5IHRvIGZpbGwgd2l0aCBkYXRhIHJlYWQgZnJvbSB0aGUgdG9rZW5pemVyLXN0cmVhbVxuICAgICAqIEBwYXJhbSBvcHRpb25zIC0gUmVhZCBiZWhhdmlvdXIgb3B0aW9uc1xuICAgICAqIEByZXR1cm5zIFByb21pc2Ugd2l0aCBudW1iZXIgb2YgYnl0ZXMgcmVhZFxuICAgICAqL1xuICAgIGFzeW5jIHJlYWRCdWZmZXIodWludDhBcnJheSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBub3JtT3B0aW9ucyA9IHRoaXMubm9ybWFsaXplT3B0aW9ucyh1aW50OEFycmF5LCBvcHRpb25zKTtcbiAgICAgICAgY29uc3Qgc2tpcEJ5dGVzID0gbm9ybU9wdGlvbnMucG9zaXRpb24gLSB0aGlzLnBvc2l0aW9uO1xuICAgICAgICBpZiAoc2tpcEJ5dGVzID4gMCkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5pZ25vcmUoc2tpcEJ5dGVzKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnJlYWRCdWZmZXIodWludDhBcnJheSwgb3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNraXBCeXRlcyA8IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYG9wdGlvbnMucG9zaXRpb25gIG11c3QgYmUgZXF1YWwgb3IgZ3JlYXRlciB0aGFuIGB0b2tlbml6ZXIucG9zaXRpb25gJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5vcm1PcHRpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGJ5dGVzUmVhZCA9IDA7XG4gICAgICAgIC8vIEFjY291bnQgZm9yIHBhcnRpYWwgaW5wdXQgYmVmb3JlIHJlcG9ydGluZyBhbiBleGFjdC1yZWFkIGZhaWx1cmUuXG4gICAgICAgIHdoaWxlIChieXRlc1JlYWQgPCBub3JtT3B0aW9ucy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IGNodW5rTGVuZ3RoID0gTWF0aC5taW4odGhpcy5tYXhCdWZmZXJTaXplLCBub3JtT3B0aW9ucy5sZW5ndGggLSBieXRlc1JlYWQpO1xuICAgICAgICAgICAgY29uc3QgY291bnQgPSBhd2FpdCB0aGlzLnN0cmVhbVJlYWRlci5yZWFkKHVpbnQ4QXJyYXkuc3ViYXJyYXkoYnl0ZXNSZWFkLCBieXRlc1JlYWQgKyBjaHVua0xlbmd0aCksIHRydWUpO1xuICAgICAgICAgICAgYnl0ZXNSZWFkICs9IGNvdW50O1xuICAgICAgICAgICAgdGhpcy5wb3NpdGlvbiArPSBjb3VudDtcbiAgICAgICAgICAgIGlmIChjb3VudCA8IGNodW5rTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFub3JtT3B0aW9ucy5tYXlCZUxlc3MgJiYgYnl0ZXNSZWFkIDwgbm9ybU9wdGlvbnMubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRW5kT2ZTdHJlYW1FcnJvcigpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBieXRlc1JlYWQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFBlZWsgKHJlYWQgYWhlYWQpIGJ1ZmZlciBmcm9tIHRva2VuaXplclxuICAgICAqIEBwYXJhbSB1aW50OEFycmF5IC0gVWludDhBcnJheSAob3IgQnVmZmVyKSB0byB3cml0ZSBkYXRhIHRvXG4gICAgICogQHBhcmFtIG9wdGlvbnMgLSBSZWFkIGJlaGF2aW91ciBvcHRpb25zXG4gICAgICogQHJldHVybnMgUHJvbWlzZSB3aXRoIG51bWJlciBvZiBieXRlcyBwZWVrZWRcbiAgICAgKi9cbiAgICBhc3luYyBwZWVrQnVmZmVyKHVpbnQ4QXJyYXksIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgbm9ybU9wdGlvbnMgPSB0aGlzLm5vcm1hbGl6ZU9wdGlvbnModWludDhBcnJheSwgb3B0aW9ucyk7XG4gICAgICAgIGlmIChub3JtT3B0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgICAgIC8vIEEga25vd24tZW1wdHkgcmFuZ2UgbmVlZHMgbmVpdGhlciBsb29rYWhlYWQgYWxsb2NhdGlvbiBub3Igc291cmNlIEkvTy5cbiAgICAgICAgaWYgKHRoaXMuZmlsZUluZm8uc2l6ZSAhPT0gdW5kZWZpbmVkICYmIG5vcm1PcHRpb25zLnBvc2l0aW9uID49IHRoaXMuZmlsZUluZm8uc2l6ZSkge1xuICAgICAgICAgICAgaWYgKG5vcm1PcHRpb25zLm1heUJlTGVzcykge1xuICAgICAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBsb29rYWhlYWRTaXplID0gbm9ybU9wdGlvbnMubGVuZ3RoICsgbm9ybU9wdGlvbnMucG9zaXRpb24gLSB0aGlzLnBvc2l0aW9uO1xuICAgICAgICB0aGlzLnZhbGlkYXRlQnVmZmVyU2l6ZShsb29rYWhlYWRTaXplKTtcbiAgICAgICAgbGV0IGJ5dGVzUmVhZCA9IDA7XG4gICAgICAgIGlmIChub3JtT3B0aW9ucy5wb3NpdGlvbikge1xuICAgICAgICAgICAgY29uc3Qgc2tpcEJ5dGVzID0gbm9ybU9wdGlvbnMucG9zaXRpb24gLSB0aGlzLnBvc2l0aW9uO1xuICAgICAgICAgICAgaWYgKHNraXBCeXRlcyA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBza2lwQnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkobm9ybU9wdGlvbnMubGVuZ3RoICsgc2tpcEJ5dGVzKTtcbiAgICAgICAgICAgICAgICBieXRlc1JlYWQgPSBhd2FpdCB0aGlzLnBlZWtCdWZmZXIoc2tpcEJ1ZmZlciwgeyBtYXlCZUxlc3M6IG5vcm1PcHRpb25zLm1heUJlTGVzcyB9KTtcbiAgICAgICAgICAgICAgICBjb25zdCBieXRlc1BlZWtlZCA9IE1hdGgubWF4KDAsIGJ5dGVzUmVhZCAtIHNraXBCeXRlcyk7XG4gICAgICAgICAgICAgICAgdWludDhBcnJheS5zZXQoc2tpcEJ1ZmZlci5zdWJhcnJheShza2lwQnl0ZXMsIHNraXBCeXRlcyArIGJ5dGVzUGVla2VkKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGJ5dGVzUGVla2VkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNraXBCeXRlcyA8IDApIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBwZWVrIGZyb20gYSBuZWdhdGl2ZSBvZmZzZXQgaW4gYSBzdHJlYW0nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAobm9ybU9wdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAvLyBUaGUgcmVhZGVyIHJldGFpbnMgdGhpcyBidWZmZXIuIEtlZXAgaXQgaW5kZXBlbmRlbnQgb2YgY2FsbGVyLW93bmVkIG1lbW9yeSxcbiAgICAgICAgICAgICAgICAvLyBpbmNsdWRpbmcgcGFydGlhbCBieXRlcyByZXRhaW5lZCB3aGVuIGFuIGV4YWN0IHBlZWsgZW5jb3VudGVycyB0cnVuY2F0aW9uLlxuICAgICAgICAgICAgICAgIGNvbnN0IHBlZWtCdWZmZXIgPSBuZXcgVWludDhBcnJheShub3JtT3B0aW9ucy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGJ5dGVzUmVhZCA9IGF3YWl0IHRoaXMuc3RyZWFtUmVhZGVyLnBlZWsocGVla0J1ZmZlciwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgdWludDhBcnJheS5zZXQocGVla0J1ZmZlci5zdWJhcnJheSgwLCBieXRlc1JlYWQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucz8ubWF5QmVMZXNzICYmIGVyciBpbnN0YW5jZW9mIEVuZE9mU3RyZWFtRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghbm9ybU9wdGlvbnMubWF5QmVMZXNzICYmIGJ5dGVzUmVhZCA8IG5vcm1PcHRpb25zLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFbmRPZlN0cmVhbUVycm9yKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGJ5dGVzUmVhZDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHBhcmFtIGxlbmd0aCBOdW1iZXIgb2YgYnl0ZXMgdG8gaWdub3JlLiBNdXN0IGJlIOKJpSAwLlxuICAgICAqL1xuICAgIGFzeW5jIGlnbm9yZShsZW5ndGgpIHtcbiAgICAgICAgaWYgKGxlbmd0aCA8IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdpZ25vcmUgbGVuZ3RoIG11c3QgYmUg4omlIDAgYnl0ZXMnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnZhbGlkYXRlTGVuZ3RoKGxlbmd0aCwgJ2lnbm9yZSBsZW5ndGgnKTtcbiAgICAgICAgdGhpcy52YWxpZGF0ZUxlbmd0aCh0aGlzLnBvc2l0aW9uICsgbGVuZ3RoLCAnZW5kIHBvc2l0aW9uJyk7XG4gICAgICAgIGlmIChsZW5ndGggPiAwICYmIHRoaXMuZmlsZUluZm8uc2l6ZSAhPT0gdW5kZWZpbmVkICYmIGxlbmd0aCA+IHRoaXMuZmlsZUluZm8uc2l6ZSAtIHRoaXMucG9zaXRpb24pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFbmRPZlN0cmVhbUVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYnVmU2l6ZSA9IE1hdGgubWluKGlnbm9yZUNodW5rU2l6ZSwgdGhpcy5tYXhCdWZmZXJTaXplLCBsZW5ndGgpO1xuICAgICAgICBjb25zdCBidWYgPSBuZXcgVWludDhBcnJheShidWZTaXplKTtcbiAgICAgICAgbGV0IHRvdEJ5dGVzUmVhZCA9IDA7XG4gICAgICAgIHdoaWxlICh0b3RCeXRlc1JlYWQgPCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IGxlbmd0aCAtIHRvdEJ5dGVzUmVhZDtcbiAgICAgICAgICAgIGNvbnN0IGJ5dGVzUmVhZCA9IGF3YWl0IHRoaXMucmVhZEJ1ZmZlcihidWYsIHsgbGVuZ3RoOiBNYXRoLm1pbihidWZTaXplLCByZW1haW5pbmcpIH0pO1xuICAgICAgICAgICAgaWYgKGJ5dGVzUmVhZCA8IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnl0ZXNSZWFkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdG90Qnl0ZXNSZWFkICs9IGJ5dGVzUmVhZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG90Qnl0ZXNSZWFkO1xuICAgIH1cbiAgICBhYm9ydCgpIHtcbiAgICAgICAgdGhpcy5yZW1vdmVBYm9ydExpc3RlbmVyKCk7XG4gICAgICAgIHJldHVybiB0aGlzLnN0cmVhbVJlYWRlci5hYm9ydCgpO1xuICAgIH1cbiAgICBhc3luYyBjbG9zZSgpIHtcbiAgICAgICAgdGhpcy5yZW1vdmVBYm9ydExpc3RlbmVyKCk7XG4gICAgICAgIHJldHVybiB0aGlzLnN0cmVhbVJlYWRlci5jbG9zZSgpO1xuICAgIH1cbiAgICBzdXBwb3J0c1JhbmRvbUFjY2VzcygpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IHRocm93SWZBYm9ydGVkIH0gZnJvbSAnLi9BYm9ydFNpZ25hbC5qcyc7XG5pbXBvcnQgeyBCbG9iVG9rZW5pemVyIH0gZnJvbSAnLi9CbG9iVG9rZW5pemVyLmpzJztcbmltcG9ydCB7IGdldE1heEJ1ZmZlclNpemUgfSBmcm9tICcuL0J1ZmZlclNpemVFcnJvci5qcyc7XG5pbXBvcnQgeyBCdWZmZXJUb2tlbml6ZXIgfSBmcm9tICcuL0J1ZmZlclRva2VuaXplci5qcyc7XG5pbXBvcnQgeyBSZWFkU3RyZWFtVG9rZW5pemVyIH0gZnJvbSAnLi9SZWFkU3RyZWFtVG9rZW5pemVyLmpzJztcbmltcG9ydCB7IG1ha2VXZWJTdHJlYW1SZWFkZXIsIFN0cmVhbVJlYWRlciB9IGZyb20gJy4vc3RyZWFtL2luZGV4LmpzJztcbmV4cG9ydCB7IEFic3RyYWN0VG9rZW5pemVyIH0gZnJvbSAnLi9BYnN0cmFjdFRva2VuaXplci5qcyc7XG5leHBvcnQgeyBCdWZmZXJTaXplRXJyb3IgfSBmcm9tICcuL0J1ZmZlclNpemVFcnJvci5qcyc7XG5leHBvcnQgeyBpc1JhbmRvbUFjY2Vzc1Rva2VuaXplciB9IGZyb20gJy4vaXNSYW5kb21BY2Nlc3NUb2tlbml6ZXIuanMnO1xuZXhwb3J0IHsgQWJvcnRFcnJvciwgRW5kT2ZTdHJlYW1FcnJvciB9IGZyb20gJy4vc3RyZWFtL2luZGV4LmpzJztcbmV4cG9ydCB7IFRva2VuaXplckJvdW5kYXJ5RXJyb3IgfSBmcm9tICcuL1Rva2VuaXplckJvdW5kYXJ5RXJyb3IuanMnO1xuZXhwb3J0IHsgY3JlYXRlVG9rZW5pemVyVmlldyB9IGZyb20gJy4vVG9rZW5pemVyVmlldy5qcyc7XG4vKipcbiAqIENvbnN0cnVjdCBSZWFkU3RyZWFtVG9rZW5pemVyIGZyb20gZ2l2ZW4gU3RyZWFtLlxuICogV2lsbCBzZXQgZmlsZVNpemUsIGlmIHByb3ZpZGVkIGdpdmVuIFN0cmVhbSBoYXMgc2V0IHRoZSAucGF0aCBwcm9wZXJ0eS9cbiAqIEBwYXJhbSBzdHJlYW0gLSBSZWFkIGZyb20gTm9kZS5qcyBTdHJlYW0uUmVhZGFibGVcbiAqIEBwYXJhbSBvcHRpb25zIC0gVG9rZW5pemVyIG9wdGlvbnNcbiAqIEByZXR1cm5zIFJlYWRTdHJlYW1Ub2tlbml6ZXJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZyb21TdHJlYW0oc3RyZWFtLCBvcHRpb25zKSB7XG4gICAgZ2V0TWF4QnVmZmVyU2l6ZShvcHRpb25zKTtcbiAgICB0aHJvd0lmQWJvcnRlZChvcHRpb25zPy5hYm9ydFNpZ25hbCk7XG4gICAgY29uc3Qgc3RyZWFtUmVhZGVyID0gbmV3IFN0cmVhbVJlYWRlcihzdHJlYW0pO1xuICAgIHJldHVybiBuZXcgUmVhZFN0cmVhbVRva2VuaXplcihzdHJlYW1SZWFkZXIsIG9wdGlvbnMpO1xufVxuLyoqXG4gKiBDb25zdHJ1Y3QgUmVhZFN0cmVhbVRva2VuaXplciBmcm9tIGdpdmVuIFJlYWRhYmxlU3RyZWFtIChXZWJTdHJlYW0gQVBJKS5cbiAqIFdpbGwgc2V0IGZpbGVTaXplLCBpZiBwcm92aWRlZCBnaXZlbiBTdHJlYW0gaGFzIHNldCB0aGUgLnBhdGggcHJvcGVydHkvXG4gKiBAcGFyYW0gd2ViU3RyZWFtIC0gUmVhZCBmcm9tIE5vZGUuanMgU3RyZWFtLlJlYWRhYmxlIChtdXN0IGJlIGEgYnl0ZSBzdHJlYW0pXG4gKiBAcGFyYW0gb3B0aW9ucyAtIFRva2VuaXplciBvcHRpb25zXG4gKiBAcmV0dXJucyBSZWFkU3RyZWFtVG9rZW5pemVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmcm9tV2ViU3RyZWFtKHdlYlN0cmVhbSwgb3B0aW9ucykge1xuICAgIGdldE1heEJ1ZmZlclNpemUob3B0aW9ucyk7XG4gICAgdGhyb3dJZkFib3J0ZWQob3B0aW9ucz8uYWJvcnRTaWduYWwpO1xuICAgIGNvbnN0IHdlYlN0cmVhbVJlYWRlciA9IG1ha2VXZWJTdHJlYW1SZWFkZXIod2ViU3RyZWFtKTtcbiAgICByZXR1cm4gbmV3IFJlYWRTdHJlYW1Ub2tlbml6ZXIod2ViU3RyZWFtUmVhZGVyLCBvcHRpb25zKTtcbn1cbi8qKlxuICogQ29uc3RydWN0IFJlYWRTdHJlYW1Ub2tlbml6ZXIgZnJvbSBnaXZlbiBCdWZmZXIuXG4gKiBAcGFyYW0gdWludDhBcnJheSAtIFVpbnQ4QXJyYXkgdG8gdG9rZW5pemVcbiAqIEBwYXJhbSBvcHRpb25zIC0gVG9rZW5pemVyIG9wdGlvbnNcbiAqIEByZXR1cm5zIEJ1ZmZlclRva2VuaXplclxuICovXG5leHBvcnQgZnVuY3Rpb24gZnJvbUJ1ZmZlcih1aW50OEFycmF5LCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIG5ldyBCdWZmZXJUb2tlbml6ZXIodWludDhBcnJheSwgb3B0aW9ucyk7XG59XG4vKipcbiAqIENvbnN0cnVjdCBSZWFkU3RyZWFtVG9rZW5pemVyIGZyb20gZ2l2ZW4gQmxvYi5cbiAqIEBwYXJhbSBibG9iIC0gVWludDhBcnJheSB0byB0b2tlbml6ZVxuICogQHBhcmFtIG9wdGlvbnMgLSBUb2tlbml6ZXIgb3B0aW9uc1xuICogQHJldHVybnMgQnVmZmVyVG9rZW5pemVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmcm9tQmxvYihibG9iLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIG5ldyBCbG9iVG9rZW5pemVyKGJsb2IsIG9wdGlvbnMpO1xufVxuIiwiaW1wb3J0IHsgdGV4dERlY29kZSwgdGV4dEVuY29kZSB9IGZyb20gJ0Bib3Jld2l0L3RleHQtY29kZWMnO1xuaW1wb3J0IHsgRmllbGREZWNvZGluZ0Vycm9yLCBJbnRlcm5hbFBhcnNlckVycm9yIH0gZnJvbSAnLi4vUGFyc2VFcnJvci5qcyc7XG5pbXBvcnQgKiBhcyB1dGlsIGZyb20gJy4vVXRpbC5qcyc7XG5jb25zdCB2YWxpZEZvdXJDQyA9IC9eW1xceDIxLVxceDdlwqldW1xceDIwLVxceDdlXFx4MDAoKV17M30vO1xuLyoqXG4gKiBUb2tlbiBmb3IgcmVhZCBGb3VyQ0NcbiAqIFJlZjogaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvRm91ckNDXG4gKi9cbmV4cG9ydCBjb25zdCBGb3VyQ2NUb2tlbiA9IHtcbiAgICBsZW46IDQsXG4gICAgZ2V0OiAoYnVmLCBvZmYpID0+IHtcbiAgICAgICAgY29uc3QgaWQgPSB0ZXh0RGVjb2RlKGJ1Zi5zdWJhcnJheShvZmYsIG9mZiArIEZvdXJDY1Rva2VuLmxlbiksICdsYXRpbjEnKTtcbiAgICAgICAgaWYgKCFpZC5tYXRjaCh2YWxpZEZvdXJDQykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBGaWVsZERlY29kaW5nRXJyb3IoYEZvdXJDQyBjb250YWlucyBpbnZhbGlkIGNoYXJhY3RlcnM6ICR7dXRpbC5hMmhleChpZCl9IFwiJHtpZH1cImApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpZDtcbiAgICB9LFxuICAgIHB1dDogKGJ1ZmZlciwgb2Zmc2V0LCBpZCkgPT4ge1xuICAgICAgICBjb25zdCBzdHIgPSB0ZXh0RW5jb2RlKGlkLCAnbGF0aW4xJyk7XG4gICAgICAgIGlmIChzdHIubGVuZ3RoICE9PSA0KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgSW50ZXJuYWxQYXJzZXJFcnJvcignSW52YWxpZCBsZW5ndGgnKTtcbiAgICAgICAgfVxuICAgICAgICBidWZmZXIuc2V0KHN0ciwgb2Zmc2V0KTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDQ7XG4gICAgfVxufTtcbiIsImltcG9ydCAqIGFzIFRva2VuIGZyb20gJ3Rva2VuLXR5cGVzJztcbmltcG9ydCB7IEZvdXJDY1Rva2VuIH0gZnJvbSAnLi4vY29tbW9uL0ZvdXJDQy5qcyc7XG5leHBvcnQgY29uc3QgRGF0YVR5cGUgPSB7XG4gICAgdGV4dF91dGY4OiAwLFxuICAgIGJpbmFyeTogMSxcbiAgICBleHRlcm5hbF9pbmZvOiAyLFxuICAgIHJlc2VydmVkOiAzXG59O1xuLyoqXG4gKiBBUEVfREVTQ1JJUFRPUjogZGVmaW5lcyB0aGUgc2l6ZXMgKGFuZCBvZmZzZXRzKSBvZiBhbGwgdGhlIHBpZWNlcywgYXMgd2VsbCBhcyB0aGUgTUQ1IGNoZWNrc3VtXG4gKi9cbmV4cG9ydCBjb25zdCBEZXNjcmlwdG9yUGFyc2VyID0ge1xuICAgIGxlbjogNTIsXG4gICAgZ2V0OiAoYnVmLCBvZmYpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIHNob3VsZCBlcXVhbCAnTUFDICdcbiAgICAgICAgICAgIElEOiBGb3VyQ2NUb2tlbi5nZXQoYnVmLCBvZmYpLFxuICAgICAgICAgICAgLy8gdmVyc2lvbkluZGV4IG51bWJlciAqIDEwMDAgKDMuODEgPSAzODEwKSAocmVtZW1iZXIgdGhhdCA0LWJ5dGUgYWxpZ25tZW50IGNhdXNlcyB0aGlzIHRvIHRha2UgNC1ieXRlcylcbiAgICAgICAgICAgIHZlcnNpb246IFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyA0KSAvIDEwMDAsXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGRlc2NyaXB0b3IgYnl0ZXMgKGFsbG93cyBsYXRlciBleHBhbnNpb24gb2YgdGhpcyBoZWFkZXIpXG4gICAgICAgICAgICBkZXNjcmlwdG9yQnl0ZXM6IFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyA4KSxcbiAgICAgICAgICAgIC8vIHRoZSBudW1iZXIgb2YgaGVhZGVyIEFQRV9IRUFERVIgYnl0ZXNcbiAgICAgICAgICAgIGhlYWRlckJ5dGVzOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgMTIpLFxuICAgICAgICAgICAgLy8gdGhlIG51bWJlciBvZiBoZWFkZXIgQVBFX0hFQURFUiBieXRlc1xuICAgICAgICAgICAgc2Vla1RhYmxlQnl0ZXM6IFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyAxNiksXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGhlYWRlciBkYXRhIGJ5dGVzIChmcm9tIG9yaWdpbmFsIGZpbGUpXG4gICAgICAgICAgICBoZWFkZXJEYXRhQnl0ZXM6IFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyAyMCksXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGJ5dGVzIG9mIEFQRSBmcmFtZSBkYXRhXG4gICAgICAgICAgICBhcGVGcmFtZURhdGFCeXRlczogVG9rZW4uVUlOVDMyX0xFLmdldChidWYsIG9mZiArIDI0KSxcbiAgICAgICAgICAgIC8vIHRoZSBoaWdoIG9yZGVyIG51bWJlciBvZiBBUEUgZnJhbWUgZGF0YSBieXRlc1xuICAgICAgICAgICAgYXBlRnJhbWVEYXRhQnl0ZXNIaWdoOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgMjgpLFxuICAgICAgICAgICAgLy8gdGhlIHRlcm1pbmF0aW5nIGRhdGEgb2YgdGhlIGZpbGUgKG5vdCBpbmNsdWRpbmcgdGFnIGRhdGEpXG4gICAgICAgICAgICB0ZXJtaW5hdGluZ0RhdGFCeXRlczogVG9rZW4uVUlOVDMyX0xFLmdldChidWYsIG9mZiArIDMyKSxcbiAgICAgICAgICAgIC8vIHRoZSBNRDUgaGFzaCBvZiB0aGUgZmlsZSAoc2VlIG5vdGVzIGZvciB1c2FnZS4uLiBpdCdzIGEgbGl0dGxlIHRyaWNreSlcbiAgICAgICAgICAgIGZpbGVNRDU6IG5ldyBUb2tlbi5VaW50OEFycmF5VHlwZSgxNikuZ2V0KGJ1Ziwgb2ZmICsgMzYpXG4gICAgICAgIH07XG4gICAgfVxufTtcbi8qKlxuICogQVBFX0hFQURFUjogZGVzY3JpYmVzIGFsbCBvZiB0aGUgbmVjZXNzYXJ5IGluZm9ybWF0aW9uIGFib3V0IHRoZSBBUEUgZmlsZVxuICovXG5leHBvcnQgY29uc3QgSGVhZGVyID0ge1xuICAgIGxlbjogMjQsXG4gICAgZ2V0OiAoYnVmLCBvZmYpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIHRoZSBjb21wcmVzc2lvbiBsZXZlbCAoc2VlIGRlZmluZXMgSS5FLiBDT01QUkVTU0lPTl9MRVZFTF9GQVNUKVxuICAgICAgICAgICAgY29tcHJlc3Npb25MZXZlbDogVG9rZW4uVUlOVDE2X0xFLmdldChidWYsIG9mZiksXG4gICAgICAgICAgICAvLyBhbnkgZm9ybWF0IGZsYWdzIChmb3IgZnV0dXJlIHVzZSlcbiAgICAgICAgICAgIGZvcm1hdEZsYWdzOiBUb2tlbi5VSU5UMTZfTEUuZ2V0KGJ1Ziwgb2ZmICsgMiksXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGF1ZGlvIGJsb2NrcyBpbiBvbmUgZnJhbWVcbiAgICAgICAgICAgIGJsb2Nrc1BlckZyYW1lOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgNCksXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGF1ZGlvIGJsb2NrcyBpbiB0aGUgZmluYWwgZnJhbWVcbiAgICAgICAgICAgIGZpbmFsRnJhbWVCbG9ja3M6IFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyA4KSxcbiAgICAgICAgICAgIC8vIHRoZSB0b3RhbCBudW1iZXIgb2YgZnJhbWVzXG4gICAgICAgICAgICB0b3RhbEZyYW1lczogVG9rZW4uVUlOVDMyX0xFLmdldChidWYsIG9mZiArIDEyKSxcbiAgICAgICAgICAgIC8vIHRoZSBiaXRzIHBlciBzYW1wbGUgKHR5cGljYWxseSAxNilcbiAgICAgICAgICAgIGJpdHNQZXJTYW1wbGU6IFRva2VuLlVJTlQxNl9MRS5nZXQoYnVmLCBvZmYgKyAxNiksXG4gICAgICAgICAgICAvLyB0aGUgbnVtYmVyIG9mIGNoYW5uZWxzICgxIG9yIDIpXG4gICAgICAgICAgICBjaGFubmVsOiBUb2tlbi5VSU5UMTZfTEUuZ2V0KGJ1Ziwgb2ZmICsgMTgpLFxuICAgICAgICAgICAgLy8gdGhlIHNhbXBsZSByYXRlICh0eXBpY2FsbHkgNDQxMDApXG4gICAgICAgICAgICBzYW1wbGVSYXRlOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgMjApXG4gICAgICAgIH07XG4gICAgfVxufTtcbi8qKlxuICogQVBFIFRhZyBIZWFkZXIvRm9vdGVyIFZlcnNpb24gMi4wXG4gKiBUQUc6IGRlc2NyaWJlcyBhbGwgdGhlIHByb3BlcnRpZXMgb2YgdGhlIGZpbGUgW29wdGlvbmFsXVxuICovXG5leHBvcnQgY29uc3QgVGFnRm9vdGVyID0ge1xuICAgIGxlbjogMzIsXG4gICAgZ2V0OiAoYnVmLCBvZmYpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC8vIHNob3VsZCBlcXVhbCAnQVBFVEFHRVgnXG4gICAgICAgICAgICBJRDogbmV3IFRva2VuLlN0cmluZ1R5cGUoOCwgJ2FzY2lpJykuZ2V0KGJ1Ziwgb2ZmKSxcbiAgICAgICAgICAgIC8vIGVxdWFscyBDVVJSRU5UX0FQRV9UQUdfVkVSU0lPTlxuICAgICAgICAgICAgdmVyc2lvbjogVG9rZW4uVUlOVDMyX0xFLmdldChidWYsIG9mZiArIDgpLFxuICAgICAgICAgICAgLy8gdGhlIGNvbXBsZXRlIHNpemUgb2YgdGhlIHRhZywgaW5jbHVkaW5nIHRoaXMgZm9vdGVyIChleGNsdWRlcyBoZWFkZXIpXG4gICAgICAgICAgICBzaXplOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgMTIpLFxuICAgICAgICAgICAgLy8gdGhlIG51bWJlciBvZiBmaWVsZHMgaW4gdGhlIHRhZ1xuICAgICAgICAgICAgZmllbGRzOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgMTYpLFxuICAgICAgICAgICAgLy8gcmVzZXJ2ZWQgZm9yIGxhdGVyIHVzZSAobXVzdCBiZSB6ZXJvKSxcbiAgICAgICAgICAgIGZsYWdzOiBwYXJzZVRhZ0ZsYWdzKFRva2VuLlVJTlQzMl9MRS5nZXQoYnVmLCBvZmYgKyAyMCkpXG4gICAgICAgIH07XG4gICAgfVxufTtcbi8qKlxuICogQVBFIFRhZyB2Mi4wIEl0ZW0gSGVhZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBUYWdJdGVtSGVhZGVyID0ge1xuICAgIGxlbjogOCxcbiAgICBnZXQ6IChidWYsIG9mZikgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLy8gTGVuZ3RoIG9mIGFzc2lnbmVkIHZhbHVlIGluIGJ5dGVzXG4gICAgICAgICAgICBzaXplOiBUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmKSxcbiAgICAgICAgICAgIC8vIHJlc2VydmVkIGZvciBsYXRlciB1c2UgKG11c3QgYmUgemVybyksXG4gICAgICAgICAgICBmbGFnczogcGFyc2VUYWdGbGFncyhUb2tlbi5VSU5UMzJfTEUuZ2V0KGJ1Ziwgb2ZmICsgNCkpXG4gICAgICAgIH07XG4gICAgfVxufTtcbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVRhZ0ZsYWdzKGZsYWdzKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY29udGFpbnNIZWFkZXI6IGlzQml0U2V0KGZsYWdzLCAzMSksXG4gICAgICAgIGNvbnRhaW5zRm9vdGVyOiBpc0JpdFNldChmbGFncywgMzApLFxuICAgICAgICBpc0hlYWRlcjogaXNCaXRTZXQoZmxhZ3MsIDI5KSxcbiAgICAgICAgcmVhZE9ubHk6IGlzQml0U2V0KGZsYWdzLCAwKSxcbiAgICAgICAgZGF0YVR5cGU6IChmbGFncyAmIDYpID4+IDFcbiAgICB9O1xufVxuLyoqXG4gKiBAcGFyYW0gbnVtIHtudW1iZXJ9XG4gKiBAcGFyYW0gYml0IDAgaXMgbGVhc3Qgc2lnbmlmaWNhbnQgYml0IChMU0IpXG4gKiBAcmV0dXJuIHtib29sZWFufSB0cnVlIGlmIGJpdCBpcyAxOyBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQml0U2V0KG51bSwgYml0KSB7XG4gICAgcmV0dXJuIChudW0gJiAoMSA8PCBiaXQpKSAhPT0gMDtcbn1cbiIsImltcG9ydCB7IHRleHREZWNvZGUgfSBmcm9tICdAYm9yZXdpdC90ZXh0LWNvZGVjJztcbmltcG9ydCBpbml0RGVidWcgZnJvbSAnZGVidWcnO1xuaW1wb3J0ICogYXMgc3RydG9rMyBmcm9tICdzdHJ0b2szJztcbmltcG9ydCB7IFN0cmluZ1R5cGUgfSBmcm9tICd0b2tlbi10eXBlcyc7XG5pbXBvcnQgeyBnZXRNYXhNZXRhZGF0YUVudHJpZXMsIGdldFRva2VuaXplck9wdGlvbnMsIHJlYWRCdWZmZXIgfSBmcm9tICcuLi9jb21tb24vQWxsb2NhdGlvbi5qcyc7XG5pbXBvcnQgeyBCYXNpY1BhcnNlciB9IGZyb20gJy4uL2NvbW1vbi9CYXNpY1BhcnNlci5qcyc7XG5pbXBvcnQgKiBhcyB1dGlsIGZyb20gJy4uL2NvbW1vbi9VdGlsLmpzJztcbmltcG9ydCB7IG1ha2VVbmV4cGVjdGVkRmlsZUNvbnRlbnRFcnJvciB9IGZyb20gJy4uL1BhcnNlRXJyb3IuanMnO1xuaW1wb3J0IHsgRGF0YVR5cGUsIERlc2NyaXB0b3JQYXJzZXIsIEhlYWRlciwgVGFnRm9vdGVyLCBUYWdJdGVtSGVhZGVyIH0gZnJvbSAnLi9BUEV2MlRva2VuLmpzJztcbmNvbnN0IGRlYnVnID0gaW5pdERlYnVnKCdtdXNpYy1tZXRhZGF0YTpwYXJzZXI6QVBFdjInKTtcbmNvbnN0IHRhZ0Zvcm1hdCA9ICdBUEV2Mic7XG5jb25zdCBwcmVhbWJsZSA9ICdBUEVUQUdFWCc7XG5leHBvcnQgY2xhc3MgQXBlQ29udGVudEVycm9yIGV4dGVuZHMgbWFrZVVuZXhwZWN0ZWRGaWxlQ29udGVudEVycm9yKCdBUEV2MicpIHtcbn1cbmV4cG9ydCBmdW5jdGlvbiB0cnlQYXJzZUFwZUhlYWRlcihtZXRhZGF0YSwgdG9rZW5pemVyLCBvcHRpb25zKSB7XG4gICAgY29uc3QgYXBlUGFyc2VyID0gbmV3IEFQRXYyUGFyc2VyKG1ldGFkYXRhLCB0b2tlbml6ZXIsIG9wdGlvbnMpO1xuICAgIHJldHVybiBhcGVQYXJzZXIudHJ5UGFyc2VBcGVIZWFkZXIoKTtcbn1cbmV4cG9ydCBjbGFzcyBBUEV2MlBhcnNlciBleHRlbmRzIEJhc2ljUGFyc2VyIHtcbiAgICAvKipcbiAgICAgKiBDYWxjdWxhdGUgdGhlIG1lZGlhIGZpbGUgZHVyYXRpb25cbiAgICAgKiBAcGFyYW0gYWggQXBlSGVhZGVyXG4gICAgICogQHJldHVybiB7bnVtYmVyfSBkdXJhdGlvbiBpbiBzZWNvbmRzXG4gICAgICovXG4gICAgc3RhdGljIGNhbGN1bGF0ZUR1cmF0aW9uKGFoKSB7XG4gICAgICAgIGxldCBkdXJhdGlvbiA9IGFoLnRvdGFsRnJhbWVzID4gMSA/IGFoLmJsb2Nrc1BlckZyYW1lICogKGFoLnRvdGFsRnJhbWVzIC0gMSkgOiAwO1xuICAgICAgICBkdXJhdGlvbiArPSBhaC5maW5hbEZyYW1lQmxvY2tzO1xuICAgICAgICByZXR1cm4gZHVyYXRpb24gLyBhaC5zYW1wbGVSYXRlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDYWxjdWxhdGVzIHRoZSBBUEV2MSAvIEFQRXYyIGZpcnN0IGZpZWxkIG9mZnNldFxuICAgICAqIEBwYXJhbSB0b2tlbml6ZXJcbiAgICAgKiBAcGFyYW0gb2Zmc2V0XG4gICAgICovXG4gICAgc3RhdGljIGFzeW5jIGZpbmRBcGVGb290ZXJPZmZzZXQodG9rZW5pemVyLCBvZmZzZXQpIHtcbiAgICAgICAgLy8gU2VhcmNoIGZvciBBUEUgZm9vdGVyIGhlYWRlciBhdCB0aGUgZW5kIG9mIHRoZSBmaWxlXG4gICAgICAgIGNvbnN0IGFwZUJ1ZiA9IG5ldyBVaW50OEFycmF5KFRhZ0Zvb3Rlci5sZW4pO1xuICAgICAgICBjb25zdCBwb3NpdGlvbiA9IHRva2VuaXplci5wb3NpdGlvbjtcbiAgICAgICAgaWYgKG9mZnNldCA8PSBUYWdGb290ZXIubGVuKSB7XG4gICAgICAgICAgICBkZWJ1ZyhgT2Zmc2V0IGlzIHRvbyBzbWFsbCB0byByZWFkIEFQRSBmb290ZXI6IG9mZnNldD0ke29mZnNldH1gKTtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9mZnNldCA+IFRhZ0Zvb3Rlci5sZW4pIHtcbiAgICAgICAgICAgIGF3YWl0IHRva2VuaXplci5yZWFkQnVmZmVyKGFwZUJ1ZiwgeyBwb3NpdGlvbjogb2Zmc2V0IC0gVGFnRm9vdGVyLmxlbiB9KTtcbiAgICAgICAgICAgIHRva2VuaXplci5zZXRQb3NpdGlvbihwb3NpdGlvbik7XG4gICAgICAgICAgICBjb25zdCB0YWdGb290ZXIgPSBUYWdGb290ZXIuZ2V0KGFwZUJ1ZiwgMCk7XG4gICAgICAgICAgICBpZiAodGFnRm9vdGVyLklEID09PSAnQVBFVEFHRVgnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRhZ0Zvb3Rlci5mbGFncy5pc0hlYWRlcikge1xuICAgICAgICAgICAgICAgICAgICBkZWJ1ZyhgQVBFIEhlYWRlciBmb3VuZCBhdCBvZmZzZXQ9JHtvZmZzZXQgLSBUYWdGb290ZXIubGVufWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZGVidWcoYEFQRSBGb290ZXIgZm91bmQgYXQgb2Zmc2V0PSR7b2Zmc2V0IC0gVGFnRm9vdGVyLmxlbn1gKTtcbiAgICAgICAgICAgICAgICAgICAgb2Zmc2V0IC09IHRhZ0Zvb3Rlci5zaXplO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4geyBmb290ZXI6IHRhZ0Zvb3Rlciwgb2Zmc2V0IH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgc3RhdGljIHBhcnNlVGFnRm9vdGVyKG1ldGFkYXRhLCBidWZmZXIsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgZm9vdGVyID0gVGFnRm9vdGVyLmdldChidWZmZXIsIGJ1ZmZlci5sZW5ndGggLSBUYWdGb290ZXIubGVuKTtcbiAgICAgICAgaWYgKGZvb3Rlci5JRCAhPT0gcHJlYW1ibGUpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBBcGVDb250ZW50RXJyb3IoJ1VuZXhwZWN0ZWQgQVBFdjIgRm9vdGVyIElEIHByZWFtYmxlIHZhbHVlJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYXBlUGFyc2VyID0gbmV3IEFQRXYyUGFyc2VyKG1ldGFkYXRhLCBzdHJ0b2szLmZyb21CdWZmZXIoYnVmZmVyLCBnZXRUb2tlbml6ZXJPcHRpb25zKG9wdGlvbnMpKSwgb3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBhcGVQYXJzZXIucGFyc2VUYWdzKGZvb3Rlcik7XG4gICAgfVxuICAgIGFwZSA9IHt9O1xuICAgIC8qKlxuICAgICAqIFBhcnNlIEFQRXYxIC8gQVBFdjIgaGVhZGVyIGlmIGhlYWRlciBzaWduYXR1cmUgZm91bmRcbiAgICAgKi9cbiAgICBhc3luYyB0cnlQYXJzZUFwZUhlYWRlcigpIHtcbiAgICAgICAgaWYgKHRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemUgJiYgdGhpcy50b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAtIHRoaXMudG9rZW5pemVyLnBvc2l0aW9uIDwgVGFnRm9vdGVyLmxlbikge1xuICAgICAgICAgICAgZGVidWcoJ05vIEFQRXYyIGhlYWRlciBmb3VuZCwgZW5kLW9mLWZpbGUgcmVhY2hlZCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZvb3RlciA9IGF3YWl0IHRoaXMudG9rZW5pemVyLnBlZWtUb2tlbihUYWdGb290ZXIpO1xuICAgICAgICBpZiAoZm9vdGVyLklEID09PSBwcmVhbWJsZSkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy50b2tlbml6ZXIuaWdub3JlKFRhZ0Zvb3Rlci5sZW4pO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VUYWdzKGZvb3Rlcik7XG4gICAgICAgIH1cbiAgICAgICAgZGVidWcoYEFQRXYyIGhlYWRlciBub3QgZm91bmQgYXQgb2Zmc2V0PSR7dGhpcy50b2tlbml6ZXIucG9zaXRpb259YCk7XG4gICAgICAgIGlmICh0aGlzLnRva2VuaXplci5maWxlSW5mby5zaXplKSB7XG4gICAgICAgICAgICAvLyBUcnkgdG8gcmVhZCB0aGUgQVBFdjIgaGVhZGVyIHVzaW5nIGp1c3QgdGhlIGZvb3Rlci1oZWFkZXJcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IHRoaXMudG9rZW5pemVyLmZpbGVJbmZvLnNpemUgLSB0aGlzLnRva2VuaXplci5wb3NpdGlvbjsgLy8gVG9EbzogdGFrZSBJRDN2MSBpbnRvIGFjY291bnRcbiAgICAgICAgICAgIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IHRoaXMucmVhZFRhZ1ZhbHVlKHJlbWFpbmluZyk7XG4gICAgICAgICAgICByZXR1cm4gQVBFdjJQYXJzZXIucGFyc2VUYWdGb290ZXIodGhpcy5tZXRhZGF0YSwgYnVmZmVyLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIHBhcnNlKCkge1xuICAgICAgICBjb25zdCBkZXNjcmlwdG9yID0gYXdhaXQgdGhpcy50b2tlbml6ZXIucmVhZFRva2VuKERlc2NyaXB0b3JQYXJzZXIpO1xuICAgICAgICBpZiAoZGVzY3JpcHRvci5JRCAhPT0gJ01BQyAnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgQXBlQ29udGVudEVycm9yKCdVbmV4cGVjdGVkIGRlc2NyaXB0b3IgSUQnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFwZS5kZXNjcmlwdG9yID0gZGVzY3JpcHRvcjtcbiAgICAgICAgY29uc3QgbGVuRXhwID0gZGVzY3JpcHRvci5kZXNjcmlwdG9yQnl0ZXMgLSBEZXNjcmlwdG9yUGFyc2VyLmxlbjtcbiAgICAgICAgY29uc3QgaGVhZGVyID0gYXdhaXQgKGxlbkV4cCA+IDAgPyB0aGlzLnBhcnNlRGVzY3JpcHRvckV4cGFuc2lvbihsZW5FeHApIDogdGhpcy5wYXJzZUhlYWRlcigpKTtcbiAgICAgICAgdGhpcy5tZXRhZGF0YS5zZXRBdWRpb09ubHkoKTtcbiAgICAgICAgYXdhaXQgdGhpcy50b2tlbml6ZXIuaWdub3JlKGhlYWRlci5mb3J3YXJkQnl0ZXMpO1xuICAgICAgICByZXR1cm4gdGhpcy50cnlQYXJzZUFwZUhlYWRlcigpO1xuICAgIH1cbiAgICBhc3luYyBwYXJzZVRhZ3MoZm9vdGVyKSB7XG4gICAgICAgIGlmIChmb290ZXIuZmllbGRzID4gZ2V0TWF4TWV0YWRhdGFFbnRyaWVzKHRoaXMub3B0aW9ucykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBBcGVDb250ZW50RXJyb3IoYFRhZyBpdGVtIGNvdW50ICR7Zm9vdGVyLmZpZWxkc30gZXhjZWVkcyBlbnRyeSBsaW1pdCAke2dldE1heE1ldGFkYXRhRW50cmllcyh0aGlzLm9wdGlvbnMpfWApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGtleUJ1ZmZlciA9IG5ldyBVaW50OEFycmF5KDI1Nik7IC8vIG1heGltdW0gdGFnIGtleSBsZW5ndGhcbiAgICAgICAgbGV0IGJ5dGVzUmVtYWluaW5nID0gZm9vdGVyLnNpemUgLSBUYWdGb290ZXIubGVuO1xuICAgICAgICBkZWJ1ZyhgUGFyc2UgQVBFIHRhZ3MgYXQgb2Zmc2V0PSR7dGhpcy50b2tlbml6ZXIucG9zaXRpb259LCBzaXplPSR7Ynl0ZXNSZW1haW5pbmd9YCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm9vdGVyLmZpZWxkczsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoYnl0ZXNSZW1haW5pbmcgPCBUYWdJdGVtSGVhZGVyLmxlbikge1xuICAgICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuYWRkV2FybmluZyhgQVBFdjIgVGFnLWhlYWRlcjogJHtmb290ZXIuZmllbGRzIC0gaX0gaXRlbXMgcmVtYWluaW5nLCBidXQgbm8gbW9yZSB0YWcgZGF0YSB0byByZWFkLmApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gT25seSBBUEV2MiB0YWcgaGFzIHRhZyBpdGVtIGhlYWRlcnNcbiAgICAgICAgICAgIGNvbnN0IHRhZ0l0ZW1IZWFkZXIgPSBhd2FpdCB0aGlzLnRva2VuaXplci5yZWFkVG9rZW4oVGFnSXRlbUhlYWRlcik7XG4gICAgICAgICAgICBieXRlc1JlbWFpbmluZyAtPSBUYWdJdGVtSGVhZGVyLmxlbjtcbiAgICAgICAgICAgIC8vIFJlc2VydmUgdGhlIHZhbHVlIGJ5dGVzIGJlZm9yZSBsb29raW5nIGZvciB0aGUga2V5IHRlcm1pbmF0b3IuXG4gICAgICAgICAgICBpZiAodGFnSXRlbUhlYWRlci5zaXplID49IGJ5dGVzUmVtYWluaW5nKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwZUNvbnRlbnRFcnJvcihgSW52YWxpZCB0YWcgaXRlbSBzaXplOiAke3RhZ0l0ZW1IZWFkZXIuc2l6ZX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGtleUJ5dGVzID0gYXdhaXQgdGhpcy50b2tlbml6ZXIucGVla0J1ZmZlcihrZXlCdWZmZXIsIHtcbiAgICAgICAgICAgICAgICBsZW5ndGg6IE1hdGgubWluKGtleUJ1ZmZlci5sZW5ndGgsIGJ5dGVzUmVtYWluaW5nIC0gdGFnSXRlbUhlYWRlci5zaXplKSxcbiAgICAgICAgICAgICAgICBtYXlCZUxlc3M6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbGV0IHplcm8gPSBrZXlCdWZmZXIuc3ViYXJyYXkoMCwga2V5Qnl0ZXMpLmluZGV4T2YoMCk7XG4gICAgICAgICAgICBpZiAoemVybyA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgQXBlQ29udGVudEVycm9yKCdVbnRlcm1pbmF0ZWQgdGFnIGl0ZW0ga2V5Jyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBrZXkgPSBhd2FpdCB0aGlzLnRva2VuaXplci5yZWFkVG9rZW4obmV3IFN0cmluZ1R5cGUoemVybywgJ2FzY2lpJykpO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy50b2tlbml6ZXIuaWdub3JlKDEpO1xuICAgICAgICAgICAgYnl0ZXNSZW1haW5pbmcgLT0ga2V5Lmxlbmd0aCArIDE7XG4gICAgICAgICAgICBpZiAodGhpcy50b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICAgICAgdGFnSXRlbUhlYWRlci5zaXplID4gdGhpcy50b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAtIHRoaXMudG9rZW5pemVyLnBvc2l0aW9uKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwZUNvbnRlbnRFcnJvcihgSW52YWxpZCB0YWcgaXRlbSBzaXplOiAke3RhZ0l0ZW1IZWFkZXIuc2l6ZX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJ5dGVzUmVtYWluaW5nIC09IHRhZ0l0ZW1IZWFkZXIuc2l6ZTtcbiAgICAgICAgICAgIHN3aXRjaCAodGFnSXRlbUhlYWRlci5mbGFncy5kYXRhVHlwZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgRGF0YVR5cGUudGV4dF91dGY4OiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIHV0Zi04IHRleHQtc3RyaW5nXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGV4dERlY29kZShhd2FpdCB0aGlzLnJlYWRUYWdWYWx1ZSh0YWdJdGVtSGVhZGVyLnNpemUpLCAndXRmLTgnKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbHVlQ291bnQgPSAxO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBvZmZzZXQgPSB2YWx1ZS5pbmRleE9mKCdcXDAnKTsgb2Zmc2V0ID49IDA7IG9mZnNldCA9IHZhbHVlLmluZGV4T2YoJ1xcMCcsIG9mZnNldCArIDEpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICArK3ZhbHVlQ291bnQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlQ291bnQgPiBnZXRNYXhNZXRhZGF0YUVudHJpZXModGhpcy5vcHRpb25zKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEFwZUNvbnRlbnRFcnJvcihgVGV4dCB2YWx1ZSBjb3VudCAke3ZhbHVlQ291bnR9IGV4Y2VlZHMgZW50cnkgbGltaXQgJHtnZXRNYXhNZXRhZGF0YUVudHJpZXModGhpcy5vcHRpb25zKX1gKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSB2YWx1ZS5zcGxpdCgvXFx4MDAvZyk7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHZhbHVlcy5tYXAodmFsID0+IHRoaXMubWV0YWRhdGEuYWRkVGFnKHRhZ0Zvcm1hdCwga2V5LCB2YWwpKSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXNlIERhdGFUeXBlLmJpbmFyeTogLy8gYmluYXJ5IChwcm9iYWJseSBhcnR3b3JrKVxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5vcHRpb25zLnNraXBDb3ZlcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMudG9rZW5pemVyLmlnbm9yZSh0YWdJdGVtSGVhZGVyLnNpemUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGljRGF0YSA9IGF3YWl0IHRoaXMucmVhZFRhZ1ZhbHVlKHRhZ0l0ZW1IZWFkZXIuc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB6ZXJvID0gdXRpbC5maW5kWmVybyhwaWNEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGV4dERlY29kZShwaWNEYXRhLnN1YmFycmF5KDAsIHplcm8pLCAndXRmLTgnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBwaWNEYXRhLnN1YmFycmF5KHplcm8gKyAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMubWV0YWRhdGEuYWRkVGFnKHRhZ0Zvcm1hdCwga2V5LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBEYXRhVHlwZS5leHRlcm5hbF9pbmZvOlxuICAgICAgICAgICAgICAgICAgICBkZWJ1ZyhgSWdub3JlIGV4dGVybmFsIGluZm8gJHtrZXl9YCk7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMudG9rZW5pemVyLmlnbm9yZSh0YWdJdGVtSGVhZGVyLnNpemUpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIERhdGFUeXBlLnJlc2VydmVkOlxuICAgICAgICAgICAgICAgICAgICBkZWJ1ZyhgSWdub3JlIGV4dGVybmFsIGluZm8gJHtrZXl9YCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWV0YWRhdGEuYWRkV2FybmluZyhgQVBFdjIgaGVhZGVyIGRlY2xhcmVzIGEgcmVzZXJ2ZWQgZGF0YXR5cGUgZm9yIFwiJHtrZXl9XCJgKTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy50b2tlbml6ZXIuaWdub3JlKHRhZ0l0ZW1IZWFkZXIuc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIHJlYWRUYWdWYWx1ZShzaXplKSB7XG4gICAgICAgIHJldHVybiByZWFkQnVmZmVyKHRoaXMudG9rZW5pemVyLCBzaXplLCB0aGlzLm9wdGlvbnMsIHVuZGVmaW5lZCwgbWVzc2FnZSA9PiBuZXcgQXBlQ29udGVudEVycm9yKG1lc3NhZ2UpKTtcbiAgICB9XG4gICAgYXN5bmMgcGFyc2VEZXNjcmlwdG9yRXhwYW5zaW9uKGxlbkV4cCkge1xuICAgICAgICBhd2FpdCB0aGlzLnRva2VuaXplci5pZ25vcmUobGVuRXhwKTtcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VIZWFkZXIoKTtcbiAgICB9XG4gICAgYXN5bmMgcGFyc2VIZWFkZXIoKSB7XG4gICAgICAgIGNvbnN0IGhlYWRlciA9IGF3YWl0IHRoaXMudG9rZW5pemVyLnJlYWRUb2tlbihIZWFkZXIpO1xuICAgICAgICAvLyBUb0RvIGJlZm9yZVxuICAgICAgICB0aGlzLm1ldGFkYXRhLnNldEZvcm1hdCgnbG9zc2xlc3MnLCB0cnVlKTtcbiAgICAgICAgdGhpcy5tZXRhZGF0YS5zZXRGb3JtYXQoJ2NvbnRhaW5lcicsIFwiTW9ua2V5J3MgQXVkaW9cIik7XG4gICAgICAgIHRoaXMubWV0YWRhdGEuc2V0Rm9ybWF0KCdjb2RlYycsIFwiTW9ua2V5J3MgQXVkaW9cIik7XG4gICAgICAgIHRoaXMubWV0YWRhdGEuc2V0Rm9ybWF0KCdiaXRzUGVyU2FtcGxlJywgaGVhZGVyLmJpdHNQZXJTYW1wbGUpO1xuICAgICAgICB0aGlzLm1ldGFkYXRhLnNldEZvcm1hdCgnc2FtcGxlUmF0ZScsIGhlYWRlci5zYW1wbGVSYXRlKTtcbiAgICAgICAgdGhpcy5tZXRhZGF0YS5zZXRGb3JtYXQoJ251bWJlck9mQ2hhbm5lbHMnLCBoZWFkZXIuY2hhbm5lbCk7XG4gICAgICAgIHRoaXMubWV0YWRhdGEuc2V0Rm9ybWF0KCdkdXJhdGlvbicsIEFQRXYyUGFyc2VyLmNhbGN1bGF0ZUR1cmF0aW9uKGhlYWRlcikpO1xuICAgICAgICBpZiAoIXRoaXMuYXBlLmRlc2NyaXB0b3IpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBBcGVDb250ZW50RXJyb3IoJ01pc3NpbmcgQVBFIGRlc2NyaXB0b3InKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZm9yd2FyZEJ5dGVzOiB0aGlzLmFwZS5kZXNjcmlwdG9yLnNlZWtUYWJsZUJ5dGVzICtcbiAgICAgICAgICAgICAgICB0aGlzLmFwZS5kZXNjcmlwdG9yLmhlYWRlckRhdGFCeXRlcyArXG4gICAgICAgICAgICAgICAgdGhpcy5hcGUuZGVzY3JpcHRvci5hcGVGcmFtZURhdGFCeXRlcyArXG4gICAgICAgICAgICAgICAgdGhpcy5hcGUuZGVzY3JpcHRvci50ZXJtaW5hdGluZ0RhdGFCeXRlc1xuICAgICAgICB9O1xuICAgIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFFQSxTQUFnQixlQUFlLFFBQVE7Q0FDbkMsSUFBSSxRQUFRLFNBQ1IsTUFBTSxJQUFJLFdBQVc7QUFFN0I7OztBQ0xBLElBQWEsa0JBQWIsY0FBcUMsV0FBVzs7Ozs7O0NBTTVDLFlBQVksZUFBZSxlQUFlO0VBQ3RDLE1BQU0seUJBQXlCLGNBQWMseUJBQXlCLGVBQWU7RUFDckYsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxPQUFPO0NBQ2hCO0FBQ0o7Ozs7Ozs7QUFPQSxTQUFnQixpQkFBaUIsU0FBUztDQUN0QyxNQUFNLFFBQVEsU0FBUyxpQkFBaUIsT0FBTztDQUMvQyxJQUFJLFVBQVUsT0FBTyxzQkFBc0IsQ0FBQyxPQUFPLGNBQWMsS0FBSyxLQUFLLFNBQVMsSUFDaEYsTUFBTSxJQUFJLFdBQVcsMkRBQTJEO0NBRXBGLE9BQU87QUFDWDs7QUN6QkEsSUFBYSx1QkFBYixNQUFrQztDQUM5QixjQUFjO0VBQ1YsS0FBSyxjQUFjO0VBQ25CLEtBQUssY0FBYzs7Ozs7RUFLbkIsS0FBSyxZQUFZLENBQUM7Q0FDdEI7Q0FDQSxNQUFNLEtBQUssWUFBWSxZQUFZLE9BQU87RUFDdEMsTUFBTSxZQUFZLE1BQU0sS0FBSyxLQUFLLFlBQVksU0FBUztFQUN2RCxLQUFLLFVBQVUsS0FBSyxXQUFXLFNBQVMsR0FBRyxTQUFTLENBQUM7RUFDckQsT0FBTztDQUNYO0NBQ0EsTUFBTSxLQUFLLFFBQVEsWUFBWSxPQUFPO0VBQ2xDLElBQUksT0FBTyxXQUFXLEdBQ2xCLE9BQU87RUFFWCxJQUFJLFlBQVksS0FBSyxtQkFBbUIsTUFBTTtFQUM5QyxJQUFJLENBQUMsS0FBSyxhQUNOLGFBQWEsTUFBTSxLQUFLLHdCQUF3QixPQUFPLFNBQVMsU0FBUyxHQUFHLFNBQVM7RUFFekYsSUFBSSxjQUFjLEtBQUssQ0FBQyxXQUNwQixNQUFNLElBQUksaUJBQWlCO0VBRS9CLE9BQU87Q0FDWDs7Ozs7O0NBTUEsbUJBQW1CLFFBQVE7RUFDdkIsSUFBSSxZQUFZLE9BQU87RUFDdkIsSUFBSSxZQUFZO0VBRWhCLE9BQU8sS0FBSyxVQUFVLFNBQVMsS0FBSyxZQUFZLEdBQUc7R0FDL0MsTUFBTSxXQUFXLEtBQUssVUFBVSxJQUFJO0dBQ3BDLElBQUksQ0FBQyxVQUNELE1BQU0sSUFBSSxNQUFNLDRCQUE0QjtHQUVoRCxNQUFNLFVBQVUsS0FBSyxJQUFJLFNBQVMsUUFBUSxTQUFTO0dBQ25ELE9BQU8sSUFBSSxTQUFTLFNBQVMsR0FBRyxPQUFPLEdBQUcsU0FBUztHQUNuRCxhQUFhO0dBQ2IsYUFBYTtHQUNiLElBQUksVUFBVSxTQUFTLFFBRW5CLEtBQUssVUFBVSxLQUFLLFNBQVMsU0FBUyxPQUFPLENBQUM7RUFFdEQ7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLHdCQUF3QixRQUFRLFdBQVc7RUFDN0MsSUFBSSxZQUFZO0VBRWhCLE9BQU8sWUFBWSxPQUFPLFVBQVUsQ0FBQyxLQUFLLGFBQWE7R0FDbkQsSUFBSSxLQUFLLGFBQ0wsTUFBTSxJQUFJLFdBQVc7R0FFekIsTUFBTSxXQUFXLE1BQU0sS0FBSyxlQUFlLE9BQU8sU0FBUyxTQUFTLEdBQUcsU0FBUztHQUNoRixJQUFJLGFBQWEsR0FDYjtHQUVKLGFBQWE7RUFDakI7RUFDQSxJQUFJLENBQUMsYUFBYSxZQUFZLE9BQU8sUUFDakMsTUFBTSxJQUFJLGlCQUFpQjtFQUUvQixPQUFPO0NBQ1g7QUFDSjs7QUN2RUEsSUFBYSxrQkFBYixjQUFxQyxxQkFBcUI7Q0FDdEQsWUFBWSxRQUFRO0VBQ2hCLE1BQU07RUFDTixLQUFLLFNBQVM7Q0FDbEI7Q0FDQSxNQUFNLFFBQVE7RUFDVixPQUFPLEtBQUssTUFBTTtDQUN0QjtDQUNBLE1BQU0sUUFBUTtFQUNWLEtBQUssT0FBTyxZQUFZO0NBQzVCO0FBQ0o7Ozs7OztBQ1BBLElBQWEsc0JBQWIsY0FBeUMsZ0JBQWdCOzs7Ozs7O0NBT3JELE1BQU0sZUFBZSxRQUFRLFdBQVc7RUFDcEMsSUFBSSxPQUFPLFdBQVcsR0FDbEIsT0FBTztFQUVYLE1BQU0sU0FBUyxNQUFNLEtBQUssT0FBTyxLQUFLLElBQUksV0FBVyxPQUFPLE1BQU0sR0FBRyxFQUNqRSxLQUFLLFlBQVksS0FBQSxJQUFZLE9BQU8sT0FDeEMsQ0FBQztFQUNELElBQUksT0FBTyxNQUNQLEtBQUssY0FBYyxPQUFPO0VBRTlCLElBQUksT0FBTyxPQUFPO0dBQ2QsT0FBTyxJQUFJLE9BQU8sS0FBSztHQUN2QixPQUFPLE9BQU8sTUFBTTtFQUN4QjtFQUNBLE9BQU87Q0FDWDtBQUNKOztBQzFCQSxJQUFhLHlCQUFiLGNBQTRDLHFCQUFxQjtDQUM3RCxZQUFZLFFBQVE7RUFDaEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssU0FBUztDQUNsQjs7OztDQUlBLFdBQVcsUUFBUSxPQUFPO0VBQ3RCLE1BQU0sVUFBVSxLQUFLLElBQUksTUFBTSxRQUFRLE9BQU8sTUFBTTtFQUNwRCxPQUFPLElBQUksTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDO0VBRXJDLElBQUksVUFBVSxNQUFNLFFBQ2hCLEtBQUssU0FBUyxNQUFNLFNBQVMsT0FBTztPQUdwQyxLQUFLLFNBQVM7RUFFbEIsT0FBTztDQUNYOzs7Ozs7O0NBT0EsTUFBTSxlQUFlLFFBQVEsV0FBVztFQUNwQyxJQUFJLE9BQU8sV0FBVyxHQUNsQixPQUFPO0VBRVgsSUFBSSxpQkFBaUI7RUFFckIsSUFBSSxLQUFLLFFBQ0wsa0JBQWtCLEtBQUssV0FBVyxRQUFRLEtBQUssTUFBTTtFQUd6RCxPQUFPLGlCQUFpQixPQUFPLFVBQVUsQ0FBQyxLQUFLLGFBQWE7R0FDeEQsTUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFPLEtBQUs7R0FDdEMsSUFBSSxPQUFPLE1BQU07SUFDYixLQUFLLGNBQWM7SUFDbkI7R0FDSjtHQUNBLElBQUksT0FBTyxPQUNQLGtCQUFrQixLQUFLLFdBQVcsT0FBTyxTQUFTLGNBQWMsR0FBRyxPQUFPLEtBQUs7RUFFdkY7RUFDQSxJQUFJLENBQUMsYUFBYSxtQkFBbUIsS0FBSyxLQUFLLGFBQzNDLE1BQU0sSUFBSSxpQkFBaUI7RUFFL0IsT0FBTztDQUNYO0NBQ0EsUUFBUTtFQUNKLEtBQUssY0FBYztFQUNuQixPQUFPLEtBQUssT0FBTyxPQUFPO0NBQzlCO0NBQ0EsTUFBTSxRQUFRO0VBQ1YsSUFBSTtHQUNBLE1BQU0sS0FBSyxNQUFNO0VBQ3JCLFVBQ1E7R0FDSixLQUFLLE9BQU8sWUFBWTtFQUM1QjtDQUNKO0FBQ0o7O0FDaEVBLFNBQWdCLG9CQUFvQixRQUFRO0NBQ3hDLElBQUk7RUFDQSxNQUFNLFNBQVMsT0FBTyxVQUFVLEVBQUUsTUFBTSxPQUFPLENBQUM7RUFDaEQsSUFBSSxrQkFBa0IsNkJBRWxCLE9BQU8sSUFBSSx1QkFBdUIsTUFBTTtFQUU1QyxPQUFPLElBQUksb0JBQW9CLE1BQU07Q0FDekMsU0FDTyxPQUFPO0VBQ1YsSUFBSSxpQkFBaUIsV0FFakIsT0FBTyxJQUFJLHVCQUF1QixPQUFPLFVBQVUsQ0FBQztFQUV4RCxNQUFNO0NBQ1Y7QUFDSjs7Ozs7QUNaQSxJQUFhLG9CQUFiLE1BQStCOzs7Ozs7Q0FNM0IsWUFBWSxTQUFTO0VBQ2pCLEtBQUssNEJBQVksSUFBSSxXQUFXLEVBQUU7Ozs7RUFJbEMsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZ0JBQWdCLGlCQUFpQixPQUFPO0VBQzdDLGVBQWUsU0FBUyxXQUFXO0VBQ25DLEtBQUssVUFBVSxTQUFTO0VBQ3hCLElBQUksU0FBUyxhQUNULEtBQUssaUJBQWlCLFFBQVEsbUJBQW1CO0dBQzdDLEtBQVUsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUU5QixDQUFDO0VBQ0wsQ0FBQztDQUVUO0NBQ0EsaUJBQWlCLFFBQVEsVUFBVTtFQUMvQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxnQkFBZ0I7RUFDckIsT0FBTyxpQkFBaUIsU0FBUyxVQUFVLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDN0Q7Q0FDQSxzQkFBc0I7RUFDbEIsSUFBSSxLQUFLLGVBQ0wsS0FBSyxhQUFhLG9CQUFvQixTQUFTLEtBQUssYUFBYTtFQUVyRSxLQUFLLGNBQWMsS0FBQTtFQUNuQixLQUFLLGdCQUFnQixLQUFBO0NBQ3pCOzs7Ozs7O0NBT0EsTUFBTSxVQUFVLE9BQU8sV0FBVyxLQUFLLFVBQVU7RUFDN0MsS0FBSyxrQkFBa0IsTUFBTSxLQUFLLFFBQVE7RUFDMUMsTUFBTSxhQUFhLElBQUksV0FBVyxNQUFNLEdBQUc7RUFFM0MsSUFBSSxNQURjLEtBQUssV0FBVyxZQUFZLEVBQUUsU0FBUyxDQUFDLElBQ2hELE1BQU0sS0FDWixNQUFNLElBQUksaUJBQWlCO0VBRS9CLE9BQU8sTUFBTSxJQUFJLFlBQVksQ0FBQztDQUNsQzs7Ozs7OztDQU9BLE1BQU0sVUFBVSxPQUFPLFdBQVcsS0FBSyxVQUFVO0VBQzdDLE1BQU0sZUFBZSxZQUFZLEtBQUs7RUFDdEMsS0FBSyxrQkFBa0IsTUFBTSxLQUFLLGNBQWMsSUFBSTtFQUNwRCxNQUFNLGFBQWEsSUFBSSxXQUFXLE1BQU0sR0FBRztFQUUzQyxJQUFJLE1BRGMsS0FBSyxXQUFXLFlBQVksRUFBRSxVQUFVLGFBQWEsQ0FBQyxJQUM5RCxNQUFNLEtBQ1osTUFBTSxJQUFJLGlCQUFpQjtFQUUvQixPQUFPLE1BQU0sSUFBSSxZQUFZLENBQUM7Q0FDbEM7Ozs7OztDQU1BLE1BQU0sV0FBVyxPQUFPO0VBRXBCLElBQUksTUFEYyxLQUFLLFdBQVcsS0FBSyxXQUFXLEVBQUUsUUFBUSxNQUFNLElBQUksQ0FBQyxJQUM3RCxNQUFNLEtBQ1osTUFBTSxJQUFJLGlCQUFpQjtFQUUvQixPQUFPLE1BQU0sSUFBSSxLQUFLLFdBQVcsQ0FBQztDQUN0Qzs7Ozs7O0NBTUEsTUFBTSxXQUFXLE9BQU87RUFFcEIsSUFBSSxNQURjLEtBQUssV0FBVyxLQUFLLFdBQVcsRUFBRSxRQUFRLE1BQU0sSUFBSSxDQUFDLElBQzdELE1BQU0sS0FDWixNQUFNLElBQUksaUJBQWlCO0VBRS9CLE9BQU8sTUFBTSxJQUFJLEtBQUssV0FBVyxDQUFDO0NBQ3RDOzs7Ozs7Q0FNQSxNQUFNLE9BQU8sUUFBUTtFQUNqQixJQUFJLFNBQVMsR0FDVCxNQUFNLElBQUksV0FBVyxpQ0FBaUM7RUFFMUQsS0FBSyxlQUFlLFFBQVEsZUFBZTtFQUMzQyxLQUFLLGVBQWUsS0FBSyxXQUFXLFFBQVEsY0FBYztFQUMxRCxJQUFJLEtBQUssU0FBUyxTQUFTLEtBQUEsR0FBVztHQUNsQyxNQUFNLFlBQVksS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLE9BQU8sS0FBSyxRQUFRO0dBQ2hFLElBQUksU0FBUyxXQUFXO0lBQ3BCLEtBQUssWUFBWTtJQUNqQixPQUFPO0dBQ1g7RUFDSjtFQUNBLEtBQUssWUFBWTtFQUNqQixPQUFPO0NBQ1g7Q0FDQSxRQUFRO0VBQ0osSUFBSSxDQUFDLEtBQUssY0FBYztHQUNwQixLQUFLLG9CQUFvQjtHQUV6QixLQUFLLGVBQWUsUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDO0VBQ3JFO0VBQ0EsT0FBTyxLQUFLO0NBQ2hCOztDQUVBLE1BQU0sWUFBWTtFQUNkLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLE1BQU0sS0FBSyxVQUFVO0NBQ3pCOzs7Ozs7O0NBT0EsZUFBZSxPQUFPLE1BQU07RUFDeEIsSUFBSSxDQUFDLE9BQU8sY0FBYyxLQUFLLEtBQUssUUFBUSxHQUN4QyxNQUFNLElBQUksV0FBVyxHQUFHLEtBQUsscUNBQXFDO0NBRTFFOzs7Ozs7O0NBT0EsbUJBQW1CLFFBQVE7RUFDdkIsS0FBSyxlQUFlLFFBQVEsZUFBZTtFQUMzQyxJQUFJLFNBQVMsS0FBSyxlQUNkLE1BQU0sSUFBSSxnQkFBZ0IsUUFBUSxLQUFLLGFBQWE7Q0FFNUQ7Ozs7Ozs7Ozs7O0NBV0Esa0JBQWtCLFFBQVEsVUFBVSxPQUFPLE9BQU87RUFDOUMsS0FBSyxtQkFBbUIsTUFBTTtFQUM5QixLQUFLLGVBQWUsVUFBVSxVQUFVO0VBQ3hDLEtBQUssZUFBZSxXQUFXLFFBQVEsY0FBYztFQUNyRCxJQUFJLENBQUMsS0FBSyxxQkFBcUIsS0FBSyxXQUFXLEtBQUssVUFDaEQsTUFBTSxJQUFJLE1BQU0sdUVBQXVFO0VBRTNGLElBQUksUUFBUSxDQUFDLEtBQUsscUJBQXFCLEdBQ25DLEtBQUssbUJBQW1CLFNBQVMsV0FBVyxLQUFLLFFBQVE7RUFFN0QsSUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFBLEtBQWEsU0FBUyxLQUFLLFNBQVMsT0FBTyxVQUNsRSxNQUFNLElBQUksaUJBQWlCO0NBRW5DOzs7Ozs7Ozs7Q0FTQSxpQkFBaUIsWUFBWSxTQUFTO0VBQ2xDLE1BQU0sU0FBUyxTQUFTLFVBQVUsV0FBVztFQUM3QyxNQUFNLFdBQVcsU0FBUyxZQUFZLEtBQUs7RUFDM0MsS0FBSyxlQUFlLFFBQVEsUUFBUTtFQUNwQyxLQUFLLGVBQWUsVUFBVSxVQUFVO0VBQ3hDLEtBQUssZUFBZSxXQUFXLFFBQVEsY0FBYztFQUNyRCxJQUFJLFNBQVMsV0FBVyxRQUNwQixNQUFNLElBQUksV0FBVyxpREFBaUQ7RUFFMUUsSUFBSSxDQUFDLEtBQUsscUJBQXFCLEtBQUssV0FBVyxLQUFLLFVBQ2hELE1BQU0sSUFBSSxNQUFNLHVFQUF1RTtFQUUzRixPQUFPO0dBQUU7R0FBUTtHQUFVLFdBQVcsU0FBUyxhQUFhO0VBQU07Q0FDdEU7Q0FDQSxRQUFRO0VBQ0osS0FBSyxvQkFBb0I7RUFDekIsT0FBTyxRQUFRLFFBQVE7Q0FDM0I7QUFDSjs7QUN6TUEsSUFBYSxnQkFBYixjQUFtQyxrQkFBa0I7Ozs7OztDQU1qRCxZQUFZLE1BQU0sU0FBUztFQUN2QixNQUFNLE9BQU87RUFDYixLQUFLLE9BQU87RUFDWixLQUFLLFdBQVc7R0FBRSxHQUFJLFNBQVMsWUFBWSxDQUFDO0dBQVMsTUFBTSxLQUFLO0dBQU0sVUFBVSxLQUFLO0VBQU87Q0FDaEc7Ozs7Ozs7Q0FPQSxNQUFNLFdBQVcsWUFBWSxTQUFTO0VBQ2xDLE1BQU0sY0FBYyxLQUFLLGlCQUFpQixZQUFZLE9BQU87RUFDN0QsTUFBTSxZQUFZLE1BQU0sS0FBSyxXQUFXLFlBQVksV0FBVztFQUMvRCxLQUFLLFdBQVcsWUFBWSxXQUFXO0VBQ3ZDLE9BQU87Q0FDWDs7Ozs7OztDQU9BLE1BQU0sV0FBVyxRQUFRLFNBQVM7RUFDOUIsTUFBTSxjQUFjLEtBQUssaUJBQWlCLFFBQVEsT0FBTztFQUN6RCxNQUFNLGFBQWEsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFlBQVksVUFBVSxZQUFZLE1BQU0sQ0FBQztFQUNsRyxJQUFJLENBQUMsWUFBWSxhQUFhLGFBQWEsWUFBWSxRQUNuRCxNQUFNLElBQUksaUJBQWlCO0VBRS9CLEtBQUssSUFBSSxTQUFTLEdBQUcsU0FBUyxhQUFhO0dBQ3ZDLE1BQU0sY0FBYyxLQUFLLElBQUksS0FBSyxlQUFlLGFBQWEsTUFBTTtHQUNwRSxNQUFNLFdBQVcsWUFBWSxXQUFXO0dBQ3hDLE1BQU0sY0FBYyxNQUFNLEtBQUssS0FBSyxNQUFNLFVBQVUsV0FBVyxXQUFXLENBQUMsQ0FBQyxZQUFZO0dBQ3hGLE9BQU8sSUFBSSxJQUFJLFdBQVcsV0FBVyxHQUFHLE1BQU07R0FDOUMsVUFBVTtFQUNkO0VBQ0EsT0FBTztDQUNYO0NBQ0EsUUFBUTtFQUNKLE9BQU8sTUFBTSxNQUFNO0NBQ3ZCO0NBQ0EsdUJBQXVCO0VBQ25CLE9BQU87Q0FDWDtDQUNBLFlBQVksVUFBVTtFQUNsQixLQUFLLGVBQWUsVUFBVSxVQUFVO0VBQ3hDLEtBQUssV0FBVztDQUNwQjtBQUNKOztBQ3REQSxJQUFhLGtCQUFiLGNBQXFDLGtCQUFrQjs7Ozs7O0NBTW5ELFlBQVksWUFBWSxTQUFTO0VBQzdCLE1BQU0sT0FBTztFQUNiLEtBQUssYUFBYTtFQUNsQixLQUFLLFdBQVc7R0FBRSxHQUFJLFNBQVMsWUFBWSxDQUFDO0dBQVMsTUFBTSxXQUFXO0VBQVM7Q0FDbkY7Ozs7Ozs7Q0FPQSxNQUFNLFdBQVcsWUFBWSxTQUFTO0VBQ2xDLE1BQU0sY0FBYyxLQUFLLGlCQUFpQixZQUFZLE9BQU87RUFDN0QsTUFBTSxZQUFZLE1BQU0sS0FBSyxXQUFXLFlBQVksV0FBVztFQUMvRCxLQUFLLFdBQVcsWUFBWSxXQUFXO0VBQ3ZDLE9BQU87Q0FDWDs7Ozs7OztDQU9BLE1BQU0sV0FBVyxZQUFZLFNBQVM7RUFDbEMsTUFBTSxjQUFjLEtBQUssaUJBQWlCLFlBQVksT0FBTztFQUM3RCxNQUFNLGFBQWEsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssV0FBVyxTQUFTLFlBQVksVUFBVSxZQUFZLE1BQU0sQ0FBQztFQUMxRyxJQUFJLENBQUMsWUFBWSxhQUFhLGFBQWEsWUFBWSxRQUNuRCxNQUFNLElBQUksaUJBQWlCO0VBRS9CLFdBQVcsSUFBSSxLQUFLLFdBQVcsU0FBUyxZQUFZLFVBQVUsWUFBWSxXQUFXLFVBQVUsQ0FBQztFQUNoRyxPQUFPO0NBQ1g7Q0FDQSxRQUFRO0VBQ0osT0FBTyxNQUFNLE1BQU07Q0FDdkI7Q0FDQSx1QkFBdUI7RUFDbkIsT0FBTztDQUNYO0NBQ0EsWUFBWSxVQUFVO0VBQ2xCLEtBQUssZUFBZSxVQUFVLFVBQVU7RUFDeEMsS0FBSyxXQUFXO0NBQ3BCO0FBQ0o7O0FDaERBLElBQU0sa0JBQWtCO0FBQ3hCLElBQWEsc0JBQWIsY0FBeUMsa0JBQWtCOzs7Ozs7Q0FNdkQsWUFBWSxjQUFjLFNBQVM7RUFDL0IsTUFBTSxPQUFPO0VBQ2IsS0FBSyxlQUFlO0VBQ3BCLEtBQUssV0FBVyxTQUFTLFlBQVksQ0FBQztDQUMxQzs7Ozs7OztDQU9BLE1BQU0sV0FBVyxZQUFZLFNBQVM7RUFDbEMsTUFBTSxjQUFjLEtBQUssaUJBQWlCLFlBQVksT0FBTztFQUM3RCxNQUFNLFlBQVksWUFBWSxXQUFXLEtBQUs7RUFDOUMsSUFBSSxZQUFZLEdBQUc7R0FDZixNQUFNLEtBQUssT0FBTyxTQUFTO0dBQzNCLE9BQU8sS0FBSyxXQUFXLFlBQVksT0FBTztFQUM5QztFQUNBLElBQUksWUFBWSxHQUNaLE1BQU0sSUFBSSxNQUFNLHVFQUF1RTtFQUUzRixJQUFJLFlBQVksV0FBVyxHQUN2QixPQUFPO0VBRVgsSUFBSSxZQUFZO0VBRWhCLE9BQU8sWUFBWSxZQUFZLFFBQVE7R0FDbkMsTUFBTSxjQUFjLEtBQUssSUFBSSxLQUFLLGVBQWUsWUFBWSxTQUFTLFNBQVM7R0FDL0UsTUFBTSxRQUFRLE1BQU0sS0FBSyxhQUFhLEtBQUssV0FBVyxTQUFTLFdBQVcsWUFBWSxXQUFXLEdBQUcsSUFBSTtHQUN4RyxhQUFhO0dBQ2IsS0FBSyxZQUFZO0dBQ2pCLElBQUksUUFBUSxhQUNSO0VBRVI7RUFDQSxJQUFJLENBQUMsWUFBWSxhQUFhLFlBQVksWUFBWSxRQUNsRCxNQUFNLElBQUksaUJBQWlCO0VBRS9CLE9BQU87Q0FDWDs7Ozs7OztDQU9BLE1BQU0sV0FBVyxZQUFZLFNBQVM7RUFDbEMsTUFBTSxjQUFjLEtBQUssaUJBQWlCLFlBQVksT0FBTztFQUM3RCxJQUFJLFlBQVksV0FBVyxHQUN2QixPQUFPO0VBR1gsSUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFBLEtBQWEsWUFBWSxZQUFZLEtBQUssU0FBUyxNQUFNO0dBQ2hGLElBQUksWUFBWSxXQUNaLE9BQU87R0FFWCxNQUFNLElBQUksaUJBQWlCO0VBQy9CO0VBQ0EsTUFBTSxnQkFBZ0IsWUFBWSxTQUFTLFlBQVksV0FBVyxLQUFLO0VBQ3ZFLEtBQUssbUJBQW1CLGFBQWE7RUFDckMsSUFBSSxZQUFZO0VBQ2hCLElBQUksWUFBWSxVQUFVO0dBQ3RCLE1BQU0sWUFBWSxZQUFZLFdBQVcsS0FBSztHQUM5QyxJQUFJLFlBQVksR0FBRztJQUNmLE1BQU0sYUFBYSxJQUFJLFdBQVcsWUFBWSxTQUFTLFNBQVM7SUFDaEUsWUFBWSxNQUFNLEtBQUssV0FBVyxZQUFZLEVBQUUsV0FBVyxZQUFZLFVBQVUsQ0FBQztJQUNsRixNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUcsWUFBWSxTQUFTO0lBQ3JELFdBQVcsSUFBSSxXQUFXLFNBQVMsV0FBVyxZQUFZLFdBQVcsQ0FBQztJQUN0RSxPQUFPO0dBQ1g7R0FDQSxJQUFJLFlBQVksR0FDWixNQUFNLElBQUksTUFBTSxnREFBZ0Q7RUFFeEU7RUFDQSxJQUFJLFlBQVksU0FBUyxHQUFHO0dBQ3hCLElBQUk7SUFHQSxNQUFNLGFBQWEsSUFBSSxXQUFXLFlBQVksTUFBTTtJQUNwRCxZQUFZLE1BQU0sS0FBSyxhQUFhLEtBQUssWUFBWSxJQUFJO0lBQ3pELFdBQVcsSUFBSSxXQUFXLFNBQVMsR0FBRyxTQUFTLENBQUM7R0FDcEQsU0FDTyxLQUFLO0lBQ1IsSUFBSSxTQUFTLGFBQWEsZUFBZSxrQkFDckMsT0FBTztJQUVYLE1BQU07R0FDVjtHQUNBLElBQUksQ0FBQyxZQUFZLGFBQWEsWUFBWSxZQUFZLFFBQ2xELE1BQU0sSUFBSSxpQkFBaUI7RUFFbkM7RUFDQSxPQUFPO0NBQ1g7Ozs7Q0FJQSxNQUFNLE9BQU8sUUFBUTtFQUNqQixJQUFJLFNBQVMsR0FDVCxNQUFNLElBQUksV0FBVyxpQ0FBaUM7RUFFMUQsS0FBSyxlQUFlLFFBQVEsZUFBZTtFQUMzQyxLQUFLLGVBQWUsS0FBSyxXQUFXLFFBQVEsY0FBYztFQUMxRCxJQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsU0FBUyxLQUFBLEtBQWEsU0FBUyxLQUFLLFNBQVMsT0FBTyxLQUFLLFVBQ3JGLE1BQU0sSUFBSSxpQkFBaUI7RUFFL0IsTUFBTSxVQUFVLEtBQUssSUFBSSxpQkFBaUIsS0FBSyxlQUFlLE1BQU07RUFDcEUsTUFBTSxNQUFNLElBQUksV0FBVyxPQUFPO0VBQ2xDLElBQUksZUFBZTtFQUNuQixPQUFPLGVBQWUsUUFBUTtHQUMxQixNQUFNLFlBQVksU0FBUztHQUMzQixNQUFNLFlBQVksTUFBTSxLQUFLLFdBQVcsS0FBSyxFQUFFLFFBQVEsS0FBSyxJQUFJLFNBQVMsU0FBUyxFQUFFLENBQUM7R0FDckYsSUFBSSxZQUFZLEdBQ1osT0FBTztHQUVYLGdCQUFnQjtFQUNwQjtFQUNBLE9BQU87Q0FDWDtDQUNBLFFBQVE7RUFDSixLQUFLLG9CQUFvQjtFQUN6QixPQUFPLEtBQUssYUFBYSxNQUFNO0NBQ25DO0NBQ0EsTUFBTSxRQUFRO0VBQ1YsS0FBSyxvQkFBb0I7RUFDekIsT0FBTyxLQUFLLGFBQWEsTUFBTTtDQUNuQztDQUNBLHVCQUF1QjtFQUNuQixPQUFPO0NBQ1g7QUFDSjs7Ozs7Ozs7O0FDM0dBLFNBQWdCLGNBQWMsV0FBVyxTQUFTO0NBQzlDLGlCQUFpQixPQUFPO0NBQ3hCLGVBQWUsU0FBUyxXQUFXO0NBRW5DLE9BQU8sSUFBSSxvQkFEYSxvQkFBb0IsU0FDYixHQUFpQixPQUFPO0FBQzNEOzs7Ozs7O0FBT0EsU0FBZ0IsV0FBVyxZQUFZLFNBQVM7Q0FDNUMsT0FBTyxJQUFJLGdCQUFnQixZQUFZLE9BQU87QUFDbEQ7Ozs7Ozs7QUFPQSxTQUFnQixTQUFTLE1BQU0sU0FBUztDQUNwQyxPQUFPLElBQUksY0FBYyxNQUFNLE9BQU87QUFDMUM7OztBQ3BEQSxJQUFNLGNBQWM7Ozs7O0FBS3BCLElBQWEsY0FBYztDQUN2QixLQUFLO0NBQ0wsTUFBTSxLQUFLLFFBQVE7RUFDZixNQUFNLEtBQUssV0FBVyxJQUFJLFNBQVMsS0FBSyxNQUFNLFlBQVksR0FBRyxHQUFHLFFBQVE7RUFDeEUsSUFBSSxDQUFDLEdBQUcsTUFBTSxXQUFXLEdBQ3JCLE1BQU0sSUFBSSxtQkFBbUIsdUNBQXVDQSxNQUFXLEVBQUUsRUFBRSxJQUFJLEdBQUcsRUFBRTtFQUVoRyxPQUFPO0NBQ1g7Q0FDQSxNQUFNLFFBQVEsUUFBUSxPQUFPO0VBQ3pCLE1BQU0sTUFBTSxXQUFXLElBQUksUUFBUTtFQUNuQyxJQUFJLElBQUksV0FBVyxHQUNmLE1BQU0sSUFBSSxvQkFBb0IsZ0JBQWdCO0VBRWxELE9BQU8sSUFBSSxLQUFLLE1BQU07RUFDdEIsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7O0FDdkJBLElBQWEsV0FBVztDQUNwQixXQUFXO0NBQ1gsUUFBUTtDQUNSLGVBQWU7Q0FDZixVQUFVO0FBQ2Q7Ozs7QUFJQSxJQUFhLG1CQUFtQjtDQUM1QixLQUFLO0NBQ0wsTUFBTSxLQUFLLFFBQVE7RUFDZixPQUFPO0dBRUgsSUFBSSxZQUFZLElBQUksS0FBSyxHQUFHO0dBRTVCLFNBQUEsVUFBeUIsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJO0dBRTdDLGlCQUFBLFVBQWlDLElBQUksS0FBSyxNQUFNLENBQUM7R0FFakQsYUFBQSxVQUE2QixJQUFJLEtBQUssTUFBTSxFQUFFO0dBRTlDLGdCQUFBLFVBQWdDLElBQUksS0FBSyxNQUFNLEVBQUU7R0FFakQsaUJBQUEsVUFBaUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUVsRCxtQkFBQSxVQUFtQyxJQUFJLEtBQUssTUFBTSxFQUFFO0dBRXBELHVCQUFBLFVBQXVDLElBQUksS0FBSyxNQUFNLEVBQUU7R0FFeEQsc0JBQUEsVUFBc0MsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUV2RCxTQUFTLElBQUlDLGVBQXFCLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7RUFDM0Q7Q0FDSjtBQUNKOzs7O0FBSUEsSUFBYSxTQUFTO0NBQ2xCLEtBQUs7Q0FDTCxNQUFNLEtBQUssUUFBUTtFQUNmLE9BQU87R0FFSCxrQkFBQSxVQUFrQyxJQUFJLEtBQUssR0FBRztHQUU5QyxhQUFBLFVBQTZCLElBQUksS0FBSyxNQUFNLENBQUM7R0FFN0MsZ0JBQUEsVUFBZ0MsSUFBSSxLQUFLLE1BQU0sQ0FBQztHQUVoRCxrQkFBQSxVQUFrQyxJQUFJLEtBQUssTUFBTSxDQUFDO0dBRWxELGFBQUEsVUFBNkIsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUU5QyxlQUFBLFVBQStCLElBQUksS0FBSyxNQUFNLEVBQUU7R0FFaEQsU0FBQSxVQUF5QixJQUFJLEtBQUssTUFBTSxFQUFFO0dBRTFDLFlBQUEsVUFBNEIsSUFBSSxLQUFLLE1BQU0sRUFBRTtFQUNqRDtDQUNKO0FBQ0o7Ozs7O0FBS0EsSUFBYSxZQUFZO0NBQ3JCLEtBQUs7Q0FDTCxNQUFNLEtBQUssUUFBUTtFQUNmLE9BQU87R0FFSCxJQUFJLElBQUlDLFdBQWlCLEdBQUcsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUc7R0FFakQsU0FBQSxVQUF5QixJQUFJLEtBQUssTUFBTSxDQUFDO0dBRXpDLE1BQUEsVUFBc0IsSUFBSSxLQUFLLE1BQU0sRUFBRTtHQUV2QyxRQUFBLFVBQXdCLElBQUksS0FBSyxNQUFNLEVBQUU7R0FFekMsT0FBTyxjQUFBLFVBQThCLElBQUksS0FBSyxNQUFNLEVBQUUsQ0FBQztFQUMzRDtDQUNKO0FBQ0o7Ozs7QUFJQSxJQUFhLGdCQUFnQjtDQUN6QixLQUFLO0NBQ0wsTUFBTSxLQUFLLFFBQVE7RUFDZixPQUFPO0dBRUgsTUFBQSxVQUFzQixJQUFJLEtBQUssR0FBRztHQUVsQyxPQUFPLGNBQUEsVUFBOEIsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0VBQzFEO0NBQ0o7QUFDSjtBQUNBLFNBQWdCLGNBQWMsT0FBTztDQUNqQyxPQUFPO0VBQ0gsZ0JBQWdCLFNBQVMsT0FBTyxFQUFFO0VBQ2xDLGdCQUFnQixTQUFTLE9BQU8sRUFBRTtFQUNsQyxVQUFVLFNBQVMsT0FBTyxFQUFFO0VBQzVCLFVBQVUsU0FBUyxPQUFPLENBQUM7RUFDM0IsV0FBVyxRQUFRLE1BQU07Q0FDN0I7QUFDSjs7Ozs7O0FBTUEsU0FBZ0IsU0FBUyxLQUFLLEtBQUs7Q0FDL0IsUUFBUSxNQUFPLEtBQUssU0FBVTtBQUNsQzs7O0FDMUdBLElBQU0sU0FBQSxHQUFRQyxlQUFBQSxRQUFBQSxDQUFVLDZCQUE2QjtBQUNyRCxJQUFNLFlBQVk7QUFDbEIsSUFBTSxXQUFXO0FBQ2pCLElBQWEsa0JBQWIsY0FBcUMsK0JBQStCLE9BQU8sQ0FBQyxDQUFDLENBQzdFO0FBQ0EsU0FBZ0Isa0JBQWtCLFVBQVUsV0FBVyxTQUFTO0NBRTVELE9BQU8sSUFEZSxZQUFZLFVBQVUsV0FBVyxPQUN4QyxDQUFDLENBQUMsa0JBQWtCO0FBQ3ZDO0FBQ0EsSUFBYSxjQUFiLE1BQWEsb0JBQW9CLFlBQVk7Ozs7OztDQU16QyxPQUFPLGtCQUFrQixJQUFJO0VBQ3pCLElBQUksV0FBVyxHQUFHLGNBQWMsSUFBSSxHQUFHLGtCQUFrQixHQUFHLGNBQWMsS0FBSztFQUMvRSxZQUFZLEdBQUc7RUFDZixPQUFPLFdBQVcsR0FBRztDQUN6Qjs7Ozs7O0NBTUEsYUFBYSxvQkFBb0IsV0FBVyxRQUFRO0VBRWhELE1BQU0sU0FBUyxJQUFJLFdBQVcsVUFBVSxHQUFHO0VBQzNDLE1BQU0sV0FBVyxVQUFVO0VBQzNCLElBQUksVUFBVSxVQUFVLEtBQUs7R0FDekIsTUFBTSxrREFBa0QsUUFBUTtHQUNoRTtFQUNKO0VBQ0EsSUFBSSxTQUFTLFVBQVUsS0FBSztHQUN4QixNQUFNLFVBQVUsV0FBVyxRQUFRLEVBQUUsVUFBVSxTQUFTLFVBQVUsSUFBSSxDQUFDO0dBQ3ZFLFVBQVUsWUFBWSxRQUFRO0dBQzlCLE1BQU0sWUFBWSxVQUFVLElBQUksUUFBUSxDQUFDO0dBQ3pDLElBQUksVUFBVSxPQUFPLFlBQVk7SUFDN0IsSUFBSSxVQUFVLE1BQU0sVUFDaEIsTUFBTSw4QkFBOEIsU0FBUyxVQUFVLEtBQUs7U0FFM0Q7S0FDRCxNQUFNLDhCQUE4QixTQUFTLFVBQVUsS0FBSztLQUM1RCxVQUFVLFVBQVU7SUFDeEI7SUFDQSxPQUFPO0tBQUUsUUFBUTtLQUFXO0lBQU87R0FDdkM7RUFDSjtDQUNKO0NBQ0EsT0FBTyxlQUFlLFVBQVUsUUFBUSxTQUFTO0VBQzdDLE1BQU0sU0FBUyxVQUFVLElBQUksUUFBUSxPQUFPLFNBQVMsVUFBVSxHQUFHO0VBQ2xFLElBQUksT0FBTyxPQUFPLFVBQ2QsTUFBTSxJQUFJLGdCQUFnQiwyQ0FBMkM7RUFHekUsT0FBTyxJQURlLFlBQVksVUFBVUMsV0FBbUIsUUFBUSxvQkFBb0IsT0FBTyxDQUFDLEdBQUcsT0FDdkYsQ0FBQyxDQUFDLFVBQVUsTUFBTTtDQUNyQztDQUNBLE1BQU0sQ0FBQzs7OztDQUlQLE1BQU0sb0JBQW9CO0VBQ3RCLElBQUksS0FBSyxVQUFVLFNBQVMsUUFBUSxLQUFLLFVBQVUsU0FBUyxPQUFPLEtBQUssVUFBVSxXQUFXLFVBQVUsS0FBSztHQUN4RyxNQUFNLDRDQUE0QztHQUNsRDtFQUNKO0VBQ0EsTUFBTSxTQUFTLE1BQU0sS0FBSyxVQUFVLFVBQVUsU0FBUztFQUN2RCxJQUFJLE9BQU8sT0FBTyxVQUFVO0dBQ3hCLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxHQUFHO0dBQ3pDLE9BQU8sS0FBSyxVQUFVLE1BQU07RUFDaEM7RUFDQSxNQUFNLG9DQUFvQyxLQUFLLFVBQVUsVUFBVTtFQUNuRSxJQUFJLEtBQUssVUFBVSxTQUFTLE1BQU07R0FFOUIsTUFBTSxZQUFZLEtBQUssVUFBVSxTQUFTLE9BQU8sS0FBSyxVQUFVO0dBQ2hFLE1BQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxTQUFTO0dBQ2hELE9BQU8sWUFBWSxlQUFlLEtBQUssVUFBVSxRQUFRLEtBQUssT0FBTztFQUN6RTtDQUNKO0NBQ0EsTUFBTSxRQUFRO0VBQ1YsTUFBTSxhQUFhLE1BQU0sS0FBSyxVQUFVLFVBQVUsZ0JBQWdCO0VBQ2xFLElBQUksV0FBVyxPQUFPLFFBQ2xCLE1BQU0sSUFBSSxnQkFBZ0IsMEJBQTBCO0VBRXhELEtBQUssSUFBSSxhQUFhO0VBQ3RCLE1BQU0sU0FBUyxXQUFXLGtCQUFrQixpQkFBaUI7RUFDN0QsTUFBTSxTQUFTLE9BQU8sU0FBUyxJQUFJLEtBQUsseUJBQXlCLE1BQU0sSUFBSSxLQUFLLFlBQVk7RUFDNUYsS0FBSyxTQUFTLGFBQWE7RUFDM0IsTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPLFlBQVk7RUFDL0MsT0FBTyxLQUFLLGtCQUFrQjtDQUNsQztDQUNBLE1BQU0sVUFBVSxRQUFRO0VBQ3BCLElBQUksT0FBTyxTQUFTLHNCQUFzQixLQUFLLE9BQU8sR0FDbEQsTUFBTSxJQUFJLGdCQUFnQixrQkFBa0IsT0FBTyxPQUFPLHVCQUF1QixzQkFBc0IsS0FBSyxPQUFPLEdBQUc7RUFFMUgsTUFBTSw0QkFBWSxJQUFJLFdBQVcsR0FBRztFQUNwQyxJQUFJLGlCQUFpQixPQUFPLE9BQU8sVUFBVTtFQUM3QyxNQUFNLDRCQUE0QixLQUFLLFVBQVUsU0FBUyxTQUFTLGdCQUFnQjtFQUNuRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7R0FDcEMsSUFBSSxpQkFBaUIsY0FBYyxLQUFLO0lBQ3BDLEtBQUssU0FBUyxXQUFXLHFCQUFxQixPQUFPLFNBQVMsRUFBRSxnREFBZ0Q7SUFDaEg7R0FDSjtHQUVBLE1BQU0sZ0JBQWdCLE1BQU0sS0FBSyxVQUFVLFVBQVUsYUFBYTtHQUNsRSxrQkFBa0IsY0FBYztHQUVoQyxJQUFJLGNBQWMsUUFBUSxnQkFDdEIsTUFBTSxJQUFJLGdCQUFnQiwwQkFBMEIsY0FBYyxNQUFNO0dBRTVFLE1BQU0sV0FBVyxNQUFNLEtBQUssVUFBVSxXQUFXLFdBQVc7SUFDeEQsUUFBUSxLQUFLLElBQUksVUFBVSxRQUFRLGlCQUFpQixjQUFjLElBQUk7SUFDdEUsV0FBVztHQUNmLENBQUM7R0FDRCxJQUFJLE9BQU8sVUFBVSxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDO0dBQ3BELElBQUksU0FBUyxJQUNULE1BQU0sSUFBSSxnQkFBZ0IsMkJBQTJCO0dBRXpELE1BQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxVQUFVLElBQUksV0FBVyxNQUFNLE9BQU8sQ0FBQztHQUN4RSxNQUFNLEtBQUssVUFBVSxPQUFPLENBQUM7R0FDN0Isa0JBQWtCLElBQUksU0FBUztHQUMvQixJQUFJLEtBQUssVUFBVSxTQUFTLFNBQVMsS0FBQSxLQUNqQyxjQUFjLE9BQU8sS0FBSyxVQUFVLFNBQVMsT0FBTyxLQUFLLFVBQVUsVUFDbkUsTUFBTSxJQUFJLGdCQUFnQiwwQkFBMEIsY0FBYyxNQUFNO0dBRTVFLGtCQUFrQixjQUFjO0dBQ2hDLFFBQVEsY0FBYyxNQUFNLFVBQTVCO0lBQ0ksS0FBSyxTQUFTLFdBQVc7S0FFckIsTUFBTSxRQUFRLFdBQVcsTUFBTSxLQUFLLGFBQWEsY0FBYyxJQUFJLEdBQUcsT0FBTztLQUM3RSxJQUFJLGFBQWE7S0FDakIsS0FBSyxJQUFJLFNBQVMsTUFBTSxRQUFRLElBQUksR0FBRyxVQUFVLEdBQUcsU0FBUyxNQUFNLFFBQVEsTUFBTSxTQUFTLENBQUMsR0FDdkYsRUFBRTtLQUVOLElBQUksYUFBYSxzQkFBc0IsS0FBSyxPQUFPLEdBQy9DLE1BQU0sSUFBSSxnQkFBZ0Isb0JBQW9CLFdBQVcsdUJBQXVCLHNCQUFzQixLQUFLLE9BQU8sR0FBRztLQUV6SCxNQUFNLFNBQVMsTUFBTSxNQUFNLE9BQU87S0FDbEMsTUFBTSxRQUFRLElBQUksT0FBTyxLQUFJLFFBQU8sS0FBSyxTQUFTLE9BQU8sV0FBVyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0tBQzlFO0lBQ0o7SUFDQSxLQUFLLFNBQVM7S0FDVixJQUFJLEtBQUssUUFBUSxZQUNiLE1BQU0sS0FBSyxVQUFVLE9BQU8sY0FBYyxJQUFJO1VBRTdDO01BQ0QsTUFBTSxVQUFVLE1BQU0sS0FBSyxhQUFhLGNBQWMsSUFBSTtNQUMxRCxPQUFPQyxTQUFjLE9BQU87TUFDNUIsTUFBTSxjQUFjLFdBQVcsUUFBUSxTQUFTLEdBQUcsSUFBSSxHQUFHLE9BQU87TUFDakUsTUFBTSxPQUFPLFFBQVEsU0FBUyxPQUFPLENBQUM7TUFDdEMsTUFBTSxLQUFLLFNBQVMsT0FBTyxXQUFXLEtBQUs7T0FDdkM7T0FDQTtNQUNKLENBQUM7S0FDTDtLQUNBO0lBQ0osS0FBSyxTQUFTO0tBQ1YsTUFBTSx3QkFBd0IsS0FBSztLQUNuQyxNQUFNLEtBQUssVUFBVSxPQUFPLGNBQWMsSUFBSTtLQUM5QztJQUNKLEtBQUssU0FBUztLQUNWLE1BQU0sd0JBQXdCLEtBQUs7S0FDbkMsS0FBSyxTQUFTLFdBQVcsa0RBQWtELElBQUksRUFBRTtLQUNqRixNQUFNLEtBQUssVUFBVSxPQUFPLGNBQWMsSUFBSTtHQUV0RDtFQUNKO0NBQ0o7Q0FDQSxNQUFNLGFBQWEsTUFBTTtFQUNyQixPQUFPLFdBQVcsS0FBSyxXQUFXLE1BQU0sS0FBSyxTQUFTLEtBQUEsSUFBVyxZQUFXLElBQUksZ0JBQWdCLE9BQU8sQ0FBQztDQUM1RztDQUNBLE1BQU0seUJBQXlCLFFBQVE7RUFDbkMsTUFBTSxLQUFLLFVBQVUsT0FBTyxNQUFNO0VBQ2xDLE9BQU8sS0FBSyxZQUFZO0NBQzVCO0NBQ0EsTUFBTSxjQUFjO0VBQ2hCLE1BQU0sU0FBUyxNQUFNLEtBQUssVUFBVSxVQUFVLE1BQU07RUFFcEQsS0FBSyxTQUFTLFVBQVUsWUFBWSxJQUFJO0VBQ3hDLEtBQUssU0FBUyxVQUFVLGFBQWEsZ0JBQWdCO0VBQ3JELEtBQUssU0FBUyxVQUFVLFNBQVMsZ0JBQWdCO0VBQ2pELEtBQUssU0FBUyxVQUFVLGlCQUFpQixPQUFPLGFBQWE7RUFDN0QsS0FBSyxTQUFTLFVBQVUsY0FBYyxPQUFPLFVBQVU7RUFDdkQsS0FBSyxTQUFTLFVBQVUsb0JBQW9CLE9BQU8sT0FBTztFQUMxRCxLQUFLLFNBQVMsVUFBVSxZQUFZLFlBQVksa0JBQWtCLE1BQU0sQ0FBQztFQUN6RSxJQUFJLENBQUMsS0FBSyxJQUFJLFlBQ1YsTUFBTSxJQUFJLGdCQUFnQix3QkFBd0I7RUFFdEQsT0FBTyxFQUNILGNBQWMsS0FBSyxJQUFJLFdBQVcsaUJBQzlCLEtBQUssSUFBSSxXQUFXLGtCQUNwQixLQUFLLElBQUksV0FBVyxvQkFDcEIsS0FBSyxJQUFJLFdBQVcscUJBQzVCO0NBQ0o7QUFDSiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0XX0=