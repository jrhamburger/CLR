import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Chats.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { fetchRecentMessages, subscribeToIncoming } from "/src/lib/socials.js";
import Avatar from "/src/components/Avatar.jsx";
import ChatConversation from "/src/components/ChatConversation.jsx";
import "/src/styles/Socials.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Chats.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function otherUser(msg, userId) {
	return msg.from_user === userId ? msg.to_user : msg.from_user;
}
// Maps each friend's id to the newest message between you
function latestByFriend(messages, userId) {
	const latest = {};
	for (const msg of messages) {
		const otherId = otherUser(msg, userId);
		if (!latest[otherId]) latest[otherId] = msg;
	}
	return latest;
}
function Chats({ userId, friends }) {
	_s();
	const [latest, setLatest] = useState({});
	const [selected, setSelected] = useState(null);
	const [message, setMessage] = useState("");
	useEffect(() => {
		fetchRecentMessages(userId).then(({ data, error }) => {
			if (error) setMessage(error.message);
			else setLatest(latestByFriend(data, userId));
		});
		return subscribeToIncoming(`chat-list-${userId}`, userId, (msg) => setLatest((current) => ({
			...current,
			[otherUser(msg, userId)]: msg
		})));
	}, [userId]);
	function recordLatest(msg) {
		setLatest((current) => ({
			...current,
			[otherUser(msg, userId)]: msg
		}));
	}
	if (selected) {
		return /* @__PURE__ */ _jsxDEV(ChatConversation, {
			userId,
			friend: selected,
			onBack: () => setSelected(null),
			onSent: recordLatest
		}, selected.friend_id, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this);
	}
	// Most recent conversation first; friends you haven't messaged last
	const sorted = [...friends].sort((a, b) => {
		const aTime = latest[a.friend_id]?.created_at ?? "";
		const bTime = latest[b.friend_id]?.created_at ?? "";
		return bTime.localeCompare(aTime);
	});
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "socials-section",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				className: "socials-heading",
				children: "Chats"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "socials-message",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 19
			}, this),
			friends.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "socials-empty",
				children: "No friends yet — add someone in the Friends tab to start chatting"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "socials-list",
				children: sorted.map((friend) => {
					const last = latest[friend.friend_id];
					return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
						className: "socials-card chat-row",
						onClick: () => setSelected(friend),
						children: [/* @__PURE__ */ _jsxDEV(Avatar, {
							userName: friend.users?.user_name,
							userId: friend.friend_id
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "socials-name share-details",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: friend.users?.user_name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "chat-preview",
								children: last ? `${last.from_user === userId ? "You: " : ""}${last.body}` : "No messages yet"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 15
					}, this) }, friend.friend_id, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_s(Chats, "Ec7xGZJW7Q2hJsOCAlI/YGscVts=");
_c = Chats;
export default Chats;
var _c;
$RefreshReg$(_c, "Chats");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Chats.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Chats.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Chats.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Chats.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUNFLHFCQUNBLDJCQUNLO0FBQ1AsT0FBTyxZQUFZO0FBQ25CLE9BQU8sc0JBQXNCO0FBQzdCLE9BQU87Ozs7QUFFUCxTQUFTLFVBQVUsS0FBSyxRQUFRO0NBQzlCLE9BQU8sSUFBSSxjQUFjLFNBQVMsSUFBSSxVQUFVLElBQUk7QUFDdEQ7O0FBR0EsU0FBUyxlQUFlLFVBQVUsUUFBUTtDQUN4QyxNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxVQUFVO0VBQzFCLE1BQU0sVUFBVSxVQUFVLEtBQUssTUFBTTtFQUNyQyxJQUFJLENBQUMsT0FBTyxVQUFVLE9BQU8sV0FBVztDQUMxQztDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsTUFBTSxFQUFFLFFBQVEsV0FBVzs7Q0FDbEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLENBQUMsQ0FBQztDQUN2QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsSUFBSTtDQUM3QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUV6QyxnQkFBZ0I7RUFDZCxvQkFBb0IsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sWUFBWTtHQUNwRCxJQUFJLE9BQU8sV0FBVyxNQUFNLE9BQU87UUFDOUIsVUFBVSxlQUFlLE1BQU0sTUFBTSxDQUFDO0VBQzdDLENBQUM7RUFFRCxPQUFPLG9CQUNMLGFBQWEsVUFDYixTQUNDLFFBQ0MsV0FBVyxhQUFhO0dBQ3RCLEdBQUc7SUFDRixVQUFVLEtBQUssTUFBTSxJQUFJO0VBQzVCLEVBQUUsQ0FDTjtDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FFWCxTQUFTLGFBQWEsS0FBSztFQUN6QixXQUFXLGFBQWE7R0FDdEIsR0FBRztJQUNGLFVBQVUsS0FBSyxNQUFNLElBQUk7RUFDNUIsRUFBRTtDQUNKO0NBRUEsSUFBSSxVQUFVO0VBQ1osT0FDRSx3QkFBQyxrQkFBRDtHQUVVO0dBQ1IsUUFBUTtHQUNSLGNBQWMsWUFBWSxJQUFJO0dBQzlCLFFBQVE7RUFDVCxHQUxNLFNBQVM7Ozs7U0FLZjtDQUVMOztDQUdBLE1BQU0sU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU07RUFDekMsTUFBTSxRQUFRLE9BQU8sRUFBRSxVQUFVLEVBQUUsY0FBYztFQUNqRCxNQUFNLFFBQVEsT0FBTyxFQUFFLFVBQVUsRUFBRSxjQUFjO0VBQ2pELE9BQU8sTUFBTSxjQUFjLEtBQUs7Q0FDbEMsQ0FBQztDQUVELE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFrQjtHQUFTOzs7OztHQUV4QyxXQUFXLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW1CO0dBQVc7Ozs7O0dBRXRELFFBQVEsV0FBVyxLQUNsQix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFnQjtHQUcxQjs7Ozs7R0FHTCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLE9BQU8sS0FBSyxXQUFXO0tBQ3RCLE1BQU0sT0FBTyxPQUFPLE9BQU87S0FDM0IsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtNQUNFLFdBQVU7TUFDVixlQUFlLFlBQVksTUFBTTtnQkFGbkMsQ0FHRSx3QkFBQyxRQUFEO09BQ0UsVUFBVSxPQUFPLE9BQU87T0FDeEIsUUFBUSxPQUFPO01BQ2hCOzs7O2dCQUNELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNFLHdCQUFDLFFBQUQsWUFBTyxPQUFPLE9BQU8sVUFBZ0I7Ozs7aUJBQ3JDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE9BQ0csR0FBRyxLQUFLLGNBQWMsU0FBUyxVQUFVLEtBQUssS0FBSyxTQUNuRDtPQUNBOzs7O2VBQ0Y7Ozs7O2NBQ0E7Ozs7O2NBQ04sR0FqQkssT0FBTzs7OztZQWlCWjtJQUVSLENBQUM7R0FDQzs7Ozs7RUFDRzs7Ozs7O0FBRWI7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hhdHMuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBmZXRjaFJlY2VudE1lc3NhZ2VzLFxyXG4gIHN1YnNjcmliZVRvSW5jb21pbmdcclxufSBmcm9tIFwiLi4vbGliL3NvY2lhbHNcIjtcclxuaW1wb3J0IEF2YXRhciBmcm9tIFwiLi9BdmF0YXJcIjtcclxuaW1wb3J0IENoYXRDb252ZXJzYXRpb24gZnJvbSBcIi4vQ2hhdENvbnZlcnNhdGlvblwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvU29jaWFscy5jc3NcIjtcclxuXHJcbmZ1bmN0aW9uIG90aGVyVXNlcihtc2csIHVzZXJJZCkge1xyXG4gIHJldHVybiBtc2cuZnJvbV91c2VyID09PSB1c2VySWQgPyBtc2cudG9fdXNlciA6IG1zZy5mcm9tX3VzZXI7XHJcbn1cclxuXHJcbi8vIE1hcHMgZWFjaCBmcmllbmQncyBpZCB0byB0aGUgbmV3ZXN0IG1lc3NhZ2UgYmV0d2VlbiB5b3VcclxuZnVuY3Rpb24gbGF0ZXN0QnlGcmllbmQobWVzc2FnZXMsIHVzZXJJZCkge1xyXG4gIGNvbnN0IGxhdGVzdCA9IHt9O1xyXG4gIGZvciAoY29uc3QgbXNnIG9mIG1lc3NhZ2VzKSB7XHJcbiAgICBjb25zdCBvdGhlcklkID0gb3RoZXJVc2VyKG1zZywgdXNlcklkKTtcclxuICAgIGlmICghbGF0ZXN0W290aGVySWRdKSBsYXRlc3Rbb3RoZXJJZF0gPSBtc2c7XHJcbiAgfVxyXG4gIHJldHVybiBsYXRlc3Q7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIENoYXRzKHsgdXNlcklkLCBmcmllbmRzIH0pIHtcclxuICBjb25zdCBbbGF0ZXN0LCBzZXRMYXRlc3RdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFJlY2VudE1lc3NhZ2VzKHVzZXJJZCkudGhlbigoeyBkYXRhLCBlcnJvciB9KSA9PiB7XHJcbiAgICAgIGlmIChlcnJvcikgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgICAgZWxzZSBzZXRMYXRlc3QobGF0ZXN0QnlGcmllbmQoZGF0YSwgdXNlcklkKSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gc3Vic2NyaWJlVG9JbmNvbWluZyhcclxuICAgICAgYGNoYXQtbGlzdC0ke3VzZXJJZH1gLFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIChtc2cpID0+XHJcbiAgICAgICAgc2V0TGF0ZXN0KChjdXJyZW50KSA9PiAoe1xyXG4gICAgICAgICAgLi4uY3VycmVudCxcclxuICAgICAgICAgIFtvdGhlclVzZXIobXNnLCB1c2VySWQpXTogbXNnXHJcbiAgICAgICAgfSkpXHJcbiAgICApO1xyXG4gIH0sIFt1c2VySWRdKTtcclxuXHJcbiAgZnVuY3Rpb24gcmVjb3JkTGF0ZXN0KG1zZykge1xyXG4gICAgc2V0TGF0ZXN0KChjdXJyZW50KSA9PiAoe1xyXG4gICAgICAuLi5jdXJyZW50LFxyXG4gICAgICBbb3RoZXJVc2VyKG1zZywgdXNlcklkKV06IG1zZ1xyXG4gICAgfSkpO1xyXG4gIH1cclxuXHJcbiAgaWYgKHNlbGVjdGVkKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8Q2hhdENvbnZlcnNhdGlvblxyXG4gICAgICAgIGtleT17c2VsZWN0ZWQuZnJpZW5kX2lkfVxyXG4gICAgICAgIHVzZXJJZD17dXNlcklkfVxyXG4gICAgICAgIGZyaWVuZD17c2VsZWN0ZWR9XHJcbiAgICAgICAgb25CYWNrPXsoKSA9PiBzZXRTZWxlY3RlZChudWxsKX1cclxuICAgICAgICBvblNlbnQ9e3JlY29yZExhdGVzdH1cclxuICAgICAgLz5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICAvLyBNb3N0IHJlY2VudCBjb252ZXJzYXRpb24gZmlyc3Q7IGZyaWVuZHMgeW91IGhhdmVuJ3QgbWVzc2FnZWQgbGFzdFxyXG4gIGNvbnN0IHNvcnRlZCA9IFsuLi5mcmllbmRzXS5zb3J0KChhLCBiKSA9PiB7XHJcbiAgICBjb25zdCBhVGltZSA9IGxhdGVzdFthLmZyaWVuZF9pZF0/LmNyZWF0ZWRfYXQgPz8gXCJcIjtcclxuICAgIGNvbnN0IGJUaW1lID0gbGF0ZXN0W2IuZnJpZW5kX2lkXT8uY3JlYXRlZF9hdCA/PyBcIlwiO1xyXG4gICAgcmV0dXJuIGJUaW1lLmxvY2FsZUNvbXBhcmUoYVRpbWUpO1xyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic29jaWFscy1zZWN0aW9uXCI+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJzb2NpYWxzLWhlYWRpbmdcIj5DaGF0czwvaDI+XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLW1lc3NhZ2VcIj57bWVzc2FnZX08L3A+fVxyXG5cclxuICAgICAge2ZyaWVuZHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLWVtcHR5XCI+XHJcbiAgICAgICAgICBObyBmcmllbmRzIHlldCDigJQgYWRkIHNvbWVvbmUgaW4gdGhlIEZyaWVuZHMgdGFiIHRvXHJcbiAgICAgICAgICBzdGFydCBjaGF0dGluZ1xyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDx1bCBjbGFzc05hbWU9XCJzb2NpYWxzLWxpc3RcIj5cclxuICAgICAgICB7c29ydGVkLm1hcCgoZnJpZW5kKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBsYXN0ID0gbGF0ZXN0W2ZyaWVuZC5mcmllbmRfaWRdO1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPGxpIGtleT17ZnJpZW5kLmZyaWVuZF9pZH0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic29jaWFscy1jYXJkIGNoYXQtcm93XCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkKGZyaWVuZCl9PlxyXG4gICAgICAgICAgICAgICAgPEF2YXRhclxyXG4gICAgICAgICAgICAgICAgICB1c2VyTmFtZT17ZnJpZW5kLnVzZXJzPy51c2VyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJJZD17ZnJpZW5kLmZyaWVuZF9pZH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzb2NpYWxzLW5hbWUgc2hhcmUtZGV0YWlsc1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj57ZnJpZW5kLnVzZXJzPy51c2VyX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjaGF0LXByZXZpZXdcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bGFzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBgJHtsYXN0LmZyb21fdXNlciA9PT0gdXNlcklkID8gXCJZb3U6IFwiIDogXCJcIn0ke2xhc3QuYm9keX1gXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm8gbWVzc2FnZXMgeWV0XCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvdWw+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hhdHM7XHJcbiJdfQ==