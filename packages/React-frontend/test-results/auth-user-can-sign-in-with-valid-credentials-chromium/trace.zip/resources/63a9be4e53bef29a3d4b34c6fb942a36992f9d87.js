import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { HouseIcon, MagnifyingGlassIcon, MusicNotesIcon, HeartIcon, ChartBarIcon, StackIcon, UsersThreeIcon, SidebarSimpleIcon, MusicNoteIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import { SCREENS } from "/src/constants/screens.js";
import "/src/styles/Sidebar.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Sidebar.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// screen values come from constants/screens.js
const NAV_ITEMS = [
	{
		label: "Home",
		icon: HouseIcon,
		screen: SCREENS.HOME
	},
	{
		label: "Search",
		icon: MagnifyingGlassIcon,
		screen: SCREENS.SEARCH
	},
	{
		label: "Genres",
		icon: MusicNotesIcon,
		screen: SCREENS.GENRES
	},
	{
		label: "Favorites",
		icon: HeartIcon,
		screen: SCREENS.FAVORITES
	},
	{
		label: "Taste Profile",
		icon: ChartBarIcon,
		screen: SCREENS.TASTE_PROFILE
	},
	{
		label: "Collections",
		icon: StackIcon,
		screen: SCREENS.COLLECTIONS
	},
	{
		label: "Socials",
		icon: UsersThreeIcon,
		screen: SCREENS.SOCIALS
	}
];
function Sidebar({ isOpen, onToggle, currentScreen, onNavigate, currentSong }) {
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: `sidebar ${isOpen ? "open" : "collapsed"}`,
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				className: "sidebar-toggle",
				onClick: onToggle,
				title: isOpen ? "Collapse sidebar" : "Expand sidebar",
				children: /* @__PURE__ */ _jsxDEV(SidebarSimpleIcon, { size: 22 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "sidebar-nav",
				children: NAV_ITEMS.map(({ label, icon: Icon, screen }) => /* @__PURE__ */ _jsxDEV("button", {
					className: `sidebar-link ${currentScreen === screen ? "active" : ""}`,
					onClick: () => onNavigate(screen),
					title: label,
					children: [/* @__PURE__ */ _jsxDEV(Icon, { size: 22 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 13
					}, this), isOpen && /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 24
					}, this)]
				}, label, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sidebar-now-playing",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "sidebar-cover",
					children: currentSong?.coverUrl ? /* @__PURE__ */ _jsxDEV("img", {
						src: currentSong.coverUrl,
						alt: currentSong.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(MusicNoteIcon, { size: isOpen ? 40 : 22 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this), isOpen && /* @__PURE__ */ _jsxDEV("p", {
					className: "sidebar-song-title",
					children: currentSong?.title ?? "Nothing playing"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = Sidebar;
export default Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Sidebar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Sidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Sidebar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxXQUNBLHFCQUNBLGdCQUNBLFdBQ0EsY0FDQSxXQUNBLGdCQUNBLG1CQUNBLHFCQUNLO0FBQ1AsU0FBUyxlQUFlO0FBQ3hCLE9BQU87Ozs7QUFHUCxNQUFNLFlBQVk7Q0FDaEI7RUFBRSxPQUFPO0VBQVEsTUFBTTtFQUFXLFFBQVEsUUFBUTtDQUFLO0NBQ3ZEO0VBQUUsT0FBTztFQUFVLE1BQU07RUFBcUIsUUFBUSxRQUFRO0NBQU87Q0FDckU7RUFBRSxPQUFPO0VBQVUsTUFBTTtFQUFnQixRQUFRLFFBQVE7Q0FBTztDQUNoRTtFQUFFLE9BQU87RUFBYSxNQUFNO0VBQVcsUUFBUSxRQUFRO0NBQVU7Q0FDakU7RUFBRSxPQUFPO0VBQWlCLE1BQU07RUFBYyxRQUFRLFFBQVE7Q0FBYztDQUM1RTtFQUFFLE9BQU87RUFBZSxNQUFNO0VBQVcsUUFBUSxRQUFRO0NBQVk7Q0FDckU7RUFBRSxPQUFPO0VBQVcsTUFBTTtFQUFnQixRQUFRLFFBQVE7Q0FBUTtBQUNwRTtBQUVBLFNBQVMsUUFBUSxFQUFFLFFBQVEsVUFBVSxlQUFlLFlBQVksZUFBZTtDQUM3RSxPQUNFLHdCQUFDLFNBQUQ7RUFBTyxXQUFXLFdBQVcsU0FBUyxTQUFTO1lBQS9DO0dBQ0Usd0JBQUMsVUFBRDtJQUNFLFdBQVU7SUFDVixTQUFTO0lBQ1QsT0FBTyxTQUFTLHFCQUFxQjtjQUVyQyx3QkFBQyxtQkFBRCxFQUFtQixNQUFNLEdBQUs7Ozs7O0dBQ3hCOzs7OztHQUVSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osVUFBVSxLQUFLLEVBQUUsT0FBTyxNQUFNLE1BQU0sYUFDbkMsd0JBQUMsVUFBRDtLQUVFLFdBQVcsZ0JBQWdCLGtCQUFrQixTQUFTLFdBQVc7S0FDakUsZUFBZSxXQUFXLE1BQU07S0FDaEMsT0FBTztlQUpULENBTUUsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztlQUNoQixVQUFVLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2FBQ3hCO09BUEQ7Ozs7V0FPQyxDQUNUO0dBQ0U7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osYUFBYSxXQUNaLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLFlBQVk7TUFBVSxLQUFLLFlBQVk7S0FBUTs7OztnQkFFekQsd0JBQUMsZUFBRCxFQUFlLE1BQU0sU0FBUyxLQUFLLEdBQUs7Ozs7O0lBRXZDOzs7O2NBQ0osVUFDQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUNWLGFBQWEsU0FBUztJQUN0Qjs7OztZQUVGOzs7Ozs7RUFDQTs7Ozs7O0FBRVg7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaWRlYmFyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIEhvdXNlSWNvbixcclxuICBNYWduaWZ5aW5nR2xhc3NJY29uLFxyXG4gIE11c2ljTm90ZXNJY29uLFxyXG4gIEhlYXJ0SWNvbixcclxuICBDaGFydEJhckljb24sXHJcbiAgU3RhY2tJY29uLFxyXG4gIFVzZXJzVGhyZWVJY29uLFxyXG4gIFNpZGViYXJTaW1wbGVJY29uLFxyXG4gIE11c2ljTm90ZUljb24sXHJcbn0gZnJvbSBcIkBwaG9zcGhvci1pY29ucy9yZWFjdFwiO1xyXG5pbXBvcnQgeyBTQ1JFRU5TIH0gZnJvbSBcIi4uL2NvbnN0YW50cy9zY3JlZW5zXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9TaWRlYmFyLmNzc1wiO1xyXG5cclxuLy8gc2NyZWVuIHZhbHVlcyBjb21lIGZyb20gY29uc3RhbnRzL3NjcmVlbnMuanNcclxuY29uc3QgTkFWX0lURU1TID0gW1xyXG4gIHsgbGFiZWw6IFwiSG9tZVwiLCBpY29uOiBIb3VzZUljb24sIHNjcmVlbjogU0NSRUVOUy5IT01FIH0sXHJcbiAgeyBsYWJlbDogXCJTZWFyY2hcIiwgaWNvbjogTWFnbmlmeWluZ0dsYXNzSWNvbiwgc2NyZWVuOiBTQ1JFRU5TLlNFQVJDSCB9LFxyXG4gIHsgbGFiZWw6IFwiR2VucmVzXCIsIGljb246IE11c2ljTm90ZXNJY29uLCBzY3JlZW46IFNDUkVFTlMuR0VOUkVTIH0sXHJcbiAgeyBsYWJlbDogXCJGYXZvcml0ZXNcIiwgaWNvbjogSGVhcnRJY29uLCBzY3JlZW46IFNDUkVFTlMuRkFWT1JJVEVTIH0sXHJcbiAgeyBsYWJlbDogXCJUYXN0ZSBQcm9maWxlXCIsIGljb246IENoYXJ0QmFySWNvbiwgc2NyZWVuOiBTQ1JFRU5TLlRBU1RFX1BST0ZJTEUgfSxcclxuICB7IGxhYmVsOiBcIkNvbGxlY3Rpb25zXCIsIGljb246IFN0YWNrSWNvbiwgc2NyZWVuOiBTQ1JFRU5TLkNPTExFQ1RJT05TIH0sXHJcbiAgeyBsYWJlbDogXCJTb2NpYWxzXCIsIGljb246IFVzZXJzVGhyZWVJY29uLCBzY3JlZW46IFNDUkVFTlMuU09DSUFMUyB9LFxyXG5dO1xyXG5cclxuZnVuY3Rpb24gU2lkZWJhcih7IGlzT3Blbiwgb25Ub2dnbGUsIGN1cnJlbnRTY3JlZW4sIG9uTmF2aWdhdGUsIGN1cnJlbnRTb25nIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGFzaWRlIGNsYXNzTmFtZT17YHNpZGViYXIgJHtpc09wZW4gPyBcIm9wZW5cIiA6IFwiY29sbGFwc2VkXCJ9YH0+XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBjbGFzc05hbWU9XCJzaWRlYmFyLXRvZ2dsZVwiXHJcbiAgICAgICAgb25DbGljaz17b25Ub2dnbGV9XHJcbiAgICAgICAgdGl0bGU9e2lzT3BlbiA/IFwiQ29sbGFwc2Ugc2lkZWJhclwiIDogXCJFeHBhbmQgc2lkZWJhclwifVxyXG4gICAgICA+XHJcbiAgICAgICAgPFNpZGViYXJTaW1wbGVJY29uIHNpemU9ezIyfSAvPlxyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwic2lkZWJhci1uYXZcIj5cclxuICAgICAgICB7TkFWX0lURU1TLm1hcCgoeyBsYWJlbCwgaWNvbjogSWNvbiwgc2NyZWVuIH0pID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXtsYWJlbH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2lkZWJhci1saW5rICR7Y3VycmVudFNjcmVlbiA9PT0gc2NyZWVuID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZShzY3JlZW4pfVxyXG4gICAgICAgICAgICB0aXRsZT17bGFiZWx9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJY29uIHNpemU9ezIyfSAvPlxyXG4gICAgICAgICAgICB7aXNPcGVuICYmIDxzcGFuPntsYWJlbH08L3NwYW4+fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvbmF2PlxyXG5cclxuICAgICAgey8qIE5vdyBwbGF5aW5nOiBzaG93cyBjb3ZlclVybCBvbmNlIHNvbmdzIGhhdmUgbWV0YWRhdGEsIHBsYWNlaG9sZGVyIHVudGlsIHRoZW4gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1ub3ctcGxheWluZ1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1jb3ZlclwiPlxyXG4gICAgICAgICAge2N1cnJlbnRTb25nPy5jb3ZlclVybCA/IChcclxuICAgICAgICAgICAgPGltZyBzcmM9e2N1cnJlbnRTb25nLmNvdmVyVXJsfSBhbHQ9e2N1cnJlbnRTb25nLnRpdGxlfSAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPE11c2ljTm90ZUljb24gc2l6ZT17aXNPcGVuID8gNDAgOiAyMn0gLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAge2lzT3BlbiAmJiAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaWRlYmFyLXNvbmctdGl0bGVcIj5cclxuICAgICAgICAgICAge2N1cnJlbnRTb25nPy50aXRsZSA/PyBcIk5vdGhpbmcgcGxheWluZ1wifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9hc2lkZT5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaWRlYmFyO1xyXG4iXX0=