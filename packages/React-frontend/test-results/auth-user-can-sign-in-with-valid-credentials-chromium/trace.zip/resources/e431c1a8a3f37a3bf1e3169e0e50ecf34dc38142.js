import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ShareTrackDialog.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { fetchFriends, shareTrack } from "/src/lib/socials.js";
import Avatar from "/src/components/Avatar.jsx";
import "/src/styles/Socials.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ShareTrackDialog.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function ShareTrackDialog({ session, track, onClose }) {
	_s();
	const [friends, setFriends] = useState([]);
	const [loading, setLoading] = useState(true);
	const [friendId, setFriendId] = useState(null);
	const [note, setNote] = useState("");
	const [sending, setSending] = useState(false);
	const [message, setMessage] = useState("");
	useEffect(() => {
		fetchFriends(session.user.id).then(({ data, error }) => {
			setLoading(false);
			if (error) setMessage(error.message);
			else setFriends(data);
		});
	}, [session]);
	async function handleShare(event) {
		event.preventDefault();
		if (!friendId) return;
		setSending(true);
		const { error } = await shareTrack(session.user.id, friendId, track.id, note.trim());
		setSending(false);
		if (error) {
			setMessage(`Couldn't share: ${error.message}`);
			return;
		}
		onClose(true);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "share-backdrop",
		onClick: () => onClose(false),
		children: /* @__PURE__ */ _jsxDEV("form", {
			className: "share-dialog",
			onClick: (event) => event.stopPropagation(),
			onSubmit: handleShare,
			children: [
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "socials-heading",
					children: [
						"Share \"",
						track.title,
						"\""
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this),
				loading && /* @__PURE__ */ _jsxDEV("p", {
					className: "socials-empty",
					children: "Loading friends…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this),
				!loading && friends.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
					className: "socials-empty",
					children: "No friends yet — add some in Socials first"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("ul", {
					className: "socials-list share-friends",
					children: friends.map((friend) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("label", {
						className: friendId === friend.friend_id ? "socials-card share-friend share-friend--selected" : "socials-card share-friend",
						children: [
							/* @__PURE__ */ _jsxDEV("input", {
								type: "radio",
								name: "share-friend",
								checked: friendId === friend.friend_id,
								onChange: () => setFriendId(friend.friend_id)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV(Avatar, {
								userName: friend.users?.user_name,
								userId: friend.friend_id
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "socials-name",
								children: friend.users?.user_name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 15
					}, this) }, friend.friend_id, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					className: "socials-search share-note",
					type: "text",
					placeholder: "Add a note (optional)",
					value: note,
					onChange: (event) => setNote(event.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this),
				message && /* @__PURE__ */ _jsxDEV("p", {
					className: "socials-message",
					children: message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "socials-actions share-buttons",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "socials-button",
						onClick: () => onClose(false),
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "socials-button socials-button--primary",
						disabled: !friendId || sending,
						children: sending ? "Sharing…" : "Share"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_s(ShareTrackDialog, "HgPZYnMGrHk526/KV546EMS0rKQ=");
_c = ShareTrackDialog;
export default ShareTrackDialog;
var _c;
$RefreshReg$(_c, "ShareTrackDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ShareTrackDialog.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ShareTrackDialog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ShareTrackDialog.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/ShareTrackDialog.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLGNBQWMsa0JBQWtCO0FBQ3pDLE9BQU8sWUFBWTtBQUNuQixPQUFPOzs7O0FBRVAsU0FBUyxpQkFBaUIsRUFBRSxTQUFTLE9BQU8sV0FBVzs7Q0FDckQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLENBQUMsQ0FBQztDQUN6QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsSUFBSTtDQUM3QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUV6QyxnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxZQUFZO0dBQ3RELFdBQVcsS0FBSztHQUNoQixJQUFJLE9BQU8sV0FBVyxNQUFNLE9BQU87UUFDOUIsV0FBVyxJQUFJO0VBQ3RCLENBQUM7Q0FDSCxHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosZUFBZSxZQUFZLE9BQU87RUFDaEMsTUFBTSxlQUFlO0VBQ3JCLElBQUksQ0FBQyxVQUFVO0VBRWYsV0FBVyxJQUFJO0VBQ2YsTUFBTSxFQUFFLFVBQVUsTUFBTSxXQUN0QixRQUFRLEtBQUssSUFDYixVQUNBLE1BQU0sSUFDTixLQUFLLEtBQUssQ0FDWjtFQUNBLFdBQVcsS0FBSztFQUVoQixJQUFJLE9BQU87R0FDVCxXQUFXLG1CQUFtQixNQUFNLFNBQVM7R0FDN0M7RUFDRjtFQUVBLFFBQVEsSUFBSTtDQUNkO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsV0FBVTtFQUNWLGVBQWUsUUFBUSxLQUFLO1lBQzVCLHdCQUFDLFFBQUQ7R0FDRSxXQUFVO0dBQ1YsVUFBVSxVQUFVLE1BQU0sZ0JBQWdCO0dBQzFDLFVBQVU7YUFIWjtJQUlFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFBZ0M7TUFDdEIsTUFBTTtNQUFNO0tBQ2xCOzs7Ozs7SUFFSCxXQUNDLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdCO0lBQW1COzs7OztJQUdqRCxDQUFDLFdBQVcsUUFBUSxXQUFXLEtBQzlCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdCO0lBRTFCOzs7OztJQUdMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsUUFBUSxLQUFLLFdBQ1osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFNBQUQ7TUFDRSxXQUNFLGFBQWEsT0FBTyxZQUNoQixxREFDQTtnQkFKUjtPQU1FLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsTUFBSztRQUNMLFNBQVMsYUFBYSxPQUFPO1FBQzdCLGdCQUFnQixZQUFZLE9BQU8sU0FBUztPQUM3Qzs7Ozs7T0FDRCx3QkFBQyxRQUFEO1FBQ0UsVUFBVSxPQUFPLE9BQU87UUFDeEIsUUFBUSxPQUFPO09BQ2hCOzs7OztPQUNELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE9BQU8sT0FBTztPQUNYOzs7OztNQUNEOzs7OztjQUNMLEdBckJLLE9BQU87Ozs7WUFxQlosQ0FDTDtJQUNDOzs7OztJQUVKLHdCQUFDLFNBQUQ7S0FDRSxXQUFVO0tBQ1YsTUFBSztLQUNMLGFBQVk7S0FDWixPQUFPO0tBQ1AsV0FBVyxVQUFVLFFBQVEsTUFBTSxPQUFPLEtBQUs7SUFDaEQ7Ozs7O0lBRUEsV0FDQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFtQjtJQUFXOzs7OztJQUc3Qyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxRQUFRLEtBQUs7Z0JBQUc7S0FFekI7Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixVQUFVLENBQUMsWUFBWTtnQkFDdEIsVUFBVSxhQUFhO0tBQ2xCOzs7O2FBQ0w7Ozs7OztHQUNEOzs7Ozs7Q0FDSDs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaGFyZVRyYWNrRGlhbG9nLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGZldGNoRnJpZW5kcywgc2hhcmVUcmFjayB9IGZyb20gXCIuLi9saWIvc29jaWFsc1wiO1xyXG5pbXBvcnQgQXZhdGFyIGZyb20gXCIuL0F2YXRhclwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvU29jaWFscy5jc3NcIjtcclxuXHJcbmZ1bmN0aW9uIFNoYXJlVHJhY2tEaWFsb2coeyBzZXNzaW9uLCB0cmFjaywgb25DbG9zZSB9KSB7XHJcbiAgY29uc3QgW2ZyaWVuZHMsIHNldEZyaWVuZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtmcmllbmRJZCwgc2V0RnJpZW5kSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW25vdGUsIHNldE5vdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbmRpbmcsIHNldFNlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hGcmllbmRzKHNlc3Npb24udXNlci5pZCkudGhlbigoeyBkYXRhLCBlcnJvciB9KSA9PiB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICBpZiAoZXJyb3IpIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIGVsc2Ugc2V0RnJpZW5kcyhkYXRhKTtcclxuICAgIH0pO1xyXG4gIH0sIFtzZXNzaW9uXSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNoYXJlKGV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKCFmcmllbmRJZCkgcmV0dXJuO1xyXG5cclxuICAgIHNldFNlbmRpbmcodHJ1ZSk7XHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzaGFyZVRyYWNrKFxyXG4gICAgICBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgIGZyaWVuZElkLFxyXG4gICAgICB0cmFjay5pZCxcclxuICAgICAgbm90ZS50cmltKClcclxuICAgICk7XHJcbiAgICBzZXRTZW5kaW5nKGZhbHNlKTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShgQ291bGRuJ3Qgc2hhcmU6ICR7ZXJyb3IubWVzc2FnZX1gKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ2xvc2UodHJ1ZSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJzaGFyZS1iYWNrZHJvcFwiXHJcbiAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2xvc2UoZmFsc2UpfT5cclxuICAgICAgPGZvcm1cclxuICAgICAgICBjbGFzc05hbWU9XCJzaGFyZS1kaWFsb2dcIlxyXG4gICAgICAgIG9uQ2xpY2s9eyhldmVudCkgPT4gZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVNoYXJlfT5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwic29jaWFscy1oZWFkaW5nXCI+XHJcbiAgICAgICAgICBTaGFyZSBcInt0cmFjay50aXRsZX1cIlxyXG4gICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgIHtsb2FkaW5nICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNvY2lhbHMtZW1wdHlcIj5Mb2FkaW5nIGZyaWVuZHPigKY8L3A+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgeyFsb2FkaW5nICYmIGZyaWVuZHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNvY2lhbHMtZW1wdHlcIj5cclxuICAgICAgICAgICAgTm8gZnJpZW5kcyB5ZXQg4oCUIGFkZCBzb21lIGluIFNvY2lhbHMgZmlyc3RcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwic29jaWFscy1saXN0IHNoYXJlLWZyaWVuZHNcIj5cclxuICAgICAgICAgIHtmcmllbmRzLm1hcCgoZnJpZW5kKSA9PiAoXHJcbiAgICAgICAgICAgIDxsaSBrZXk9e2ZyaWVuZC5mcmllbmRfaWR9PlxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgZnJpZW5kSWQgPT09IGZyaWVuZC5mcmllbmRfaWRcclxuICAgICAgICAgICAgICAgICAgICA/IFwic29jaWFscy1jYXJkIHNoYXJlLWZyaWVuZCBzaGFyZS1mcmllbmQtLXNlbGVjdGVkXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwic29jaWFscy1jYXJkIHNoYXJlLWZyaWVuZFwiXHJcbiAgICAgICAgICAgICAgICB9PlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJzaGFyZS1mcmllbmRcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtmcmllbmRJZCA9PT0gZnJpZW5kLmZyaWVuZF9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldEZyaWVuZElkKGZyaWVuZC5mcmllbmRfaWQpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgdXNlck5hbWU9e2ZyaWVuZC51c2Vycz8udXNlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICB1c2VySWQ9e2ZyaWVuZC5mcmllbmRfaWR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic29jaWFscy1uYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtmcmllbmQudXNlcnM/LnVzZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC91bD5cclxuXHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLXNlYXJjaCBzaGFyZS1ub3RlXCJcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgbm90ZSAob3B0aW9uYWwpXCJcclxuICAgICAgICAgIHZhbHVlPXtub3RlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0Tm90ZShldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIHttZXNzYWdlICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNvY2lhbHMtbWVzc2FnZVwiPnttZXNzYWdlfTwvcD5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbHMtYWN0aW9ucyBzaGFyZS1idXR0b25zXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2xvc2UoZmFsc2UpfT5cclxuICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtYnV0dG9uIHNvY2lhbHMtYnV0dG9uLS1wcmltYXJ5XCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFmcmllbmRJZCB8fCBzZW5kaW5nfT5cclxuICAgICAgICAgICAge3NlbmRpbmcgPyBcIlNoYXJpbmfigKZcIiA6IFwiU2hhcmVcIn1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaGFyZVRyYWNrRGlhbG9nO1xyXG4iXX0=