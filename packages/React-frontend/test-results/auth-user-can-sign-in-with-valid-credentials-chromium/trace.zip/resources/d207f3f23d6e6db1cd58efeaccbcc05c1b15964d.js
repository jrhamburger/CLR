import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport22_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport22_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import "/src/App.css";
import { supabase } from "/src/lib/supabase.js";
import { uploadFiles } from "/src/lib/fileuploading.js";
import { SCREENS, assertValidScreen } from "/src/constants/screens.js";
import SignUp from "/src/components/SignUp.jsx";
import MusicPlayer from "/src/components/MusicPlayer.jsx";
import MiniPlayer from "/src/components/MiniPlayer.jsx";
import SignIn from "/src/components/SignIn.jsx";
import Home from "/src/components/Home.jsx";
import Playlists from "/src/components/Playlists.jsx";
import Sidebar from "/src/components/Sidebar.jsx";
import ProfileMenu from "/src/components/ProfileMenu.jsx";
import Search from "/src/components/Search.jsx";
import Genres from "/src/components/Genres.jsx";
import Favorites from "/src/components/Favorites.jsx";
import TasteProfile from "/src/components/TasteProfile.jsx";
import Collections from "/src/components/Collections.jsx";
import Socials from "/src/components/Socials.jsx";
import NowPlaying from "/src/components/NowPlaying.jsx";
import NowPlayingPanel from "/src/components/NowPlayingPanel.jsx";
import "/src/styles/TopNav.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/App.jsx";
import __vite__cjsImport22_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
const TOP_NAV_ITEMS = [
	{
		label: "Home",
		screen: SCREENS.HOME
	},
	{
		label: "Playlists",
		screen: SCREENS.PLAYLISTS
	},
	{
		label: "Player",
		screen: SCREENS.PLAYER
	},
	{
		label: "Now Playing",
		screen: SCREENS.NOW_PLAYING
	}
];
function App() {
	_s();
	const [currentScreen, setCurrentScreen] = useState(SCREENS.SIGN_UP);
	// Always change screens through this so a bad screen name fails loudly
	function navigate(screen) {
		assertValidScreen(screen);
		setCurrentScreen(screen);
	}
	const [currentQueue, setCurrentQueue] = useState([]);
	const [playOrder, setPlayOrder] = useState([]);
	const [playPosition, setPlayPosition] = useState(0);
	const [isShuffle, setIsShuffle] = useState(false);
	const [isRepeating, setIsRepeating] = useState(false);
	const [session, setSession] = useState(null);
	const [savedTracks, setSavedTracks] = useState([]);
	const [signedIn, setSignedIn] = useState(false);
	const [isSidebarOpen, setIsSidebarOpen] = useState(true);
	const [uploadProgress, setUploadProgress] = useState(null);
	const [panelMode, setPanelMode] = useState("open");
	const currentSong = currentQueue[playOrder[playPosition]];
	const upNext = playOrder.slice(playPosition + 1).map((index) => currentQueue[index]);
	const queue = {
		tracks: currentQueue,
		order: playOrder,
		position: playPosition
	};
	const modes = {
		isShuffle,
		isRepeating
	};
	const controls = {
		nextTrack: handleNextTrack,
		previousTrack: handlePreviousTrack,
		toggleShuffle: handleToggleShuffle,
		toggleRepeat: handleToggleRepeat
	};
	useEffect(() => {
		supabase.auth.getSession().then(({ data }) => setSession(data.session));
		const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
			setSession(session);
			navigate(session ? SCREENS.HOME : SCREENS.SIGN_IN);
		});
		return () => listener.subscription.unsubscribe();
	}, []);
	async function handleSignOut() {
		await supabase.auth.signOut();
	}
	async function handleFileUpload(event) {
		const files = Array.from(event.target.files ?? []);
		// Reset so the same file(s) can be picked again later
		event.target.value = "";
		if (files.length === 0) return;
		setUploadProgress({
			done: 0,
			total: files.length
		});
		const { uploaded, failed } = await uploadFiles(files, session.user.id, (done, total) => setUploadProgress({
			done,
			total
		}));
		setUploadProgress(null);
		setSavedTracks((currentTracks) => [...uploaded, ...currentTracks]);
		if (failed.length > 0) {
			console.log(failed);
			alert(`${uploaded.length} uploaded; ${failed.length} failed.`);
		} else {
			alert(`${uploaded.length} song(s) uploaded successfully.`);
		}
	}
	function startQueue(tracks, startingIndex = 0) {
		const normalOrder = tracks.map((_, index) => index);
		setCurrentQueue(tracks);
		setPlayOrder(normalOrder);
		setPlayPosition(startingIndex);
	}
	// TODO: Fix this function
	function handleNextTrack() {
		if (playPosition < playOrder.length - 1) {
			setPlayPosition((position) => position + 1);
		} else if (isRepeating) {
			setPlayPosition(0);
		}
	}
	function handlePreviousTrack() {
		setPlayPosition((currentPosition) => {
			if (currentPosition === 0) {
				return 0;
			}
			return currentPosition - 1;
		});
	}
	function handleToggleShuffle() {
		if (!currentSong) return;
		if (!isShuffle) {
			const shuffledOrder = createShuffleOrder(currentQueue.length);
			const currentPositionInOrder = shuffledOrder.indexOf(currentTrackIndex);
			[shuffledOrder[0], shuffledOrder[currentPositionInOrder]] = [shuffledOrder[currentPositionInOrder], shuffledOrder[0]];
			setPlayOrder(shuffledOrder);
			setPlayPosition(0);
			setIsShuffle(true);
		} else {
			const normalOrder = currentQueue.map((_, index) => index);
			setPlayOrder(normalOrder);
			setPlayPosition(currentTrackIndex);
			setIsShuffle(false);
		}
	}
	function handleToggleRepeat() {
		if (isRepeating) {
			setIsRepeating(false);
		} else {
			setIsRepeating(true);
		}
	}
	function createShuffleOrder(queueLength) {
		const order = Array.from({ length: queueLength }, (_, index) => index);
		for (let index = order.length - 1; index > 0; --index) {
			const randomIndex = Math.floor(Math.random() * (index + 1));
			[order[index], order[randomIndex]] = [order[randomIndex], order[index]];
		}
		return order;
	}
	if (!session) {
		return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("nav", { children: [/* @__PURE__ */ _jsxDEV("button", {
				onClick: () => navigate(SCREENS.SIGN_UP),
				children: "Sign Up"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => navigate(SCREENS.SIGN_IN),
				children: "Sign In"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 9
			}, this),
			currentScreen === SCREENS.SIGN_UP && /* @__PURE__ */ _jsxDEV(SignUp, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 47
			}, this),
			currentScreen === SCREENS.SIGN_IN && /* @__PURE__ */ _jsxDEV(SignIn, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 216,
				columnNumber: 47
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ _jsxDEV(Sidebar, {
				isOpen: isSidebarOpen,
				onToggle: () => setIsSidebarOpen(!isSidebarOpen),
				currentScreen,
				onNavigate: navigate,
				currentSong
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 223,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "app-main",
				children: [
					/* @__PURE__ */ _jsxDEV("nav", {
						className: "top-nav",
						children: [TOP_NAV_ITEMS.map(({ label, screen }) => /* @__PURE__ */ _jsxDEV("button", {
							className: currentScreen === screen ? "active" : "",
							onClick: () => navigate(screen),
							children: label
						}, screen, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 13
						}, this)), /* @__PURE__ */ _jsxDEV("button", {
							className: "sign-out",
							onClick: handleSignOut,
							children: "Sign out"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 9
					}, this),
					currentScreen === SCREENS.HOME && /* @__PURE__ */ _jsxDEV(Home, {
						session,
						onStartQueue: startQueue
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 247,
						columnNumber: 44
					}, this),
					currentScreen === SCREENS.PLAYLISTS && /* @__PURE__ */ _jsxDEV(Playlists, { session }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 248,
						columnNumber: 49
					}, this),
					currentScreen === SCREENS.SEARCH && /* @__PURE__ */ _jsxDEV(Search, {
						session,
						onStartQueue: startQueue
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 46
					}, this),
					currentScreen === SCREENS.GENRES && /* @__PURE__ */ _jsxDEV(Genres, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 250,
						columnNumber: 46
					}, this),
					currentScreen === SCREENS.FAVORITES && /* @__PURE__ */ _jsxDEV(Favorites, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 49
					}, this),
					currentScreen === SCREENS.TASTE_PROFILE && /* @__PURE__ */ _jsxDEV(TasteProfile, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 252,
						columnNumber: 53
					}, this),
					currentScreen === SCREENS.COLLECTIONS && /* @__PURE__ */ _jsxDEV(Collections, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 253,
						columnNumber: 51
					}, this),
					currentScreen === SCREENS.SOCIALS && /* @__PURE__ */ _jsxDEV(Socials, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 47
					}, this),
					currentScreen === SCREENS.NOW_PLAYING && /* @__PURE__ */ _jsxDEV(NowPlaying, {
						currentSong,
						upNext
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 11
					}, this),
					currentScreen === SCREENS.PLAYER && /* @__PURE__ */ _jsxDEV(MusicPlayer, {
						currentQueue,
						playOrder,
						playPosition,
						onFileUpload: handleFileUpload,
						uploadProgress
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 260,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 7
			}, this),
			currentScreen !== SCREENS.NOW_PLAYING && /* @__PURE__ */ _jsxDEV(NowPlayingPanel, {
				mode: panelMode,
				onChangeMode: setPanelMode,
				currentSong,
				upNext
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 272,
				columnNumber: 9
			}, this),
			currentQueue && /* @__PURE__ */ _jsxDEV(MiniPlayer, {
				queue,
				modes,
				controls
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 281,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ProfileMenu, { onSignOut: handleSignOut }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 288,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 222,
		columnNumber: 5
	}, this);
}
_s(App, "ZIRmm20aEeeFY3d58iR3W30IVTE=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxPQUFPO0FBQ1AsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxTQUFTLHlCQUF5QjtBQUUzQyxPQUFPLFlBQVk7QUFDbkIsT0FBTyxpQkFBaUI7QUFDeEIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyxZQUFZO0FBQ25CLE9BQU8sVUFBVTtBQUNqQixPQUFPLGVBQWU7QUFDdEIsT0FBTyxhQUFhO0FBQ3BCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sWUFBWTtBQUNuQixPQUFPLFlBQVk7QUFDbkIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sYUFBYTtBQUNwQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLHFCQUFxQjtBQUM1QixPQUFPOzs7O0FBRVAsTUFBTSxnQkFBZ0I7Q0FDcEI7RUFBRSxPQUFPO0VBQVEsUUFBUSxRQUFRO0NBQUs7Q0FDdEM7RUFBRSxPQUFPO0VBQWEsUUFBUSxRQUFRO0NBQVU7Q0FDaEQ7RUFBRSxPQUFPO0VBQVUsUUFBUSxRQUFRO0NBQU87Q0FDMUM7RUFBRSxPQUFPO0VBQWUsUUFBUSxRQUFRO0NBQVk7QUFDdEQ7QUFFQSxTQUFTLE1BQU07O0NBQ2IsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsUUFBUSxPQUFPOztDQUdsRSxTQUFTLFNBQVMsUUFBUTtFQUN4QixrQkFBa0IsTUFBTTtFQUN4QixpQkFBaUIsTUFBTTtDQUN6QjtDQUNBLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLENBQUMsQ0FBQztDQUNuRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsQ0FBQztDQUVsRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FFcEQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQyxDQUFDO0NBQ2pELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLElBQUk7Q0FDdkQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxJQUFJO0NBQ3pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLE1BQU07Q0FFakQsTUFBTSxjQUFjLGFBQWEsVUFBVTtDQUMzQyxNQUFNLFNBQVMsVUFDWixNQUFNLGVBQWUsQ0FBQyxDQUFDLENBQ3ZCLEtBQUssVUFBVSxhQUFhLE1BQU07Q0FFckMsTUFBTSxRQUFRO0VBQ1osUUFBUTtFQUNSLE9BQU87RUFDUCxVQUFVO0NBQ1o7Q0FFQSxNQUFNLFFBQVE7RUFDWjtFQUNBO0NBQ0Y7Q0FFQSxNQUFNLFdBQVc7RUFDZixXQUFXO0VBQ1gsZUFBZTtFQUNmLGVBQWU7RUFDZixjQUFjO0NBQ2hCO0NBRUEsZ0JBQWdCO0VBQ2hCLFNBQVMsS0FBSyxXQUFXLENBQUMsQ0FBQyxNQUFNLEVBQUUsV0FBVyxXQUFXLEtBQUssT0FBTyxDQUFDO0VBQ3RFLE1BQU0sRUFBRSxNQUFNLGFBQWEsU0FBUyxLQUFLLG1CQUN0QyxRQUFRLFlBQVk7R0FDbkIsV0FBVyxPQUFPO0dBQ2xCLFNBQVMsVUFBVSxRQUFRLE9BQU8sUUFBUSxPQUFPO0VBQ25ELENBQ0E7RUFDQSxhQUFhLFNBQVMsYUFBYSxZQUFZO0NBQ2pELEdBQUcsQ0FBQyxDQUFDO0NBRUwsZUFBZSxnQkFBZ0I7RUFDN0IsTUFBTSxTQUFTLEtBQUssUUFBUTtDQUM5QjtDQUVBLGVBQWUsaUJBQWlCLE9BQU87RUFDckMsTUFBTSxRQUFRLE1BQU0sS0FBSyxNQUFNLE9BQU8sU0FBUyxDQUFDLENBQUM7O0VBRWpELE1BQU0sT0FBTyxRQUFRO0VBRXJCLElBQUksTUFBTSxXQUFXLEdBQ25CO0VBRUYsa0JBQWtCO0dBQUUsTUFBTTtHQUFHLE9BQU8sTUFBTTtFQUFPLENBQUM7RUFFbEQsTUFBTSxFQUFFLFVBQVUsV0FBVyxNQUFNLFlBQ2pDLE9BQ0EsUUFBUSxLQUFLLEtBQ1osTUFBTSxVQUFVLGtCQUFrQjtHQUFFO0dBQU07RUFBTSxDQUFDLENBQ3BEO0VBRUEsa0JBQWtCLElBQUk7RUFDdEIsZ0JBQWdCLGtCQUFrQixDQUFDLEdBQUcsVUFBVSxHQUFHLGFBQWEsQ0FBQztFQUVqRSxJQUFJLE9BQU8sU0FBUyxHQUFHO0dBQ3JCLFFBQVEsSUFBSSxNQUFNO0dBQ2xCLE1BQU0sR0FBRyxTQUFTLE9BQU8sYUFBYSxPQUFPLE9BQU8sU0FBUztFQUMvRCxPQUFPO0dBQ0wsTUFBTSxHQUFHLFNBQVMsT0FBTyxnQ0FBZ0M7RUFDM0Q7Q0FDRjtDQUVBLFNBQVMsV0FBVyxRQUFRLGdCQUFnQixHQUFHO0VBQzdDLE1BQU0sY0FBYyxPQUFPLEtBQUssR0FBRyxVQUFVLEtBQUs7RUFFbEQsZ0JBQWdCLE1BQU07RUFDdEIsYUFBYSxXQUFXO0VBQ3hCLGdCQUFnQixhQUFhO0NBQy9COztDQUdBLFNBQVMsa0JBQWtCO0VBRXpCLElBQUksZUFBZSxVQUFVLFNBQVMsR0FBRztHQUN2QyxpQkFBaUIsYUFBYSxXQUFXLENBQUM7RUFDNUMsT0FBTyxJQUFJLGFBQWE7R0FDdEIsZ0JBQWdCLENBQUM7RUFDbkI7Q0FDRjtDQUVBLFNBQVMsc0JBQXNCO0VBQzdCLGlCQUFpQixvQkFBb0I7R0FDbkMsSUFBSSxvQkFBb0IsR0FBRztJQUN6QixPQUFPO0dBQ1Q7R0FDQSxPQUFPLGtCQUFrQjtFQUMzQixDQUFDO0NBQ0g7Q0FHQSxTQUFTLHNCQUFzQjtFQUM3QixJQUFJLENBQUMsYUFBYTtFQUVsQixJQUFJLENBQUMsV0FBVztHQUNkLE1BQU0sZ0JBQWdCLG1CQUNwQixhQUFhLE1BQ2Y7R0FFQSxNQUFNLHlCQUF5QixjQUFjLFFBQzNDLGlCQUNGO0dBRUEsQ0FDRSxjQUFjLElBQ2QsY0FBYywyQkFDWixDQUNGLGNBQWMseUJBQ2QsY0FBYyxFQUNoQjtHQUVBLGFBQWEsYUFBYTtHQUMxQixnQkFBZ0IsQ0FBQztHQUNqQixhQUFhLElBQUk7RUFDbkIsT0FBTztHQUNMLE1BQU0sY0FBYyxhQUFhLEtBQUssR0FBRyxVQUFVLEtBQUs7R0FFeEQsYUFBYSxXQUFXO0dBQ3hCLGdCQUFnQixpQkFBaUI7R0FDakMsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FFQSxTQUFTLHFCQUFxQjtFQUM1QixJQUFJLGFBQWE7R0FDZixlQUFlLEtBQUs7RUFDdEIsT0FBTztHQUNMLGVBQWUsSUFBSTtFQUNyQjtDQUNGO0NBRUEsU0FBUyxtQkFBbUIsYUFBYTtFQUN2QyxNQUFNLFFBQVEsTUFBTSxLQUNsQixFQUFFLFFBQVEsWUFBWSxJQUNyQixHQUFHLFVBQVUsS0FDaEI7RUFFQSxLQUFLLElBQUksUUFBUSxNQUFNLFNBQVMsR0FBRyxRQUFRLEdBQUcsRUFBRSxPQUFPO0dBQ3JELE1BQU0sY0FBYyxLQUFLLE1BQ3ZCLEtBQUssT0FBTyxLQUFLLFFBQVEsRUFDM0I7R0FFQSxDQUFDLE1BQU0sUUFBUSxNQUFNLGdCQUFnQixDQUNuQyxNQUFNLGNBQ04sTUFBTSxNQUNSO0VBQ0Y7RUFFQSxPQUFPO0NBQ1Q7Q0FFQSxJQUFJLENBQUMsU0FBUztFQUNaLE9BQ0U7R0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRDtJQUFRLGVBQWUsU0FBUyxRQUFRLE9BQU87Y0FBRztHQUFlOzs7O2FBQ2pFLHdCQUFDLFVBQUQ7SUFBUSxlQUFlLFNBQVMsUUFBUSxPQUFPO2NBQUc7R0FBZTs7OztXQUM5RDs7Ozs7R0FFSixrQkFBa0IsUUFBUSxXQUFXLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7R0FDOUMsa0JBQWtCLFFBQVEsV0FBVyx3QkFBQyxRQUFELENBQVM7Ozs7O0VBQy9DOzs7OztDQUVOO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsU0FBRDtJQUNFLFFBQVE7SUFDUixnQkFBZ0IsaUJBQWlCLENBQUMsYUFBYTtJQUNoQztJQUNmLFlBQVk7SUFDQztHQUNkOzs7OztHQUVELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNHLGNBQWMsS0FBSyxFQUFFLE9BQU8sYUFDM0Isd0JBQUMsVUFBRDtPQUVFLFdBQVcsa0JBQWtCLFNBQVMsV0FBVztPQUNqRCxlQUFlLFNBQVMsTUFBTTtpQkFFN0I7TUFDSyxHQUxEOzs7O2FBS0MsQ0FDVCxHQUNELHdCQUFDLFVBQUQ7T0FBUSxXQUFVO09BQVcsU0FBUztpQkFBZTtNQUU3Qzs7OztjQUNMOzs7Ozs7S0FFSixrQkFBa0IsUUFBUSxRQUFRLHdCQUFDLE1BQUQ7TUFBZTtNQUFTLGNBQWM7S0FBYTs7Ozs7S0FDckYsa0JBQWtCLFFBQVEsYUFBYSx3QkFBQyxXQUFELEVBQW9CLFFBQVU7Ozs7O0tBQ3JFLGtCQUFrQixRQUFRLFVBQVUsd0JBQUMsUUFBRDtNQUFpQjtNQUFTLGNBQWM7S0FBYTs7Ozs7S0FDekYsa0JBQWtCLFFBQVEsVUFBVSx3QkFBQyxRQUFELENBQVM7Ozs7O0tBQzdDLGtCQUFrQixRQUFRLGFBQWEsd0JBQUMsV0FBRCxDQUFZOzs7OztLQUNuRCxrQkFBa0IsUUFBUSxpQkFBaUIsd0JBQUMsY0FBRCxDQUFlOzs7OztLQUMxRCxrQkFBa0IsUUFBUSxlQUFlLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7S0FDdkQsa0JBQWtCLFFBQVEsV0FBVyx3QkFBQyxTQUFELENBQVU7Ozs7O0tBQy9DLGtCQUFrQixRQUFRLGVBQ3pCLHdCQUFDLFlBQUQ7TUFBeUI7TUFBcUI7S0FBUzs7Ozs7S0FHeEQsa0JBQWtCLFFBQVEsVUFDekIsd0JBQUMsYUFBRDtNQUNnQjtNQUNIO01BQ0c7TUFDZCxjQUFjO01BQ0U7S0FDakI7Ozs7O0lBRUE7Ozs7OztHQUdKLGtCQUFrQixRQUFRLGVBQ3pCLHdCQUFDLGlCQUFEO0lBQ0UsTUFBTTtJQUNOLGNBQWM7SUFDRDtJQUNMO0dBQ1Q7Ozs7O0dBR0YsZ0JBQ0Msd0JBQUMsWUFBRDtJQUNTO0lBQ0E7SUFDRztHQUNYOzs7OztHQUdILHdCQUFDLGFBQUQsRUFBYSxXQUFXLGNBQWdCOzs7OztFQUNyQzs7Ozs7O0FBRVQ7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCIuL2xpYi9zdXBhYmFzZVwiO1xyXG5pbXBvcnQgeyB1cGxvYWRGaWxlcyB9IGZyb20gXCIuL2xpYi9maWxldXBsb2FkaW5nXCI7XHJcbmltcG9ydCB7IFNDUkVFTlMsIGFzc2VydFZhbGlkU2NyZWVuIH0gZnJvbSBcIi4vY29uc3RhbnRzL3NjcmVlbnNcIjtcclxuXHJcbmltcG9ydCBTaWduVXAgZnJvbSBcIi4vY29tcG9uZW50cy9TaWduVXBcIjtcclxuaW1wb3J0IE11c2ljUGxheWVyIGZyb20gXCIuL2NvbXBvbmVudHMvTXVzaWNQbGF5ZXJcIjtcclxuaW1wb3J0IE1pbmlQbGF5ZXIgZnJvbSBcIi4vY29tcG9uZW50cy9NaW5pUGxheWVyXCI7XHJcbmltcG9ydCBTaWduSW4gZnJvbSBcIi4vY29tcG9uZW50cy9TaWduSW5cIjtcclxuaW1wb3J0IEhvbWUgZnJvbSBcIi4vY29tcG9uZW50cy9Ib21lXCI7XHJcbmltcG9ydCBQbGF5bGlzdHMgZnJvbSBcIi4vY29tcG9uZW50cy9QbGF5bGlzdHNcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4vY29tcG9uZW50cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBQcm9maWxlTWVudSBmcm9tIFwiLi9jb21wb25lbnRzL1Byb2ZpbGVNZW51XCI7XHJcbmltcG9ydCBTZWFyY2ggZnJvbSBcIi4vY29tcG9uZW50cy9TZWFyY2hcIjtcclxuaW1wb3J0IEdlbnJlcyBmcm9tIFwiLi9jb21wb25lbnRzL0dlbnJlc1wiO1xyXG5pbXBvcnQgRmF2b3JpdGVzIGZyb20gXCIuL2NvbXBvbmVudHMvRmF2b3JpdGVzXCI7XHJcbmltcG9ydCBUYXN0ZVByb2ZpbGUgZnJvbSBcIi4vY29tcG9uZW50cy9UYXN0ZVByb2ZpbGVcIjtcclxuaW1wb3J0IENvbGxlY3Rpb25zIGZyb20gXCIuL2NvbXBvbmVudHMvQ29sbGVjdGlvbnNcIjtcclxuaW1wb3J0IFNvY2lhbHMgZnJvbSBcIi4vY29tcG9uZW50cy9Tb2NpYWxzXCI7XHJcbmltcG9ydCBOb3dQbGF5aW5nIGZyb20gXCIuL2NvbXBvbmVudHMvTm93UGxheWluZ1wiO1xyXG5pbXBvcnQgTm93UGxheWluZ1BhbmVsIGZyb20gXCIuL2NvbXBvbmVudHMvTm93UGxheWluZ1BhbmVsXCI7XHJcbmltcG9ydCBcIi4vc3R5bGVzL1RvcE5hdi5jc3NcIjtcclxuXHJcbmNvbnN0IFRPUF9OQVZfSVRFTVMgPSBbXHJcbiAgeyBsYWJlbDogXCJIb21lXCIsIHNjcmVlbjogU0NSRUVOUy5IT01FIH0sXHJcbiAgeyBsYWJlbDogXCJQbGF5bGlzdHNcIiwgc2NyZWVuOiBTQ1JFRU5TLlBMQVlMSVNUUyB9LFxyXG4gIHsgbGFiZWw6IFwiUGxheWVyXCIsIHNjcmVlbjogU0NSRUVOUy5QTEFZRVIgfSxcclxuICB7IGxhYmVsOiBcIk5vdyBQbGF5aW5nXCIsIHNjcmVlbjogU0NSRUVOUy5OT1dfUExBWUlORyB9LFxyXG5dO1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIGNvbnN0IFtjdXJyZW50U2NyZWVuLCBzZXRDdXJyZW50U2NyZWVuXSA9IHVzZVN0YXRlKFNDUkVFTlMuU0lHTl9VUCk7XHJcblxyXG4gIC8vIEFsd2F5cyBjaGFuZ2Ugc2NyZWVucyB0aHJvdWdoIHRoaXMgc28gYSBiYWQgc2NyZWVuIG5hbWUgZmFpbHMgbG91ZGx5XHJcbiAgZnVuY3Rpb24gbmF2aWdhdGUoc2NyZWVuKSB7XHJcbiAgICBhc3NlcnRWYWxpZFNjcmVlbihzY3JlZW4pO1xyXG4gICAgc2V0Q3VycmVudFNjcmVlbihzY3JlZW4pO1xyXG4gIH1cclxuICBjb25zdCBbY3VycmVudFF1ZXVlLCBzZXRDdXJyZW50UXVldWVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwbGF5T3JkZXIsIHNldFBsYXlPcmRlcl0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BsYXlQb3NpdGlvbiwgc2V0UGxheVBvc2l0aW9uXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBbaXNTaHVmZmxlLCBzZXRJc1NodWZmbGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc1JlcGVhdGluZywgc2V0SXNSZXBlYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2Vzc2lvbiwgc2V0U2Vzc2lvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2F2ZWRUcmFja3MsIHNldFNhdmVkVHJhY2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2lnbmVkSW4sIHNldFNpZ25lZEluXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTaWRlYmFyT3Blbiwgc2V0SXNTaWRlYmFyT3Blbl0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbdXBsb2FkUHJvZ3Jlc3MsIHNldFVwbG9hZFByb2dyZXNzXSA9IHVzZVN0YXRlKG51bGwpOyAvLyB7IGRvbmUsIHRvdGFsIH0gd2hpbGUgdXBsb2FkaW5nXHJcbiAgY29uc3QgW3BhbmVsTW9kZSwgc2V0UGFuZWxNb2RlXSA9IHVzZVN0YXRlKFwib3BlblwiKTsgLy8gcmlnaHQgY29sdW1uOiBcIm9wZW5cIiB8IFwibWluaVwiIHwgXCJoaWRkZW5cIlxyXG5cclxuICBjb25zdCBjdXJyZW50U29uZyA9IGN1cnJlbnRRdWV1ZVtwbGF5T3JkZXJbcGxheVBvc2l0aW9uXV07XHJcbiAgY29uc3QgdXBOZXh0ID0gcGxheU9yZGVyXHJcbiAgICAuc2xpY2UocGxheVBvc2l0aW9uICsgMSlcclxuICAgIC5tYXAoKGluZGV4KSA9PiBjdXJyZW50UXVldWVbaW5kZXhdKTtcclxuXHJcbiAgY29uc3QgcXVldWUgPSB7XHJcbiAgICB0cmFja3M6IGN1cnJlbnRRdWV1ZSxcclxuICAgIG9yZGVyOiBwbGF5T3JkZXIsXHJcbiAgICBwb3NpdGlvbjogcGxheVBvc2l0aW9uXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbW9kZXMgPSB7XHJcbiAgICBpc1NodWZmbGUsXHJcbiAgICBpc1JlcGVhdGluZ1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbnRyb2xzID0ge1xyXG4gICAgbmV4dFRyYWNrOiBoYW5kbGVOZXh0VHJhY2ssXHJcbiAgICBwcmV2aW91c1RyYWNrOiBoYW5kbGVQcmV2aW91c1RyYWNrLFxyXG4gICAgdG9nZ2xlU2h1ZmZsZTogaGFuZGxlVG9nZ2xlU2h1ZmZsZSxcclxuICAgIHRvZ2dsZVJlcGVhdDogaGFuZGxlVG9nZ2xlUmVwZWF0XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICBzdXBhYmFzZS5hdXRoLmdldFNlc3Npb24oKS50aGVuKCh7IGRhdGEgfSkgPT4gc2V0U2Vzc2lvbihkYXRhLnNlc3Npb24pKTtcclxuICBjb25zdCB7IGRhdGE6IGxpc3RlbmVyIH0gPSBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKFxyXG4gICAgKF9ldmVudCwgc2Vzc2lvbikgPT4ge1xyXG4gICAgICBzZXRTZXNzaW9uKHNlc3Npb24pO1xyXG4gICAgICBuYXZpZ2F0ZShzZXNzaW9uID8gU0NSRUVOUy5IT01FIDogU0NSRUVOUy5TSUdOX0lOKTtcclxuICAgIH1cclxuICAgICk7XHJcbiAgICByZXR1cm4gKCkgPT4gbGlzdGVuZXIuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTaWduT3V0KCkge1xyXG4gICAgYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduT3V0KCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVGaWxlVXBsb2FkKGV2ZW50KSB7XHJcbiAgICBjb25zdCBmaWxlcyA9IEFycmF5LmZyb20oZXZlbnQudGFyZ2V0LmZpbGVzID8/IFtdKTtcclxuICAgIC8vIFJlc2V0IHNvIHRoZSBzYW1lIGZpbGUocykgY2FuIGJlIHBpY2tlZCBhZ2FpbiBsYXRlclxyXG4gICAgZXZlbnQudGFyZ2V0LnZhbHVlID0gXCJcIjtcclxuXHJcbiAgICBpZiAoZmlsZXMubGVuZ3RoID09PSAwKSBcclxuICAgICAgcmV0dXJuO1xyXG5cclxuICAgIHNldFVwbG9hZFByb2dyZXNzKHsgZG9uZTogMCwgdG90YWw6IGZpbGVzLmxlbmd0aCB9KTtcclxuXHJcbiAgICBjb25zdCB7IHVwbG9hZGVkLCBmYWlsZWQgfSA9IGF3YWl0IHVwbG9hZEZpbGVzKFxyXG4gICAgICBmaWxlcyxcclxuICAgICAgc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICAoZG9uZSwgdG90YWwpID0+IHNldFVwbG9hZFByb2dyZXNzKHsgZG9uZSwgdG90YWwgfSlcclxuICAgICk7XHJcblxyXG4gICAgc2V0VXBsb2FkUHJvZ3Jlc3MobnVsbCk7XHJcbiAgICBzZXRTYXZlZFRyYWNrcygoY3VycmVudFRyYWNrcykgPT4gWy4uLnVwbG9hZGVkLCAuLi5jdXJyZW50VHJhY2tzXSk7XHJcblxyXG4gICAgaWYgKGZhaWxlZC5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGZhaWxlZCk7XHJcbiAgICAgIGFsZXJ0KGAke3VwbG9hZGVkLmxlbmd0aH0gdXBsb2FkZWQ7ICR7ZmFpbGVkLmxlbmd0aH0gZmFpbGVkLmApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYWxlcnQoYCR7dXBsb2FkZWQubGVuZ3RofSBzb25nKHMpIHVwbG9hZGVkIHN1Y2Nlc3NmdWxseS5gKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHN0YXJ0UXVldWUodHJhY2tzLCBzdGFydGluZ0luZGV4ID0gMCkge1xyXG4gICAgY29uc3Qgbm9ybWFsT3JkZXIgPSB0cmFja3MubWFwKChfLCBpbmRleCkgPT4gaW5kZXgpO1xyXG5cclxuICAgIHNldEN1cnJlbnRRdWV1ZSh0cmFja3MpO1xyXG4gICAgc2V0UGxheU9yZGVyKG5vcm1hbE9yZGVyKTtcclxuICAgIHNldFBsYXlQb3NpdGlvbihzdGFydGluZ0luZGV4KTtcclxuICB9XHJcblxyXG4gIC8vIFRPRE86IEZpeCB0aGlzIGZ1bmN0aW9uXHJcbiAgZnVuY3Rpb24gaGFuZGxlTmV4dFRyYWNrKCkge1xyXG5cclxuICAgIGlmIChwbGF5UG9zaXRpb24gPCBwbGF5T3JkZXIubGVuZ3RoIC0gMSkge1xyXG4gICAgICBzZXRQbGF5UG9zaXRpb24oKHBvc2l0aW9uKSA9PiBwb3NpdGlvbiArIDEpO1xyXG4gICAgfSBlbHNlIGlmIChpc1JlcGVhdGluZykge1xyXG4gICAgICBzZXRQbGF5UG9zaXRpb24oMCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBoYW5kbGVQcmV2aW91c1RyYWNrKCkge1xyXG4gICAgc2V0UGxheVBvc2l0aW9uKChjdXJyZW50UG9zaXRpb24pID0+IHtcclxuICAgICAgaWYgKGN1cnJlbnRQb3NpdGlvbiA9PT0gMCkge1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBjdXJyZW50UG9zaXRpb24gLSAxO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlVG9nZ2xlU2h1ZmZsZSgpIHtcclxuICAgIGlmICghY3VycmVudFNvbmcpIHJldHVybjtcclxuXHJcbiAgICBpZiAoIWlzU2h1ZmZsZSkge1xyXG4gICAgICBjb25zdCBzaHVmZmxlZE9yZGVyID0gY3JlYXRlU2h1ZmZsZU9yZGVyKFxyXG4gICAgICAgIGN1cnJlbnRRdWV1ZS5sZW5ndGhcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IGN1cnJlbnRQb3NpdGlvbkluT3JkZXIgPSBzaHVmZmxlZE9yZGVyLmluZGV4T2YoXHJcbiAgICAgICAgY3VycmVudFRyYWNrSW5kZXhcclxuICAgICAgKTtcclxuXHJcbiAgICAgIFtcclxuICAgICAgICBzaHVmZmxlZE9yZGVyWzBdLFxyXG4gICAgICAgIHNodWZmbGVkT3JkZXJbY3VycmVudFBvc2l0aW9uSW5PcmRlcl1cclxuICAgICAgXSA9IFtcclxuICAgICAgICBzaHVmZmxlZE9yZGVyW2N1cnJlbnRQb3NpdGlvbkluT3JkZXJdLFxyXG4gICAgICAgIHNodWZmbGVkT3JkZXJbMF1cclxuICAgICAgXTtcclxuXHJcbiAgICAgIHNldFBsYXlPcmRlcihzaHVmZmxlZE9yZGVyKTtcclxuICAgICAgc2V0UGxheVBvc2l0aW9uKDApO1xyXG4gICAgICBzZXRJc1NodWZmbGUodHJ1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBub3JtYWxPcmRlciA9IGN1cnJlbnRRdWV1ZS5tYXAoKF8sIGluZGV4KSA9PiBpbmRleCk7XHJcblxyXG4gICAgICBzZXRQbGF5T3JkZXIobm9ybWFsT3JkZXIpO1xyXG4gICAgICBzZXRQbGF5UG9zaXRpb24oY3VycmVudFRyYWNrSW5kZXgpO1xyXG4gICAgICBzZXRJc1NodWZmbGUoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlVG9nZ2xlUmVwZWF0KCkge1xyXG4gICAgaWYgKGlzUmVwZWF0aW5nKSB7XHJcbiAgICAgIHNldElzUmVwZWF0aW5nKGZhbHNlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldElzUmVwZWF0aW5nKHRydWUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY3JlYXRlU2h1ZmZsZU9yZGVyKHF1ZXVlTGVuZ3RoKSB7XHJcbiAgICBjb25zdCBvcmRlciA9IEFycmF5LmZyb20oXHJcbiAgICAgIHsgbGVuZ3RoOiBxdWV1ZUxlbmd0aCB9LFxyXG4gICAgICAoXywgaW5kZXgpID0+IGluZGV4XHJcbiAgICApO1xyXG5cclxuICAgIGZvciAobGV0IGluZGV4ID0gb3JkZXIubGVuZ3RoIC0gMTsgaW5kZXggPiAwOyAtLWluZGV4KSB7XHJcbiAgICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihcclxuICAgICAgICBNYXRoLnJhbmRvbSgpICogKGluZGV4ICsgMSlcclxuICAgICAgKTtcclxuXHJcbiAgICAgIFtvcmRlcltpbmRleF0sIG9yZGVyW3JhbmRvbUluZGV4XV0gPSBbXHJcbiAgICAgICAgb3JkZXJbcmFuZG9tSW5kZXhdLFxyXG4gICAgICAgIG9yZGVyW2luZGV4XVxyXG4gICAgICBdO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBvcmRlcjtcclxuICB9XHJcblxyXG4gIGlmICghc2Vzc2lvbikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPD5cclxuICAgICAgICA8bmF2PlxyXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShTQ1JFRU5TLlNJR05fVVApfT5TaWduIFVwPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFNDUkVFTlMuU0lHTl9JTil9PlNpZ24gSW48L2J1dHRvbj5cclxuICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAge2N1cnJlbnRTY3JlZW4gPT09IFNDUkVFTlMuU0lHTl9VUCAmJiA8U2lnblVwIC8+fVxyXG4gICAgICAgIHtjdXJyZW50U2NyZWVuID09PSBTQ1JFRU5TLlNJR05fSU4gJiYgPFNpZ25JbiAvPn1cclxuICAgICAgPC8+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLXNoZWxsXCI+XHJcbiAgICAgIDxTaWRlYmFyXHJcbiAgICAgICAgaXNPcGVuPXtpc1NpZGViYXJPcGVufVxyXG4gICAgICAgIG9uVG9nZ2xlPXsoKSA9PiBzZXRJc1NpZGViYXJPcGVuKCFpc1NpZGViYXJPcGVuKX1cclxuICAgICAgICBjdXJyZW50U2NyZWVuPXtjdXJyZW50U2NyZWVufVxyXG4gICAgICAgIG9uTmF2aWdhdGU9e25hdmlnYXRlfVxyXG4gICAgICAgIGN1cnJlbnRTb25nPXtjdXJyZW50U29uZ31cclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLW1haW5cIj5cclxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInRvcC1uYXZcIj5cclxuICAgICAgICAgIHtUT1BfTkFWX0lURU1TLm1hcCgoeyBsYWJlbCwgc2NyZWVuIH0pID0+IChcclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGtleT17c2NyZWVufVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y3VycmVudFNjcmVlbiA9PT0gc2NyZWVuID8gXCJhY3RpdmVcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoc2NyZWVuKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtsYWJlbH1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwic2lnbi1vdXRcIiBvbkNsaWNrPXtoYW5kbGVTaWduT3V0fT5cclxuICAgICAgICAgICAgU2lnbiBvdXRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvbmF2PlxyXG5cclxuICAgICAgICB7Y3VycmVudFNjcmVlbiA9PT0gU0NSRUVOUy5IT01FICYmIDxIb21lIHNlc3Npb249e3Nlc3Npb259IG9uU3RhcnRRdWV1ZT17c3RhcnRRdWV1ZX0gLz59XHJcbiAgICAgICAge2N1cnJlbnRTY3JlZW4gPT09IFNDUkVFTlMuUExBWUxJU1RTICYmIDxQbGF5bGlzdHMgc2Vzc2lvbj17c2Vzc2lvbn0gLz59XHJcbiAgICAgICAge2N1cnJlbnRTY3JlZW4gPT09IFNDUkVFTlMuU0VBUkNIICYmIDxTZWFyY2ggc2Vzc2lvbj17c2Vzc2lvbn0gb25TdGFydFF1ZXVlPXtzdGFydFF1ZXVlfSAvPn1cclxuICAgICAgICB7Y3VycmVudFNjcmVlbiA9PT0gU0NSRUVOUy5HRU5SRVMgJiYgPEdlbnJlcyAvPn1cclxuICAgICAgICB7Y3VycmVudFNjcmVlbiA9PT0gU0NSRUVOUy5GQVZPUklURVMgJiYgPEZhdm9yaXRlcyAvPn1cclxuICAgICAgICB7Y3VycmVudFNjcmVlbiA9PT0gU0NSRUVOUy5UQVNURV9QUk9GSUxFICYmIDxUYXN0ZVByb2ZpbGUgLz59XHJcbiAgICAgICAge2N1cnJlbnRTY3JlZW4gPT09IFNDUkVFTlMuQ09MTEVDVElPTlMgJiYgPENvbGxlY3Rpb25zIC8+fVxyXG4gICAgICAgIHtjdXJyZW50U2NyZWVuID09PSBTQ1JFRU5TLlNPQ0lBTFMgJiYgPFNvY2lhbHMgLz59XHJcbiAgICAgICAge2N1cnJlbnRTY3JlZW4gPT09IFNDUkVFTlMuTk9XX1BMQVlJTkcgJiYgKFxyXG4gICAgICAgICAgPE5vd1BsYXlpbmcgY3VycmVudFNvbmc9e2N1cnJlbnRTb25nfSB1cE5leHQ9e3VwTmV4dH0gLz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7Y3VycmVudFNjcmVlbiA9PT0gU0NSRUVOUy5QTEFZRVIgJiYgKFxyXG4gICAgICAgICAgPE11c2ljUGxheWVyXHJcbiAgICAgICAgICAgIGN1cnJlbnRRdWV1ZT17Y3VycmVudFF1ZXVlfVxyXG4gICAgICAgICAgICBwbGF5T3JkZXI9e3BsYXlPcmRlcn1cclxuICAgICAgICAgICAgcGxheVBvc2l0aW9uPXtwbGF5UG9zaXRpb259XHJcbiAgICAgICAgICAgIG9uRmlsZVVwbG9hZD17aGFuZGxlRmlsZVVwbG9hZH1cclxuICAgICAgICAgICAgdXBsb2FkUHJvZ3Jlc3M9e3VwbG9hZFByb2dyZXNzfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBPbiB0aGUgTm93IFBsYXlpbmcgcGFnZSB0aGUgY29sdW1uJ3MgY29udGVudCBpcyB0aGUgcGFnZSBpdHNlbGYgKi99XHJcbiAgICAgIHtjdXJyZW50U2NyZWVuICE9PSBTQ1JFRU5TLk5PV19QTEFZSU5HICYmIChcclxuICAgICAgICA8Tm93UGxheWluZ1BhbmVsXHJcbiAgICAgICAgICBtb2RlPXtwYW5lbE1vZGV9XHJcbiAgICAgICAgICBvbkNoYW5nZU1vZGU9e3NldFBhbmVsTW9kZX1cclxuICAgICAgICAgIGN1cnJlbnRTb25nPXtjdXJyZW50U29uZ31cclxuICAgICAgICAgIHVwTmV4dD17dXBOZXh0fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7Y3VycmVudFF1ZXVlICYmIChcclxuICAgICAgICA8TWluaVBsYXllclxyXG4gICAgICAgICAgcXVldWU9e3F1ZXVlfVxyXG4gICAgICAgICAgbW9kZXM9e21vZGVzfVxyXG4gICAgICAgICAgY29udHJvbHM9e2NvbnRyb2xzfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8UHJvZmlsZU1lbnUgb25TaWduT3V0PXtoYW5kbGVTaWduT3V0fSAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwO1xyXG4iXX0=