import { D as INT8, L as UINT8, O as StringType } from "/node_modules/.vite/deps/BasicParser-CAIs-t7m.js?v=987d57e9";
import { a as getBit } from "/node_modules/.vite/deps/Util-DYMxorDw.js?v=987d57e9";
// node_modules/music-metadata/lib/id3v2/ID3v2Token.js
/**
* The picture type according to the ID3v2 APIC frame
* Ref: http://id3.org/id3v2.3.0#Attached_picture
*/
var AttachedPictureType = {
	0: "Other",
	1: "32x32 pixels 'file icon' (PNG only)",
	2: "Other file icon",
	3: "Cover (front)",
	4: "Cover (back)",
	5: "Leaflet page",
	6: "Media (e.g. label side of CD)",
	7: "Lead artist/lead performer/soloist",
	8: "Artist/performer",
	9: "Conductor",
	10: "Band/Orchestra",
	11: "Composer",
	12: "Lyricist/text writer",
	13: "Recording Location",
	14: "During recording",
	15: "During performance",
	16: "Movie/video screen capture",
	17: "A bright coloured fish",
	18: "Illustration",
	19: "Band/artist logotype",
	20: "Publisher/Studio logotype"
};
/**
* https://id3.org/id3v2.3.0#Synchronised_lyrics.2Ftext
*/
var LyricsContentType = {
	other: 0,
	lyrics: 1,
	text: 2,
	movement_part: 3,
	events: 4,
	chord: 5,
	trivia_pop: 6
};
var TimestampFormat = {
	notSynchronized: 0,
	mpegFrameNumber: 1,
	milliseconds: 2
};
/**
* 28 bits (representing up to 256MB) integer, the msb is 0 to avoid 'false syncsignals'.
* 4 * %0xxxxxxx
*/
var UINT32SYNCSAFE = {
	get: (buf, off) => {
		return buf[off + 3] & 127 | buf[off + 2] << 7 | buf[off + 1] << 14 | buf[off] << 21;
	},
	len: 4
};
/**
* ID3v2 header
* Ref: http://id3.org/id3v2.3.0#ID3v2_header
* ToDo
*/
var ID3v2Header = {
	len: 10,
	get: (buf, off) => {
		return {
			fileIdentifier: new StringType(3, "ascii").get(buf, off),
			version: {
				major: INT8.get(buf, off + 3),
				revision: INT8.get(buf, off + 4)
			},
			flags: {
				unsynchronisation: getBit(buf, off + 5, 7),
				isExtendedHeader: getBit(buf, off + 5, 6),
				expIndicator: getBit(buf, off + 5, 5),
				footer: getBit(buf, off + 5, 4)
			},
			size: UINT32SYNCSAFE.get(buf, off + 6)
		};
	}
};
var TextEncodingToken = {
	len: 1,
	get: (uint8Array, off) => {
		switch (uint8Array[off]) {
			case 0: return { encoding: "latin1" };
			case 1: return {
				encoding: "utf-16le",
				bom: true
			};
			case 2: return {
				encoding: "utf-16be",
				bom: false
			};
			case 3: return {
				encoding: "utf8",
				bom: false
			};
			default: return {
				encoding: "utf8",
				bom: false
			};
		}
	}
};
/**
* Used to read first portion of `SYLT` frame
*/
var TextHeader = {
	len: 4,
	get: (uint8Array, off) => {
		return {
			encoding: TextEncodingToken.get(uint8Array, off),
			language: new StringType(3, "latin1").get(uint8Array, off + 1)
		};
	}
};
/**
* Used to read first portion of `SYLT` frame
*/
var SyncTextHeader = {
	len: 6,
	get: (uint8Array, off) => {
		const text = TextHeader.get(uint8Array, off);
		return {
			encoding: text.encoding,
			language: text.language,
			timeStampFormat: UINT8.get(uint8Array, off + 4),
			contentType: UINT8.get(uint8Array, off + 5)
		};
	}
};
export { TextEncodingToken as a, UINT32SYNCSAFE as c, SyncTextHeader as i, ID3v2Header as n, TextHeader as o, LyricsContentType as r, TimestampFormat as s, AttachedPictureType as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSUQzdjJUb2tlbi1EQkhrbUlWai5qcyIsIm5hbWVzIjpbIlRva2VuLlN0cmluZ1R5cGUiLCJ1dGlsLmdldEJpdCJdLCJzb3VyY2VzIjpbIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9pZDN2Mi9JRDN2MlRva2VuLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFRva2VuIGZyb20gJ3Rva2VuLXR5cGVzJztcbmltcG9ydCAqIGFzIHV0aWwgZnJvbSAnLi4vY29tbW9uL1V0aWwuanMnO1xuLyoqXG4gKiBUaGUgcGljdHVyZSB0eXBlIGFjY29yZGluZyB0byB0aGUgSUQzdjIgQVBJQyBmcmFtZVxuICogUmVmOiBodHRwOi8vaWQzLm9yZy9pZDN2Mi4zLjAjQXR0YWNoZWRfcGljdHVyZVxuICovXG5leHBvcnQgY29uc3QgQXR0YWNoZWRQaWN0dXJlVHlwZSA9IHtcbiAgICAwOiAnT3RoZXInLFxuICAgIDE6IFwiMzJ4MzIgcGl4ZWxzICdmaWxlIGljb24nIChQTkcgb25seSlcIixcbiAgICAyOiAnT3RoZXIgZmlsZSBpY29uJyxcbiAgICAzOiAnQ292ZXIgKGZyb250KScsXG4gICAgNDogJ0NvdmVyIChiYWNrKScsXG4gICAgNTogJ0xlYWZsZXQgcGFnZScsXG4gICAgNjogJ01lZGlhIChlLmcuIGxhYmVsIHNpZGUgb2YgQ0QpJyxcbiAgICA3OiAnTGVhZCBhcnRpc3QvbGVhZCBwZXJmb3JtZXIvc29sb2lzdCcsXG4gICAgODogJ0FydGlzdC9wZXJmb3JtZXInLFxuICAgIDk6ICdDb25kdWN0b3InLFxuICAgIDEwOiAnQmFuZC9PcmNoZXN0cmEnLFxuICAgIDExOiAnQ29tcG9zZXInLFxuICAgIDEyOiAnTHlyaWNpc3QvdGV4dCB3cml0ZXInLFxuICAgIDEzOiAnUmVjb3JkaW5nIExvY2F0aW9uJyxcbiAgICAxNDogJ0R1cmluZyByZWNvcmRpbmcnLFxuICAgIDE1OiAnRHVyaW5nIHBlcmZvcm1hbmNlJyxcbiAgICAxNjogJ01vdmllL3ZpZGVvIHNjcmVlbiBjYXB0dXJlJyxcbiAgICAxNzogJ0EgYnJpZ2h0IGNvbG91cmVkIGZpc2gnLFxuICAgIDE4OiAnSWxsdXN0cmF0aW9uJyxcbiAgICAxOTogJ0JhbmQvYXJ0aXN0IGxvZ290eXBlJyxcbiAgICAyMDogJ1B1Ymxpc2hlci9TdHVkaW8gbG9nb3R5cGUnXG59O1xuLyoqXG4gKiBodHRwczovL2lkMy5vcmcvaWQzdjIuMy4wI1N5bmNocm9uaXNlZF9seXJpY3MuMkZ0ZXh0XG4gKi9cbmV4cG9ydCBjb25zdCBMeXJpY3NDb250ZW50VHlwZSA9IHtcbiAgICBvdGhlcjogMCxcbiAgICBseXJpY3M6IDEsXG4gICAgdGV4dDogMixcbiAgICBtb3ZlbWVudF9wYXJ0OiAzLFxuICAgIGV2ZW50czogNCxcbiAgICBjaG9yZDogNSxcbiAgICB0cml2aWFfcG9wOiA2XG59O1xuZXhwb3J0IGNvbnN0IFRpbWVzdGFtcEZvcm1hdCA9IHtcbiAgICBub3RTeW5jaHJvbml6ZWQ6IDAsXG4gICAgbXBlZ0ZyYW1lTnVtYmVyOiAxLFxuICAgIG1pbGxpc2Vjb25kczogMlxufTtcbi8qKlxuICogMjggYml0cyAocmVwcmVzZW50aW5nIHVwIHRvIDI1Nk1CKSBpbnRlZ2VyLCB0aGUgbXNiIGlzIDAgdG8gYXZvaWQgJ2ZhbHNlIHN5bmNzaWduYWxzJy5cbiAqIDQgKiAlMHh4eHh4eHhcbiAqL1xuZXhwb3J0IGNvbnN0IFVJTlQzMlNZTkNTQUZFID0ge1xuICAgIGdldDogKGJ1Ziwgb2ZmKSA9PiB7XG4gICAgICAgIHJldHVybiAoYnVmW29mZiArIDNdICYgMHg3ZikgfCAoYnVmW29mZiArIDJdIDw8IDcpIHwgKGJ1ZltvZmYgKyAxXSA8PCAxNCkgfCAoYnVmW29mZl0gPDwgMjEpO1xuICAgIH0sXG4gICAgbGVuOiA0XG59O1xuLyoqXG4gKiBJRDN2MiBoZWFkZXJcbiAqIFJlZjogaHR0cDovL2lkMy5vcmcvaWQzdjIuMy4wI0lEM3YyX2hlYWRlclxuICogVG9Eb1xuICovXG5leHBvcnQgY29uc3QgSUQzdjJIZWFkZXIgPSB7XG4gICAgbGVuOiAxMCxcbiAgICBnZXQ6IChidWYsIG9mZikgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLy8gSUQzdjIvZmlsZSBpZGVudGlmaWVyICAgXCJJRDNcIlxuICAgICAgICAgICAgZmlsZUlkZW50aWZpZXI6IG5ldyBUb2tlbi5TdHJpbmdUeXBlKDMsICdhc2NpaScpLmdldChidWYsIG9mZiksXG4gICAgICAgICAgICAvLyBJRDN2MiB2ZXJzaW9uSW5kZXhcbiAgICAgICAgICAgIHZlcnNpb246IHtcbiAgICAgICAgICAgICAgICBtYWpvcjogVG9rZW4uSU5UOC5nZXQoYnVmLCBvZmYgKyAzKSxcbiAgICAgICAgICAgICAgICByZXZpc2lvbjogVG9rZW4uSU5UOC5nZXQoYnVmLCBvZmYgKyA0KVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIC8vIElEM3YyIGZsYWdzXG4gICAgICAgICAgICBmbGFnczoge1xuICAgICAgICAgICAgICAgIC8vIFVuc3luY2hyb25pc2F0aW9uXG4gICAgICAgICAgICAgICAgdW5zeW5jaHJvbmlzYXRpb246IHV0aWwuZ2V0Qml0KGJ1Ziwgb2ZmICsgNSwgNyksXG4gICAgICAgICAgICAgICAgLy8gRXh0ZW5kZWQgaGVhZGVyXG4gICAgICAgICAgICAgICAgaXNFeHRlbmRlZEhlYWRlcjogdXRpbC5nZXRCaXQoYnVmLCBvZmYgKyA1LCA2KSxcbiAgICAgICAgICAgICAgICAvLyBFeHBlcmltZW50YWwgaW5kaWNhdG9yXG4gICAgICAgICAgICAgICAgZXhwSW5kaWNhdG9yOiB1dGlsLmdldEJpdChidWYsIG9mZiArIDUsIDUpLFxuICAgICAgICAgICAgICAgIGZvb3RlcjogdXRpbC5nZXRCaXQoYnVmLCBvZmYgKyA1LCA0KVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNpemU6IFVJTlQzMlNZTkNTQUZFLmdldChidWYsIG9mZiArIDYpXG4gICAgICAgIH07XG4gICAgfVxufTtcbmV4cG9ydCBjb25zdCBUZXh0RW5jb2RpbmdUb2tlbiA9IHtcbiAgICBsZW46IDEsXG4gICAgZ2V0OiAodWludDhBcnJheSwgb2ZmKSA9PiB7XG4gICAgICAgIHN3aXRjaCAodWludDhBcnJheVtvZmZdKSB7XG4gICAgICAgICAgICBjYXNlIDB4MDA6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgZW5jb2Rpbmc6ICdsYXRpbjEnIH07IC8vIGJpbmFyeVxuICAgICAgICAgICAgY2FzZSAweDAxOlxuICAgICAgICAgICAgICAgIHJldHVybiB7IGVuY29kaW5nOiAndXRmLTE2bGUnLCBib206IHRydWUgfTtcbiAgICAgICAgICAgIGNhc2UgMHgwMjpcbiAgICAgICAgICAgICAgICByZXR1cm4geyBlbmNvZGluZzogJ3V0Zi0xNmJlJywgYm9tOiBmYWxzZSB9O1xuICAgICAgICAgICAgY2FzZSAweDAzOlxuICAgICAgICAgICAgICAgIHJldHVybiB7IGVuY29kaW5nOiAndXRmOCcsIGJvbTogZmFsc2UgfTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgZW5jb2Rpbmc6ICd1dGY4JywgYm9tOiBmYWxzZSB9O1xuICAgICAgICB9XG4gICAgfVxufTtcbi8qKlxuICogVXNlZCB0byByZWFkIGZpcnN0IHBvcnRpb24gb2YgYFNZTFRgIGZyYW1lXG4gKi9cbmV4cG9ydCBjb25zdCBUZXh0SGVhZGVyID0ge1xuICAgIGxlbjogNCxcbiAgICBnZXQ6ICh1aW50OEFycmF5LCBvZmYpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVuY29kaW5nOiBUZXh0RW5jb2RpbmdUb2tlbi5nZXQodWludDhBcnJheSwgb2ZmKSxcbiAgICAgICAgICAgIGxhbmd1YWdlOiBuZXcgVG9rZW4uU3RyaW5nVHlwZSgzLCAnbGF0aW4xJykuZ2V0KHVpbnQ4QXJyYXksIG9mZiArIDEpXG4gICAgICAgIH07XG4gICAgfVxufTtcbi8qKlxuICogVXNlZCB0byByZWFkIGZpcnN0IHBvcnRpb24gb2YgYFNZTFRgIGZyYW1lXG4gKi9cbmV4cG9ydCBjb25zdCBTeW5jVGV4dEhlYWRlciA9IHtcbiAgICBsZW46IDYsXG4gICAgZ2V0OiAodWludDhBcnJheSwgb2ZmKSA9PiB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBUZXh0SGVhZGVyLmdldCh1aW50OEFycmF5LCBvZmYpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZW5jb2Rpbmc6IHRleHQuZW5jb2RpbmcsXG4gICAgICAgICAgICBsYW5ndWFnZTogdGV4dC5sYW5ndWFnZSxcbiAgICAgICAgICAgIHRpbWVTdGFtcEZvcm1hdDogVG9rZW4uVUlOVDguZ2V0KHVpbnQ4QXJyYXksIG9mZiArIDQpLFxuICAgICAgICAgICAgY29udGVudFR5cGU6IFRva2VuLlVJTlQ4LmdldCh1aW50OEFycmF5LCBvZmYgKyA1KVxuICAgICAgICB9O1xuICAgIH1cbn07XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFNQSxJQUFhLHNCQUFzQjtDQUMvQixHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7QUFDUjs7OztBQUlBLElBQWEsb0JBQW9CO0NBQzdCLE9BQU87Q0FDUCxRQUFRO0NBQ1IsTUFBTTtDQUNOLGVBQWU7Q0FDZixRQUFRO0NBQ1IsT0FBTztDQUNQLFlBQVk7QUFDaEI7QUFDQSxJQUFhLGtCQUFrQjtDQUMzQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLGNBQWM7QUFDbEI7Ozs7O0FBS0EsSUFBYSxpQkFBaUI7Q0FDMUIsTUFBTSxLQUFLLFFBQVE7RUFDZixPQUFRLElBQUksTUFBTSxLQUFLLE1BQVMsSUFBSSxNQUFNLE1BQU0sSUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFPLElBQUksUUFBUTtDQUM3RjtDQUNBLEtBQUs7QUFDVDs7Ozs7O0FBTUEsSUFBYSxjQUFjO0NBQ3ZCLEtBQUs7Q0FDTCxNQUFNLEtBQUssUUFBUTtFQUNmLE9BQU87R0FFSCxnQkFBZ0IsSUFBSUEsV0FBaUIsR0FBRyxPQUFPLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRztHQUU3RCxTQUFTO0lBQ0wsT0FBQSxLQUFrQixJQUFJLEtBQUssTUFBTSxDQUFDO0lBQ2xDLFVBQUEsS0FBcUIsSUFBSSxLQUFLLE1BQU0sQ0FBQztHQUN6QztHQUVBLE9BQU87SUFFSCxtQkFBbUJDLE9BQVksS0FBSyxNQUFNLEdBQUcsQ0FBQztJQUU5QyxrQkFBa0JBLE9BQVksS0FBSyxNQUFNLEdBQUcsQ0FBQztJQUU3QyxjQUFjQSxPQUFZLEtBQUssTUFBTSxHQUFHLENBQUM7SUFDekMsUUFBUUEsT0FBWSxLQUFLLE1BQU0sR0FBRyxDQUFDO0dBQ3ZDO0dBQ0EsTUFBTSxlQUFlLElBQUksS0FBSyxNQUFNLENBQUM7RUFDekM7Q0FDSjtBQUNKO0FBQ0EsSUFBYSxvQkFBb0I7Q0FDN0IsS0FBSztDQUNMLE1BQU0sWUFBWSxRQUFRO0VBQ3RCLFFBQVEsV0FBVyxNQUFuQjtHQUNJLEtBQUssR0FDRCxPQUFPLEVBQUUsVUFBVSxTQUFTO0dBQ2hDLEtBQUssR0FDRCxPQUFPO0lBQUUsVUFBVTtJQUFZLEtBQUs7R0FBSztHQUM3QyxLQUFLLEdBQ0QsT0FBTztJQUFFLFVBQVU7SUFBWSxLQUFLO0dBQU07R0FDOUMsS0FBSyxHQUNELE9BQU87SUFBRSxVQUFVO0lBQVEsS0FBSztHQUFNO0dBQzFDLFNBQ0ksT0FBTztJQUFFLFVBQVU7SUFBUSxLQUFLO0dBQU07RUFDOUM7Q0FDSjtBQUNKOzs7O0FBSUEsSUFBYSxhQUFhO0NBQ3RCLEtBQUs7Q0FDTCxNQUFNLFlBQVksUUFBUTtFQUN0QixPQUFPO0dBQ0gsVUFBVSxrQkFBa0IsSUFBSSxZQUFZLEdBQUc7R0FDL0MsVUFBVSxJQUFJRCxXQUFpQixHQUFHLFFBQVEsQ0FBQyxDQUFDLElBQUksWUFBWSxNQUFNLENBQUM7RUFDdkU7Q0FDSjtBQUNKOzs7O0FBSUEsSUFBYSxpQkFBaUI7Q0FDMUIsS0FBSztDQUNMLE1BQU0sWUFBWSxRQUFRO0VBQ3RCLE1BQU0sT0FBTyxXQUFXLElBQUksWUFBWSxHQUFHO0VBQzNDLE9BQU87R0FDSCxVQUFVLEtBQUs7R0FDZixVQUFVLEtBQUs7R0FDZixpQkFBQSxNQUE2QixJQUFJLFlBQVksTUFBTSxDQUFDO0dBQ3BELGFBQUEsTUFBeUIsSUFBSSxZQUFZLE1BQU0sQ0FBQztFQUNwRDtDQUNKO0FBQ0oiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19