import { n as __exportAll, r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=987d57e9";
// node_modules/strtok3/lib/stream/Errors.js
var defaultMessages = "End-Of-Stream";
/**
* Thrown on read operation of the end of file or stream has been reached
*/
var EndOfStreamError = class extends Error {
	constructor() {
		super(defaultMessages);
		this.name = "EndOfStreamError";
	}
};
var AbortError = class extends Error {
	constructor(message = "The operation was aborted") {
		super(message);
		this.name = "AbortError";
	}
};
// node_modules/strtok3/lib/isRandomAccessTokenizer.js
/**
* Check for random-access capability, position control and a known file size.
* A known size alone does not imply random access.
*/
function isRandomAccessTokenizer(tokenizer) {
	return tokenizer.supportsRandomAccess() && "setPosition" in tokenizer && typeof tokenizer.setPosition === "function" && typeof tokenizer.fileInfo.size === "number";
}
// node_modules/@borewit/text-codec/lib/index.js
var WINDOWS_1252_EXTRA = {
	128: "€",
	130: "‚",
	131: "ƒ",
	132: "„",
	133: "…",
	134: "†",
	135: "‡",
	136: "ˆ",
	137: "‰",
	138: "Š",
	139: "‹",
	140: "Œ",
	142: "Ž",
	145: "‘",
	146: "’",
	147: "“",
	148: "”",
	149: "•",
	150: "–",
	151: "—",
	152: "˜",
	153: "™",
	154: "š",
	155: "›",
	156: "œ",
	158: "ž",
	159: "Ÿ"
};
var WINDOWS_1252_REVERSE = {};
for (const [code, char] of Object.entries(WINDOWS_1252_EXTRA)) WINDOWS_1252_REVERSE[char] = Number.parseInt(code, 10);
var _utf8Decoder;
var _utf8Encoder;
function utf8Decoder() {
	if (_utf8Decoder === void 0) try {
		_utf8Decoder = typeof globalThis.TextDecoder === "undefined" ? null : new globalThis.TextDecoder("utf-8");
	} catch {
		_utf8Decoder = null;
	}
	return _utf8Decoder !== null && _utf8Decoder !== void 0 ? _utf8Decoder : void 0;
}
function utf8Encoder() {
	if (_utf8Encoder === void 0) try {
		_utf8Encoder = typeof globalThis.TextEncoder === "undefined" ? null : new globalThis.TextEncoder();
	} catch {
		_utf8Encoder = null;
	}
	return _utf8Encoder !== null && _utf8Encoder !== void 0 ? _utf8Encoder : void 0;
}
var CHUNK = 32768;
var REPLACEMENT = 65533;
/**
* Decode text from binary data
*/
function textDecode(bytes, encoding = "utf-8") {
	switch (encoding.toLowerCase()) {
		case "utf-8":
		case "utf8": {
			const dec = utf8Decoder();
			return dec ? dec.decode(bytes) : decodeUTF8(bytes);
		}
		case "utf-16le": return decodeUTF16LE(bytes);
		case "us-ascii":
		case "ascii": return decodeASCII(bytes);
		case "latin1":
		case "iso-8859-1": return decodeLatin1(bytes);
		case "windows-1252": return decodeWindows1252(bytes);
		default: throw new RangeError(`Encoding '${encoding}' not supported`);
	}
}
function textEncode(input = "", encoding = "utf-8") {
	switch (encoding.toLowerCase()) {
		case "utf-8":
		case "utf8": {
			const enc = utf8Encoder();
			return enc ? enc.encode(input) : encodeUTF8(input);
		}
		case "utf-16le": return encodeUTF16LE(input);
		case "us-ascii":
		case "ascii": return encodeASCII(input);
		case "latin1":
		case "iso-8859-1": return encodeLatin1(input);
		case "windows-1252": return encodeWindows1252(input);
		default: throw new RangeError(`Encoding '${encoding}' not supported`);
	}
}
function flushChunk(parts, chunk) {
	if (chunk.length === 0) return;
	parts.push(String.fromCharCode.apply(null, chunk));
	chunk.length = 0;
}
function pushCodeUnit(parts, chunk, codeUnit) {
	chunk.push(codeUnit);
	if (chunk.length >= CHUNK) flushChunk(parts, chunk);
}
function pushCodePoint(parts, chunk, cp) {
	if (cp <= 65535) {
		pushCodeUnit(parts, chunk, cp);
		return;
	}
	cp -= 65536;
	pushCodeUnit(parts, chunk, 55296 + (cp >> 10));
	pushCodeUnit(parts, chunk, 56320 + (cp & 1023));
}
function decodeUTF8(bytes) {
	const parts = [];
	const chunk = [];
	let i = 0;
	if (bytes.length >= 3 && bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) i = 3;
	while (i < bytes.length) {
		const b1 = bytes[i];
		if (b1 <= 127) {
			pushCodeUnit(parts, chunk, b1);
			i++;
			continue;
		}
		if (b1 < 194 || b1 > 244) {
			pushCodeUnit(parts, chunk, REPLACEMENT);
			i++;
			continue;
		}
		const length = b1 <= 223 ? 2 : b1 <= 239 ? 3 : 4;
		let cp = b1 & 127 >> length;
		let lower = b1 === 224 ? 160 : b1 === 240 ? 144 : 128;
		let upper = b1 === 237 ? 159 : b1 === 244 ? 143 : 191;
		let consumed = 1;
		i++;
		while (consumed < length && i < bytes.length) {
			const next = bytes[i];
			if (next < lower || next > upper) break;
			cp = cp << 6 | next & 63;
			consumed++;
			i++;
			lower = 128;
			upper = 191;
		}
		pushCodePoint(parts, chunk, consumed === length ? cp : REPLACEMENT);
	}
	flushChunk(parts, chunk);
	return parts.join("");
}
function decodeUTF16LE(bytes) {
	const parts = [];
	const chunk = [];
	const len = bytes.length;
	let i = 0;
	if (len >= 2 && bytes[0] === 255 && bytes[1] === 254) i = 2;
	while (i + 1 < len) {
		const u1 = bytes[i] | bytes[i + 1] << 8;
		i += 2;
		if (u1 >= 55296 && u1 <= 56319) {
			if (i + 1 < len) {
				const u2 = bytes[i] | bytes[i + 1] << 8;
				if (u2 >= 56320 && u2 <= 57343) {
					pushCodeUnit(parts, chunk, u1);
					pushCodeUnit(parts, chunk, u2);
					i += 2;
				} else pushCodeUnit(parts, chunk, REPLACEMENT);
			} else pushCodeUnit(parts, chunk, REPLACEMENT);
			continue;
		}
		if (u1 >= 56320 && u1 <= 57343) {
			pushCodeUnit(parts, chunk, REPLACEMENT);
			continue;
		}
		pushCodeUnit(parts, chunk, u1);
	}
	if (i < len) pushCodeUnit(parts, chunk, REPLACEMENT);
	flushChunk(parts, chunk);
	return parts.join("");
}
function decodeASCII(bytes) {
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) {
		const end = Math.min(bytes.length, i + CHUNK);
		const codes = new Array(end - i);
		for (let j = i, k = 0; j < end; j++, k++) codes[k] = bytes[j] & 127;
		parts.push(String.fromCharCode.apply(null, codes));
	}
	return parts.join("");
}
function decodeLatin1(bytes) {
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) {
		const end = Math.min(bytes.length, i + CHUNK);
		const codes = new Array(end - i);
		for (let j = i, k = 0; j < end; j++, k++) codes[k] = bytes[j];
		parts.push(String.fromCharCode.apply(null, codes));
	}
	return parts.join("");
}
function decodeWindows1252(bytes) {
	const parts = [];
	let out = "";
	for (let i = 0; i < bytes.length; i++) {
		const b = bytes[i];
		const extra = b >= 128 && b <= 159 ? WINDOWS_1252_EXTRA[b] : void 0;
		out += extra !== null && extra !== void 0 ? extra : String.fromCharCode(b);
		if (out.length >= CHUNK) {
			parts.push(out);
			out = "";
		}
	}
	if (out) parts.push(out);
	return parts.join("");
}
function encodeUTF8(str) {
	const out = [];
	for (let i = 0; i < str.length; i++) {
		let cp = str.charCodeAt(i);
		if (cp >= 55296 && cp <= 56319) {
			if (i + 1 < str.length) {
				const lo = str.charCodeAt(i + 1);
				if (lo >= 56320 && lo <= 57343) {
					cp = 65536 + (cp - 55296 << 10) + (lo - 56320);
					i++;
				} else cp = REPLACEMENT;
			} else cp = REPLACEMENT;
		} else if (cp >= 56320 && cp <= 57343) cp = REPLACEMENT;
		if (cp < 128) out.push(cp);
		else if (cp < 2048) out.push(192 | cp >> 6, 128 | cp & 63);
		else if (cp < 65536) out.push(224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63);
		else out.push(240 | cp >> 18, 128 | cp >> 12 & 63, 128 | cp >> 6 & 63, 128 | cp & 63);
	}
	return new Uint8Array(out);
}
function encodeUTF16LE(str) {
	const units = [];
	for (let i = 0; i < str.length; i++) {
		const u = str.charCodeAt(i);
		if (u >= 55296 && u <= 56319) {
			if (i + 1 < str.length) {
				const lo = str.charCodeAt(i + 1);
				if (lo >= 56320 && lo <= 57343) {
					units.push(u, lo);
					i++;
				} else units.push(REPLACEMENT);
			} else units.push(REPLACEMENT);
			continue;
		}
		if (u >= 56320 && u <= 57343) {
			units.push(REPLACEMENT);
			continue;
		}
		units.push(u);
	}
	const out = new Uint8Array(units.length * 2);
	for (let i = 0; i < units.length; i++) {
		const code = units[i];
		const o = i * 2;
		out[o] = code & 255;
		out[o + 1] = code >>> 8;
	}
	return out;
}
function encodeASCII(str) {
	const out = new Uint8Array(str.length);
	for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 127;
	return out;
}
function encodeLatin1(str) {
	const out = new Uint8Array(str.length);
	for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 255;
	return out;
}
function encodeWindows1252(str) {
	const out = new Uint8Array(str.length);
	for (let i = 0; i < str.length; i++) {
		const ch = str[i];
		const code = ch.charCodeAt(0);
		if (WINDOWS_1252_REVERSE[ch] !== void 0) {
			out[i] = WINDOWS_1252_REVERSE[ch];
			continue;
		}
		if (code >= 0 && code <= 127 || code >= 160 && code <= 255) {
			out[i] = code;
			continue;
		}
		out[i] = 63;
	}
	return out;
}
// node_modules/ms/index.js
var require_ms = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Helpers.
	*/
	var s = 1e3;
	var m = s * 60;
	var h = m * 60;
	var d = h * 24;
	var w = d * 7;
	var y = d * 365.25;
	/**
	* Parse or format the given `val`.
	*
	* Options:
	*
	*  - `long` verbose formatting [false]
	*
	* @param {String|Number} val
	* @param {Object} [options]
	* @throws {Error} throw an error if val is not a non-empty string or a number
	* @return {String|Number}
	* @api public
	*/
	module.exports = function(val, options) {
		options = options || {};
		var type = typeof val;
		if (type === "string" && val.length > 0) return parse(val);
		else if (type === "number" && isFinite(val)) return options.long ? fmtLong(val) : fmtShort(val);
		throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(val));
	};
	/**
	* Parse the given `str` and return milliseconds.
	*
	* @param {String} str
	* @return {Number}
	* @api private
	*/
	function parse(str) {
		str = String(str);
		if (str.length > 100) return;
		var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
		if (!match) return;
		var n = parseFloat(match[1]);
		switch ((match[2] || "ms").toLowerCase()) {
			case "years":
			case "year":
			case "yrs":
			case "yr":
			case "y": return n * y;
			case "weeks":
			case "week":
			case "w": return n * w;
			case "days":
			case "day":
			case "d": return n * d;
			case "hours":
			case "hour":
			case "hrs":
			case "hr":
			case "h": return n * h;
			case "minutes":
			case "minute":
			case "mins":
			case "min":
			case "m": return n * m;
			case "seconds":
			case "second":
			case "secs":
			case "sec":
			case "s": return n * s;
			case "milliseconds":
			case "millisecond":
			case "msecs":
			case "msec":
			case "ms": return n;
			default: return;
		}
	}
	/**
	* Short format for `ms`.
	*
	* @param {Number} ms
	* @return {String}
	* @api private
	*/
	function fmtShort(ms) {
		var msAbs = Math.abs(ms);
		if (msAbs >= d) return Math.round(ms / d) + "d";
		if (msAbs >= h) return Math.round(ms / h) + "h";
		if (msAbs >= m) return Math.round(ms / m) + "m";
		if (msAbs >= s) return Math.round(ms / s) + "s";
		return ms + "ms";
	}
	/**
	* Long format for `ms`.
	*
	* @param {Number} ms
	* @return {String}
	* @api private
	*/
	function fmtLong(ms) {
		var msAbs = Math.abs(ms);
		if (msAbs >= d) return plural(ms, msAbs, d, "day");
		if (msAbs >= h) return plural(ms, msAbs, h, "hour");
		if (msAbs >= m) return plural(ms, msAbs, m, "minute");
		if (msAbs >= s) return plural(ms, msAbs, s, "second");
		return ms + " ms";
	}
	/**
	* Pluralization helper.
	*/
	function plural(ms, msAbs, n, name) {
		var isPlural = msAbs >= n * 1.5;
		return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
	}
}));
// node_modules/debug/src/common.js
var require_common = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* This is the common logic for both the Node.js and web browser
	* implementations of `debug()`.
	*/
	function setup(env) {
		createDebug.debug = createDebug;
		createDebug.default = createDebug;
		createDebug.coerce = coerce;
		createDebug.disable = disable;
		createDebug.enable = enable;
		createDebug.enabled = enabled;
		createDebug.humanize = require_ms();
		createDebug.destroy = destroy;
		Object.keys(env).forEach((key) => {
			createDebug[key] = env[key];
		});
		/**
		* The currently active debug mode names, and names to skip.
		*/
		createDebug.names = [];
		createDebug.skips = [];
		/**
		* Map of special "%n" handling functions, for the debug "format" argument.
		*
		* Valid key names are a single, lower or upper-case letter, i.e. "n" and "N".
		*/
		createDebug.formatters = {};
		/**
		* Selects a color for a debug namespace
		* @param {String} namespace The namespace string for the debug instance to be colored
		* @return {Number|String} An ANSI color code for the given namespace
		* @api private
		*/
		function selectColor(namespace) {
			let hash = 0;
			for (let i = 0; i < namespace.length; i++) {
				hash = (hash << 5) - hash + namespace.charCodeAt(i);
				hash |= 0;
			}
			return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
		}
		createDebug.selectColor = selectColor;
		/**
		* Create a debugger with the given `namespace`.
		*
		* @param {String} namespace
		* @return {Function}
		* @api public
		*/
		function createDebug(namespace) {
			let prevTime;
			let enableOverride = null;
			let namespacesCache;
			let enabledCache;
			function debug(...args) {
				if (!debug.enabled) return;
				const self = debug;
				const curr = Number(/* @__PURE__ */ new Date());
				self.diff = curr - (prevTime || curr);
				self.prev = prevTime;
				self.curr = curr;
				prevTime = curr;
				args[0] = createDebug.coerce(args[0]);
				if (typeof args[0] !== "string") args.unshift("%O");
				let index = 0;
				args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
					if (match === "%%") return "%";
					index++;
					const formatter = createDebug.formatters[format];
					if (typeof formatter === "function") {
						const val = args[index];
						match = formatter.call(self, val);
						args.splice(index, 1);
						index--;
					}
					return match;
				});
				createDebug.formatArgs.call(self, args);
				(self.log || createDebug.log).apply(self, args);
			}
			debug.namespace = namespace;
			debug.useColors = createDebug.useColors();
			debug.color = createDebug.selectColor(namespace);
			debug.extend = extend;
			debug.destroy = createDebug.destroy;
			Object.defineProperty(debug, "enabled", {
				enumerable: true,
				configurable: false,
				get: () => {
					if (enableOverride !== null) return enableOverride;
					if (namespacesCache !== createDebug.namespaces) {
						namespacesCache = createDebug.namespaces;
						enabledCache = createDebug.enabled(namespace);
					}
					return enabledCache;
				},
				set: (v) => {
					enableOverride = v;
				}
			});
			if (typeof createDebug.init === "function") createDebug.init(debug);
			return debug;
		}
		function extend(namespace, delimiter) {
			const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
			newDebug.log = this.log;
			return newDebug;
		}
		/**
		* Enables a debug mode by namespaces. This can include modes
		* separated by a colon and wildcards.
		*
		* @param {String} namespaces
		* @api public
		*/
		function enable(namespaces) {
			createDebug.save(namespaces);
			createDebug.namespaces = namespaces;
			createDebug.names = [];
			createDebug.skips = [];
			const split = (typeof namespaces === "string" ? namespaces : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
			for (const ns of split) if (ns[0] === "-") createDebug.skips.push(ns.slice(1));
			else createDebug.names.push(ns);
		}
		/**
		* Checks if the given string matches a namespace template, honoring
		* asterisks as wildcards.
		*
		* @param {String} search
		* @param {String} template
		* @return {Boolean}
		*/
		function matchesTemplate(search, template) {
			let searchIndex = 0;
			let templateIndex = 0;
			let starIndex = -1;
			let matchIndex = 0;
			while (searchIndex < search.length) if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === "*")) {
				if (template[templateIndex] === "*") {
					starIndex = templateIndex;
					matchIndex = searchIndex;
					templateIndex++;
				} else {
					searchIndex++;
					templateIndex++;
				}
			} else if (starIndex !== -1) {
				templateIndex = starIndex + 1;
				matchIndex++;
				searchIndex = matchIndex;
			} else return false;
			while (templateIndex < template.length && template[templateIndex] === "*") templateIndex++;
			return templateIndex === template.length;
		}
		/**
		* Disable debug output.
		*
		* @return {String} namespaces
		* @api public
		*/
		function disable() {
			const namespaces = [...createDebug.names, ...createDebug.skips.map((namespace) => "-" + namespace)].join(",");
			createDebug.enable("");
			return namespaces;
		}
		/**
		* Returns true if the given mode name is enabled, false otherwise.
		*
		* @param {String} name
		* @return {Boolean}
		* @api public
		*/
		function enabled(name) {
			for (const skip of createDebug.skips) if (matchesTemplate(name, skip)) return false;
			for (const ns of createDebug.names) if (matchesTemplate(name, ns)) return true;
			return false;
		}
		/**
		* Coerce `val`.
		*
		* @param {Mixed} val
		* @return {Mixed}
		* @api private
		*/
		function coerce(val) {
			if (val instanceof Error) return val.stack || val.message;
			return val;
		}
		/**
		* XXX DO NOT USE. This is a temporary stub function.
		* XXX It WILL be removed in the next major release.
		*/
		function destroy() {
			console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
		}
		createDebug.enable(createDebug.load());
		return createDebug;
	}
	module.exports = setup;
}));
// node_modules/debug/src/browser.js
var require_browser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* This is the web browser implementation of `debug()`.
	*/
	exports.formatArgs = formatArgs;
	exports.save = save;
	exports.load = load;
	exports.useColors = useColors;
	exports.storage = localstorage();
	exports.destroy = (() => {
		let warned = false;
		return () => {
			if (!warned) {
				warned = true;
				console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
			}
		};
	})();
	/**
	* Colors.
	*/
	exports.colors = [
		"#0000CC",
		"#0000FF",
		"#0033CC",
		"#0033FF",
		"#0066CC",
		"#0066FF",
		"#0099CC",
		"#0099FF",
		"#00CC00",
		"#00CC33",
		"#00CC66",
		"#00CC99",
		"#00CCCC",
		"#00CCFF",
		"#3300CC",
		"#3300FF",
		"#3333CC",
		"#3333FF",
		"#3366CC",
		"#3366FF",
		"#3399CC",
		"#3399FF",
		"#33CC00",
		"#33CC33",
		"#33CC66",
		"#33CC99",
		"#33CCCC",
		"#33CCFF",
		"#6600CC",
		"#6600FF",
		"#6633CC",
		"#6633FF",
		"#66CC00",
		"#66CC33",
		"#9900CC",
		"#9900FF",
		"#9933CC",
		"#9933FF",
		"#99CC00",
		"#99CC33",
		"#CC0000",
		"#CC0033",
		"#CC0066",
		"#CC0099",
		"#CC00CC",
		"#CC00FF",
		"#CC3300",
		"#CC3333",
		"#CC3366",
		"#CC3399",
		"#CC33CC",
		"#CC33FF",
		"#CC6600",
		"#CC6633",
		"#CC9900",
		"#CC9933",
		"#CCCC00",
		"#CCCC33",
		"#FF0000",
		"#FF0033",
		"#FF0066",
		"#FF0099",
		"#FF00CC",
		"#FF00FF",
		"#FF3300",
		"#FF3333",
		"#FF3366",
		"#FF3399",
		"#FF33CC",
		"#FF33FF",
		"#FF6600",
		"#FF6633",
		"#FF9900",
		"#FF9933",
		"#FFCC00",
		"#FFCC33"
	];
	/**
	* Currently only WebKit-based Web Inspectors, Firefox >= v31,
	* and the Firebug extension (any Firefox version) are known
	* to support "%c" CSS customizations.
	*
	* TODO: add a `localStorage` variable to explicitly enable/disable colors
	*/
	function useColors() {
		if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) return true;
		if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return false;
		let m;
		return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator !== "undefined" && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
	}
	/**
	* Colorize log arguments if enabled.
	*
	* @api public
	*/
	function formatArgs(args) {
		args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
		if (!this.useColors) return;
		const c = "color: " + this.color;
		args.splice(1, 0, c, "color: inherit");
		let index = 0;
		let lastC = 0;
		args[0].replace(/%[a-zA-Z%]/g, (match) => {
			if (match === "%%") return;
			index++;
			if (match === "%c") lastC = index;
		});
		args.splice(lastC, 0, c);
	}
	/**
	* Invokes `console.debug()` when available.
	* No-op when `console.debug` is not a "function".
	* If `console.debug` is not available, falls back
	* to `console.log`.
	*
	* @api public
	*/
	exports.log = console.debug || console.log || (() => {});
	/**
	* Save `namespaces`.
	*
	* @param {String} namespaces
	* @api private
	*/
	function save(namespaces) {
		try {
			if (namespaces) exports.storage.setItem("debug", namespaces);
			else exports.storage.removeItem("debug");
		} catch (error) {}
	}
	/**
	* Load `namespaces`.
	*
	* @return {String} returns the previously persisted debug modes
	* @api private
	*/
	function load() {
		let r;
		try {
			r = exports.storage.getItem("debug") || exports.storage.getItem("DEBUG");
		} catch (error) {}
		if (!r && typeof process !== "undefined" && "env" in process) r = process.env.DEBUG;
		return r;
	}
	/**
	* Localstorage attempts to return the localstorage.
	*
	* This is necessary because safari throws
	* when a user disables cookies/localstorage
	* and you attempt to access it.
	*
	* @return {LocalStorage}
	* @api private
	*/
	function localstorage() {
		try {
			return localStorage;
		} catch (error) {}
	}
	module.exports = require_common()(exports);
	var { formatters } = module.exports;
	/**
	* Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
	*/
	formatters.j = function(v) {
		try {
			return JSON.stringify(v);
		} catch (error) {
			return "[UnexpectedJSONParseError]: " + error.message;
		}
	};
}));
// node_modules/ieee754/index.js
var require_ieee754 = /* @__PURE__ */ __commonJSMin(((exports) => {
	/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
	exports.read = function(buffer, offset, isLE, mLen, nBytes) {
		var e, m;
		var eLen = nBytes * 8 - mLen - 1;
		var eMax = (1 << eLen) - 1;
		var eBias = eMax >> 1;
		var nBits = -7;
		var i = isLE ? nBytes - 1 : 0;
		var d = isLE ? -1 : 1;
		var s = buffer[offset + i];
		i += d;
		e = s & (1 << -nBits) - 1;
		s >>= -nBits;
		nBits += eLen;
		for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8);
		m = e & (1 << -nBits) - 1;
		e >>= -nBits;
		nBits += mLen;
		for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8);
		if (e === 0) e = 1 - eBias;
		else if (e === eMax) return m ? NaN : (s ? -1 : 1) * Infinity;
		else {
			m = m + Math.pow(2, mLen);
			e = e - eBias;
		}
		return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
	};
	exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
		var e, m, c;
		var eLen = nBytes * 8 - mLen - 1;
		var eMax = (1 << eLen) - 1;
		var eBias = eMax >> 1;
		var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
		var i = isLE ? 0 : nBytes - 1;
		var d = isLE ? 1 : -1;
		var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
		value = Math.abs(value);
		if (isNaN(value) || value === Infinity) {
			m = isNaN(value) ? 1 : 0;
			e = eMax;
		} else {
			e = Math.floor(Math.log(value) / Math.LN2);
			if (value * (c = Math.pow(2, -e)) < 1) {
				e--;
				c *= 2;
			}
			if (e + eBias >= 1) value += rt / c;
			else value += rt * Math.pow(2, 1 - eBias);
			if (value * c >= 2) {
				e++;
				c /= 2;
			}
			if (e + eBias >= eMax) {
				m = 0;
				e = eMax;
			} else if (e + eBias >= 1) {
				m = (value * c - 1) * Math.pow(2, mLen);
				e = e + eBias;
			} else {
				m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
				e = 0;
			}
		}
		for (; mLen >= 8; buffer[offset + i] = m & 255, i += d, m /= 256, mLen -= 8);
		e = e << mLen | m;
		eLen += mLen;
		for (; eLen > 0; buffer[offset + i] = e & 255, i += d, e /= 256, eLen -= 8);
		buffer[offset + i - d] |= s * 128;
	};
}));
// node_modules/token-types/lib/index.js
var lib_exports = /* @__PURE__ */ __exportAll({
	AnsiStringType: () => AnsiStringType,
	Float16_BE: () => Float16_BE,
	Float16_LE: () => Float16_LE,
	Float32_BE: () => Float32_BE,
	Float32_LE: () => Float32_LE,
	Float64_BE: () => Float64_BE,
	Float64_LE: () => Float64_LE,
	Float80_BE: () => Float80_BE,
	Float80_LE: () => Float80_LE,
	INT16_BE: () => INT16_BE,
	INT16_LE: () => INT16_LE,
	INT24_BE: () => INT24_BE,
	INT24_LE: () => INT24_LE,
	INT32_BE: () => INT32_BE,
	INT32_LE: () => INT32_LE,
	INT64_BE: () => INT64_BE,
	INT64_LE: () => INT64_LE,
	INT8: () => INT8,
	IgnoreType: () => IgnoreType,
	StringType: () => StringType,
	UINT16_BE: () => UINT16_BE,
	UINT16_LE: () => UINT16_LE,
	UINT24_BE: () => UINT24_BE,
	UINT24_LE: () => UINT24_LE,
	UINT32_BE: () => UINT32_BE,
	UINT32_LE: () => UINT32_LE,
	UINT64_BE: () => UINT64_BE,
	UINT64_LE: () => UINT64_LE,
	UINT8: () => UINT8,
	Uint8ArrayType: () => Uint8ArrayType
});
var import_ieee754 = /* @__PURE__ */ __toESM(require_ieee754());
function dv(array) {
	return new DataView(array.buffer, array.byteOffset);
}
var UINT8 = {
	len: 1,
	get(array, offset) {
		return dv(array).getUint8(offset);
	},
	put(array, offset, value) {
		dv(array).setUint8(offset, value);
		return offset + 1;
	}
};
/**
* 16-bit unsigned integer, Little Endian byte order
*/
var UINT16_LE = {
	len: 2,
	get(array, offset) {
		return dv(array).getUint16(offset, true);
	},
	put(array, offset, value) {
		dv(array).setUint16(offset, value, true);
		return offset + 2;
	}
};
/**
* 16-bit unsigned integer, Big Endian byte order
*/
var UINT16_BE = {
	len: 2,
	get(array, offset) {
		return dv(array).getUint16(offset);
	},
	put(array, offset, value) {
		dv(array).setUint16(offset, value);
		return offset + 2;
	}
};
/**
* 24-bit unsigned integer, Little Endian byte order
*/
var UINT24_LE = {
	len: 3,
	get(array, offset) {
		const dataView = dv(array);
		return dataView.getUint8(offset) + (dataView.getUint16(offset + 1, true) << 8);
	},
	put(array, offset, value) {
		const dataView = dv(array);
		dataView.setUint8(offset, value & 255);
		dataView.setUint16(offset + 1, value >> 8, true);
		return offset + 3;
	}
};
/**
* 24-bit unsigned integer, Big Endian byte order
*/
var UINT24_BE = {
	len: 3,
	get(array, offset) {
		const dataView = dv(array);
		return (dataView.getUint16(offset) << 8) + dataView.getUint8(offset + 2);
	},
	put(array, offset, value) {
		const dataView = dv(array);
		dataView.setUint16(offset, value >> 8);
		dataView.setUint8(offset + 2, value & 255);
		return offset + 3;
	}
};
/**
* 32-bit unsigned integer, Little Endian byte order
*/
var UINT32_LE = {
	len: 4,
	get(array, offset) {
		return dv(array).getUint32(offset, true);
	},
	put(array, offset, value) {
		dv(array).setUint32(offset, value, true);
		return offset + 4;
	}
};
/**
* 32-bit unsigned integer, Big Endian byte order
*/
var UINT32_BE = {
	len: 4,
	get(array, offset) {
		return dv(array).getUint32(offset);
	},
	put(array, offset, value) {
		dv(array).setUint32(offset, value);
		return offset + 4;
	}
};
/**
* 8-bit signed integer
*/
var INT8 = {
	len: 1,
	get(array, offset) {
		return dv(array).getInt8(offset);
	},
	put(array, offset, value) {
		dv(array).setInt8(offset, value);
		return offset + 1;
	}
};
/**
* 16-bit signed integer, Big Endian byte order
*/
var INT16_BE = {
	len: 2,
	get(array, offset) {
		return dv(array).getInt16(offset);
	},
	put(array, offset, value) {
		dv(array).setInt16(offset, value);
		return offset + 2;
	}
};
/**
* 16-bit signed integer, Little Endian byte order
*/
var INT16_LE = {
	len: 2,
	get(array, offset) {
		return dv(array).getInt16(offset, true);
	},
	put(array, offset, value) {
		dv(array).setInt16(offset, value, true);
		return offset + 2;
	}
};
/**
* 24-bit signed integer, Little Endian byte order
*/
var INT24_LE = {
	len: 3,
	get(array, offset) {
		const unsigned = UINT24_LE.get(array, offset);
		return unsigned > 8388607 ? unsigned - 16777216 : unsigned;
	},
	put(array, offset, value) {
		const dataView = dv(array);
		dataView.setUint8(offset, value & 255);
		dataView.setUint16(offset + 1, value >> 8, true);
		return offset + 3;
	}
};
/**
* 24-bit signed integer, Big Endian byte order
*/
var INT24_BE = {
	len: 3,
	get(array, offset) {
		const unsigned = UINT24_BE.get(array, offset);
		return unsigned > 8388607 ? unsigned - 16777216 : unsigned;
	},
	put(array, offset, value) {
		const dataView = dv(array);
		dataView.setUint16(offset, value >> 8);
		dataView.setUint8(offset + 2, value & 255);
		return offset + 3;
	}
};
/**
* 32-bit signed integer, Big Endian byte order
*/
var INT32_BE = {
	len: 4,
	get(array, offset) {
		return dv(array).getInt32(offset);
	},
	put(array, offset, value) {
		dv(array).setInt32(offset, value);
		return offset + 4;
	}
};
/**
* 32-bit signed integer, Big Endian byte order
*/
var INT32_LE = {
	len: 4,
	get(array, offset) {
		return dv(array).getInt32(offset, true);
	},
	put(array, offset, value) {
		dv(array).setInt32(offset, value, true);
		return offset + 4;
	}
};
/**
* 64-bit unsigned integer, Little Endian byte order
*/
var UINT64_LE = {
	len: 8,
	get(array, offset) {
		return dv(array).getBigUint64(offset, true);
	},
	put(array, offset, value) {
		dv(array).setBigUint64(offset, value, true);
		return offset + 8;
	}
};
/**
* 64-bit signed integer, Little Endian byte order
*/
var INT64_LE = {
	len: 8,
	get(array, offset) {
		return dv(array).getBigInt64(offset, true);
	},
	put(array, offset, value) {
		dv(array).setBigInt64(offset, value, true);
		return offset + 8;
	}
};
/**
* 64-bit unsigned integer, Big Endian byte order
*/
var UINT64_BE = {
	len: 8,
	get(array, offset) {
		return dv(array).getBigUint64(offset);
	},
	put(array, offset, value) {
		dv(array).setBigUint64(offset, value);
		return offset + 8;
	}
};
/**
* 64-bit signed integer, Big Endian byte order
*/
var INT64_BE = {
	len: 8,
	get(array, offset) {
		return dv(array).getBigInt64(offset);
	},
	put(array, offset, value) {
		dv(array).setBigInt64(offset, value);
		return offset + 8;
	}
};
/**
* IEEE 754 16-bit (half precision) float, big endian
*/
var Float16_BE = {
	len: 2,
	get(dataView, offset) {
		return import_ieee754.read(dataView, offset, false, 10, this.len);
	},
	put(dataView, offset, value) {
		import_ieee754.write(dataView, value, offset, false, 10, this.len);
		return offset + this.len;
	}
};
/**
* IEEE 754 16-bit (half precision) float, little endian
*/
var Float16_LE = {
	len: 2,
	get(array, offset) {
		return import_ieee754.read(array, offset, true, 10, this.len);
	},
	put(array, offset, value) {
		import_ieee754.write(array, value, offset, true, 10, this.len);
		return offset + this.len;
	}
};
/**
* IEEE 754 32-bit (single precision) float, big endian
*/
var Float32_BE = {
	len: 4,
	get(array, offset) {
		return dv(array).getFloat32(offset);
	},
	put(array, offset, value) {
		dv(array).setFloat32(offset, value);
		return offset + 4;
	}
};
/**
* IEEE 754 32-bit (single precision) float, little endian
*/
var Float32_LE = {
	len: 4,
	get(array, offset) {
		return dv(array).getFloat32(offset, true);
	},
	put(array, offset, value) {
		dv(array).setFloat32(offset, value, true);
		return offset + 4;
	}
};
/**
* IEEE 754 64-bit (double precision) float, big endian
*/
var Float64_BE = {
	len: 8,
	get(array, offset) {
		return dv(array).getFloat64(offset);
	},
	put(array, offset, value) {
		dv(array).setFloat64(offset, value);
		return offset + 8;
	}
};
/**
* IEEE 754 64-bit (double precision) float, little endian
*/
var Float64_LE = {
	len: 8,
	get(array, offset) {
		return dv(array).getFloat64(offset, true);
	},
	put(array, offset, value) {
		dv(array).setFloat64(offset, value, true);
		return offset + 8;
	}
};
/**
* IEEE 754 80-bit (extended precision) float, big endian
*/
var Float80_BE = {
	len: 10,
	get(array, offset) {
		return import_ieee754.read(array, offset, false, 63, this.len);
	},
	put(array, offset, value) {
		import_ieee754.write(array, value, offset, false, 63, this.len);
		return offset + this.len;
	}
};
/**
* IEEE 754 80-bit (extended precision) float, little endian
*/
var Float80_LE = {
	len: 10,
	get(array, offset) {
		return import_ieee754.read(array, offset, true, 63, this.len);
	},
	put(array, offset, value) {
		import_ieee754.write(array, value, offset, true, 63, this.len);
		return offset + this.len;
	}
};
/**
* Ignore a given number of bytes
*/
var IgnoreType = class {
	/**
	* @param len number of bytes to ignore
	*/
	constructor(len) {
		this.len = len;
	}
	get(_array, _off) {}
};
var Uint8ArrayType = class {
	constructor(len) {
		this.len = len;
	}
	get(array, offset) {
		return array.subarray(offset, offset + this.len);
	}
};
/**
* Consume a fixed number of bytes from the stream and return a string with a specified encoding.
* Supports all encodings supported by TextDecoder, plus 'windows-1252'.
*/
var StringType = class {
	constructor(len, encoding) {
		this.len = len;
		this.encoding = encoding;
	}
	get(data, offset = 0) {
		return textDecode(data.subarray(offset, offset + this.len), this.encoding);
	}
};
/**
* ANSI Latin 1 String using Windows-1252 (Code Page 1252)
* Windows-1252 is a superset of ISO 8859-1 / Latin-1.
*/
var AnsiStringType = class extends StringType {
	constructor(len) {
		super(len, "windows-1252");
	}
};
// node_modules/music-metadata/lib/ParseError.js
var makeParseError = (name) => {
	return class ParseError extends Error {
		name;
		constructor(message) {
			super(message);
			this.name = name;
		}
	};
};
var CouldNotDetermineFileTypeError = class extends makeParseError("CouldNotDetermineFileTypeError") {};
var UnsupportedFileTypeError = class extends makeParseError("UnsupportedFileTypeError") {};
var UnexpectedFileContentError = class extends makeParseError("UnexpectedFileContentError") {
	fileType;
	constructor(fileType, message) {
		super(message);
		this.fileType = fileType;
	}
	toString() {
		return `${this.name} (FileType: ${this.fileType}): ${this.message}`;
	}
};
var FieldDecodingError = class extends makeParseError("FieldDecodingError") {};
var InternalParserError = class extends makeParseError("InternalParserError") {};
var makeUnexpectedFileContentError = (fileType) => {
	return class extends UnexpectedFileContentError {
		constructor(message) {
			super(fileType, message);
		}
	};
};
// node_modules/music-metadata/lib/common/Allocation.js
var defaultMaxMemoryAllocation = 67108864;
var defaultMaxMetadataEntries = 1e5;
var defaultMaxChapterCount = 1e3;
var readChunkSize = 65536;
var allocationError = (message) => new UnexpectedFileContentError("metadata", message);
function getMaxMemoryAllocation(options) {
	const limit = options.maxMemoryAllocation ?? defaultMaxMemoryAllocation;
	if (!Number.isSafeInteger(limit) || limit <= 0) throw new RangeError("maxMemoryAllocation must be a positive safe integer");
	return limit;
}
/** Limit entries in an individual decoded list or table, independently of byte-buffer limits. */
function getMaxMetadataEntries(options) {
	const limit = options.maxMetadataEntries ?? 1e5;
	if (!Number.isSafeInteger(limit) || limit <= 0) throw new RangeError("maxMetadataEntries must be a positive safe integer");
	return limit;
}
/** Maximum chapters returned by supported chapter parsers. */
function getMaxChapterCount(options) {
	const limit = options.maxChapterCount ?? 1e3;
	if (!Number.isSafeInteger(limit) || limit <= 0) throw new RangeError("maxChapterCount must be a positive safe integer");
	return limit;
}
/** Configure the tokenizer safety net once, using the same limit as parser-owned buffers. */
function getTokenizerOptions(options, fileInfo) {
	return {
		maxBufferSize: getMaxMemoryAllocation(options),
		fileInfo
	};
}
/** Check untrusted lengths before allocating, including accumulated stream payloads. */
function validateAllocation(length, options, makeError = allocationError) {
	if (!Number.isSafeInteger(length) || length < 0) throw makeError(`Invalid allocation size: ${length}`);
	const limit = getMaxMemoryAllocation(options);
	if (length > limit) throw makeError(`Metadata size ${length} exceeds allocation limit ${limit} (buffering limit)`);
}
function validateAvailableBytes(tokenizer, length, position) {
	if (tokenizer.fileInfo.size !== void 0 && length > tokenizer.fileInfo.size - position) throw new EndOfStreamError();
}
/** Read only bounded chunks from streams; an advertised stream size does not prove bytes exist. */
async function readBuffer(tokenizer, length, options, position = tokenizer.position, makeError = allocationError) {
	validateAllocation(length, options, makeError);
	validateAvailableBytes(tokenizer, length, position);
	if (!isRandomAccessTokenizer(tokenizer) && length > readChunkSize) {
		const chunks = [];
		for (let remaining = length; remaining > 0;) {
			const chunk = new Uint8Array(Math.min(remaining, readChunkSize));
			if (await tokenizer.readBuffer(chunk, { position }) !== chunk.length) throw new EndOfStreamError();
			chunks.push(chunk);
			remaining -= chunk.length;
			position += chunk.length;
		}
		const buffer = new Uint8Array(length);
		let offset = 0;
		for (const chunk of chunks) {
			buffer.set(chunk, offset);
			offset += chunk.length;
		}
		return buffer;
	}
	const buffer = new Uint8Array(length);
	if (await tokenizer.readBuffer(buffer, { position }) !== length) throw new EndOfStreamError();
	return buffer;
}
/** Bound custom tokenizer reads and buffer large stream payloads incrementally. */
async function readToken(tokenizer, token, options, position = tokenizer.position, makeError = allocationError) {
	validateAllocation(token.len, options, makeError);
	validateAvailableBytes(tokenizer, token.len, position);
	if (token.len <= readChunkSize) return tokenizer.readToken(token, position);
	return token.get(await readBuffer(tokenizer, token.len, options, position, makeError), 0);
}
// node_modules/music-metadata/lib/common/BasicParser.js
var BasicParser = class {
	metadata;
	tokenizer;
	options;
	/**
	* Initialize parser with output (metadata), input (tokenizer) & parsing options (options).
	* @param {INativeMetadataCollector} metadata Output
	* @param {ITokenizer} tokenizer Input
	* @param {IOptions} options Parsing options
	*/
	constructor(metadata, tokenizer, options) {
		getMaxMemoryAllocation(options);
		this.metadata = metadata;
		this.tokenizer = tokenizer;
		this.options = options;
	}
	readToken(token, position) {
		return readToken(this.tokenizer, token, this.options, position);
	}
};
export { UINT16_LE as A, require_browser as B, INT32_BE as C, INT8 as D, INT64_LE as E, UINT64_BE as F, EndOfStreamError as G, textEncode as H, UINT64_LE as I, UINT8 as L, UINT24_LE as M, UINT32_BE as N, StringType as O, UINT32_LE as P, Uint8ArrayType as R, INT24_BE as S, INT64_BE as T, isRandomAccessTokenizer as U, textDecode as V, AbortError as W, makeUnexpectedFileContentError as _, getMaxMemoryAllocation as a, INT16_BE as b, readBuffer as c, CouldNotDetermineFileTypeError as d, FieldDecodingError as f, makeParseError as g, UnsupportedFileTypeError as h, getMaxChapterCount as i, UINT24_BE as j, UINT16_BE as k, readToken as l, UnexpectedFileContentError as m, defaultMaxChapterCount as n, getMaxMetadataEntries as o, InternalParserError as p, defaultMaxMetadataEntries as r, getTokenizerOptions as s, BasicParser as t, validateAllocation as u, Float32_BE as v, INT32_LE as w, INT16_LE as x, Float64_BE as y, lib_exports as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQmFzaWNQYXJzZXItQ0FJcy10N20uanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vc3RydG9rMy9saWIvc3RyZWFtL0Vycm9ycy5qcyIsIi4uLy4uL3N0cnRvazMvbGliL2lzUmFuZG9tQWNjZXNzVG9rZW5pemVyLmpzIiwiLi4vLi4vQGJvcmV3aXQvdGV4dC1jb2RlYy9saWIvaW5kZXguanMiLCIuLi8uLi9tcy9pbmRleC5qcyIsIi4uLy4uL2RlYnVnL3NyYy9jb21tb24uanMiLCIuLi8uLi9kZWJ1Zy9zcmMvYnJvd3Nlci5qcyIsIi4uLy4uL2llZWU3NTQvaW5kZXguanMiLCIuLi8uLi90b2tlbi10eXBlcy9saWIvaW5kZXguanMiLCIuLi8uLi9tdXNpYy1tZXRhZGF0YS9saWIvUGFyc2VFcnJvci5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb21tb24vQWxsb2NhdGlvbi5qcyIsIi4uLy4uL211c2ljLW1ldGFkYXRhL2xpYi9jb21tb24vQmFzaWNQYXJzZXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGRlZmF1bHRNZXNzYWdlcyA9ICdFbmQtT2YtU3RyZWFtJztcbi8qKlxuICogVGhyb3duIG9uIHJlYWQgb3BlcmF0aW9uIG9mIHRoZSBlbmQgb2YgZmlsZSBvciBzdHJlYW0gaGFzIGJlZW4gcmVhY2hlZFxuICovXG5leHBvcnQgY2xhc3MgRW5kT2ZTdHJlYW1FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoZGVmYXVsdE1lc3NhZ2VzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ0VuZE9mU3RyZWFtRXJyb3InO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBBYm9ydEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UgPSAnVGhlIG9wZXJhdGlvbiB3YXMgYWJvcnRlZCcpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdBYm9ydEVycm9yJztcbiAgICB9XG59XG4iLCIvKipcbiAqIENoZWNrIGZvciByYW5kb20tYWNjZXNzIGNhcGFiaWxpdHksIHBvc2l0aW9uIGNvbnRyb2wgYW5kIGEga25vd24gZmlsZSBzaXplLlxuICogQSBrbm93biBzaXplIGFsb25lIGRvZXMgbm90IGltcGx5IHJhbmRvbSBhY2Nlc3MuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc1JhbmRvbUFjY2Vzc1Rva2VuaXplcih0b2tlbml6ZXIpIHtcbiAgICByZXR1cm4gKHRva2VuaXplci5zdXBwb3J0c1JhbmRvbUFjY2VzcygpICYmXG4gICAgICAgICdzZXRQb3NpdGlvbicgaW4gdG9rZW5pemVyICYmXG4gICAgICAgIHR5cGVvZiB0b2tlbml6ZXIuc2V0UG9zaXRpb24gPT09ICdmdW5jdGlvbicgJiZcbiAgICAgICAgdHlwZW9mIHRva2VuaXplci5maWxlSW5mby5zaXplID09PSAnbnVtYmVyJyk7XG59XG4iLCJjb25zdCBXSU5ET1dTXzEyNTJfRVhUUkEgPSB7XG4gICAgMHg4MDogJ+KCrCcsXG4gICAgMHg4MjogJ+KAmicsXG4gICAgMHg4MzogJ8aSJyxcbiAgICAweDg0OiAn4oCeJyxcbiAgICAweDg1OiAn4oCmJyxcbiAgICAweDg2OiAn4oCgJyxcbiAgICAweDg3OiAn4oChJyxcbiAgICAweDg4OiAny4YnLFxuICAgIDB4ODk6ICfigLAnLFxuICAgIDB4OGE6ICfFoCcsXG4gICAgMHg4YjogJ+KAuScsXG4gICAgMHg4YzogJ8WSJyxcbiAgICAweDhlOiAnxb0nLFxuICAgIDB4OTE6ICfigJgnLFxuICAgIDB4OTI6ICfigJknLFxuICAgIDB4OTM6ICfigJwnLFxuICAgIDB4OTQ6ICfigJ0nLFxuICAgIDB4OTU6ICfigKInLFxuICAgIDB4OTY6ICfigJMnLFxuICAgIDB4OTc6ICfigJQnLFxuICAgIDB4OTg6ICfLnCcsXG4gICAgMHg5OTogJ+KEoicsXG4gICAgMHg5YTogJ8WhJyxcbiAgICAweDliOiAn4oC6JyxcbiAgICAweDljOiAnxZMnLFxuICAgIDB4OWU6ICfFvicsXG4gICAgMHg5ZjogJ8W4J1xufTtcbmNvbnN0IFdJTkRPV1NfMTI1Ml9SRVZFUlNFID0ge307XG5mb3IgKGNvbnN0IFtjb2RlLCBjaGFyXSBvZiBPYmplY3QuZW50cmllcyhXSU5ET1dTXzEyNTJfRVhUUkEpKSB7XG4gICAgV0lORE9XU18xMjUyX1JFVkVSU0VbY2hhcl0gPSBOdW1iZXIucGFyc2VJbnQoY29kZSwgMTApO1xufVxubGV0IF91dGY4RGVjb2RlcjtcbmxldCBfdXRmOEVuY29kZXI7XG5mdW5jdGlvbiB1dGY4RGVjb2RlcigpIHtcbiAgICBpZiAoX3V0ZjhEZWNvZGVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIF91dGY4RGVjb2RlciA9IHR5cGVvZiBnbG9iYWxUaGlzLlRleHREZWNvZGVyID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiBuZXcgZ2xvYmFsVGhpcy5UZXh0RGVjb2RlcigndXRmLTgnKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICBfdXRmOERlY29kZXIgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBfdXRmOERlY29kZXIgIT09IG51bGwgJiYgX3V0ZjhEZWNvZGVyICE9PSB2b2lkIDAgPyBfdXRmOERlY29kZXIgOiB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiB1dGY4RW5jb2RlcigpIHtcbiAgICBpZiAoX3V0ZjhFbmNvZGVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIF91dGY4RW5jb2RlciA9IHR5cGVvZiBnbG9iYWxUaGlzLlRleHRFbmNvZGVyID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiBuZXcgZ2xvYmFsVGhpcy5UZXh0RW5jb2RlcigpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHtcbiAgICAgICAgICAgIF91dGY4RW5jb2RlciA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIF91dGY4RW5jb2RlciAhPT0gbnVsbCAmJiBfdXRmOEVuY29kZXIgIT09IHZvaWQgMCA/IF91dGY4RW5jb2RlciA6IHVuZGVmaW5lZDtcbn1cbmNvbnN0IENIVU5LID0gMzIgKiAxMDI0O1xuY29uc3QgUkVQTEFDRU1FTlQgPSAweGZmZmQ7XG4vKipcbiAqIERlY29kZSB0ZXh0IGZyb20gYmluYXJ5IGRhdGFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRleHREZWNvZGUoYnl0ZXMsIGVuY29kaW5nID0gJ3V0Zi04Jykge1xuICAgIHN3aXRjaCAoZW5jb2RpbmcudG9Mb3dlckNhc2UoKSkge1xuICAgICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIGNhc2UgJ3V0ZjgnOiB7XG4gICAgICAgICAgICBjb25zdCBkZWMgPSB1dGY4RGVjb2RlcigpO1xuICAgICAgICAgICAgcmV0dXJuIGRlYyA/IGRlYy5kZWNvZGUoYnl0ZXMpIDogZGVjb2RlVVRGOChieXRlcyk7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgICAgICAgcmV0dXJuIGRlY29kZVVURjE2TEUoYnl0ZXMpO1xuICAgICAgICBjYXNlICd1cy1hc2NpaSc6XG4gICAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgICAgICAgIHJldHVybiBkZWNvZGVBU0NJSShieXRlcyk7XG4gICAgICAgIGNhc2UgJ2xhdGluMSc6XG4gICAgICAgIGNhc2UgJ2lzby04ODU5LTEnOlxuICAgICAgICAgICAgcmV0dXJuIGRlY29kZUxhdGluMShieXRlcyk7XG4gICAgICAgIGNhc2UgJ3dpbmRvd3MtMTI1Mic6XG4gICAgICAgICAgICByZXR1cm4gZGVjb2RlV2luZG93czEyNTIoYnl0ZXMpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYEVuY29kaW5nICcke2VuY29kaW5nfScgbm90IHN1cHBvcnRlZGApO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiB0ZXh0RW5jb2RlKGlucHV0ID0gJycsIGVuY29kaW5nID0gJ3V0Zi04Jykge1xuICAgIHN3aXRjaCAoZW5jb2RpbmcudG9Mb3dlckNhc2UoKSkge1xuICAgICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIGNhc2UgJ3V0ZjgnOiB7XG4gICAgICAgICAgICBjb25zdCBlbmMgPSB1dGY4RW5jb2RlcigpO1xuICAgICAgICAgICAgcmV0dXJuIGVuYyA/IGVuYy5lbmNvZGUoaW5wdXQpIDogZW5jb2RlVVRGOChpbnB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgICAgICAgcmV0dXJuIGVuY29kZVVURjE2TEUoaW5wdXQpO1xuICAgICAgICBjYXNlICd1cy1hc2NpaSc6XG4gICAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgICAgICAgIHJldHVybiBlbmNvZGVBU0NJSShpbnB1dCk7XG4gICAgICAgIGNhc2UgJ2xhdGluMSc6XG4gICAgICAgIGNhc2UgJ2lzby04ODU5LTEnOlxuICAgICAgICAgICAgcmV0dXJuIGVuY29kZUxhdGluMShpbnB1dCk7XG4gICAgICAgIGNhc2UgJ3dpbmRvd3MtMTI1Mic6XG4gICAgICAgICAgICByZXR1cm4gZW5jb2RlV2luZG93czEyNTIoaW5wdXQpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYEVuY29kaW5nICcke2VuY29kaW5nfScgbm90IHN1cHBvcnRlZGApO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZsdXNoQ2h1bmsocGFydHMsIGNodW5rKSB7XG4gICAgaWYgKGNodW5rLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHBhcnRzLnB1c2goU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBjaHVuaykpO1xuICAgIGNodW5rLmxlbmd0aCA9IDA7XG59XG5mdW5jdGlvbiBwdXNoQ29kZVVuaXQocGFydHMsIGNodW5rLCBjb2RlVW5pdCkge1xuICAgIGNodW5rLnB1c2goY29kZVVuaXQpO1xuICAgIGlmIChjaHVuay5sZW5ndGggPj0gQ0hVTkspIHtcbiAgICAgICAgZmx1c2hDaHVuayhwYXJ0cywgY2h1bmspO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHB1c2hDb2RlUG9pbnQocGFydHMsIGNodW5rLCBjcCkge1xuICAgIGlmIChjcCA8PSAweGZmZmYpIHtcbiAgICAgICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgY3ApO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNwIC09IDB4MTAwMDA7XG4gICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgMHhkODAwICsgKGNwID4+IDEwKSk7XG4gICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgMHhkYzAwICsgKGNwICYgMHgzZmYpKTtcbn1cbmZ1bmN0aW9uIGRlY29kZVVURjgoYnl0ZXMpIHtcbiAgICBjb25zdCBwYXJ0cyA9IFtdO1xuICAgIGNvbnN0IGNodW5rID0gW107XG4gICAgbGV0IGkgPSAwO1xuICAgIC8vIE1hdGNoIFRleHREZWNvZGVyKFwidXRmLThcIikgZGVmYXVsdCBCT00gaGFuZGxpbmdcbiAgICBpZiAoYnl0ZXMubGVuZ3RoID49IDMgJiYgYnl0ZXNbMF0gPT09IDB4ZWYgJiYgYnl0ZXNbMV0gPT09IDB4YmIgJiYgYnl0ZXNbMl0gPT09IDB4YmYpIHtcbiAgICAgICAgaSA9IDM7XG4gICAgfVxuICAgIHdoaWxlIChpIDwgYnl0ZXMubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGIxID0gYnl0ZXNbaV07XG4gICAgICAgIGlmIChiMSA8PSAweDdmKSB7XG4gICAgICAgICAgICBwdXNoQ29kZVVuaXQocGFydHMsIGNodW5rLCBiMSk7XG4gICAgICAgICAgICBpKys7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJbnZhbGlkIGxlYWRpbmcgYnl0ZXM6IGNvbnRpbnVhdGlvbiBieXRlIG9yIGltcG9zc2libGUgcHJlZml4ZXNcbiAgICAgICAgaWYgKGIxIDwgMHhjMiB8fCBiMSA+IDB4ZjQpIHtcbiAgICAgICAgICAgIHB1c2hDb2RlVW5pdChwYXJ0cywgY2h1bmssIFJFUExBQ0VNRU5UKTtcbiAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxlbmd0aCA9IGIxIDw9IDB4ZGYgPyAyIDogYjEgPD0gMHhlZiA/IDMgOiA0O1xuICAgICAgICBsZXQgY3AgPSBiMSAmICgweDdmID4+IGxlbmd0aCk7XG4gICAgICAgIGxldCBsb3dlciA9IGIxID09PSAweGUwID8gMHhhMCA6IGIxID09PSAweGYwID8gMHg5MCA6IDB4ODA7XG4gICAgICAgIGxldCB1cHBlciA9IGIxID09PSAweGVkID8gMHg5ZiA6IGIxID09PSAweGY0ID8gMHg4ZiA6IDB4YmY7XG4gICAgICAgIGxldCBjb25zdW1lZCA9IDE7XG4gICAgICAgIGkrKztcbiAgICAgICAgLy8gQ29uc3VtZSBvbmx5IHRoZSB2YWxpZCBwcmVmaXguIEFuIGludGVycnVwdGluZyBieXRlIHN0YXJ0cyBhIG5ldyBzZXF1ZW5jZS5cbiAgICAgICAgd2hpbGUgKGNvbnN1bWVkIDwgbGVuZ3RoICYmIGkgPCBieXRlcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBieXRlc1tpXTtcbiAgICAgICAgICAgIGlmIChuZXh0IDwgbG93ZXIgfHwgbmV4dCA+IHVwcGVyKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjcCA9IChjcCA8PCA2KSB8IChuZXh0ICYgMHgzZik7XG4gICAgICAgICAgICBjb25zdW1lZCsrO1xuICAgICAgICAgICAgaSsrO1xuICAgICAgICAgICAgbG93ZXIgPSAweDgwO1xuICAgICAgICAgICAgdXBwZXIgPSAweGJmO1xuICAgICAgICB9XG4gICAgICAgIHB1c2hDb2RlUG9pbnQocGFydHMsIGNodW5rLCBjb25zdW1lZCA9PT0gbGVuZ3RoID8gY3AgOiBSRVBMQUNFTUVOVCk7XG4gICAgfVxuICAgIGZsdXNoQ2h1bmsocGFydHMsIGNodW5rKTtcbiAgICByZXR1cm4gcGFydHMuam9pbignJyk7XG59XG5mdW5jdGlvbiBkZWNvZGVVVEYxNkxFKGJ5dGVzKSB7XG4gICAgY29uc3QgcGFydHMgPSBbXTtcbiAgICBjb25zdCBjaHVuayA9IFtdO1xuICAgIGNvbnN0IGxlbiA9IGJ5dGVzLmxlbmd0aDtcbiAgICBsZXQgaSA9IDA7XG4gICAgLy8gTWF0Y2ggVGV4dERlY29kZXIoXCJ1dGYtMTZsZVwiKSBkZWZhdWx0IEJPTSBoYW5kbGluZ1xuICAgIGlmIChsZW4gPj0gMiAmJiBieXRlc1swXSA9PT0gMHhmZiAmJiBieXRlc1sxXSA9PT0gMHhmZSkge1xuICAgICAgICBpID0gMjtcbiAgICB9XG4gICAgd2hpbGUgKGkgKyAxIDwgbGVuKSB7XG4gICAgICAgIGNvbnN0IHUxID0gYnl0ZXNbaV0gfCAoYnl0ZXNbaSArIDFdIDw8IDgpO1xuICAgICAgICBpICs9IDI7XG4gICAgICAgIC8vIEhpZ2ggc3Vycm9nYXRlXG4gICAgICAgIGlmICh1MSA+PSAweGQ4MDAgJiYgdTEgPD0gMHhkYmZmKSB7XG4gICAgICAgICAgICBpZiAoaSArIDEgPCBsZW4pIHtcbiAgICAgICAgICAgICAgICBjb25zdCB1MiA9IGJ5dGVzW2ldIHwgKGJ5dGVzW2kgKyAxXSA8PCA4KTtcbiAgICAgICAgICAgICAgICBpZiAodTIgPj0gMHhkYzAwICYmIHUyIDw9IDB4ZGZmZikge1xuICAgICAgICAgICAgICAgICAgICBwdXNoQ29kZVVuaXQocGFydHMsIGNodW5rLCB1MSk7XG4gICAgICAgICAgICAgICAgICAgIHB1c2hDb2RlVW5pdChwYXJ0cywgY2h1bmssIHUyKTtcbiAgICAgICAgICAgICAgICAgICAgaSArPSAyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgUkVQTEFDRU1FTlQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHB1c2hDb2RlVW5pdChwYXJ0cywgY2h1bmssIFJFUExBQ0VNRU5UKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIC8vIExvbmUgbG93IHN1cnJvZ2F0ZVxuICAgICAgICBpZiAodTEgPj0gMHhkYzAwICYmIHUxIDw9IDB4ZGZmZikge1xuICAgICAgICAgICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgUkVQTEFDRU1FTlQpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcHVzaENvZGVVbml0KHBhcnRzLCBjaHVuaywgdTEpO1xuICAgIH1cbiAgICAvLyBPZGQgdHJhaWxpbmcgYnl0ZVxuICAgIGlmIChpIDwgbGVuKSB7XG4gICAgICAgIHB1c2hDb2RlVW5pdChwYXJ0cywgY2h1bmssIFJFUExBQ0VNRU5UKTtcbiAgICB9XG4gICAgZmx1c2hDaHVuayhwYXJ0cywgY2h1bmspO1xuICAgIHJldHVybiBwYXJ0cy5qb2luKCcnKTtcbn1cbmZ1bmN0aW9uIGRlY29kZUFTQ0lJKGJ5dGVzKSB7XG4gICAgY29uc3QgcGFydHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJ5dGVzLmxlbmd0aDsgaSArPSBDSFVOSykge1xuICAgICAgICBjb25zdCBlbmQgPSBNYXRoLm1pbihieXRlcy5sZW5ndGgsIGkgKyBDSFVOSyk7XG4gICAgICAgIGNvbnN0IGNvZGVzID0gbmV3IEFycmF5KGVuZCAtIGkpO1xuICAgICAgICBmb3IgKGxldCBqID0gaSwgayA9IDA7IGogPCBlbmQ7IGorKywgaysrKSB7XG4gICAgICAgICAgICBjb2Rlc1trXSA9IGJ5dGVzW2pdICYgMHg3ZjtcbiAgICAgICAgfVxuICAgICAgICBwYXJ0cy5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkobnVsbCwgY29kZXMpKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnRzLmpvaW4oJycpO1xufVxuZnVuY3Rpb24gZGVjb2RlTGF0aW4xKGJ5dGVzKSB7XG4gICAgY29uc3QgcGFydHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJ5dGVzLmxlbmd0aDsgaSArPSBDSFVOSykge1xuICAgICAgICBjb25zdCBlbmQgPSBNYXRoLm1pbihieXRlcy5sZW5ndGgsIGkgKyBDSFVOSyk7XG4gICAgICAgIGNvbnN0IGNvZGVzID0gbmV3IEFycmF5KGVuZCAtIGkpO1xuICAgICAgICBmb3IgKGxldCBqID0gaSwgayA9IDA7IGogPCBlbmQ7IGorKywgaysrKSB7XG4gICAgICAgICAgICBjb2Rlc1trXSA9IGJ5dGVzW2pdO1xuICAgICAgICB9XG4gICAgICAgIHBhcnRzLnB1c2goU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBjb2RlcykpO1xuICAgIH1cbiAgICByZXR1cm4gcGFydHMuam9pbignJyk7XG59XG5mdW5jdGlvbiBkZWNvZGVXaW5kb3dzMTI1MihieXRlcykge1xuICAgIGNvbnN0IHBhcnRzID0gW107XG4gICAgbGV0IG91dCA9ICcnO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgYiA9IGJ5dGVzW2ldO1xuICAgICAgICBjb25zdCBleHRyYSA9IGIgPj0gMHg4MCAmJiBiIDw9IDB4OWYgPyBXSU5ET1dTXzEyNTJfRVhUUkFbYl0gOiB1bmRlZmluZWQ7XG4gICAgICAgIG91dCArPSBleHRyYSAhPT0gbnVsbCAmJiBleHRyYSAhPT0gdm9pZCAwID8gZXh0cmEgOiBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICAgICAgICBpZiAob3V0Lmxlbmd0aCA+PSBDSFVOSykge1xuICAgICAgICAgICAgcGFydHMucHVzaChvdXQpO1xuICAgICAgICAgICAgb3V0ID0gJyc7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKG91dCkge1xuICAgICAgICBwYXJ0cy5wdXNoKG91dCk7XG4gICAgfVxuICAgIHJldHVybiBwYXJ0cy5qb2luKCcnKTtcbn1cbmZ1bmN0aW9uIGVuY29kZVVURjgoc3RyKSB7XG4gICAgY29uc3Qgb3V0ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IGNwID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgIC8vIFZhbGlkIHN1cnJvZ2F0ZSBwYWlyXG4gICAgICAgIGlmIChjcCA+PSAweGQ4MDAgJiYgY3AgPD0gMHhkYmZmKSB7XG4gICAgICAgICAgICBpZiAoaSArIDEgPCBzdHIubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbG8gPSBzdHIuY2hhckNvZGVBdChpICsgMSk7XG4gICAgICAgICAgICAgICAgaWYgKGxvID49IDB4ZGMwMCAmJiBsbyA8PSAweGRmZmYpIHtcbiAgICAgICAgICAgICAgICAgICAgY3AgPSAweDEwMDAwICsgKChjcCAtIDB4ZDgwMCkgPDwgMTApICsgKGxvIC0gMHhkYzAwKTtcbiAgICAgICAgICAgICAgICAgICAgaSsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY3AgPSBSRVBMQUNFTUVOVDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjcCA9IFJFUExBQ0VNRU5UO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGNwID49IDB4ZGMwMCAmJiBjcCA8PSAweGRmZmYpIHtcbiAgICAgICAgICAgIC8vIExvbmUgbG93IHN1cnJvZ2F0ZVxuICAgICAgICAgICAgY3AgPSBSRVBMQUNFTUVOVDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY3AgPCAweDgwKSB7XG4gICAgICAgICAgICBvdXQucHVzaChjcCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoY3AgPCAweDgwMCkge1xuICAgICAgICAgICAgb3V0LnB1c2goMHhjMCB8IChjcCA+PiA2KSwgMHg4MCB8IChjcCAmIDB4M2YpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChjcCA8IDB4MTAwMDApIHtcbiAgICAgICAgICAgIG91dC5wdXNoKDB4ZTAgfCAoY3AgPj4gMTIpLCAweDgwIHwgKChjcCA+PiA2KSAmIDB4M2YpLCAweDgwIHwgKGNwICYgMHgzZikpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb3V0LnB1c2goMHhmMCB8IChjcCA+PiAxOCksIDB4ODAgfCAoKGNwID4+IDEyKSAmIDB4M2YpLCAweDgwIHwgKChjcCA+PiA2KSAmIDB4M2YpLCAweDgwIHwgKGNwICYgMHgzZikpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBuZXcgVWludDhBcnJheShvdXQpO1xufVxuZnVuY3Rpb24gZW5jb2RlVVRGMTZMRShzdHIpIHtcbiAgICAvLyBQcmVzZXJ2ZSBKUyBzdHJpbmcgY29kZSB1bml0cywgYnV0IGRvIG5vdCBlbWl0IG5vbi13ZWxsLWZvcm1lZCBVVEYtMTYuXG4gICAgLy8gUmVwbGFjZSBsb25lIHN1cnJvZ2F0ZXMgd2l0aCBVK0ZGRkQuXG4gICAgY29uc3QgdW5pdHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCB1ID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgIGlmICh1ID49IDB4ZDgwMCAmJiB1IDw9IDB4ZGJmZikge1xuICAgICAgICAgICAgaWYgKGkgKyAxIDwgc3RyLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxvID0gc3RyLmNoYXJDb2RlQXQoaSArIDEpO1xuICAgICAgICAgICAgICAgIGlmIChsbyA+PSAweGRjMDAgJiYgbG8gPD0gMHhkZmZmKSB7XG4gICAgICAgICAgICAgICAgICAgIHVuaXRzLnB1c2godSwgbG8pO1xuICAgICAgICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB1bml0cy5wdXNoKFJFUExBQ0VNRU5UKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB1bml0cy5wdXNoKFJFUExBQ0VNRU5UKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh1ID49IDB4ZGMwMCAmJiB1IDw9IDB4ZGZmZikge1xuICAgICAgICAgICAgdW5pdHMucHVzaChSRVBMQUNFTUVOVCk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB1bml0cy5wdXNoKHUpO1xuICAgIH1cbiAgICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheSh1bml0cy5sZW5ndGggKiAyKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHVuaXRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSB1bml0c1tpXTtcbiAgICAgICAgY29uc3QgbyA9IGkgKiAyO1xuICAgICAgICBvdXRbb10gPSBjb2RlICYgMHhmZjtcbiAgICAgICAgb3V0W28gKyAxXSA9IGNvZGUgPj4+IDg7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG59XG5mdW5jdGlvbiBlbmNvZGVBU0NJSShzdHIpIHtcbiAgICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShzdHIubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICBvdXRbaV0gPSBzdHIuY2hhckNvZGVBdChpKSAmIDB4N2Y7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG59XG5mdW5jdGlvbiBlbmNvZGVMYXRpbjEoc3RyKSB7XG4gICAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgb3V0W2ldID0gc3RyLmNoYXJDb2RlQXQoaSkgJiAweGZmO1xuICAgIH1cbiAgICByZXR1cm4gb3V0O1xufVxuZnVuY3Rpb24gZW5jb2RlV2luZG93czEyNTIoc3RyKSB7XG4gICAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgY2ggPSBzdHJbaV07XG4gICAgICAgIGNvbnN0IGNvZGUgPSBjaC5jaGFyQ29kZUF0KDApO1xuICAgICAgICBpZiAoV0lORE9XU18xMjUyX1JFVkVSU0VbY2hdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIG91dFtpXSA9IFdJTkRPV1NfMTI1Ml9SRVZFUlNFW2NoXTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICgoY29kZSA+PSAweDAwICYmIGNvZGUgPD0gMHg3ZikgfHwgKGNvZGUgPj0gMHhhMCAmJiBjb2RlIDw9IDB4ZmYpKSB7XG4gICAgICAgICAgICBvdXRbaV0gPSBjb2RlO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgb3V0W2ldID0gMHgzZjsgLy8gJz8nXG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG59XG4iLCIvKipcbiAqIEhlbHBlcnMuXG4gKi9cblxudmFyIHMgPSAxMDAwO1xudmFyIG0gPSBzICogNjA7XG52YXIgaCA9IG0gKiA2MDtcbnZhciBkID0gaCAqIDI0O1xudmFyIHcgPSBkICogNztcbnZhciB5ID0gZCAqIDM2NS4yNTtcblxuLyoqXG4gKiBQYXJzZSBvciBmb3JtYXQgdGhlIGdpdmVuIGB2YWxgLlxuICpcbiAqIE9wdGlvbnM6XG4gKlxuICogIC0gYGxvbmdgIHZlcmJvc2UgZm9ybWF0dGluZyBbZmFsc2VdXG4gKlxuICogQHBhcmFtIHtTdHJpbmd8TnVtYmVyfSB2YWxcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEB0aHJvd3Mge0Vycm9yfSB0aHJvdyBhbiBlcnJvciBpZiB2YWwgaXMgbm90IGEgbm9uLWVtcHR5IHN0cmluZyBvciBhIG51bWJlclxuICogQHJldHVybiB7U3RyaW5nfE51bWJlcn1cbiAqIEBhcGkgcHVibGljXG4gKi9cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAodmFsLCBvcHRpb25zKSB7XG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICB2YXIgdHlwZSA9IHR5cGVvZiB2YWw7XG4gIGlmICh0eXBlID09PSAnc3RyaW5nJyAmJiB2YWwubGVuZ3RoID4gMCkge1xuICAgIHJldHVybiBwYXJzZSh2YWwpO1xuICB9IGVsc2UgaWYgKHR5cGUgPT09ICdudW1iZXInICYmIGlzRmluaXRlKHZhbCkpIHtcbiAgICByZXR1cm4gb3B0aW9ucy5sb25nID8gZm10TG9uZyh2YWwpIDogZm10U2hvcnQodmFsKTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgJ3ZhbCBpcyBub3QgYSBub24tZW1wdHkgc3RyaW5nIG9yIGEgdmFsaWQgbnVtYmVyLiB2YWw9JyArXG4gICAgICBKU09OLnN0cmluZ2lmeSh2YWwpXG4gICk7XG59O1xuXG4vKipcbiAqIFBhcnNlIHRoZSBnaXZlbiBgc3RyYCBhbmQgcmV0dXJuIG1pbGxpc2Vjb25kcy5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyXG4gKiBAcmV0dXJuIHtOdW1iZXJ9XG4gKiBAYXBpIHByaXZhdGVcbiAqL1xuXG5mdW5jdGlvbiBwYXJzZShzdHIpIHtcbiAgc3RyID0gU3RyaW5nKHN0cik7XG4gIGlmIChzdHIubGVuZ3RoID4gMTAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciBtYXRjaCA9IC9eKC0/KD86XFxkKyk/XFwuP1xcZCspICoobWlsbGlzZWNvbmRzP3xtc2Vjcz98bXN8c2Vjb25kcz98c2Vjcz98c3xtaW51dGVzP3xtaW5zP3xtfGhvdXJzP3xocnM/fGh8ZGF5cz98ZHx3ZWVrcz98d3x5ZWFycz98eXJzP3x5KT8kL2kuZXhlYyhcbiAgICBzdHJcbiAgKTtcbiAgaWYgKCFtYXRjaCkge1xuICAgIHJldHVybjtcbiAgfVxuICB2YXIgbiA9IHBhcnNlRmxvYXQobWF0Y2hbMV0pO1xuICB2YXIgdHlwZSA9IChtYXRjaFsyXSB8fCAnbXMnKS50b0xvd2VyQ2FzZSgpO1xuICBzd2l0Y2ggKHR5cGUpIHtcbiAgICBjYXNlICd5ZWFycyc6XG4gICAgY2FzZSAneWVhcic6XG4gICAgY2FzZSAneXJzJzpcbiAgICBjYXNlICd5cic6XG4gICAgY2FzZSAneSc6XG4gICAgICByZXR1cm4gbiAqIHk7XG4gICAgY2FzZSAnd2Vla3MnOlxuICAgIGNhc2UgJ3dlZWsnOlxuICAgIGNhc2UgJ3cnOlxuICAgICAgcmV0dXJuIG4gKiB3O1xuICAgIGNhc2UgJ2RheXMnOlxuICAgIGNhc2UgJ2RheSc6XG4gICAgY2FzZSAnZCc6XG4gICAgICByZXR1cm4gbiAqIGQ7XG4gICAgY2FzZSAnaG91cnMnOlxuICAgIGNhc2UgJ2hvdXInOlxuICAgIGNhc2UgJ2hycyc6XG4gICAgY2FzZSAnaHInOlxuICAgIGNhc2UgJ2gnOlxuICAgICAgcmV0dXJuIG4gKiBoO1xuICAgIGNhc2UgJ21pbnV0ZXMnOlxuICAgIGNhc2UgJ21pbnV0ZSc6XG4gICAgY2FzZSAnbWlucyc6XG4gICAgY2FzZSAnbWluJzpcbiAgICBjYXNlICdtJzpcbiAgICAgIHJldHVybiBuICogbTtcbiAgICBjYXNlICdzZWNvbmRzJzpcbiAgICBjYXNlICdzZWNvbmQnOlxuICAgIGNhc2UgJ3NlY3MnOlxuICAgIGNhc2UgJ3NlYyc6XG4gICAgY2FzZSAncyc6XG4gICAgICByZXR1cm4gbiAqIHM7XG4gICAgY2FzZSAnbWlsbGlzZWNvbmRzJzpcbiAgICBjYXNlICdtaWxsaXNlY29uZCc6XG4gICAgY2FzZSAnbXNlY3MnOlxuICAgIGNhc2UgJ21zZWMnOlxuICAgIGNhc2UgJ21zJzpcbiAgICAgIHJldHVybiBuO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59XG5cbi8qKlxuICogU2hvcnQgZm9ybWF0IGZvciBgbXNgLlxuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSBtc1xuICogQHJldHVybiB7U3RyaW5nfVxuICogQGFwaSBwcml2YXRlXG4gKi9cblxuZnVuY3Rpb24gZm10U2hvcnQobXMpIHtcbiAgdmFyIG1zQWJzID0gTWF0aC5hYnMobXMpO1xuICBpZiAobXNBYnMgPj0gZCkge1xuICAgIHJldHVybiBNYXRoLnJvdW5kKG1zIC8gZCkgKyAnZCc7XG4gIH1cbiAgaWYgKG1zQWJzID49IGgpIHtcbiAgICByZXR1cm4gTWF0aC5yb3VuZChtcyAvIGgpICsgJ2gnO1xuICB9XG4gIGlmIChtc0FicyA+PSBtKSB7XG4gICAgcmV0dXJuIE1hdGgucm91bmQobXMgLyBtKSArICdtJztcbiAgfVxuICBpZiAobXNBYnMgPj0gcykge1xuICAgIHJldHVybiBNYXRoLnJvdW5kKG1zIC8gcykgKyAncyc7XG4gIH1cbiAgcmV0dXJuIG1zICsgJ21zJztcbn1cblxuLyoqXG4gKiBMb25nIGZvcm1hdCBmb3IgYG1zYC5cbiAqXG4gKiBAcGFyYW0ge051bWJlcn0gbXNcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqIEBhcGkgcHJpdmF0ZVxuICovXG5cbmZ1bmN0aW9uIGZtdExvbmcobXMpIHtcbiAgdmFyIG1zQWJzID0gTWF0aC5hYnMobXMpO1xuICBpZiAobXNBYnMgPj0gZCkge1xuICAgIHJldHVybiBwbHVyYWwobXMsIG1zQWJzLCBkLCAnZGF5Jyk7XG4gIH1cbiAgaWYgKG1zQWJzID49IGgpIHtcbiAgICByZXR1cm4gcGx1cmFsKG1zLCBtc0FicywgaCwgJ2hvdXInKTtcbiAgfVxuICBpZiAobXNBYnMgPj0gbSkge1xuICAgIHJldHVybiBwbHVyYWwobXMsIG1zQWJzLCBtLCAnbWludXRlJyk7XG4gIH1cbiAgaWYgKG1zQWJzID49IHMpIHtcbiAgICByZXR1cm4gcGx1cmFsKG1zLCBtc0FicywgcywgJ3NlY29uZCcpO1xuICB9XG4gIHJldHVybiBtcyArICcgbXMnO1xufVxuXG4vKipcbiAqIFBsdXJhbGl6YXRpb24gaGVscGVyLlxuICovXG5cbmZ1bmN0aW9uIHBsdXJhbChtcywgbXNBYnMsIG4sIG5hbWUpIHtcbiAgdmFyIGlzUGx1cmFsID0gbXNBYnMgPj0gbiAqIDEuNTtcbiAgcmV0dXJuIE1hdGgucm91bmQobXMgLyBuKSArICcgJyArIG5hbWUgKyAoaXNQbHVyYWwgPyAncycgOiAnJyk7XG59XG4iLCJcbi8qKlxuICogVGhpcyBpcyB0aGUgY29tbW9uIGxvZ2ljIGZvciBib3RoIHRoZSBOb2RlLmpzIGFuZCB3ZWIgYnJvd3NlclxuICogaW1wbGVtZW50YXRpb25zIG9mIGBkZWJ1ZygpYC5cbiAqL1xuXG5mdW5jdGlvbiBzZXR1cChlbnYpIHtcblx0Y3JlYXRlRGVidWcuZGVidWcgPSBjcmVhdGVEZWJ1Zztcblx0Y3JlYXRlRGVidWcuZGVmYXVsdCA9IGNyZWF0ZURlYnVnO1xuXHRjcmVhdGVEZWJ1Zy5jb2VyY2UgPSBjb2VyY2U7XG5cdGNyZWF0ZURlYnVnLmRpc2FibGUgPSBkaXNhYmxlO1xuXHRjcmVhdGVEZWJ1Zy5lbmFibGUgPSBlbmFibGU7XG5cdGNyZWF0ZURlYnVnLmVuYWJsZWQgPSBlbmFibGVkO1xuXHRjcmVhdGVEZWJ1Zy5odW1hbml6ZSA9IHJlcXVpcmUoJ21zJyk7XG5cdGNyZWF0ZURlYnVnLmRlc3Ryb3kgPSBkZXN0cm95O1xuXG5cdE9iamVjdC5rZXlzKGVudikuZm9yRWFjaChrZXkgPT4ge1xuXHRcdGNyZWF0ZURlYnVnW2tleV0gPSBlbnZba2V5XTtcblx0fSk7XG5cblx0LyoqXG5cdCogVGhlIGN1cnJlbnRseSBhY3RpdmUgZGVidWcgbW9kZSBuYW1lcywgYW5kIG5hbWVzIHRvIHNraXAuXG5cdCovXG5cblx0Y3JlYXRlRGVidWcubmFtZXMgPSBbXTtcblx0Y3JlYXRlRGVidWcuc2tpcHMgPSBbXTtcblxuXHQvKipcblx0KiBNYXAgb2Ygc3BlY2lhbCBcIiVuXCIgaGFuZGxpbmcgZnVuY3Rpb25zLCBmb3IgdGhlIGRlYnVnIFwiZm9ybWF0XCIgYXJndW1lbnQuXG5cdCpcblx0KiBWYWxpZCBrZXkgbmFtZXMgYXJlIGEgc2luZ2xlLCBsb3dlciBvciB1cHBlci1jYXNlIGxldHRlciwgaS5lLiBcIm5cIiBhbmQgXCJOXCIuXG5cdCovXG5cdGNyZWF0ZURlYnVnLmZvcm1hdHRlcnMgPSB7fTtcblxuXHQvKipcblx0KiBTZWxlY3RzIGEgY29sb3IgZm9yIGEgZGVidWcgbmFtZXNwYWNlXG5cdCogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZSBUaGUgbmFtZXNwYWNlIHN0cmluZyBmb3IgdGhlIGRlYnVnIGluc3RhbmNlIHRvIGJlIGNvbG9yZWRcblx0KiBAcmV0dXJuIHtOdW1iZXJ8U3RyaW5nfSBBbiBBTlNJIGNvbG9yIGNvZGUgZm9yIHRoZSBnaXZlbiBuYW1lc3BhY2Vcblx0KiBAYXBpIHByaXZhdGVcblx0Ki9cblx0ZnVuY3Rpb24gc2VsZWN0Q29sb3IobmFtZXNwYWNlKSB7XG5cdFx0bGV0IGhhc2ggPSAwO1xuXG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBuYW1lc3BhY2UubGVuZ3RoOyBpKyspIHtcblx0XHRcdGhhc2ggPSAoKGhhc2ggPDwgNSkgLSBoYXNoKSArIG5hbWVzcGFjZS5jaGFyQ29kZUF0KGkpO1xuXHRcdFx0aGFzaCB8PSAwOyAvLyBDb252ZXJ0IHRvIDMyYml0IGludGVnZXJcblx0XHR9XG5cblx0XHRyZXR1cm4gY3JlYXRlRGVidWcuY29sb3JzW01hdGguYWJzKGhhc2gpICUgY3JlYXRlRGVidWcuY29sb3JzLmxlbmd0aF07XG5cdH1cblx0Y3JlYXRlRGVidWcuc2VsZWN0Q29sb3IgPSBzZWxlY3RDb2xvcjtcblxuXHQvKipcblx0KiBDcmVhdGUgYSBkZWJ1Z2dlciB3aXRoIHRoZSBnaXZlbiBgbmFtZXNwYWNlYC5cblx0KlxuXHQqIEBwYXJhbSB7U3RyaW5nfSBuYW1lc3BhY2Vcblx0KiBAcmV0dXJuIHtGdW5jdGlvbn1cblx0KiBAYXBpIHB1YmxpY1xuXHQqL1xuXHRmdW5jdGlvbiBjcmVhdGVEZWJ1ZyhuYW1lc3BhY2UpIHtcblx0XHRsZXQgcHJldlRpbWU7XG5cdFx0bGV0IGVuYWJsZU92ZXJyaWRlID0gbnVsbDtcblx0XHRsZXQgbmFtZXNwYWNlc0NhY2hlO1xuXHRcdGxldCBlbmFibGVkQ2FjaGU7XG5cblx0XHRmdW5jdGlvbiBkZWJ1ZyguLi5hcmdzKSB7XG5cdFx0XHQvLyBEaXNhYmxlZD9cblx0XHRcdGlmICghZGVidWcuZW5hYmxlZCkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IHNlbGYgPSBkZWJ1ZztcblxuXHRcdFx0Ly8gU2V0IGBkaWZmYCB0aW1lc3RhbXBcblx0XHRcdGNvbnN0IGN1cnIgPSBOdW1iZXIobmV3IERhdGUoKSk7XG5cdFx0XHRjb25zdCBtcyA9IGN1cnIgLSAocHJldlRpbWUgfHwgY3Vycik7XG5cdFx0XHRzZWxmLmRpZmYgPSBtcztcblx0XHRcdHNlbGYucHJldiA9IHByZXZUaW1lO1xuXHRcdFx0c2VsZi5jdXJyID0gY3Vycjtcblx0XHRcdHByZXZUaW1lID0gY3VycjtcblxuXHRcdFx0YXJnc1swXSA9IGNyZWF0ZURlYnVnLmNvZXJjZShhcmdzWzBdKTtcblxuXHRcdFx0aWYgKHR5cGVvZiBhcmdzWzBdICE9PSAnc3RyaW5nJykge1xuXHRcdFx0XHQvLyBBbnl0aGluZyBlbHNlIGxldCdzIGluc3BlY3Qgd2l0aCAlT1xuXHRcdFx0XHRhcmdzLnVuc2hpZnQoJyVPJyk7XG5cdFx0XHR9XG5cblx0XHRcdC8vIEFwcGx5IGFueSBgZm9ybWF0dGVyc2AgdHJhbnNmb3JtYXRpb25zXG5cdFx0XHRsZXQgaW5kZXggPSAwO1xuXHRcdFx0YXJnc1swXSA9IGFyZ3NbMF0ucmVwbGFjZSgvJShbYS16QS1aJV0pL2csIChtYXRjaCwgZm9ybWF0KSA9PiB7XG5cdFx0XHRcdC8vIElmIHdlIGVuY291bnRlciBhbiBlc2NhcGVkICUgdGhlbiBkb24ndCBpbmNyZWFzZSB0aGUgYXJyYXkgaW5kZXhcblx0XHRcdFx0aWYgKG1hdGNoID09PSAnJSUnKSB7XG5cdFx0XHRcdFx0cmV0dXJuICclJztcblx0XHRcdFx0fVxuXHRcdFx0XHRpbmRleCsrO1xuXHRcdFx0XHRjb25zdCBmb3JtYXR0ZXIgPSBjcmVhdGVEZWJ1Zy5mb3JtYXR0ZXJzW2Zvcm1hdF07XG5cdFx0XHRcdGlmICh0eXBlb2YgZm9ybWF0dGVyID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsID0gYXJnc1tpbmRleF07XG5cdFx0XHRcdFx0bWF0Y2ggPSBmb3JtYXR0ZXIuY2FsbChzZWxmLCB2YWwpO1xuXG5cdFx0XHRcdFx0Ly8gTm93IHdlIG5lZWQgdG8gcmVtb3ZlIGBhcmdzW2luZGV4XWAgc2luY2UgaXQncyBpbmxpbmVkIGluIHRoZSBgZm9ybWF0YFxuXHRcdFx0XHRcdGFyZ3Muc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdFx0XHRpbmRleC0tO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBtYXRjaDtcblx0XHRcdH0pO1xuXG5cdFx0XHQvLyBBcHBseSBlbnYtc3BlY2lmaWMgZm9ybWF0dGluZyAoY29sb3JzLCBldGMuKVxuXHRcdFx0Y3JlYXRlRGVidWcuZm9ybWF0QXJncy5jYWxsKHNlbGYsIGFyZ3MpO1xuXG5cdFx0XHRjb25zdCBsb2dGbiA9IHNlbGYubG9nIHx8IGNyZWF0ZURlYnVnLmxvZztcblx0XHRcdGxvZ0ZuLmFwcGx5KHNlbGYsIGFyZ3MpO1xuXHRcdH1cblxuXHRcdGRlYnVnLm5hbWVzcGFjZSA9IG5hbWVzcGFjZTtcblx0XHRkZWJ1Zy51c2VDb2xvcnMgPSBjcmVhdGVEZWJ1Zy51c2VDb2xvcnMoKTtcblx0XHRkZWJ1Zy5jb2xvciA9IGNyZWF0ZURlYnVnLnNlbGVjdENvbG9yKG5hbWVzcGFjZSk7XG5cdFx0ZGVidWcuZXh0ZW5kID0gZXh0ZW5kO1xuXHRcdGRlYnVnLmRlc3Ryb3kgPSBjcmVhdGVEZWJ1Zy5kZXN0cm95OyAvLyBYWFggVGVtcG9yYXJ5LiBXaWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgcmVsZWFzZS5cblxuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkZWJ1ZywgJ2VuYWJsZWQnLCB7XG5cdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0Y29uZmlndXJhYmxlOiBmYWxzZSxcblx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHRpZiAoZW5hYmxlT3ZlcnJpZGUgIT09IG51bGwpIHtcblx0XHRcdFx0XHRyZXR1cm4gZW5hYmxlT3ZlcnJpZGU7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5hbWVzcGFjZXNDYWNoZSAhPT0gY3JlYXRlRGVidWcubmFtZXNwYWNlcykge1xuXHRcdFx0XHRcdG5hbWVzcGFjZXNDYWNoZSA9IGNyZWF0ZURlYnVnLm5hbWVzcGFjZXM7XG5cdFx0XHRcdFx0ZW5hYmxlZENhY2hlID0gY3JlYXRlRGVidWcuZW5hYmxlZChuYW1lc3BhY2UpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuIGVuYWJsZWRDYWNoZTtcblx0XHRcdH0sXG5cdFx0XHRzZXQ6IHYgPT4ge1xuXHRcdFx0XHRlbmFibGVPdmVycmlkZSA9IHY7XG5cdFx0XHR9XG5cdFx0fSk7XG5cblx0XHQvLyBFbnYtc3BlY2lmaWMgaW5pdGlhbGl6YXRpb24gbG9naWMgZm9yIGRlYnVnIGluc3RhbmNlc1xuXHRcdGlmICh0eXBlb2YgY3JlYXRlRGVidWcuaW5pdCA9PT0gJ2Z1bmN0aW9uJykge1xuXHRcdFx0Y3JlYXRlRGVidWcuaW5pdChkZWJ1Zyk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGRlYnVnO1xuXHR9XG5cblx0ZnVuY3Rpb24gZXh0ZW5kKG5hbWVzcGFjZSwgZGVsaW1pdGVyKSB7XG5cdFx0Y29uc3QgbmV3RGVidWcgPSBjcmVhdGVEZWJ1Zyh0aGlzLm5hbWVzcGFjZSArICh0eXBlb2YgZGVsaW1pdGVyID09PSAndW5kZWZpbmVkJyA/ICc6JyA6IGRlbGltaXRlcikgKyBuYW1lc3BhY2UpO1xuXHRcdG5ld0RlYnVnLmxvZyA9IHRoaXMubG9nO1xuXHRcdHJldHVybiBuZXdEZWJ1Zztcblx0fVxuXG5cdC8qKlxuXHQqIEVuYWJsZXMgYSBkZWJ1ZyBtb2RlIGJ5IG5hbWVzcGFjZXMuIFRoaXMgY2FuIGluY2x1ZGUgbW9kZXNcblx0KiBzZXBhcmF0ZWQgYnkgYSBjb2xvbiBhbmQgd2lsZGNhcmRzLlxuXHQqXG5cdCogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZXNcblx0KiBAYXBpIHB1YmxpY1xuXHQqL1xuXHRmdW5jdGlvbiBlbmFibGUobmFtZXNwYWNlcykge1xuXHRcdGNyZWF0ZURlYnVnLnNhdmUobmFtZXNwYWNlcyk7XG5cdFx0Y3JlYXRlRGVidWcubmFtZXNwYWNlcyA9IG5hbWVzcGFjZXM7XG5cblx0XHRjcmVhdGVEZWJ1Zy5uYW1lcyA9IFtdO1xuXHRcdGNyZWF0ZURlYnVnLnNraXBzID0gW107XG5cblx0XHRjb25zdCBzcGxpdCA9ICh0eXBlb2YgbmFtZXNwYWNlcyA9PT0gJ3N0cmluZycgPyBuYW1lc3BhY2VzIDogJycpXG5cdFx0XHQudHJpbSgpXG5cdFx0XHQucmVwbGFjZSgvXFxzKy9nLCAnLCcpXG5cdFx0XHQuc3BsaXQoJywnKVxuXHRcdFx0LmZpbHRlcihCb29sZWFuKTtcblxuXHRcdGZvciAoY29uc3QgbnMgb2Ygc3BsaXQpIHtcblx0XHRcdGlmIChuc1swXSA9PT0gJy0nKSB7XG5cdFx0XHRcdGNyZWF0ZURlYnVnLnNraXBzLnB1c2gobnMuc2xpY2UoMSkpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Y3JlYXRlRGVidWcubmFtZXMucHVzaChucyk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIENoZWNrcyBpZiB0aGUgZ2l2ZW4gc3RyaW5nIG1hdGNoZXMgYSBuYW1lc3BhY2UgdGVtcGxhdGUsIGhvbm9yaW5nXG5cdCAqIGFzdGVyaXNrcyBhcyB3aWxkY2FyZHMuXG5cdCAqXG5cdCAqIEBwYXJhbSB7U3RyaW5nfSBzZWFyY2hcblx0ICogQHBhcmFtIHtTdHJpbmd9IHRlbXBsYXRlXG5cdCAqIEByZXR1cm4ge0Jvb2xlYW59XG5cdCAqL1xuXHRmdW5jdGlvbiBtYXRjaGVzVGVtcGxhdGUoc2VhcmNoLCB0ZW1wbGF0ZSkge1xuXHRcdGxldCBzZWFyY2hJbmRleCA9IDA7XG5cdFx0bGV0IHRlbXBsYXRlSW5kZXggPSAwO1xuXHRcdGxldCBzdGFySW5kZXggPSAtMTtcblx0XHRsZXQgbWF0Y2hJbmRleCA9IDA7XG5cblx0XHR3aGlsZSAoc2VhcmNoSW5kZXggPCBzZWFyY2gubGVuZ3RoKSB7XG5cdFx0XHRpZiAodGVtcGxhdGVJbmRleCA8IHRlbXBsYXRlLmxlbmd0aCAmJiAodGVtcGxhdGVbdGVtcGxhdGVJbmRleF0gPT09IHNlYXJjaFtzZWFyY2hJbmRleF0gfHwgdGVtcGxhdGVbdGVtcGxhdGVJbmRleF0gPT09ICcqJykpIHtcblx0XHRcdFx0Ly8gTWF0Y2ggY2hhcmFjdGVyIG9yIHByb2NlZWQgd2l0aCB3aWxkY2FyZFxuXHRcdFx0XHRpZiAodGVtcGxhdGVbdGVtcGxhdGVJbmRleF0gPT09ICcqJykge1xuXHRcdFx0XHRcdHN0YXJJbmRleCA9IHRlbXBsYXRlSW5kZXg7XG5cdFx0XHRcdFx0bWF0Y2hJbmRleCA9IHNlYXJjaEluZGV4O1xuXHRcdFx0XHRcdHRlbXBsYXRlSW5kZXgrKzsgLy8gU2tpcCB0aGUgJyonXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0c2VhcmNoSW5kZXgrKztcblx0XHRcdFx0XHR0ZW1wbGF0ZUluZGV4Kys7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAoc3RhckluZGV4ICE9PSAtMSkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW5lZ2F0ZWQtY29uZGl0aW9uXG5cdFx0XHRcdC8vIEJhY2t0cmFjayB0byB0aGUgbGFzdCAnKicgYW5kIHRyeSB0byBtYXRjaCBtb3JlIGNoYXJhY3RlcnNcblx0XHRcdFx0dGVtcGxhdGVJbmRleCA9IHN0YXJJbmRleCArIDE7XG5cdFx0XHRcdG1hdGNoSW5kZXgrKztcblx0XHRcdFx0c2VhcmNoSW5kZXggPSBtYXRjaEluZGV4O1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cmV0dXJuIGZhbHNlOyAvLyBObyBtYXRjaFxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8vIEhhbmRsZSB0cmFpbGluZyAnKicgaW4gdGVtcGxhdGVcblx0XHR3aGlsZSAodGVtcGxhdGVJbmRleCA8IHRlbXBsYXRlLmxlbmd0aCAmJiB0ZW1wbGF0ZVt0ZW1wbGF0ZUluZGV4XSA9PT0gJyonKSB7XG5cdFx0XHR0ZW1wbGF0ZUluZGV4Kys7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHRlbXBsYXRlSW5kZXggPT09IHRlbXBsYXRlLmxlbmd0aDtcblx0fVxuXG5cdC8qKlxuXHQqIERpc2FibGUgZGVidWcgb3V0cHV0LlxuXHQqXG5cdCogQHJldHVybiB7U3RyaW5nfSBuYW1lc3BhY2VzXG5cdCogQGFwaSBwdWJsaWNcblx0Ki9cblx0ZnVuY3Rpb24gZGlzYWJsZSgpIHtcblx0XHRjb25zdCBuYW1lc3BhY2VzID0gW1xuXHRcdFx0Li4uY3JlYXRlRGVidWcubmFtZXMsXG5cdFx0XHQuLi5jcmVhdGVEZWJ1Zy5za2lwcy5tYXAobmFtZXNwYWNlID0+ICctJyArIG5hbWVzcGFjZSlcblx0XHRdLmpvaW4oJywnKTtcblx0XHRjcmVhdGVEZWJ1Zy5lbmFibGUoJycpO1xuXHRcdHJldHVybiBuYW1lc3BhY2VzO1xuXHR9XG5cblx0LyoqXG5cdCogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBtb2RlIG5hbWUgaXMgZW5hYmxlZCwgZmFsc2Ugb3RoZXJ3aXNlLlxuXHQqXG5cdCogQHBhcmFtIHtTdHJpbmd9IG5hbWVcblx0KiBAcmV0dXJuIHtCb29sZWFufVxuXHQqIEBhcGkgcHVibGljXG5cdCovXG5cdGZ1bmN0aW9uIGVuYWJsZWQobmFtZSkge1xuXHRcdGZvciAoY29uc3Qgc2tpcCBvZiBjcmVhdGVEZWJ1Zy5za2lwcykge1xuXHRcdFx0aWYgKG1hdGNoZXNUZW1wbGF0ZShuYW1lLCBza2lwKSkge1xuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Zm9yIChjb25zdCBucyBvZiBjcmVhdGVEZWJ1Zy5uYW1lcykge1xuXHRcdFx0aWYgKG1hdGNoZXNUZW1wbGF0ZShuYW1lLCBucykpIHtcblx0XHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cblx0LyoqXG5cdCogQ29lcmNlIGB2YWxgLlxuXHQqXG5cdCogQHBhcmFtIHtNaXhlZH0gdmFsXG5cdCogQHJldHVybiB7TWl4ZWR9XG5cdCogQGFwaSBwcml2YXRlXG5cdCovXG5cdGZ1bmN0aW9uIGNvZXJjZSh2YWwpIHtcblx0XHRpZiAodmFsIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRcdHJldHVybiB2YWwuc3RhY2sgfHwgdmFsLm1lc3NhZ2U7XG5cdFx0fVxuXHRcdHJldHVybiB2YWw7XG5cdH1cblxuXHQvKipcblx0KiBYWFggRE8gTk9UIFVTRS4gVGhpcyBpcyBhIHRlbXBvcmFyeSBzdHViIGZ1bmN0aW9uLlxuXHQqIFhYWCBJdCBXSUxMIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgcmVsZWFzZS5cblx0Ki9cblx0ZnVuY3Rpb24gZGVzdHJveSgpIHtcblx0XHRjb25zb2xlLndhcm4oJ0luc3RhbmNlIG1ldGhvZCBgZGVidWcuZGVzdHJveSgpYCBpcyBkZXByZWNhdGVkIGFuZCBubyBsb25nZXIgZG9lcyBhbnl0aGluZy4gSXQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24gb2YgYGRlYnVnYC4nKTtcblx0fVxuXG5cdGNyZWF0ZURlYnVnLmVuYWJsZShjcmVhdGVEZWJ1Zy5sb2FkKCkpO1xuXG5cdHJldHVybiBjcmVhdGVEZWJ1Zztcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBzZXR1cDtcbiIsIi8qIGVzbGludC1lbnYgYnJvd3NlciAqL1xuXG4vKipcbiAqIFRoaXMgaXMgdGhlIHdlYiBicm93c2VyIGltcGxlbWVudGF0aW9uIG9mIGBkZWJ1ZygpYC5cbiAqL1xuXG5leHBvcnRzLmZvcm1hdEFyZ3MgPSBmb3JtYXRBcmdzO1xuZXhwb3J0cy5zYXZlID0gc2F2ZTtcbmV4cG9ydHMubG9hZCA9IGxvYWQ7XG5leHBvcnRzLnVzZUNvbG9ycyA9IHVzZUNvbG9ycztcbmV4cG9ydHMuc3RvcmFnZSA9IGxvY2Fsc3RvcmFnZSgpO1xuZXhwb3J0cy5kZXN0cm95ID0gKCgpID0+IHtcblx0bGV0IHdhcm5lZCA9IGZhbHNlO1xuXG5cdHJldHVybiAoKSA9PiB7XG5cdFx0aWYgKCF3YXJuZWQpIHtcblx0XHRcdHdhcm5lZCA9IHRydWU7XG5cdFx0XHRjb25zb2xlLndhcm4oJ0luc3RhbmNlIG1ldGhvZCBgZGVidWcuZGVzdHJveSgpYCBpcyBkZXByZWNhdGVkIGFuZCBubyBsb25nZXIgZG9lcyBhbnl0aGluZy4gSXQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24gb2YgYGRlYnVnYC4nKTtcblx0XHR9XG5cdH07XG59KSgpO1xuXG4vKipcbiAqIENvbG9ycy5cbiAqL1xuXG5leHBvcnRzLmNvbG9ycyA9IFtcblx0JyMwMDAwQ0MnLFxuXHQnIzAwMDBGRicsXG5cdCcjMDAzM0NDJyxcblx0JyMwMDMzRkYnLFxuXHQnIzAwNjZDQycsXG5cdCcjMDA2NkZGJyxcblx0JyMwMDk5Q0MnLFxuXHQnIzAwOTlGRicsXG5cdCcjMDBDQzAwJyxcblx0JyMwMENDMzMnLFxuXHQnIzAwQ0M2NicsXG5cdCcjMDBDQzk5Jyxcblx0JyMwMENDQ0MnLFxuXHQnIzAwQ0NGRicsXG5cdCcjMzMwMENDJyxcblx0JyMzMzAwRkYnLFxuXHQnIzMzMzNDQycsXG5cdCcjMzMzM0ZGJyxcblx0JyMzMzY2Q0MnLFxuXHQnIzMzNjZGRicsXG5cdCcjMzM5OUNDJyxcblx0JyMzMzk5RkYnLFxuXHQnIzMzQ0MwMCcsXG5cdCcjMzNDQzMzJyxcblx0JyMzM0NDNjYnLFxuXHQnIzMzQ0M5OScsXG5cdCcjMzNDQ0NDJyxcblx0JyMzM0NDRkYnLFxuXHQnIzY2MDBDQycsXG5cdCcjNjYwMEZGJyxcblx0JyM2NjMzQ0MnLFxuXHQnIzY2MzNGRicsXG5cdCcjNjZDQzAwJyxcblx0JyM2NkNDMzMnLFxuXHQnIzk5MDBDQycsXG5cdCcjOTkwMEZGJyxcblx0JyM5OTMzQ0MnLFxuXHQnIzk5MzNGRicsXG5cdCcjOTlDQzAwJyxcblx0JyM5OUNDMzMnLFxuXHQnI0NDMDAwMCcsXG5cdCcjQ0MwMDMzJyxcblx0JyNDQzAwNjYnLFxuXHQnI0NDMDA5OScsXG5cdCcjQ0MwMENDJyxcblx0JyNDQzAwRkYnLFxuXHQnI0NDMzMwMCcsXG5cdCcjQ0MzMzMzJyxcblx0JyNDQzMzNjYnLFxuXHQnI0NDMzM5OScsXG5cdCcjQ0MzM0NDJyxcblx0JyNDQzMzRkYnLFxuXHQnI0NDNjYwMCcsXG5cdCcjQ0M2NjMzJyxcblx0JyNDQzk5MDAnLFxuXHQnI0NDOTkzMycsXG5cdCcjQ0NDQzAwJyxcblx0JyNDQ0NDMzMnLFxuXHQnI0ZGMDAwMCcsXG5cdCcjRkYwMDMzJyxcblx0JyNGRjAwNjYnLFxuXHQnI0ZGMDA5OScsXG5cdCcjRkYwMENDJyxcblx0JyNGRjAwRkYnLFxuXHQnI0ZGMzMwMCcsXG5cdCcjRkYzMzMzJyxcblx0JyNGRjMzNjYnLFxuXHQnI0ZGMzM5OScsXG5cdCcjRkYzM0NDJyxcblx0JyNGRjMzRkYnLFxuXHQnI0ZGNjYwMCcsXG5cdCcjRkY2NjMzJyxcblx0JyNGRjk5MDAnLFxuXHQnI0ZGOTkzMycsXG5cdCcjRkZDQzAwJyxcblx0JyNGRkNDMzMnXG5dO1xuXG4vKipcbiAqIEN1cnJlbnRseSBvbmx5IFdlYktpdC1iYXNlZCBXZWIgSW5zcGVjdG9ycywgRmlyZWZveCA+PSB2MzEsXG4gKiBhbmQgdGhlIEZpcmVidWcgZXh0ZW5zaW9uIChhbnkgRmlyZWZveCB2ZXJzaW9uKSBhcmUga25vd25cbiAqIHRvIHN1cHBvcnQgXCIlY1wiIENTUyBjdXN0b21pemF0aW9ucy5cbiAqXG4gKiBUT0RPOiBhZGQgYSBgbG9jYWxTdG9yYWdlYCB2YXJpYWJsZSB0byBleHBsaWNpdGx5IGVuYWJsZS9kaXNhYmxlIGNvbG9yc1xuICovXG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb21wbGV4aXR5XG5mdW5jdGlvbiB1c2VDb2xvcnMoKSB7XG5cdC8vIE5COiBJbiBhbiBFbGVjdHJvbiBwcmVsb2FkIHNjcmlwdCwgZG9jdW1lbnQgd2lsbCBiZSBkZWZpbmVkIGJ1dCBub3QgZnVsbHlcblx0Ly8gaW5pdGlhbGl6ZWQuIFNpbmNlIHdlIGtub3cgd2UncmUgaW4gQ2hyb21lLCB3ZSdsbCBqdXN0IGRldGVjdCB0aGlzIGNhc2Vcblx0Ly8gZXhwbGljaXRseVxuXHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LnByb2Nlc3MgJiYgKHdpbmRvdy5wcm9jZXNzLnR5cGUgPT09ICdyZW5kZXJlcicgfHwgd2luZG93LnByb2Nlc3MuX19ud2pzKSkge1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cblx0Ly8gSW50ZXJuZXQgRXhwbG9yZXIgYW5kIEVkZ2UgZG8gbm90IHN1cHBvcnQgY29sb3JzLlxuXHRpZiAodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudCAmJiBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkubWF0Y2goLyhlZGdlfHRyaWRlbnQpXFwvKFxcZCspLykpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblxuXHRsZXQgbTtcblxuXHQvLyBJcyB3ZWJraXQ/IGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzE2NDU5NjA2LzM3Njc3M1xuXHQvLyBkb2N1bWVudCBpcyB1bmRlZmluZWQgaW4gcmVhY3QtbmF0aXZlOiBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QtbmF0aXZlL3B1bGwvMTYzMlxuXHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmV0dXJuLWFzc2lnblxuXHRyZXR1cm4gKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50ICYmIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZSAmJiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc3R5bGUuV2Via2l0QXBwZWFyYW5jZSkgfHxcblx0XHQvLyBJcyBmaXJlYnVnPyBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8zOTgxMjAvMzc2NzczXG5cdFx0KHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5jb25zb2xlICYmICh3aW5kb3cuY29uc29sZS5maXJlYnVnIHx8ICh3aW5kb3cuY29uc29sZS5leGNlcHRpb24gJiYgd2luZG93LmNvbnNvbGUudGFibGUpKSkgfHxcblx0XHQvLyBJcyBmaXJlZm94ID49IHYzMT9cblx0XHQvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1Rvb2xzL1dlYl9Db25zb2xlI1N0eWxpbmdfbWVzc2FnZXNcblx0XHQodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudCAmJiAobSA9IG5hdmlnYXRvci51c2VyQWdlbnQudG9Mb3dlckNhc2UoKS5tYXRjaCgvZmlyZWZveFxcLyhcXGQrKS8pKSAmJiBwYXJzZUludChtWzFdLCAxMCkgPj0gMzEpIHx8XG5cdFx0Ly8gRG91YmxlIGNoZWNrIHdlYmtpdCBpbiB1c2VyQWdlbnQganVzdCBpbiBjYXNlIHdlIGFyZSBpbiBhIHdvcmtlclxuXHRcdCh0eXBlb2YgbmF2aWdhdG9yICE9PSAndW5kZWZpbmVkJyAmJiBuYXZpZ2F0b3IudXNlckFnZW50ICYmIG5hdmlnYXRvci51c2VyQWdlbnQudG9Mb3dlckNhc2UoKS5tYXRjaCgvYXBwbGV3ZWJraXRcXC8oXFxkKykvKSk7XG59XG5cbi8qKlxuICogQ29sb3JpemUgbG9nIGFyZ3VtZW50cyBpZiBlbmFibGVkLlxuICpcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuZnVuY3Rpb24gZm9ybWF0QXJncyhhcmdzKSB7XG5cdGFyZ3NbMF0gPSAodGhpcy51c2VDb2xvcnMgPyAnJWMnIDogJycpICtcblx0XHR0aGlzLm5hbWVzcGFjZSArXG5cdFx0KHRoaXMudXNlQ29sb3JzID8gJyAlYycgOiAnICcpICtcblx0XHRhcmdzWzBdICtcblx0XHQodGhpcy51c2VDb2xvcnMgPyAnJWMgJyA6ICcgJykgK1xuXHRcdCcrJyArIG1vZHVsZS5leHBvcnRzLmh1bWFuaXplKHRoaXMuZGlmZik7XG5cblx0aWYgKCF0aGlzLnVzZUNvbG9ycykge1xuXHRcdHJldHVybjtcblx0fVxuXG5cdGNvbnN0IGMgPSAnY29sb3I6ICcgKyB0aGlzLmNvbG9yO1xuXHRhcmdzLnNwbGljZSgxLCAwLCBjLCAnY29sb3I6IGluaGVyaXQnKTtcblxuXHQvLyBUaGUgZmluYWwgXCIlY1wiIGlzIHNvbWV3aGF0IHRyaWNreSwgYmVjYXVzZSB0aGVyZSBjb3VsZCBiZSBvdGhlclxuXHQvLyBhcmd1bWVudHMgcGFzc2VkIGVpdGhlciBiZWZvcmUgb3IgYWZ0ZXIgdGhlICVjLCBzbyB3ZSBuZWVkIHRvXG5cdC8vIGZpZ3VyZSBvdXQgdGhlIGNvcnJlY3QgaW5kZXggdG8gaW5zZXJ0IHRoZSBDU1MgaW50b1xuXHRsZXQgaW5kZXggPSAwO1xuXHRsZXQgbGFzdEMgPSAwO1xuXHRhcmdzWzBdLnJlcGxhY2UoLyVbYS16QS1aJV0vZywgbWF0Y2ggPT4ge1xuXHRcdGlmIChtYXRjaCA9PT0gJyUlJykge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpbmRleCsrO1xuXHRcdGlmIChtYXRjaCA9PT0gJyVjJykge1xuXHRcdFx0Ly8gV2Ugb25seSBhcmUgaW50ZXJlc3RlZCBpbiB0aGUgKmxhc3QqICVjXG5cdFx0XHQvLyAodGhlIHVzZXIgbWF5IGhhdmUgcHJvdmlkZWQgdGhlaXIgb3duKVxuXHRcdFx0bGFzdEMgPSBpbmRleDtcblx0XHR9XG5cdH0pO1xuXG5cdGFyZ3Muc3BsaWNlKGxhc3RDLCAwLCBjKTtcbn1cblxuLyoqXG4gKiBJbnZva2VzIGBjb25zb2xlLmRlYnVnKClgIHdoZW4gYXZhaWxhYmxlLlxuICogTm8tb3Agd2hlbiBgY29uc29sZS5kZWJ1Z2AgaXMgbm90IGEgXCJmdW5jdGlvblwiLlxuICogSWYgYGNvbnNvbGUuZGVidWdgIGlzIG5vdCBhdmFpbGFibGUsIGZhbGxzIGJhY2tcbiAqIHRvIGBjb25zb2xlLmxvZ2AuXG4gKlxuICogQGFwaSBwdWJsaWNcbiAqL1xuZXhwb3J0cy5sb2cgPSBjb25zb2xlLmRlYnVnIHx8IGNvbnNvbGUubG9nIHx8ICgoKSA9PiB7fSk7XG5cbi8qKlxuICogU2F2ZSBgbmFtZXNwYWNlc2AuXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IG5hbWVzcGFjZXNcbiAqIEBhcGkgcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBzYXZlKG5hbWVzcGFjZXMpIHtcblx0dHJ5IHtcblx0XHRpZiAobmFtZXNwYWNlcykge1xuXHRcdFx0ZXhwb3J0cy5zdG9yYWdlLnNldEl0ZW0oJ2RlYnVnJywgbmFtZXNwYWNlcyk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGV4cG9ydHMuc3RvcmFnZS5yZW1vdmVJdGVtKCdkZWJ1ZycpO1xuXHRcdH1cblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHQvLyBTd2FsbG93XG5cdFx0Ly8gWFhYIChAUWl4LSkgc2hvdWxkIHdlIGJlIGxvZ2dpbmcgdGhlc2U/XG5cdH1cbn1cblxuLyoqXG4gKiBMb2FkIGBuYW1lc3BhY2VzYC5cbiAqXG4gKiBAcmV0dXJuIHtTdHJpbmd9IHJldHVybnMgdGhlIHByZXZpb3VzbHkgcGVyc2lzdGVkIGRlYnVnIG1vZGVzXG4gKiBAYXBpIHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gbG9hZCgpIHtcblx0bGV0IHI7XG5cdHRyeSB7XG5cdFx0ciA9IGV4cG9ydHMuc3RvcmFnZS5nZXRJdGVtKCdkZWJ1ZycpIHx8IGV4cG9ydHMuc3RvcmFnZS5nZXRJdGVtKCdERUJVRycpIDtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHQvLyBTd2FsbG93XG5cdFx0Ly8gWFhYIChAUWl4LSkgc2hvdWxkIHdlIGJlIGxvZ2dpbmcgdGhlc2U/XG5cdH1cblxuXHQvLyBJZiBkZWJ1ZyBpc24ndCBzZXQgaW4gTFMsIGFuZCB3ZSdyZSBpbiBFbGVjdHJvbiwgdHJ5IHRvIGxvYWQgJERFQlVHXG5cdGlmICghciAmJiB0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiYgJ2VudicgaW4gcHJvY2Vzcykge1xuXHRcdHIgPSBwcm9jZXNzLmVudi5ERUJVRztcblx0fVxuXG5cdHJldHVybiByO1xufVxuXG4vKipcbiAqIExvY2Fsc3RvcmFnZSBhdHRlbXB0cyB0byByZXR1cm4gdGhlIGxvY2Fsc3RvcmFnZS5cbiAqXG4gKiBUaGlzIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIHNhZmFyaSB0aHJvd3NcbiAqIHdoZW4gYSB1c2VyIGRpc2FibGVzIGNvb2tpZXMvbG9jYWxzdG9yYWdlXG4gKiBhbmQgeW91IGF0dGVtcHQgdG8gYWNjZXNzIGl0LlxuICpcbiAqIEByZXR1cm4ge0xvY2FsU3RvcmFnZX1cbiAqIEBhcGkgcHJpdmF0ZVxuICovXG5cbmZ1bmN0aW9uIGxvY2Fsc3RvcmFnZSgpIHtcblx0dHJ5IHtcblx0XHQvLyBUVk1MS2l0IChBcHBsZSBUViBKUyBSdW50aW1lKSBkb2VzIG5vdCBoYXZlIGEgd2luZG93IG9iamVjdCwganVzdCBsb2NhbFN0b3JhZ2UgaW4gdGhlIGdsb2JhbCBjb250ZXh0XG5cdFx0Ly8gVGhlIEJyb3dzZXIgYWxzbyBoYXMgbG9jYWxTdG9yYWdlIGluIHRoZSBnbG9iYWwgY29udGV4dC5cblx0XHRyZXR1cm4gbG9jYWxTdG9yYWdlO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdC8vIFN3YWxsb3dcblx0XHQvLyBYWFggKEBRaXgtKSBzaG91bGQgd2UgYmUgbG9nZ2luZyB0aGVzZT9cblx0fVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY29tbW9uJykoZXhwb3J0cyk7XG5cbmNvbnN0IHtmb3JtYXR0ZXJzfSA9IG1vZHVsZS5leHBvcnRzO1xuXG4vKipcbiAqIE1hcCAlaiB0byBgSlNPTi5zdHJpbmdpZnkoKWAsIHNpbmNlIG5vIFdlYiBJbnNwZWN0b3JzIGRvIHRoYXQgYnkgZGVmYXVsdC5cbiAqL1xuXG5mb3JtYXR0ZXJzLmogPSBmdW5jdGlvbiAodikge1xuXHR0cnkge1xuXHRcdHJldHVybiBKU09OLnN0cmluZ2lmeSh2KTtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4gJ1tVbmV4cGVjdGVkSlNPTlBhcnNlRXJyb3JdOiAnICsgZXJyb3IubWVzc2FnZTtcblx0fVxufTtcbiIsIi8qISBpZWVlNzU0LiBCU0QtMy1DbGF1c2UgTGljZW5zZS4gRmVyb3NzIEFib3VraGFkaWplaCA8aHR0cHM6Ly9mZXJvc3Mub3JnL29wZW5zb3VyY2U+ICovXG5leHBvcnRzLnJlYWQgPSBmdW5jdGlvbiAoYnVmZmVyLCBvZmZzZXQsIGlzTEUsIG1MZW4sIG5CeXRlcykge1xuICB2YXIgZSwgbVxuICB2YXIgZUxlbiA9IChuQnl0ZXMgKiA4KSAtIG1MZW4gLSAxXG4gIHZhciBlTWF4ID0gKDEgPDwgZUxlbikgLSAxXG4gIHZhciBlQmlhcyA9IGVNYXggPj4gMVxuICB2YXIgbkJpdHMgPSAtN1xuICB2YXIgaSA9IGlzTEUgPyAobkJ5dGVzIC0gMSkgOiAwXG4gIHZhciBkID0gaXNMRSA/IC0xIDogMVxuICB2YXIgcyA9IGJ1ZmZlcltvZmZzZXQgKyBpXVxuXG4gIGkgKz0gZFxuXG4gIGUgPSBzICYgKCgxIDw8ICgtbkJpdHMpKSAtIDEpXG4gIHMgPj49ICgtbkJpdHMpXG4gIG5CaXRzICs9IGVMZW5cbiAgZm9yICg7IG5CaXRzID4gMDsgZSA9IChlICogMjU2KSArIGJ1ZmZlcltvZmZzZXQgKyBpXSwgaSArPSBkLCBuQml0cyAtPSA4KSB7fVxuXG4gIG0gPSBlICYgKCgxIDw8ICgtbkJpdHMpKSAtIDEpXG4gIGUgPj49ICgtbkJpdHMpXG4gIG5CaXRzICs9IG1MZW5cbiAgZm9yICg7IG5CaXRzID4gMDsgbSA9IChtICogMjU2KSArIGJ1ZmZlcltvZmZzZXQgKyBpXSwgaSArPSBkLCBuQml0cyAtPSA4KSB7fVxuXG4gIGlmIChlID09PSAwKSB7XG4gICAgZSA9IDEgLSBlQmlhc1xuICB9IGVsc2UgaWYgKGUgPT09IGVNYXgpIHtcbiAgICByZXR1cm4gbSA/IE5hTiA6ICgocyA/IC0xIDogMSkgKiBJbmZpbml0eSlcbiAgfSBlbHNlIHtcbiAgICBtID0gbSArIE1hdGgucG93KDIsIG1MZW4pXG4gICAgZSA9IGUgLSBlQmlhc1xuICB9XG4gIHJldHVybiAocyA/IC0xIDogMSkgKiBtICogTWF0aC5wb3coMiwgZSAtIG1MZW4pXG59XG5cbmV4cG9ydHMud3JpdGUgPSBmdW5jdGlvbiAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0LCBpc0xFLCBtTGVuLCBuQnl0ZXMpIHtcbiAgdmFyIGUsIG0sIGNcbiAgdmFyIGVMZW4gPSAobkJ5dGVzICogOCkgLSBtTGVuIC0gMVxuICB2YXIgZU1heCA9ICgxIDw8IGVMZW4pIC0gMVxuICB2YXIgZUJpYXMgPSBlTWF4ID4+IDFcbiAgdmFyIHJ0ID0gKG1MZW4gPT09IDIzID8gTWF0aC5wb3coMiwgLTI0KSAtIE1hdGgucG93KDIsIC03NykgOiAwKVxuICB2YXIgaSA9IGlzTEUgPyAwIDogKG5CeXRlcyAtIDEpXG4gIHZhciBkID0gaXNMRSA/IDEgOiAtMVxuICB2YXIgcyA9IHZhbHVlIDwgMCB8fCAodmFsdWUgPT09IDAgJiYgMSAvIHZhbHVlIDwgMCkgPyAxIDogMFxuXG4gIHZhbHVlID0gTWF0aC5hYnModmFsdWUpXG5cbiAgaWYgKGlzTmFOKHZhbHVlKSB8fCB2YWx1ZSA9PT0gSW5maW5pdHkpIHtcbiAgICBtID0gaXNOYU4odmFsdWUpID8gMSA6IDBcbiAgICBlID0gZU1heFxuICB9IGVsc2Uge1xuICAgIGUgPSBNYXRoLmZsb29yKE1hdGgubG9nKHZhbHVlKSAvIE1hdGguTE4yKVxuICAgIGlmICh2YWx1ZSAqIChjID0gTWF0aC5wb3coMiwgLWUpKSA8IDEpIHtcbiAgICAgIGUtLVxuICAgICAgYyAqPSAyXG4gICAgfVxuICAgIGlmIChlICsgZUJpYXMgPj0gMSkge1xuICAgICAgdmFsdWUgKz0gcnQgLyBjXG4gICAgfSBlbHNlIHtcbiAgICAgIHZhbHVlICs9IHJ0ICogTWF0aC5wb3coMiwgMSAtIGVCaWFzKVxuICAgIH1cbiAgICBpZiAodmFsdWUgKiBjID49IDIpIHtcbiAgICAgIGUrK1xuICAgICAgYyAvPSAyXG4gICAgfVxuXG4gICAgaWYgKGUgKyBlQmlhcyA+PSBlTWF4KSB7XG4gICAgICBtID0gMFxuICAgICAgZSA9IGVNYXhcbiAgICB9IGVsc2UgaWYgKGUgKyBlQmlhcyA+PSAxKSB7XG4gICAgICBtID0gKCh2YWx1ZSAqIGMpIC0gMSkgKiBNYXRoLnBvdygyLCBtTGVuKVxuICAgICAgZSA9IGUgKyBlQmlhc1xuICAgIH0gZWxzZSB7XG4gICAgICBtID0gdmFsdWUgKiBNYXRoLnBvdygyLCBlQmlhcyAtIDEpICogTWF0aC5wb3coMiwgbUxlbilcbiAgICAgIGUgPSAwXG4gICAgfVxuICB9XG5cbiAgZm9yICg7IG1MZW4gPj0gODsgYnVmZmVyW29mZnNldCArIGldID0gbSAmIDB4ZmYsIGkgKz0gZCwgbSAvPSAyNTYsIG1MZW4gLT0gOCkge31cblxuICBlID0gKGUgPDwgbUxlbikgfCBtXG4gIGVMZW4gKz0gbUxlblxuICBmb3IgKDsgZUxlbiA+IDA7IGJ1ZmZlcltvZmZzZXQgKyBpXSA9IGUgJiAweGZmLCBpICs9IGQsIGUgLz0gMjU2LCBlTGVuIC09IDgpIHt9XG5cbiAgYnVmZmVyW29mZnNldCArIGkgLSBkXSB8PSBzICogMTI4XG59XG4iLCJpbXBvcnQgKiBhcyBpZWVlNzU0IGZyb20gJ2llZWU3NTQnO1xuaW1wb3J0IHsgdGV4dERlY29kZSB9IGZyb20gXCJAYm9yZXdpdC90ZXh0LWNvZGVjXCI7XG4vLyBQcmltaXRpdmUgdHlwZXNcbmZ1bmN0aW9uIGR2KGFycmF5KSB7XG4gICAgcmV0dXJuIG5ldyBEYXRhVmlldyhhcnJheS5idWZmZXIsIGFycmF5LmJ5dGVPZmZzZXQpO1xufVxuLypcbiAqIDgtYml0IHVuc2lnbmVkIGludGVnZXJcbiAqL1xuZXhwb3J0IGNvbnN0IFVJTlQ4ID0ge1xuICAgIGxlbjogMSxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldFVpbnQ4KG9mZnNldCk7XG4gICAgfSxcbiAgICBwdXQoYXJyYXksIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgZHYoYXJyYXkpLnNldFVpbnQ4KG9mZnNldCwgdmFsdWUpO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgMTtcbiAgICB9XG59O1xuLyoqXG4gKiAxNi1iaXQgdW5zaWduZWQgaW50ZWdlciwgTGl0dGxlIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBVSU5UMTZfTEUgPSB7XG4gICAgbGVuOiAyLFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0VWludDE2KG9mZnNldCwgdHJ1ZSk7XG4gICAgfSxcbiAgICBwdXQoYXJyYXksIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgZHYoYXJyYXkpLnNldFVpbnQxNihvZmZzZXQsIHZhbHVlLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDI7XG4gICAgfVxufTtcbi8qKlxuICogMTYtYml0IHVuc2lnbmVkIGludGVnZXIsIEJpZyBFbmRpYW4gYnl0ZSBvcmRlclxuICovXG5leHBvcnQgY29uc3QgVUlOVDE2X0JFID0ge1xuICAgIGxlbjogMixcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldFVpbnQxNihvZmZzZXQpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRVaW50MTYob2Zmc2V0LCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyAyO1xuICAgIH1cbn07XG4vKipcbiAqIDI0LWJpdCB1bnNpZ25lZCBpbnRlZ2VyLCBMaXR0bGUgRW5kaWFuIGJ5dGUgb3JkZXJcbiAqL1xuZXhwb3J0IGNvbnN0IFVJTlQyNF9MRSA9IHtcbiAgICBsZW46IDMsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgY29uc3QgZGF0YVZpZXcgPSBkdihhcnJheSk7XG4gICAgICAgIHJldHVybiBkYXRhVmlldy5nZXRVaW50OChvZmZzZXQpICsgKGRhdGFWaWV3LmdldFVpbnQxNihvZmZzZXQgKyAxLCB0cnVlKSA8PCA4KTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBkYXRhVmlldyA9IGR2KGFycmF5KTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDgob2Zmc2V0LCB2YWx1ZSAmIDB4ZmYpO1xuICAgICAgICBkYXRhVmlldy5zZXRVaW50MTYob2Zmc2V0ICsgMSwgdmFsdWUgPj4gOCwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyAzO1xuICAgIH1cbn07XG4vKipcbiAqIDI0LWJpdCB1bnNpZ25lZCBpbnRlZ2VyLCBCaWcgRW5kaWFuIGJ5dGUgb3JkZXJcbiAqL1xuZXhwb3J0IGNvbnN0IFVJTlQyNF9CRSA9IHtcbiAgICBsZW46IDMsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgY29uc3QgZGF0YVZpZXcgPSBkdihhcnJheSk7XG4gICAgICAgIHJldHVybiAoZGF0YVZpZXcuZ2V0VWludDE2KG9mZnNldCkgPDwgOCkgKyBkYXRhVmlldy5nZXRVaW50OChvZmZzZXQgKyAyKTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBkYXRhVmlldyA9IGR2KGFycmF5KTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDE2KG9mZnNldCwgdmFsdWUgPj4gOCk7XG4gICAgICAgIGRhdGFWaWV3LnNldFVpbnQ4KG9mZnNldCArIDIsIHZhbHVlICYgMHhmZik7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyAzO1xuICAgIH1cbn07XG4vKipcbiAqIDMyLWJpdCB1bnNpZ25lZCBpbnRlZ2VyLCBMaXR0bGUgRW5kaWFuIGJ5dGUgb3JkZXJcbiAqL1xuZXhwb3J0IGNvbnN0IFVJTlQzMl9MRSA9IHtcbiAgICBsZW46IDQsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRVaW50MzIob2Zmc2V0LCB0cnVlKTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBkdihhcnJheSkuc2V0VWludDMyKG9mZnNldCwgdmFsdWUsIHRydWUpO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgNDtcbiAgICB9XG59O1xuLyoqXG4gKiAzMi1iaXQgdW5zaWduZWQgaW50ZWdlciwgQmlnIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBVSU5UMzJfQkUgPSB7XG4gICAgbGVuOiA0LFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0VWludDMyKG9mZnNldCk7XG4gICAgfSxcbiAgICBwdXQoYXJyYXksIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgZHYoYXJyYXkpLnNldFVpbnQzMihvZmZzZXQsIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDQ7XG4gICAgfVxufTtcbi8qKlxuICogOC1iaXQgc2lnbmVkIGludGVnZXJcbiAqL1xuZXhwb3J0IGNvbnN0IElOVDggPSB7XG4gICAgbGVuOiAxLFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0SW50OChvZmZzZXQpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRJbnQ4KG9mZnNldCwgdmFsdWUpO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgMTtcbiAgICB9XG59O1xuLyoqXG4gKiAxNi1iaXQgc2lnbmVkIGludGVnZXIsIEJpZyBFbmRpYW4gYnl0ZSBvcmRlclxuICovXG5leHBvcnQgY29uc3QgSU5UMTZfQkUgPSB7XG4gICAgbGVuOiAyLFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0SW50MTYob2Zmc2V0KTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBkdihhcnJheSkuc2V0SW50MTYob2Zmc2V0LCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyAyO1xuICAgIH1cbn07XG4vKipcbiAqIDE2LWJpdCBzaWduZWQgaW50ZWdlciwgTGl0dGxlIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBJTlQxNl9MRSA9IHtcbiAgICBsZW46IDIsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRJbnQxNihvZmZzZXQsIHRydWUpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRJbnQxNihvZmZzZXQsIHZhbHVlLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDI7XG4gICAgfVxufTtcbi8qKlxuICogMjQtYml0IHNpZ25lZCBpbnRlZ2VyLCBMaXR0bGUgRW5kaWFuIGJ5dGUgb3JkZXJcbiAqL1xuZXhwb3J0IGNvbnN0IElOVDI0X0xFID0ge1xuICAgIGxlbjogMyxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICBjb25zdCB1bnNpZ25lZCA9IFVJTlQyNF9MRS5nZXQoYXJyYXksIG9mZnNldCk7XG4gICAgICAgIHJldHVybiB1bnNpZ25lZCA+IDB4N2ZmZmZmID8gdW5zaWduZWQgLSAweDEwMDAwMDAgOiB1bnNpZ25lZDtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBkYXRhVmlldyA9IGR2KGFycmF5KTtcbiAgICAgICAgZGF0YVZpZXcuc2V0VWludDgob2Zmc2V0LCB2YWx1ZSAmIDB4ZmYpO1xuICAgICAgICBkYXRhVmlldy5zZXRVaW50MTYob2Zmc2V0ICsgMSwgdmFsdWUgPj4gOCwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyAzO1xuICAgIH1cbn07XG4vKipcbiAqIDI0LWJpdCBzaWduZWQgaW50ZWdlciwgQmlnIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBJTlQyNF9CRSA9IHtcbiAgICBsZW46IDMsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgY29uc3QgdW5zaWduZWQgPSBVSU5UMjRfQkUuZ2V0KGFycmF5LCBvZmZzZXQpO1xuICAgICAgICByZXR1cm4gdW5zaWduZWQgPiAweDdmZmZmZiA/IHVuc2lnbmVkIC0gMHgxMDAwMDAwIDogdW5zaWduZWQ7XG4gICAgfSxcbiAgICBwdXQoYXJyYXksIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgZGF0YVZpZXcgPSBkdihhcnJheSk7XG4gICAgICAgIGRhdGFWaWV3LnNldFVpbnQxNihvZmZzZXQsIHZhbHVlID4+IDgpO1xuICAgICAgICBkYXRhVmlldy5zZXRVaW50OChvZmZzZXQgKyAyLCB2YWx1ZSAmIDB4ZmYpO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgMztcbiAgICB9XG59O1xuLyoqXG4gKiAzMi1iaXQgc2lnbmVkIGludGVnZXIsIEJpZyBFbmRpYW4gYnl0ZSBvcmRlclxuICovXG5leHBvcnQgY29uc3QgSU5UMzJfQkUgPSB7XG4gICAgbGVuOiA0LFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0SW50MzIob2Zmc2V0KTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBkdihhcnJheSkuc2V0SW50MzIob2Zmc2V0LCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyA0O1xuICAgIH1cbn07XG4vKipcbiAqIDMyLWJpdCBzaWduZWQgaW50ZWdlciwgQmlnIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBJTlQzMl9MRSA9IHtcbiAgICBsZW46IDQsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRJbnQzMihvZmZzZXQsIHRydWUpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRJbnQzMihvZmZzZXQsIHZhbHVlLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDQ7XG4gICAgfVxufTtcbi8qKlxuICogNjQtYml0IHVuc2lnbmVkIGludGVnZXIsIExpdHRsZSBFbmRpYW4gYnl0ZSBvcmRlclxuICovXG5leHBvcnQgY29uc3QgVUlOVDY0X0xFID0ge1xuICAgIGxlbjogOCxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldEJpZ1VpbnQ2NChvZmZzZXQsIHRydWUpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRCaWdVaW50NjQob2Zmc2V0LCB2YWx1ZSwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyA4O1xuICAgIH1cbn07XG4vKipcbiAqIDY0LWJpdCBzaWduZWQgaW50ZWdlciwgTGl0dGxlIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBJTlQ2NF9MRSA9IHtcbiAgICBsZW46IDgsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRCaWdJbnQ2NChvZmZzZXQsIHRydWUpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRCaWdJbnQ2NChvZmZzZXQsIHZhbHVlLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDg7XG4gICAgfVxufTtcbi8qKlxuICogNjQtYml0IHVuc2lnbmVkIGludGVnZXIsIEJpZyBFbmRpYW4gYnl0ZSBvcmRlclxuICovXG5leHBvcnQgY29uc3QgVUlOVDY0X0JFID0ge1xuICAgIGxlbjogOCxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldEJpZ1VpbnQ2NChvZmZzZXQpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRCaWdVaW50NjQob2Zmc2V0LCB2YWx1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyA4O1xuICAgIH1cbn07XG4vKipcbiAqIDY0LWJpdCBzaWduZWQgaW50ZWdlciwgQmlnIEVuZGlhbiBieXRlIG9yZGVyXG4gKi9cbmV4cG9ydCBjb25zdCBJTlQ2NF9CRSA9IHtcbiAgICBsZW46IDgsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRCaWdJbnQ2NChvZmZzZXQpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRCaWdJbnQ2NChvZmZzZXQsIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDg7XG4gICAgfVxufTtcbi8qKlxuICogSUVFRSA3NTQgMTYtYml0IChoYWxmIHByZWNpc2lvbikgZmxvYXQsIGJpZyBlbmRpYW5cbiAqL1xuZXhwb3J0IGNvbnN0IEZsb2F0MTZfQkUgPSB7XG4gICAgbGVuOiAyLFxuICAgIGdldChkYXRhVmlldywgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBpZWVlNzU0LnJlYWQoZGF0YVZpZXcsIG9mZnNldCwgZmFsc2UsIDEwLCB0aGlzLmxlbik7XG4gICAgfSxcbiAgICBwdXQoZGF0YVZpZXcsIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgaWVlZTc1NC53cml0ZShkYXRhVmlldywgdmFsdWUsIG9mZnNldCwgZmFsc2UsIDEwLCB0aGlzLmxlbik7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyB0aGlzLmxlbjtcbiAgICB9XG59O1xuLyoqXG4gKiBJRUVFIDc1NCAxNi1iaXQgKGhhbGYgcHJlY2lzaW9uKSBmbG9hdCwgbGl0dGxlIGVuZGlhblxuICovXG5leHBvcnQgY29uc3QgRmxvYXQxNl9MRSA9IHtcbiAgICBsZW46IDIsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGllZWU3NTQucmVhZChhcnJheSwgb2Zmc2V0LCB0cnVlLCAxMCwgdGhpcy5sZW4pO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGllZWU3NTQud3JpdGUoYXJyYXksIHZhbHVlLCBvZmZzZXQsIHRydWUsIDEwLCB0aGlzLmxlbik7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyB0aGlzLmxlbjtcbiAgICB9XG59O1xuLyoqXG4gKiBJRUVFIDc1NCAzMi1iaXQgKHNpbmdsZSBwcmVjaXNpb24pIGZsb2F0LCBiaWcgZW5kaWFuXG4gKi9cbmV4cG9ydCBjb25zdCBGbG9hdDMyX0JFID0ge1xuICAgIGxlbjogNCxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldEZsb2F0MzIob2Zmc2V0KTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBkdihhcnJheSkuc2V0RmxvYXQzMihvZmZzZXQsIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDQ7XG4gICAgfVxufTtcbi8qKlxuICogSUVFRSA3NTQgMzItYml0IChzaW5nbGUgcHJlY2lzaW9uKSBmbG9hdCwgbGl0dGxlIGVuZGlhblxuICovXG5leHBvcnQgY29uc3QgRmxvYXQzMl9MRSA9IHtcbiAgICBsZW46IDQsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGR2KGFycmF5KS5nZXRGbG9hdDMyKG9mZnNldCwgdHJ1ZSk7XG4gICAgfSxcbiAgICBwdXQoYXJyYXksIG9mZnNldCwgdmFsdWUpIHtcbiAgICAgICAgZHYoYXJyYXkpLnNldEZsb2F0MzIob2Zmc2V0LCB2YWx1ZSwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiBvZmZzZXQgKyA0O1xuICAgIH1cbn07XG4vKipcbiAqIElFRUUgNzU0IDY0LWJpdCAoZG91YmxlIHByZWNpc2lvbikgZmxvYXQsIGJpZyBlbmRpYW5cbiAqL1xuZXhwb3J0IGNvbnN0IEZsb2F0NjRfQkUgPSB7XG4gICAgbGVuOiA4LFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBkdihhcnJheSkuZ2V0RmxvYXQ2NChvZmZzZXQpO1xuICAgIH0sXG4gICAgcHV0KGFycmF5LCBvZmZzZXQsIHZhbHVlKSB7XG4gICAgICAgIGR2KGFycmF5KS5zZXRGbG9hdDY0KG9mZnNldCwgdmFsdWUpO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgODtcbiAgICB9XG59O1xuLyoqXG4gKiBJRUVFIDc1NCA2NC1iaXQgKGRvdWJsZSBwcmVjaXNpb24pIGZsb2F0LCBsaXR0bGUgZW5kaWFuXG4gKi9cbmV4cG9ydCBjb25zdCBGbG9hdDY0X0xFID0ge1xuICAgIGxlbjogOCxcbiAgICBnZXQoYXJyYXksIG9mZnNldCkge1xuICAgICAgICByZXR1cm4gZHYoYXJyYXkpLmdldEZsb2F0NjQob2Zmc2V0LCB0cnVlKTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBkdihhcnJheSkuc2V0RmxvYXQ2NChvZmZzZXQsIHZhbHVlLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIDg7XG4gICAgfVxufTtcbi8qKlxuICogSUVFRSA3NTQgODAtYml0IChleHRlbmRlZCBwcmVjaXNpb24pIGZsb2F0LCBiaWcgZW5kaWFuXG4gKi9cbmV4cG9ydCBjb25zdCBGbG9hdDgwX0JFID0ge1xuICAgIGxlbjogMTAsXG4gICAgZ2V0KGFycmF5LCBvZmZzZXQpIHtcbiAgICAgICAgcmV0dXJuIGllZWU3NTQucmVhZChhcnJheSwgb2Zmc2V0LCBmYWxzZSwgNjMsIHRoaXMubGVuKTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBpZWVlNzU0LndyaXRlKGFycmF5LCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgNjMsIHRoaXMubGVuKTtcbiAgICAgICAgcmV0dXJuIG9mZnNldCArIHRoaXMubGVuO1xuICAgIH1cbn07XG4vKipcbiAqIElFRUUgNzU0IDgwLWJpdCAoZXh0ZW5kZWQgcHJlY2lzaW9uKSBmbG9hdCwgbGl0dGxlIGVuZGlhblxuICovXG5leHBvcnQgY29uc3QgRmxvYXQ4MF9MRSA9IHtcbiAgICBsZW46IDEwLFxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBpZWVlNzU0LnJlYWQoYXJyYXksIG9mZnNldCwgdHJ1ZSwgNjMsIHRoaXMubGVuKTtcbiAgICB9LFxuICAgIHB1dChhcnJheSwgb2Zmc2V0LCB2YWx1ZSkge1xuICAgICAgICBpZWVlNzU0LndyaXRlKGFycmF5LCB2YWx1ZSwgb2Zmc2V0LCB0cnVlLCA2MywgdGhpcy5sZW4pO1xuICAgICAgICByZXR1cm4gb2Zmc2V0ICsgdGhpcy5sZW47XG4gICAgfVxufTtcbi8qKlxuICogSWdub3JlIGEgZ2l2ZW4gbnVtYmVyIG9mIGJ5dGVzXG4gKi9cbmV4cG9ydCBjbGFzcyBJZ25vcmVUeXBlIHtcbiAgICAvKipcbiAgICAgKiBAcGFyYW0gbGVuIG51bWJlciBvZiBieXRlcyB0byBpZ25vcmVcbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihsZW4pIHtcbiAgICAgICAgdGhpcy5sZW4gPSBsZW47XG4gICAgfVxuICAgIC8vIFRvRG86IGRvbid0IHJlYWQsIGJ1dCBza2lwIGRhdGFcbiAgICBnZXQoX2FycmF5LCBfb2ZmKSB7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIFVpbnQ4QXJyYXlUeXBlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW4pIHtcbiAgICAgICAgdGhpcy5sZW4gPSBsZW47XG4gICAgfVxuICAgIGdldChhcnJheSwgb2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5zdWJhcnJheShvZmZzZXQsIG9mZnNldCArIHRoaXMubGVuKTtcbiAgICB9XG59XG4vKipcbiAqIENvbnN1bWUgYSBmaXhlZCBudW1iZXIgb2YgYnl0ZXMgZnJvbSB0aGUgc3RyZWFtIGFuZCByZXR1cm4gYSBzdHJpbmcgd2l0aCBhIHNwZWNpZmllZCBlbmNvZGluZy5cbiAqIFN1cHBvcnRzIGFsbCBlbmNvZGluZ3Mgc3VwcG9ydGVkIGJ5IFRleHREZWNvZGVyLCBwbHVzICd3aW5kb3dzLTEyNTInLlxuICovXG5leHBvcnQgY2xhc3MgU3RyaW5nVHlwZSB7XG4gICAgY29uc3RydWN0b3IobGVuLCBlbmNvZGluZykge1xuICAgICAgICB0aGlzLmxlbiA9IGxlbjtcbiAgICAgICAgdGhpcy5lbmNvZGluZyA9IGVuY29kaW5nO1xuICAgIH1cbiAgICBnZXQoZGF0YSwgb2Zmc2V0ID0gMCkge1xuICAgICAgICBjb25zdCBieXRlcyA9IGRhdGEuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyB0aGlzLmxlbik7XG4gICAgICAgIHJldHVybiB0ZXh0RGVjb2RlKGJ5dGVzLCB0aGlzLmVuY29kaW5nKTtcbiAgICB9XG59XG4vKipcbiAqIEFOU0kgTGF0aW4gMSBTdHJpbmcgdXNpbmcgV2luZG93cy0xMjUyIChDb2RlIFBhZ2UgMTI1MilcbiAqIFdpbmRvd3MtMTI1MiBpcyBhIHN1cGVyc2V0IG9mIElTTyA4ODU5LTEgLyBMYXRpbi0xLlxuICovXG5leHBvcnQgY2xhc3MgQW5zaVN0cmluZ1R5cGUgZXh0ZW5kcyBTdHJpbmdUeXBlIHtcbiAgICBjb25zdHJ1Y3RvcihsZW4pIHtcbiAgICAgICAgc3VwZXIobGVuLCAnd2luZG93cy0xMjUyJyk7XG4gICAgfVxufVxuIiwiZXhwb3J0IGNvbnN0IG1ha2VQYXJzZUVycm9yID0gKG5hbWUpID0+IHtcbiAgICByZXR1cm4gY2xhc3MgUGFyc2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICAgICAgbmFtZTtcbiAgICAgICAgY29uc3RydWN0b3IobWVzc2FnZSkge1xuICAgICAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICB9XG4gICAgfTtcbn07XG4vLyBDb25jcmV0ZSBlcnJvciBjbGFzcyByZXByZXNlbnRpbmcgYSBmaWxlIHR5cGUgZGV0ZXJtaW5hdGlvbiBmYWlsdXJlLlxuZXhwb3J0IGNsYXNzIENvdWxkTm90RGV0ZXJtaW5lRmlsZVR5cGVFcnJvciBleHRlbmRzIG1ha2VQYXJzZUVycm9yKCdDb3VsZE5vdERldGVybWluZUZpbGVUeXBlRXJyb3InKSB7XG59XG4vLyBDb25jcmV0ZSBlcnJvciBjbGFzcyByZXByZXNlbnRpbmcgYW4gdW5zdXBwb3J0ZWQgZmlsZSB0eXBlLlxuZXhwb3J0IGNsYXNzIFVuc3VwcG9ydGVkRmlsZVR5cGVFcnJvciBleHRlbmRzIG1ha2VQYXJzZUVycm9yKCdVbnN1cHBvcnRlZEZpbGVUeXBlRXJyb3InKSB7XG59XG4vLyBDb25jcmV0ZSBlcnJvciBjbGFzcyByZXByZXNlbnRpbmcgdW5leHBlY3RlZCBmaWxlIGNvbnRlbnQuXG5leHBvcnQgY2xhc3MgVW5leHBlY3RlZEZpbGVDb250ZW50RXJyb3IgZXh0ZW5kcyBtYWtlUGFyc2VFcnJvcignVW5leHBlY3RlZEZpbGVDb250ZW50RXJyb3InKSB7XG4gICAgZmlsZVR5cGU7XG4gICAgY29uc3RydWN0b3IoZmlsZVR5cGUsIG1lc3NhZ2UpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMuZmlsZVR5cGUgPSBmaWxlVHlwZTtcbiAgICB9XG4gICAgLy8gT3ZlcnJpZGUgdG9TdHJpbmcgdG8gaW5jbHVkZSBmaWxlIHR5cGUgaW5mb3JtYXRpb24uXG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIHJldHVybiBgJHt0aGlzLm5hbWV9IChGaWxlVHlwZTogJHt0aGlzLmZpbGVUeXBlfSk6ICR7dGhpcy5tZXNzYWdlfWA7XG4gICAgfVxufVxuLy8gQ29uY3JldGUgZXJyb3IgY2xhc3MgcmVwcmVzZW50aW5nIGEgZmllbGQgZGVjb2RpbmcgZXJyb3IuXG5leHBvcnQgY2xhc3MgRmllbGREZWNvZGluZ0Vycm9yIGV4dGVuZHMgbWFrZVBhcnNlRXJyb3IoJ0ZpZWxkRGVjb2RpbmdFcnJvcicpIHtcbn1cbmV4cG9ydCBjbGFzcyBJbnRlcm5hbFBhcnNlckVycm9yIGV4dGVuZHMgbWFrZVBhcnNlRXJyb3IoJ0ludGVybmFsUGFyc2VyRXJyb3InKSB7XG59XG4vLyBGYWN0b3J5IGZ1bmN0aW9uIHRvIGNyZWF0ZSBhIHNwZWNpZmljIHR5cGUgb2YgVW5leHBlY3RlZEZpbGVDb250ZW50RXJyb3IuXG5leHBvcnQgY29uc3QgbWFrZVVuZXhwZWN0ZWRGaWxlQ29udGVudEVycm9yID0gKGZpbGVUeXBlKSA9PiB7XG4gICAgcmV0dXJuIGNsYXNzIGV4dGVuZHMgVW5leHBlY3RlZEZpbGVDb250ZW50RXJyb3Ige1xuICAgICAgICBjb25zdHJ1Y3RvcihtZXNzYWdlKSB7XG4gICAgICAgICAgICBzdXBlcihmaWxlVHlwZSwgbWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICB9O1xufTtcbiIsImltcG9ydCB7IEVuZE9mU3RyZWFtRXJyb3IsIGlzUmFuZG9tQWNjZXNzVG9rZW5pemVyIH0gZnJvbSAnc3RydG9rMyc7XG5pbXBvcnQgeyBVbmV4cGVjdGVkRmlsZUNvbnRlbnRFcnJvciB9IGZyb20gJy4uL1BhcnNlRXJyb3IuanMnO1xuY29uc3QgZGVmYXVsdE1heE1lbW9yeUFsbG9jYXRpb24gPSA2NCAqIDEwMjQgKiAxMDI0O1xuZXhwb3J0IGNvbnN0IGRlZmF1bHRNYXhNZXRhZGF0YUVudHJpZXMgPSAxMDBfMDAwO1xuZXhwb3J0IGNvbnN0IGRlZmF1bHRNYXhDaGFwdGVyQ291bnQgPSAxXzAwMDtcbmNvbnN0IHJlYWRDaHVua1NpemUgPSA2NCAqIDEwMjQ7XG5jb25zdCBhbGxvY2F0aW9uRXJyb3IgPSBtZXNzYWdlID0+IG5ldyBVbmV4cGVjdGVkRmlsZUNvbnRlbnRFcnJvcignbWV0YWRhdGEnLCBtZXNzYWdlKTtcbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXhNZW1vcnlBbGxvY2F0aW9uKG9wdGlvbnMpIHtcbiAgICBjb25zdCBsaW1pdCA9IG9wdGlvbnMubWF4TWVtb3J5QWxsb2NhdGlvbiA/PyBkZWZhdWx0TWF4TWVtb3J5QWxsb2NhdGlvbjtcbiAgICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKGxpbWl0KSB8fCBsaW1pdCA8PSAwKSB7XG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdtYXhNZW1vcnlBbGxvY2F0aW9uIG11c3QgYmUgYSBwb3NpdGl2ZSBzYWZlIGludGVnZXInKTtcbiAgICB9XG4gICAgcmV0dXJuIGxpbWl0O1xufVxuLyoqIExpbWl0IGVudHJpZXMgaW4gYW4gaW5kaXZpZHVhbCBkZWNvZGVkIGxpc3Qgb3IgdGFibGUsIGluZGVwZW5kZW50bHkgb2YgYnl0ZS1idWZmZXIgbGltaXRzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE1heE1ldGFkYXRhRW50cmllcyhvcHRpb25zKSB7XG4gICAgY29uc3QgbGltaXQgPSBvcHRpb25zLm1heE1ldGFkYXRhRW50cmllcyA/PyBkZWZhdWx0TWF4TWV0YWRhdGFFbnRyaWVzO1xuICAgIGlmICghTnVtYmVyLmlzU2FmZUludGVnZXIobGltaXQpIHx8IGxpbWl0IDw9IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ21heE1ldGFkYXRhRW50cmllcyBtdXN0IGJlIGEgcG9zaXRpdmUgc2FmZSBpbnRlZ2VyJyk7XG4gICAgfVxuICAgIHJldHVybiBsaW1pdDtcbn1cbi8qKiBNYXhpbXVtIGNoYXB0ZXJzIHJldHVybmVkIGJ5IHN1cHBvcnRlZCBjaGFwdGVyIHBhcnNlcnMuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWF4Q2hhcHRlckNvdW50KG9wdGlvbnMpIHtcbiAgICBjb25zdCBsaW1pdCA9IG9wdGlvbnMubWF4Q2hhcHRlckNvdW50ID8/IGRlZmF1bHRNYXhDaGFwdGVyQ291bnQ7XG4gICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihsaW1pdCkgfHwgbGltaXQgPD0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignbWF4Q2hhcHRlckNvdW50IG11c3QgYmUgYSBwb3NpdGl2ZSBzYWZlIGludGVnZXInKTtcbiAgICB9XG4gICAgcmV0dXJuIGxpbWl0O1xufVxuLyoqIENvbmZpZ3VyZSB0aGUgdG9rZW5pemVyIHNhZmV0eSBuZXQgb25jZSwgdXNpbmcgdGhlIHNhbWUgbGltaXQgYXMgcGFyc2VyLW93bmVkIGJ1ZmZlcnMuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9rZW5pemVyT3B0aW9ucyhvcHRpb25zLCBmaWxlSW5mbykge1xuICAgIHJldHVybiB7IG1heEJ1ZmZlclNpemU6IGdldE1heE1lbW9yeUFsbG9jYXRpb24ob3B0aW9ucyksIGZpbGVJbmZvIH07XG59XG4vKiogQ2hlY2sgdW50cnVzdGVkIGxlbmd0aHMgYmVmb3JlIGFsbG9jYXRpbmcsIGluY2x1ZGluZyBhY2N1bXVsYXRlZCBzdHJlYW0gcGF5bG9hZHMuICovXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVBbGxvY2F0aW9uKGxlbmd0aCwgb3B0aW9ucywgbWFrZUVycm9yID0gYWxsb2NhdGlvbkVycm9yKSB7XG4gICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihsZW5ndGgpIHx8IGxlbmd0aCA8IDApIHtcbiAgICAgICAgdGhyb3cgbWFrZUVycm9yKGBJbnZhbGlkIGFsbG9jYXRpb24gc2l6ZTogJHtsZW5ndGh9YCk7XG4gICAgfVxuICAgIGNvbnN0IGxpbWl0ID0gZ2V0TWF4TWVtb3J5QWxsb2NhdGlvbihvcHRpb25zKTtcbiAgICBpZiAobGVuZ3RoID4gbGltaXQpIHtcbiAgICAgICAgdGhyb3cgbWFrZUVycm9yKGBNZXRhZGF0YSBzaXplICR7bGVuZ3RofSBleGNlZWRzIGFsbG9jYXRpb24gbGltaXQgJHtsaW1pdH0gKGJ1ZmZlcmluZyBsaW1pdClgKTtcbiAgICB9XG59XG5mdW5jdGlvbiB2YWxpZGF0ZUF2YWlsYWJsZUJ5dGVzKHRva2VuaXplciwgbGVuZ3RoLCBwb3NpdGlvbikge1xuICAgIGlmICh0b2tlbml6ZXIuZmlsZUluZm8uc2l6ZSAhPT0gdW5kZWZpbmVkICYmIGxlbmd0aCA+IHRva2VuaXplci5maWxlSW5mby5zaXplIC0gcG9zaXRpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVuZE9mU3RyZWFtRXJyb3IoKTtcbiAgICB9XG59XG4vKiogUmVhZCBvbmx5IGJvdW5kZWQgY2h1bmtzIGZyb20gc3RyZWFtczsgYW4gYWR2ZXJ0aXNlZCBzdHJlYW0gc2l6ZSBkb2VzIG5vdCBwcm92ZSBieXRlcyBleGlzdC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWFkQnVmZmVyKHRva2VuaXplciwgbGVuZ3RoLCBvcHRpb25zLCBwb3NpdGlvbiA9IHRva2VuaXplci5wb3NpdGlvbiwgbWFrZUVycm9yID0gYWxsb2NhdGlvbkVycm9yKSB7XG4gICAgdmFsaWRhdGVBbGxvY2F0aW9uKGxlbmd0aCwgb3B0aW9ucywgbWFrZUVycm9yKTtcbiAgICB2YWxpZGF0ZUF2YWlsYWJsZUJ5dGVzKHRva2VuaXplciwgbGVuZ3RoLCBwb3NpdGlvbik7XG4gICAgaWYgKCFpc1JhbmRvbUFjY2Vzc1Rva2VuaXplcih0b2tlbml6ZXIpICYmIGxlbmd0aCA+IHJlYWRDaHVua1NpemUpIHtcbiAgICAgICAgY29uc3QgY2h1bmtzID0gW107XG4gICAgICAgIGZvciAobGV0IHJlbWFpbmluZyA9IGxlbmd0aDsgcmVtYWluaW5nID4gMDspIHtcbiAgICAgICAgICAgIGNvbnN0IGNodW5rID0gbmV3IFVpbnQ4QXJyYXkoTWF0aC5taW4ocmVtYWluaW5nLCByZWFkQ2h1bmtTaXplKSk7XG4gICAgICAgICAgICBjb25zdCBieXRlc1JlYWQgPSBhd2FpdCB0b2tlbml6ZXIucmVhZEJ1ZmZlcihjaHVuaywgeyBwb3NpdGlvbiB9KTtcbiAgICAgICAgICAgIGlmIChieXRlc1JlYWQgIT09IGNodW5rLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFbmRPZlN0cmVhbUVycm9yKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaHVua3MucHVzaChjaHVuayk7XG4gICAgICAgICAgICByZW1haW5pbmcgLT0gY2h1bmsubGVuZ3RoO1xuICAgICAgICAgICAgcG9zaXRpb24gKz0gY2h1bmsubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJ1ZmZlciA9IG5ldyBVaW50OEFycmF5KGxlbmd0aCk7XG4gICAgICAgIGxldCBvZmZzZXQgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IGNodW5rIG9mIGNodW5rcykge1xuICAgICAgICAgICAgYnVmZmVyLnNldChjaHVuaywgb2Zmc2V0KTtcbiAgICAgICAgICAgIG9mZnNldCArPSBjaHVuay5sZW5ndGg7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGJ1ZmZlcjtcbiAgICB9XG4gICAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkobGVuZ3RoKTtcbiAgICBpZiAoKGF3YWl0IHRva2VuaXplci5yZWFkQnVmZmVyKGJ1ZmZlciwgeyBwb3NpdGlvbiB9KSkgIT09IGxlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRW5kT2ZTdHJlYW1FcnJvcigpO1xuICAgIH1cbiAgICByZXR1cm4gYnVmZmVyO1xufVxuLyoqIEJvdW5kIGN1c3RvbSB0b2tlbml6ZXIgcmVhZHMgYW5kIGJ1ZmZlciBsYXJnZSBzdHJlYW0gcGF5bG9hZHMgaW5jcmVtZW50YWxseS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWFkVG9rZW4odG9rZW5pemVyLCB0b2tlbiwgb3B0aW9ucywgcG9zaXRpb24gPSB0b2tlbml6ZXIucG9zaXRpb24sIG1ha2VFcnJvciA9IGFsbG9jYXRpb25FcnJvcikge1xuICAgIHZhbGlkYXRlQWxsb2NhdGlvbih0b2tlbi5sZW4sIG9wdGlvbnMsIG1ha2VFcnJvcik7XG4gICAgdmFsaWRhdGVBdmFpbGFibGVCeXRlcyh0b2tlbml6ZXIsIHRva2VuLmxlbiwgcG9zaXRpb24pO1xuICAgIGlmICh0b2tlbi5sZW4gPD0gcmVhZENodW5rU2l6ZSkge1xuICAgICAgICByZXR1cm4gdG9rZW5pemVyLnJlYWRUb2tlbih0b2tlbiwgcG9zaXRpb24pO1xuICAgIH1cbiAgICByZXR1cm4gdG9rZW4uZ2V0KGF3YWl0IHJlYWRCdWZmZXIodG9rZW5pemVyLCB0b2tlbi5sZW4sIG9wdGlvbnMsIHBvc2l0aW9uLCBtYWtlRXJyb3IpLCAwKTtcbn1cbiIsImltcG9ydCB7IGdldE1heE1lbW9yeUFsbG9jYXRpb24sIHJlYWRUb2tlbiB9IGZyb20gJy4vQWxsb2NhdGlvbi5qcyc7XG5leHBvcnQgY2xhc3MgQmFzaWNQYXJzZXIge1xuICAgIG1ldGFkYXRhO1xuICAgIHRva2VuaXplcjtcbiAgICBvcHRpb25zO1xuICAgIC8qKlxuICAgICAqIEluaXRpYWxpemUgcGFyc2VyIHdpdGggb3V0cHV0IChtZXRhZGF0YSksIGlucHV0ICh0b2tlbml6ZXIpICYgcGFyc2luZyBvcHRpb25zIChvcHRpb25zKS5cbiAgICAgKiBAcGFyYW0ge0lOYXRpdmVNZXRhZGF0YUNvbGxlY3Rvcn0gbWV0YWRhdGEgT3V0cHV0XG4gICAgICogQHBhcmFtIHtJVG9rZW5pemVyfSB0b2tlbml6ZXIgSW5wdXRcbiAgICAgKiBAcGFyYW0ge0lPcHRpb25zfSBvcHRpb25zIFBhcnNpbmcgb3B0aW9uc1xuICAgICAqL1xuICAgIGNvbnN0cnVjdG9yKG1ldGFkYXRhLCB0b2tlbml6ZXIsIG9wdGlvbnMpIHtcbiAgICAgICAgZ2V0TWF4TWVtb3J5QWxsb2NhdGlvbihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5tZXRhZGF0YSA9IG1ldGFkYXRhO1xuICAgICAgICB0aGlzLnRva2VuaXplciA9IHRva2VuaXplcjtcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB9XG4gICAgcmVhZFRva2VuKHRva2VuLCBwb3NpdGlvbikge1xuICAgICAgICByZXR1cm4gcmVhZFRva2VuKHRoaXMudG9rZW5pemVyLCB0b2tlbiwgdGhpcy5vcHRpb25zLCBwb3NpdGlvbik7XG4gICAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOztBQUFBLElBQWEsa0JBQWtCOzs7O0FBSS9CLElBQWEsbUJBQWIsY0FBc0MsTUFBTTtDQUN4QyxjQUFjO0VBQ1YsTUFBTSxlQUFlO0VBQ3JCLEtBQUssT0FBTztDQUNoQjtBQUNKO0FBQ0EsSUFBYSxhQUFiLGNBQWdDLE1BQU07Q0FDbEMsWUFBWSxVQUFVLDZCQUE2QjtFQUMvQyxNQUFNLE9BQU87RUFDYixLQUFLLE9BQU87Q0FDaEI7QUFDSjs7Ozs7O0FDWEEsU0FBZ0Isd0JBQXdCLFdBQVc7Q0FDL0MsT0FBUSxVQUFVLHFCQUFxQixLQUNuQyxpQkFBaUIsYUFDakIsT0FBTyxVQUFVLGdCQUFnQixjQUNqQyxPQUFPLFVBQVUsU0FBUyxTQUFTO0FBQzNDOztBQ1RBLElBQU0scUJBQXFCO0NBQ3ZCLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtDQUNOLEtBQU07Q0FDTixLQUFNO0NBQ04sS0FBTTtBQUNWO0FBQ0EsSUFBTSx1QkFBdUIsQ0FBQztBQUM5QixLQUFLLE1BQU0sQ0FBQyxNQUFNLFNBQVMsT0FBTyxRQUFRLGtCQUFrQixHQUN4RCxxQkFBcUIsUUFBUSxPQUFPLFNBQVMsTUFBTSxFQUFFO0FBRXpELElBQUk7QUFDSixJQUFJO0FBQ0osU0FBUyxjQUFjO0NBQ25CLElBQUksaUJBQWlCLEtBQUEsR0FDakIsSUFBSTtFQUNBLGVBQWUsT0FBTyxXQUFXLGdCQUFnQixjQUFjLE9BQU8sSUFBSSxXQUFXLFlBQVksT0FBTztDQUM1RyxRQUNNO0VBQ0YsZUFBZTtDQUNuQjtDQUVKLE9BQU8saUJBQWlCLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxlQUFlLEtBQUE7QUFDN0U7QUFDQSxTQUFTLGNBQWM7Q0FDbkIsSUFBSSxpQkFBaUIsS0FBQSxHQUNqQixJQUFJO0VBQ0EsZUFBZSxPQUFPLFdBQVcsZ0JBQWdCLGNBQWMsT0FBTyxJQUFJLFdBQVcsWUFBWTtDQUNyRyxRQUNNO0VBQ0YsZUFBZTtDQUNuQjtDQUVKLE9BQU8saUJBQWlCLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxlQUFlLEtBQUE7QUFDN0U7QUFDQSxJQUFNLFFBQVE7QUFDZCxJQUFNLGNBQWM7Ozs7QUFJcEIsU0FBZ0IsV0FBVyxPQUFPLFdBQVcsU0FBUztDQUNsRCxRQUFRLFNBQVMsWUFBWSxHQUE3QjtFQUNJLEtBQUs7RUFDTCxLQUFLLFFBQVE7R0FDVCxNQUFNLE1BQU0sWUFBWTtHQUN4QixPQUFPLE1BQU0sSUFBSSxPQUFPLEtBQUssSUFBSSxXQUFXLEtBQUs7RUFDckQ7RUFDQSxLQUFLLFlBQ0QsT0FBTyxjQUFjLEtBQUs7RUFDOUIsS0FBSztFQUNMLEtBQUssU0FDRCxPQUFPLFlBQVksS0FBSztFQUM1QixLQUFLO0VBQ0wsS0FBSyxjQUNELE9BQU8sYUFBYSxLQUFLO0VBQzdCLEtBQUssZ0JBQ0QsT0FBTyxrQkFBa0IsS0FBSztFQUNsQyxTQUNJLE1BQU0sSUFBSSxXQUFXLGFBQWEsU0FBUyxnQkFBZ0I7Q0FDbkU7QUFDSjtBQUNBLFNBQWdCLFdBQVcsUUFBUSxJQUFJLFdBQVcsU0FBUztDQUN2RCxRQUFRLFNBQVMsWUFBWSxHQUE3QjtFQUNJLEtBQUs7RUFDTCxLQUFLLFFBQVE7R0FDVCxNQUFNLE1BQU0sWUFBWTtHQUN4QixPQUFPLE1BQU0sSUFBSSxPQUFPLEtBQUssSUFBSSxXQUFXLEtBQUs7RUFDckQ7RUFDQSxLQUFLLFlBQ0QsT0FBTyxjQUFjLEtBQUs7RUFDOUIsS0FBSztFQUNMLEtBQUssU0FDRCxPQUFPLFlBQVksS0FBSztFQUM1QixLQUFLO0VBQ0wsS0FBSyxjQUNELE9BQU8sYUFBYSxLQUFLO0VBQzdCLEtBQUssZ0JBQ0QsT0FBTyxrQkFBa0IsS0FBSztFQUNsQyxTQUNJLE1BQU0sSUFBSSxXQUFXLGFBQWEsU0FBUyxnQkFBZ0I7Q0FDbkU7QUFDSjtBQUNBLFNBQVMsV0FBVyxPQUFPLE9BQU87Q0FDOUIsSUFBSSxNQUFNLFdBQVcsR0FDakI7Q0FFSixNQUFNLEtBQUssT0FBTyxhQUFhLE1BQU0sTUFBTSxLQUFLLENBQUM7Q0FDakQsTUFBTSxTQUFTO0FBQ25CO0FBQ0EsU0FBUyxhQUFhLE9BQU8sT0FBTyxVQUFVO0NBQzFDLE1BQU0sS0FBSyxRQUFRO0NBQ25CLElBQUksTUFBTSxVQUFVLE9BQ2hCLFdBQVcsT0FBTyxLQUFLO0FBRS9CO0FBQ0EsU0FBUyxjQUFjLE9BQU8sT0FBTyxJQUFJO0NBQ3JDLElBQUksTUFBTSxPQUFRO0VBQ2QsYUFBYSxPQUFPLE9BQU8sRUFBRTtFQUM3QjtDQUNKO0NBQ0EsTUFBTTtDQUNOLGFBQWEsT0FBTyxPQUFPLFNBQVUsTUFBTSxHQUFHO0NBQzlDLGFBQWEsT0FBTyxPQUFPLFNBQVUsS0FBSyxLQUFNO0FBQ3BEO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDdkIsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLFFBQVEsQ0FBQztDQUNmLElBQUksSUFBSTtDQUVSLElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxPQUFPLE9BQVEsTUFBTSxPQUFPLE9BQVEsTUFBTSxPQUFPLEtBQzVFLElBQUk7Q0FFUixPQUFPLElBQUksTUFBTSxRQUFRO0VBQ3JCLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLElBQUksTUFBTSxLQUFNO0dBQ1osYUFBYSxPQUFPLE9BQU8sRUFBRTtHQUM3QjtHQUNBO0VBQ0o7RUFFQSxJQUFJLEtBQUssT0FBUSxLQUFLLEtBQU07R0FDeEIsYUFBYSxPQUFPLE9BQU8sV0FBVztHQUN0QztHQUNBO0VBQ0o7RUFDQSxNQUFNLFNBQVMsTUFBTSxNQUFPLElBQUksTUFBTSxNQUFPLElBQUk7RUFDakQsSUFBSSxLQUFLLEtBQU0sT0FBUTtFQUN2QixJQUFJLFFBQVEsT0FBTyxNQUFPLE1BQU8sT0FBTyxNQUFPLE1BQU87RUFDdEQsSUFBSSxRQUFRLE9BQU8sTUFBTyxNQUFPLE9BQU8sTUFBTyxNQUFPO0VBQ3RELElBQUksV0FBVztFQUNmO0VBRUEsT0FBTyxXQUFXLFVBQVUsSUFBSSxNQUFNLFFBQVE7R0FDMUMsTUFBTSxPQUFPLE1BQU07R0FDbkIsSUFBSSxPQUFPLFNBQVMsT0FBTyxPQUN2QjtHQUVKLEtBQU0sTUFBTSxJQUFNLE9BQU87R0FDekI7R0FDQTtHQUNBLFFBQVE7R0FDUixRQUFRO0VBQ1o7RUFDQSxjQUFjLE9BQU8sT0FBTyxhQUFhLFNBQVMsS0FBSyxXQUFXO0NBQ3RFO0NBQ0EsV0FBVyxPQUFPLEtBQUs7Q0FDdkIsT0FBTyxNQUFNLEtBQUssRUFBRTtBQUN4QjtBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLE1BQU0sTUFBTTtDQUNsQixJQUFJLElBQUk7Q0FFUixJQUFJLE9BQU8sS0FBSyxNQUFNLE9BQU8sT0FBUSxNQUFNLE9BQU8sS0FDOUMsSUFBSTtDQUVSLE9BQU8sSUFBSSxJQUFJLEtBQUs7RUFDaEIsTUFBTSxLQUFLLE1BQU0sS0FBTSxNQUFNLElBQUksTUFBTTtFQUN2QyxLQUFLO0VBRUwsSUFBSSxNQUFNLFNBQVUsTUFBTSxPQUFRO0dBQzlCLElBQUksSUFBSSxJQUFJLEtBQUs7SUFDYixNQUFNLEtBQUssTUFBTSxLQUFNLE1BQU0sSUFBSSxNQUFNO0lBQ3ZDLElBQUksTUFBTSxTQUFVLE1BQU0sT0FBUTtLQUM5QixhQUFhLE9BQU8sT0FBTyxFQUFFO0tBQzdCLGFBQWEsT0FBTyxPQUFPLEVBQUU7S0FDN0IsS0FBSztJQUNULE9BRUksYUFBYSxPQUFPLE9BQU8sV0FBVztHQUU5QyxPQUVJLGFBQWEsT0FBTyxPQUFPLFdBQVc7R0FFMUM7RUFDSjtFQUVBLElBQUksTUFBTSxTQUFVLE1BQU0sT0FBUTtHQUM5QixhQUFhLE9BQU8sT0FBTyxXQUFXO0dBQ3RDO0VBQ0o7RUFDQSxhQUFhLE9BQU8sT0FBTyxFQUFFO0NBQ2pDO0NBRUEsSUFBSSxJQUFJLEtBQ0osYUFBYSxPQUFPLE9BQU8sV0FBVztDQUUxQyxXQUFXLE9BQU8sS0FBSztDQUN2QixPQUFPLE1BQU0sS0FBSyxFQUFFO0FBQ3hCO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDeEIsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssT0FBTztFQUMxQyxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sUUFBUSxJQUFJLEtBQUs7RUFDNUMsTUFBTSxRQUFRLElBQUksTUFBTSxNQUFNLENBQUM7RUFDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssS0FDakMsTUFBTSxLQUFLLE1BQU0sS0FBSztFQUUxQixNQUFNLEtBQUssT0FBTyxhQUFhLE1BQU0sTUFBTSxLQUFLLENBQUM7Q0FDckQ7Q0FDQSxPQUFPLE1BQU0sS0FBSyxFQUFFO0FBQ3hCO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDekIsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssT0FBTztFQUMxQyxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sUUFBUSxJQUFJLEtBQUs7RUFDNUMsTUFBTSxRQUFRLElBQUksTUFBTSxNQUFNLENBQUM7RUFDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssS0FDakMsTUFBTSxLQUFLLE1BQU07RUFFckIsTUFBTSxLQUFLLE9BQU8sYUFBYSxNQUFNLE1BQU0sS0FBSyxDQUFDO0NBQ3JEO0NBQ0EsT0FBTyxNQUFNLEtBQUssRUFBRTtBQUN4QjtBQUNBLFNBQVMsa0JBQWtCLE9BQU87Q0FDOUIsTUFBTSxRQUFRLENBQUM7Q0FDZixJQUFJLE1BQU07Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7RUFDbkMsTUFBTSxJQUFJLE1BQU07RUFDaEIsTUFBTSxRQUFRLEtBQUssT0FBUSxLQUFLLE1BQU8sbUJBQW1CLEtBQUssS0FBQTtFQUMvRCxPQUFPLFVBQVUsUUFBUSxVQUFVLEtBQUssSUFBSSxRQUFRLE9BQU8sYUFBYSxDQUFDO0VBQ3pFLElBQUksSUFBSSxVQUFVLE9BQU87R0FDckIsTUFBTSxLQUFLLEdBQUc7R0FDZCxNQUFNO0VBQ1Y7Q0FDSjtDQUNBLElBQUksS0FDQSxNQUFNLEtBQUssR0FBRztDQUVsQixPQUFPLE1BQU0sS0FBSyxFQUFFO0FBQ3hCO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDckIsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7RUFDakMsSUFBSSxLQUFLLElBQUksV0FBVyxDQUFDO0VBRXpCLElBQUksTUFBTSxTQUFVLE1BQU0sT0FBUTtHQUM5QixJQUFJLElBQUksSUFBSSxJQUFJLFFBQVE7SUFDcEIsTUFBTSxLQUFLLElBQUksV0FBVyxJQUFJLENBQUM7SUFDL0IsSUFBSSxNQUFNLFNBQVUsTUFBTSxPQUFRO0tBQzlCLEtBQUssU0FBWSxLQUFLLFNBQVcsT0FBTyxLQUFLO0tBQzdDO0lBQ0osT0FFSSxLQUFLO0dBRWIsT0FFSSxLQUFLO0VBRWIsT0FDSyxJQUFJLE1BQU0sU0FBVSxNQUFNLE9BRTNCLEtBQUs7RUFFVCxJQUFJLEtBQUssS0FDTCxJQUFJLEtBQUssRUFBRTtPQUVWLElBQUksS0FBSyxNQUNWLElBQUksS0FBSyxNQUFRLE1BQU0sR0FBSSxNQUFRLEtBQUssRUFBSztPQUU1QyxJQUFJLEtBQUssT0FDVixJQUFJLEtBQUssTUFBUSxNQUFNLElBQUssTUFBUyxNQUFNLElBQUssSUFBTyxNQUFRLEtBQUssRUFBSztPQUd6RSxJQUFJLEtBQUssTUFBUSxNQUFNLElBQUssTUFBUyxNQUFNLEtBQU0sSUFBTyxNQUFTLE1BQU0sSUFBSyxJQUFPLE1BQVEsS0FBSyxFQUFLO0NBRTdHO0NBQ0EsT0FBTyxJQUFJLFdBQVcsR0FBRztBQUM3QjtBQUNBLFNBQVMsY0FBYyxLQUFLO0NBR3hCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0VBQ2pDLE1BQU0sSUFBSSxJQUFJLFdBQVcsQ0FBQztFQUMxQixJQUFJLEtBQUssU0FBVSxLQUFLLE9BQVE7R0FDNUIsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRO0lBQ3BCLE1BQU0sS0FBSyxJQUFJLFdBQVcsSUFBSSxDQUFDO0lBQy9CLElBQUksTUFBTSxTQUFVLE1BQU0sT0FBUTtLQUM5QixNQUFNLEtBQUssR0FBRyxFQUFFO0tBQ2hCO0lBQ0osT0FFSSxNQUFNLEtBQUssV0FBVztHQUU5QixPQUVJLE1BQU0sS0FBSyxXQUFXO0dBRTFCO0VBQ0o7RUFDQSxJQUFJLEtBQUssU0FBVSxLQUFLLE9BQVE7R0FDNUIsTUFBTSxLQUFLLFdBQVc7R0FDdEI7RUFDSjtFQUNBLE1BQU0sS0FBSyxDQUFDO0NBQ2hCO0NBQ0EsTUFBTSxNQUFNLElBQUksV0FBVyxNQUFNLFNBQVMsQ0FBQztDQUMzQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7RUFDbkMsTUFBTSxPQUFPLE1BQU07RUFDbkIsTUFBTSxJQUFJLElBQUk7RUFDZCxJQUFJLEtBQUssT0FBTztFQUNoQixJQUFJLElBQUksS0FBSyxTQUFTO0NBQzFCO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxZQUFZLEtBQUs7Q0FDdEIsTUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07Q0FDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUM1QixJQUFJLEtBQUssSUFBSSxXQUFXLENBQUMsSUFBSTtDQUVqQyxPQUFPO0FBQ1g7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN2QixNQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtDQUNyQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQzVCLElBQUksS0FBSyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0NBRWpDLE9BQU87QUFDWDtBQUNBLFNBQVMsa0JBQWtCLEtBQUs7Q0FDNUIsTUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07Q0FDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0VBQ2pDLE1BQU0sS0FBSyxJQUFJO0VBQ2YsTUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDO0VBQzVCLElBQUkscUJBQXFCLFFBQVEsS0FBQSxHQUFXO0dBQ3hDLElBQUksS0FBSyxxQkFBcUI7R0FDOUI7RUFDSjtFQUNBLElBQUssUUFBUSxLQUFRLFFBQVEsT0FBVSxRQUFRLE9BQVEsUUFBUSxLQUFPO0dBQ2xFLElBQUksS0FBSztHQUNUO0VBQ0o7RUFDQSxJQUFJLEtBQUs7Q0FDYjtDQUNBLE9BQU87QUFDWDs7Ozs7O0NDcldBLElBQUksSUFBSTtDQUNSLElBQUksSUFBSSxJQUFJO0NBQ1osSUFBSSxJQUFJLElBQUk7Q0FDWixJQUFJLElBQUksSUFBSTtDQUNaLElBQUksSUFBSSxJQUFJO0NBQ1osSUFBSSxJQUFJLElBQUk7Ozs7Ozs7Ozs7Ozs7O0NBZ0JaLE9BQU8sVUFBVSxTQUFVLEtBQUssU0FBUztFQUN2QyxVQUFVLFdBQVcsQ0FBQztFQUN0QixJQUFJLE9BQU8sT0FBTztFQUNsQixJQUFJLFNBQVMsWUFBWSxJQUFJLFNBQVMsR0FDcEMsT0FBTyxNQUFNLEdBQUc7T0FDWCxJQUFJLFNBQVMsWUFBWSxTQUFTLEdBQUcsR0FDMUMsT0FBTyxRQUFRLE9BQU8sUUFBUSxHQUFHLElBQUksU0FBUyxHQUFHO0VBRW5ELE1BQU0sSUFBSSxNQUNSLDBEQUNFLEtBQUssVUFBVSxHQUFHLENBQ3RCO0NBQ0Y7Ozs7Ozs7O0NBVUEsU0FBUyxNQUFNLEtBQUs7RUFDbEIsTUFBTSxPQUFPLEdBQUc7RUFDaEIsSUFBSSxJQUFJLFNBQVMsS0FDZjtFQUVGLElBQUksUUFBUSxtSUFBbUksS0FDN0ksR0FDRjtFQUNBLElBQUksQ0FBQyxPQUNIO0VBRUYsSUFBSSxJQUFJLFdBQVcsTUFBTSxFQUFFO0VBRTNCLFNBRFksTUFBTSxNQUFNLEtBQUEsQ0FBTSxZQUNuQixHQUFYO0dBQ0UsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssS0FDSCxPQUFPLElBQUk7R0FDYixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssS0FDSCxPQUFPLElBQUk7R0FDYixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssS0FDSCxPQUFPLElBQUk7R0FDYixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSyxLQUNILE9BQU8sSUFBSTtHQUNiLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLLEtBQ0gsT0FBTyxJQUFJO0dBQ2IsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssS0FDSCxPQUFPLElBQUk7R0FDYixLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSyxNQUNILE9BQU87R0FDVCxTQUNFO0VBQ0o7Q0FDRjs7Ozs7Ozs7Q0FVQSxTQUFTLFNBQVMsSUFBSTtFQUNwQixJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQUU7RUFDdkIsSUFBSSxTQUFTLEdBQ1gsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUk7RUFFOUIsSUFBSSxTQUFTLEdBQ1gsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUk7RUFFOUIsSUFBSSxTQUFTLEdBQ1gsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUk7RUFFOUIsSUFBSSxTQUFTLEdBQ1gsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUk7RUFFOUIsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7O0NBVUEsU0FBUyxRQUFRLElBQUk7RUFDbkIsSUFBSSxRQUFRLEtBQUssSUFBSSxFQUFFO0VBQ3ZCLElBQUksU0FBUyxHQUNYLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxLQUFLO0VBRW5DLElBQUksU0FBUyxHQUNYLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxNQUFNO0VBRXBDLElBQUksU0FBUyxHQUNYLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxRQUFRO0VBRXRDLElBQUksU0FBUyxHQUNYLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxRQUFRO0VBRXRDLE9BQU8sS0FBSztDQUNkOzs7O0NBTUEsU0FBUyxPQUFPLElBQUksT0FBTyxHQUFHLE1BQU07RUFDbEMsSUFBSSxXQUFXLFNBQVMsSUFBSTtFQUM1QixPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFFBQVEsV0FBVyxNQUFNO0NBQzdEOzs7Ozs7OztDQzNKQSxTQUFTLE1BQU0sS0FBSztFQUNuQixZQUFZLFFBQVE7RUFDcEIsWUFBWSxVQUFVO0VBQ3RCLFlBQVksU0FBUztFQUNyQixZQUFZLFVBQVU7RUFDdEIsWUFBWSxTQUFTO0VBQ3JCLFlBQVksVUFBVTtFQUN0QixZQUFZLFdBQUEsV0FBQTtFQUNaLFlBQVksVUFBVTtFQUV0QixPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsU0FBUSxRQUFPO0dBQy9CLFlBQVksT0FBTyxJQUFJO0VBQ3hCLENBQUM7Ozs7RUFNRCxZQUFZLFFBQVEsQ0FBQztFQUNyQixZQUFZLFFBQVEsQ0FBQzs7Ozs7O0VBT3JCLFlBQVksYUFBYSxDQUFDOzs7Ozs7O0VBUTFCLFNBQVMsWUFBWSxXQUFXO0dBQy9CLElBQUksT0FBTztHQUVYLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztJQUMxQyxRQUFTLFFBQVEsS0FBSyxPQUFRLFVBQVUsV0FBVyxDQUFDO0lBQ3BELFFBQVE7R0FDVDtHQUVBLE9BQU8sWUFBWSxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksWUFBWSxPQUFPO0VBQy9EO0VBQ0EsWUFBWSxjQUFjOzs7Ozs7OztFQVMxQixTQUFTLFlBQVksV0FBVztHQUMvQixJQUFJO0dBQ0osSUFBSSxpQkFBaUI7R0FDckIsSUFBSTtHQUNKLElBQUk7R0FFSixTQUFTLE1BQU0sR0FBRyxNQUFNO0lBRXZCLElBQUksQ0FBQyxNQUFNLFNBQ1Y7SUFHRCxNQUFNLE9BQU87SUFHYixNQUFNLE9BQU8sdUJBQU8sSUFBSSxLQUFLLENBQUM7SUFFOUIsS0FBSyxPQURNLFFBQVEsWUFBWTtJQUUvQixLQUFLLE9BQU87SUFDWixLQUFLLE9BQU87SUFDWixXQUFXO0lBRVgsS0FBSyxLQUFLLFlBQVksT0FBTyxLQUFLLEVBQUU7SUFFcEMsSUFBSSxPQUFPLEtBQUssT0FBTyxVQUV0QixLQUFLLFFBQVEsSUFBSTtJQUlsQixJQUFJLFFBQVE7SUFDWixLQUFLLEtBQUssS0FBSyxFQUFFLENBQUMsUUFBUSxrQkFBa0IsT0FBTyxXQUFXO0tBRTdELElBQUksVUFBVSxNQUNiLE9BQU87S0FFUjtLQUNBLE1BQU0sWUFBWSxZQUFZLFdBQVc7S0FDekMsSUFBSSxPQUFPLGNBQWMsWUFBWTtNQUNwQyxNQUFNLE1BQU0sS0FBSztNQUNqQixRQUFRLFVBQVUsS0FBSyxNQUFNLEdBQUc7TUFHaEMsS0FBSyxPQUFPLE9BQU8sQ0FBQztNQUNwQjtLQUNEO0tBQ0EsT0FBTztJQUNSLENBQUM7SUFHRCxZQUFZLFdBQVcsS0FBSyxNQUFNLElBQUk7SUFHdEMsQ0FEYyxLQUFLLE9BQU8sWUFBWSxJQUFBLENBQ2hDLE1BQU0sTUFBTSxJQUFJO0dBQ3ZCO0dBRUEsTUFBTSxZQUFZO0dBQ2xCLE1BQU0sWUFBWSxZQUFZLFVBQVU7R0FDeEMsTUFBTSxRQUFRLFlBQVksWUFBWSxTQUFTO0dBQy9DLE1BQU0sU0FBUztHQUNmLE1BQU0sVUFBVSxZQUFZO0dBRTVCLE9BQU8sZUFBZSxPQUFPLFdBQVc7SUFDdkMsWUFBWTtJQUNaLGNBQWM7SUFDZCxXQUFXO0tBQ1YsSUFBSSxtQkFBbUIsTUFDdEIsT0FBTztLQUVSLElBQUksb0JBQW9CLFlBQVksWUFBWTtNQUMvQyxrQkFBa0IsWUFBWTtNQUM5QixlQUFlLFlBQVksUUFBUSxTQUFTO0tBQzdDO0tBRUEsT0FBTztJQUNSO0lBQ0EsTUFBSyxNQUFLO0tBQ1QsaUJBQWlCO0lBQ2xCO0dBQ0QsQ0FBQztHQUdELElBQUksT0FBTyxZQUFZLFNBQVMsWUFDL0IsWUFBWSxLQUFLLEtBQUs7R0FHdkIsT0FBTztFQUNSO0VBRUEsU0FBUyxPQUFPLFdBQVcsV0FBVztHQUNyQyxNQUFNLFdBQVcsWUFBWSxLQUFLLGFBQWEsT0FBTyxjQUFjLGNBQWMsTUFBTSxhQUFhLFNBQVM7R0FDOUcsU0FBUyxNQUFNLEtBQUs7R0FDcEIsT0FBTztFQUNSOzs7Ozs7OztFQVNBLFNBQVMsT0FBTyxZQUFZO0dBQzNCLFlBQVksS0FBSyxVQUFVO0dBQzNCLFlBQVksYUFBYTtHQUV6QixZQUFZLFFBQVEsQ0FBQztHQUNyQixZQUFZLFFBQVEsQ0FBQztHQUVyQixNQUFNLFNBQVMsT0FBTyxlQUFlLFdBQVcsYUFBYSxHQUFBLENBQzNELEtBQUssQ0FBQyxDQUNOLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FDcEIsTUFBTSxHQUFHLENBQUMsQ0FDVixPQUFPLE9BQU87R0FFaEIsS0FBSyxNQUFNLE1BQU0sT0FDaEIsSUFBSSxHQUFHLE9BQU8sS0FDYixZQUFZLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBRWxDLFlBQVksTUFBTSxLQUFLLEVBQUU7RUFHNUI7Ozs7Ozs7OztFQVVBLFNBQVMsZ0JBQWdCLFFBQVEsVUFBVTtHQUMxQyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxnQkFBZ0I7R0FDcEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksYUFBYTtHQUVqQixPQUFPLGNBQWMsT0FBTyxRQUMzQixJQUFJLGdCQUFnQixTQUFTLFdBQVcsU0FBUyxtQkFBbUIsT0FBTyxnQkFBZ0IsU0FBUyxtQkFBbUIsTUFBTTtJQUU1SCxJQUFJLFNBQVMsbUJBQW1CLEtBQUs7S0FDcEMsWUFBWTtLQUNaLGFBQWE7S0FDYjtJQUNELE9BQU87S0FDTjtLQUNBO0lBQ0Q7R0FDRCxPQUFPLElBQUksY0FBYyxJQUFJO0lBRTVCLGdCQUFnQixZQUFZO0lBQzVCO0lBQ0EsY0FBYztHQUNmLE9BQ0MsT0FBTztHQUtULE9BQU8sZ0JBQWdCLFNBQVMsVUFBVSxTQUFTLG1CQUFtQixLQUNyRTtHQUdELE9BQU8sa0JBQWtCLFNBQVM7RUFDbkM7Ozs7Ozs7RUFRQSxTQUFTLFVBQVU7R0FDbEIsTUFBTSxhQUFhLENBQ2xCLEdBQUcsWUFBWSxPQUNmLEdBQUcsWUFBWSxNQUFNLEtBQUksY0FBYSxNQUFNLFNBQVMsQ0FDdEQsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUNWLFlBQVksT0FBTyxFQUFFO0dBQ3JCLE9BQU87RUFDUjs7Ozs7Ozs7RUFTQSxTQUFTLFFBQVEsTUFBTTtHQUN0QixLQUFLLE1BQU0sUUFBUSxZQUFZLE9BQzlCLElBQUksZ0JBQWdCLE1BQU0sSUFBSSxHQUM3QixPQUFPO0dBSVQsS0FBSyxNQUFNLE1BQU0sWUFBWSxPQUM1QixJQUFJLGdCQUFnQixNQUFNLEVBQUUsR0FDM0IsT0FBTztHQUlULE9BQU87RUFDUjs7Ozs7Ozs7RUFTQSxTQUFTLE9BQU8sS0FBSztHQUNwQixJQUFJLGVBQWUsT0FDbEIsT0FBTyxJQUFJLFNBQVMsSUFBSTtHQUV6QixPQUFPO0VBQ1I7Ozs7O0VBTUEsU0FBUyxVQUFVO0dBQ2xCLFFBQVEsS0FBSyx1SUFBdUk7RUFDcko7RUFFQSxZQUFZLE9BQU8sWUFBWSxLQUFLLENBQUM7RUFFckMsT0FBTztDQUNSO0NBRUEsT0FBTyxVQUFVOzs7Ozs7O0NDN1JqQixRQUFRLGFBQWE7Q0FDckIsUUFBUSxPQUFPO0NBQ2YsUUFBUSxPQUFPO0NBQ2YsUUFBUSxZQUFZO0NBQ3BCLFFBQVEsVUFBVSxhQUFhO0NBQy9CLFFBQVEsaUJBQWlCO0VBQ3hCLElBQUksU0FBUztFQUViLGFBQWE7R0FDWixJQUFJLENBQUMsUUFBUTtJQUNaLFNBQVM7SUFDVCxRQUFRLEtBQUssdUlBQXVJO0dBQ3JKO0VBQ0Q7Q0FDRCxFQUFBLENBQUc7Ozs7Q0FNSCxRQUFRLFNBQVM7RUFDaEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDs7Ozs7Ozs7Q0FXQSxTQUFTLFlBQVk7RUFJcEIsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLFlBQVksT0FBTyxRQUFRLFNBQVMsY0FBYyxPQUFPLFFBQVEsU0FDNUcsT0FBTztFQUlSLElBQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxhQUFhLFVBQVUsVUFBVSxZQUFZLENBQUMsQ0FBQyxNQUFNLHVCQUF1QixHQUM3SCxPQUFPO0VBR1IsSUFBSTtFQUtKLE9BQVEsT0FBTyxhQUFhLGVBQWUsU0FBUyxtQkFBbUIsU0FBUyxnQkFBZ0IsU0FBUyxTQUFTLGdCQUFnQixNQUFNLG9CQUV0SSxPQUFPLFdBQVcsZUFBZSxPQUFPLFlBQVksT0FBTyxRQUFRLFdBQVksT0FBTyxRQUFRLGFBQWEsT0FBTyxRQUFRLFVBRzFILE9BQU8sY0FBYyxlQUFlLFVBQVUsY0FBYyxJQUFJLFVBQVUsVUFBVSxZQUFZLENBQUMsQ0FBQyxNQUFNLGdCQUFnQixNQUFNLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxNQUVwSixPQUFPLGNBQWMsZUFBZSxVQUFVLGFBQWEsVUFBVSxVQUFVLFlBQVksQ0FBQyxDQUFDLE1BQU0sb0JBQW9CO0NBQzFIOzs7Ozs7Q0FRQSxTQUFTLFdBQVcsTUFBTTtFQUN6QixLQUFLLE1BQU0sS0FBSyxZQUFZLE9BQU8sTUFDbEMsS0FBSyxhQUNKLEtBQUssWUFBWSxRQUFRLE9BQzFCLEtBQUssTUFDSixLQUFLLFlBQVksUUFBUSxPQUMxQixNQUFNLE9BQU8sUUFBUSxTQUFTLEtBQUssSUFBSTtFQUV4QyxJQUFJLENBQUMsS0FBSyxXQUNUO0VBR0QsTUFBTSxJQUFJLFlBQVksS0FBSztFQUMzQixLQUFLLE9BQU8sR0FBRyxHQUFHLEdBQUcsZ0JBQWdCO0VBS3JDLElBQUksUUFBUTtFQUNaLElBQUksUUFBUTtFQUNaLEtBQUssRUFBRSxDQUFDLFFBQVEsZ0JBQWUsVUFBUztHQUN2QyxJQUFJLFVBQVUsTUFDYjtHQUVEO0dBQ0EsSUFBSSxVQUFVLE1BR2IsUUFBUTtFQUVWLENBQUM7RUFFRCxLQUFLLE9BQU8sT0FBTyxHQUFHLENBQUM7Q0FDeEI7Ozs7Ozs7OztDQVVBLFFBQVEsTUFBTSxRQUFRLFNBQVMsUUFBUSxjQUFjLENBQUM7Ozs7Ozs7Q0FRdEQsU0FBUyxLQUFLLFlBQVk7RUFDekIsSUFBSTtHQUNILElBQUksWUFDSCxRQUFRLFFBQVEsUUFBUSxTQUFTLFVBQVU7UUFFM0MsUUFBUSxRQUFRLFdBQVcsT0FBTztFQUVwQyxTQUFTLE9BQU8sQ0FHaEI7Q0FDRDs7Ozs7OztDQVFBLFNBQVMsT0FBTztFQUNmLElBQUk7RUFDSixJQUFJO0dBQ0gsSUFBSSxRQUFRLFFBQVEsUUFBUSxPQUFPLEtBQUssUUFBUSxRQUFRLFFBQVEsT0FBTztFQUN4RSxTQUFTLE9BQU8sQ0FHaEI7RUFHQSxJQUFJLENBQUMsS0FBSyxPQUFPLFlBQVksZUFBZSxTQUFTLFNBQ3BELElBQUksUUFBUSxJQUFJO0VBR2pCLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7Q0FhQSxTQUFTLGVBQWU7RUFDdkIsSUFBSTtHQUdILE9BQU87RUFDUixTQUFTLE9BQU8sQ0FHaEI7Q0FDRDtDQUVBLE9BQU8sVUFBQSxlQUFBLENBQUEsQ0FBOEIsT0FBTztDQUU1QyxJQUFNLEVBQUMsZUFBYyxPQUFPOzs7O0NBTTVCLFdBQVcsSUFBSSxTQUFVLEdBQUc7RUFDM0IsSUFBSTtHQUNILE9BQU8sS0FBSyxVQUFVLENBQUM7RUFDeEIsU0FBUyxPQUFPO0dBQ2YsT0FBTyxpQ0FBaUMsTUFBTTtFQUMvQztDQUNEOzs7OztDQzlRQSxRQUFRLE9BQU8sU0FBVSxRQUFRLFFBQVEsTUFBTSxNQUFNLFFBQVE7RUFDM0QsSUFBSSxHQUFHO0VBQ1AsSUFBSSxPQUFRLFNBQVMsSUFBSyxPQUFPO0VBQ2pDLElBQUksUUFBUSxLQUFLLFFBQVE7RUFDekIsSUFBSSxRQUFRLFFBQVE7RUFDcEIsSUFBSSxRQUFRO0VBQ1osSUFBSSxJQUFJLE9BQVEsU0FBUyxJQUFLO0VBQzlCLElBQUksSUFBSSxPQUFPLEtBQUs7RUFDcEIsSUFBSSxJQUFJLE9BQU8sU0FBUztFQUV4QixLQUFLO0VBRUwsSUFBSSxLQUFNLEtBQU0sQ0FBQyxTQUFVO0VBQzNCLE1BQU8sQ0FBQztFQUNSLFNBQVM7RUFDVCxPQUFPLFFBQVEsR0FBRyxJQUFLLElBQUksTUFBTyxPQUFPLFNBQVMsSUFBSSxLQUFLLEdBQUcsU0FBUztFQUV2RSxJQUFJLEtBQU0sS0FBTSxDQUFDLFNBQVU7RUFDM0IsTUFBTyxDQUFDO0VBQ1IsU0FBUztFQUNULE9BQU8sUUFBUSxHQUFHLElBQUssSUFBSSxNQUFPLE9BQU8sU0FBUyxJQUFJLEtBQUssR0FBRyxTQUFTO0VBRXZFLElBQUksTUFBTSxHQUNSLElBQUksSUFBSTtPQUNILElBQUksTUFBTSxNQUNmLE9BQU8sSUFBSSxPQUFRLElBQUksS0FBSyxLQUFLO09BQzVCO0dBQ0wsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUk7R0FDeEIsSUFBSSxJQUFJO0VBQ1Y7RUFDQSxRQUFRLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJO0NBQ2hEO0NBRUEsUUFBUSxRQUFRLFNBQVUsUUFBUSxPQUFPLFFBQVEsTUFBTSxNQUFNLFFBQVE7RUFDbkUsSUFBSSxHQUFHLEdBQUc7RUFDVixJQUFJLE9BQVEsU0FBUyxJQUFLLE9BQU87RUFDakMsSUFBSSxRQUFRLEtBQUssUUFBUTtFQUN6QixJQUFJLFFBQVEsUUFBUTtFQUNwQixJQUFJLEtBQU0sU0FBUyxLQUFLLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHLElBQUk7RUFDOUQsSUFBSSxJQUFJLE9BQU8sSUFBSyxTQUFTO0VBQzdCLElBQUksSUFBSSxPQUFPLElBQUk7RUFDbkIsSUFBSSxJQUFJLFFBQVEsS0FBTSxVQUFVLEtBQUssSUFBSSxRQUFRLElBQUssSUFBSTtFQUUxRCxRQUFRLEtBQUssSUFBSSxLQUFLO0VBRXRCLElBQUksTUFBTSxLQUFLLEtBQUssVUFBVSxVQUFVO0dBQ3RDLElBQUksTUFBTSxLQUFLLElBQUksSUFBSTtHQUN2QixJQUFJO0VBQ04sT0FBTztHQUNMLElBQUksS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxHQUFHO0dBQ3pDLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUc7SUFDckM7SUFDQSxLQUFLO0dBQ1A7R0FDQSxJQUFJLElBQUksU0FBUyxHQUNmLFNBQVMsS0FBSztRQUVkLFNBQVMsS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUs7R0FFckMsSUFBSSxRQUFRLEtBQUssR0FBRztJQUNsQjtJQUNBLEtBQUs7R0FDUDtHQUVBLElBQUksSUFBSSxTQUFTLE1BQU07SUFDckIsSUFBSTtJQUNKLElBQUk7R0FDTixPQUFPLElBQUksSUFBSSxTQUFTLEdBQUc7SUFDekIsS0FBTSxRQUFRLElBQUssS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJO0lBQ3hDLElBQUksSUFBSTtHQUNWLE9BQU87SUFDTCxJQUFJLFFBQVEsS0FBSyxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSTtJQUNyRCxJQUFJO0dBQ047RUFDRjtFQUVBLE9BQU8sUUFBUSxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksS0FBTSxLQUFLLEdBQUcsS0FBSyxLQUFLLFFBQVE7RUFFM0UsSUFBSyxLQUFLLE9BQVE7RUFDbEIsUUFBUTtFQUNSLE9BQU8sT0FBTyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksS0FBTSxLQUFLLEdBQUcsS0FBSyxLQUFLLFFBQVE7RUFFMUUsT0FBTyxTQUFTLElBQUksTUFBTSxJQUFJO0NBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRkEsU0FBUyxHQUFHLE9BQU87Q0FDZixPQUFPLElBQUksU0FBUyxNQUFNLFFBQVEsTUFBTSxVQUFVO0FBQ3REO0FBSUEsSUFBYSxRQUFRO0NBQ2pCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxTQUFTLE1BQU07Q0FDcEM7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLEdBQUcsS0FBSyxDQUFDLENBQUMsU0FBUyxRQUFRLEtBQUs7RUFDaEMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFlBQVk7Q0FDckIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFVBQVUsUUFBUSxJQUFJO0NBQzNDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFVBQVUsUUFBUSxPQUFPLElBQUk7RUFDdkMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFlBQVk7Q0FDckIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFVBQVUsTUFBTTtDQUNyQztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxVQUFVLFFBQVEsS0FBSztFQUNqQyxPQUFPLFNBQVM7Q0FDcEI7QUFDSjs7OztBQUlBLElBQWEsWUFBWTtDQUNyQixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixNQUFNLFdBQVcsR0FBRyxLQUFLO0VBQ3pCLE9BQU8sU0FBUyxTQUFTLE1BQU0sS0FBSyxTQUFTLFVBQVUsU0FBUyxHQUFHLElBQUksS0FBSztDQUNoRjtDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsTUFBTSxXQUFXLEdBQUcsS0FBSztFQUN6QixTQUFTLFNBQVMsUUFBUSxRQUFRLEdBQUk7RUFDdEMsU0FBUyxVQUFVLFNBQVMsR0FBRyxTQUFTLEdBQUcsSUFBSTtFQUMvQyxPQUFPLFNBQVM7Q0FDcEI7QUFDSjs7OztBQUlBLElBQWEsWUFBWTtDQUNyQixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixNQUFNLFdBQVcsR0FBRyxLQUFLO0VBQ3pCLFFBQVEsU0FBUyxVQUFVLE1BQU0sS0FBSyxLQUFLLFNBQVMsU0FBUyxTQUFTLENBQUM7Q0FDM0U7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLE1BQU0sV0FBVyxHQUFHLEtBQUs7RUFDekIsU0FBUyxVQUFVLFFBQVEsU0FBUyxDQUFDO0VBQ3JDLFNBQVMsU0FBUyxTQUFTLEdBQUcsUUFBUSxHQUFJO0VBQzFDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxZQUFZO0NBQ3JCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxVQUFVLFFBQVEsSUFBSTtDQUMzQztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxVQUFVLFFBQVEsT0FBTyxJQUFJO0VBQ3ZDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxZQUFZO0NBQ3JCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxVQUFVLE1BQU07Q0FDckM7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLEdBQUcsS0FBSyxDQUFDLENBQUMsVUFBVSxRQUFRLEtBQUs7RUFDakMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLE9BQU87Q0FDaEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFFBQVEsTUFBTTtDQUNuQztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFRLFFBQVEsS0FBSztFQUMvQixPQUFPLFNBQVM7Q0FDcEI7QUFDSjs7OztBQUlBLElBQWEsV0FBVztDQUNwQixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsU0FBUyxNQUFNO0NBQ3BDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUSxLQUFLO0VBQ2hDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxXQUFXO0NBQ3BCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxTQUFTLFFBQVEsSUFBSTtDQUMxQztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxTQUFTLFFBQVEsT0FBTyxJQUFJO0VBQ3RDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxXQUFXO0NBQ3BCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE1BQU0sV0FBVyxVQUFVLElBQUksT0FBTyxNQUFNO0VBQzVDLE9BQU8sV0FBVyxVQUFXLFdBQVcsV0FBWTtDQUN4RDtDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsTUFBTSxXQUFXLEdBQUcsS0FBSztFQUN6QixTQUFTLFNBQVMsUUFBUSxRQUFRLEdBQUk7RUFDdEMsU0FBUyxVQUFVLFNBQVMsR0FBRyxTQUFTLEdBQUcsSUFBSTtFQUMvQyxPQUFPLFNBQVM7Q0FDcEI7QUFDSjs7OztBQUlBLElBQWEsV0FBVztDQUNwQixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixNQUFNLFdBQVcsVUFBVSxJQUFJLE9BQU8sTUFBTTtFQUM1QyxPQUFPLFdBQVcsVUFBVyxXQUFXLFdBQVk7Q0FDeEQ7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLE1BQU0sV0FBVyxHQUFHLEtBQUs7RUFDekIsU0FBUyxVQUFVLFFBQVEsU0FBUyxDQUFDO0VBQ3JDLFNBQVMsU0FBUyxTQUFTLEdBQUcsUUFBUSxHQUFJO0VBQzFDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxXQUFXO0NBQ3BCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxTQUFTLE1BQU07Q0FDcEM7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLEdBQUcsS0FBSyxDQUFDLENBQUMsU0FBUyxRQUFRLEtBQUs7RUFDaEMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFdBQVc7Q0FDcEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUSxJQUFJO0NBQzFDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFNBQVMsUUFBUSxPQUFPLElBQUk7RUFDdEMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFlBQVk7Q0FDckIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLGFBQWEsUUFBUSxJQUFJO0NBQzlDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLGFBQWEsUUFBUSxPQUFPLElBQUk7RUFDMUMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFdBQVc7Q0FDcEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFlBQVksUUFBUSxJQUFJO0NBQzdDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFlBQVksUUFBUSxPQUFPLElBQUk7RUFDekMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLFlBQVk7Q0FDckIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLGFBQWEsTUFBTTtDQUN4QztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxhQUFhLFFBQVEsS0FBSztFQUNwQyxPQUFPLFNBQVM7Q0FDcEI7QUFDSjs7OztBQUlBLElBQWEsV0FBVztDQUNwQixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsWUFBWSxNQUFNO0NBQ3ZDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFlBQVksUUFBUSxLQUFLO0VBQ25DLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxhQUFhO0NBQ3RCLEtBQUs7Q0FDTCxJQUFJLFVBQVUsUUFBUTtFQUNsQixPQUFBLGVBQWUsS0FBSyxVQUFVLFFBQVEsT0FBTyxJQUFJLEtBQUssR0FBRztDQUM3RDtDQUNBLElBQUksVUFBVSxRQUFRLE9BQU87RUFDekIsZUFBUSxNQUFNLFVBQVUsT0FBTyxRQUFRLE9BQU8sSUFBSSxLQUFLLEdBQUc7RUFDMUQsT0FBTyxTQUFTLEtBQUs7Q0FDekI7QUFDSjs7OztBQUlBLElBQWEsYUFBYTtDQUN0QixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixPQUFBLGVBQWUsS0FBSyxPQUFPLFFBQVEsTUFBTSxJQUFJLEtBQUssR0FBRztDQUN6RDtDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsZUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDdEQsT0FBTyxTQUFTLEtBQUs7Q0FDekI7QUFDSjs7OztBQUlBLElBQWEsYUFBYTtDQUN0QixLQUFLO0NBQ0wsSUFBSSxPQUFPLFFBQVE7RUFDZixPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsV0FBVyxNQUFNO0NBQ3RDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFdBQVcsUUFBUSxLQUFLO0VBQ2xDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxhQUFhO0NBQ3RCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxXQUFXLFFBQVEsSUFBSTtDQUM1QztDQUNBLElBQUksT0FBTyxRQUFRLE9BQU87RUFDdEIsR0FBRyxLQUFLLENBQUMsQ0FBQyxXQUFXLFFBQVEsT0FBTyxJQUFJO0VBQ3hDLE9BQU8sU0FBUztDQUNwQjtBQUNKOzs7O0FBSUEsSUFBYSxhQUFhO0NBQ3RCLEtBQUs7Q0FDTCxJQUFJLE9BQU8sUUFBUTtFQUNmLE9BQU8sR0FBRyxLQUFLLENBQUMsQ0FBQyxXQUFXLE1BQU07Q0FDdEM7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLEdBQUcsS0FBSyxDQUFDLENBQUMsV0FBVyxRQUFRLEtBQUs7RUFDbEMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLGFBQWE7Q0FDdEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLFdBQVcsUUFBUSxJQUFJO0NBQzVDO0NBQ0EsSUFBSSxPQUFPLFFBQVEsT0FBTztFQUN0QixHQUFHLEtBQUssQ0FBQyxDQUFDLFdBQVcsUUFBUSxPQUFPLElBQUk7RUFDeEMsT0FBTyxTQUFTO0NBQ3BCO0FBQ0o7Ozs7QUFJQSxJQUFhLGFBQWE7Q0FDdEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBQSxlQUFlLEtBQUssT0FBTyxRQUFRLE9BQU8sSUFBSSxLQUFLLEdBQUc7Q0FDMUQ7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLGVBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxPQUFPLElBQUksS0FBSyxHQUFHO0VBQ3ZELE9BQU8sU0FBUyxLQUFLO0NBQ3pCO0FBQ0o7Ozs7QUFJQSxJQUFhLGFBQWE7Q0FDdEIsS0FBSztDQUNMLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBQSxlQUFlLEtBQUssT0FBTyxRQUFRLE1BQU0sSUFBSSxLQUFLLEdBQUc7Q0FDekQ7Q0FDQSxJQUFJLE9BQU8sUUFBUSxPQUFPO0VBQ3RCLGVBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxNQUFNLElBQUksS0FBSyxHQUFHO0VBQ3RELE9BQU8sU0FBUyxLQUFLO0NBQ3pCO0FBQ0o7Ozs7QUFJQSxJQUFhLGFBQWIsTUFBd0I7Ozs7Q0FJcEIsWUFBWSxLQUFLO0VBQ2IsS0FBSyxNQUFNO0NBQ2Y7Q0FFQSxJQUFJLFFBQVEsTUFBTSxDQUNsQjtBQUNKO0FBQ0EsSUFBYSxpQkFBYixNQUE0QjtDQUN4QixZQUFZLEtBQUs7RUFDYixLQUFLLE1BQU07Q0FDZjtDQUNBLElBQUksT0FBTyxRQUFRO0VBQ2YsT0FBTyxNQUFNLFNBQVMsUUFBUSxTQUFTLEtBQUssR0FBRztDQUNuRDtBQUNKOzs7OztBQUtBLElBQWEsYUFBYixNQUF3QjtDQUNwQixZQUFZLEtBQUssVUFBVTtFQUN2QixLQUFLLE1BQU07RUFDWCxLQUFLLFdBQVc7Q0FDcEI7Q0FDQSxJQUFJLE1BQU0sU0FBUyxHQUFHO0VBRWxCLE9BQU8sV0FETyxLQUFLLFNBQVMsUUFBUSxTQUFTLEtBQUssR0FDaEMsR0FBTyxLQUFLLFFBQVE7Q0FDMUM7QUFDSjs7Ozs7QUFLQSxJQUFhLGlCQUFiLGNBQW9DLFdBQVc7Q0FDM0MsWUFBWSxLQUFLO0VBQ2IsTUFBTSxLQUFLLGNBQWM7Q0FDN0I7QUFDSjs7QUNoWkEsSUFBYSxrQkFBa0IsU0FBUztDQUNwQyxPQUFPLE1BQU0sbUJBQW1CLE1BQU07RUFDbEM7RUFDQSxZQUFZLFNBQVM7R0FDakIsTUFBTSxPQUFPO0dBQ2IsS0FBSyxPQUFPO0VBQ2hCO0NBQ0o7QUFDSjtBQUVBLElBQWEsaUNBQWIsY0FBb0QsZUFBZSxnQ0FBZ0MsQ0FBQyxDQUFDLENBQ3JHO0FBRUEsSUFBYSwyQkFBYixjQUE4QyxlQUFlLDBCQUEwQixDQUFDLENBQUMsQ0FDekY7QUFFQSxJQUFhLDZCQUFiLGNBQWdELGVBQWUsNEJBQTRCLENBQUMsQ0FBQztDQUN6RjtDQUNBLFlBQVksVUFBVSxTQUFTO0VBQzNCLE1BQU0sT0FBTztFQUNiLEtBQUssV0FBVztDQUNwQjtDQUVBLFdBQVc7RUFDUCxPQUFPLEdBQUcsS0FBSyxLQUFLLGNBQWMsS0FBSyxTQUFTLEtBQUssS0FBSztDQUM5RDtBQUNKO0FBRUEsSUFBYSxxQkFBYixjQUF3QyxlQUFlLG9CQUFvQixDQUFDLENBQUMsQ0FDN0U7QUFDQSxJQUFhLHNCQUFiLGNBQXlDLGVBQWUscUJBQXFCLENBQUMsQ0FBQyxDQUMvRTtBQUVBLElBQWEsa0NBQWtDLGFBQWE7Q0FDeEQsT0FBTyxjQUFjLDJCQUEyQjtFQUM1QyxZQUFZLFNBQVM7R0FDakIsTUFBTSxVQUFVLE9BQU87RUFDM0I7Q0FDSjtBQUNKOztBQ3JDQSxJQUFNLDZCQUE2QjtBQUNuQyxJQUFhLDRCQUE0QjtBQUN6QyxJQUFhLHlCQUF5QjtBQUN0QyxJQUFNLGdCQUFnQjtBQUN0QixJQUFNLG1CQUFrQixZQUFXLElBQUksMkJBQTJCLFlBQVksT0FBTztBQUNyRixTQUFnQix1QkFBdUIsU0FBUztDQUM1QyxNQUFNLFFBQVEsUUFBUSx1QkFBdUI7Q0FDN0MsSUFBSSxDQUFDLE9BQU8sY0FBYyxLQUFLLEtBQUssU0FBUyxHQUN6QyxNQUFNLElBQUksV0FBVyxxREFBcUQ7Q0FFOUUsT0FBTztBQUNYOztBQUVBLFNBQWdCLHNCQUFzQixTQUFTO0NBQzNDLE1BQU0sUUFBUSxRQUFRLHNCQUFBO0NBQ3RCLElBQUksQ0FBQyxPQUFPLGNBQWMsS0FBSyxLQUFLLFNBQVMsR0FDekMsTUFBTSxJQUFJLFdBQVcsb0RBQW9EO0NBRTdFLE9BQU87QUFDWDs7QUFFQSxTQUFnQixtQkFBbUIsU0FBUztDQUN4QyxNQUFNLFFBQVEsUUFBUSxtQkFBQTtDQUN0QixJQUFJLENBQUMsT0FBTyxjQUFjLEtBQUssS0FBSyxTQUFTLEdBQ3pDLE1BQU0sSUFBSSxXQUFXLGlEQUFpRDtDQUUxRSxPQUFPO0FBQ1g7O0FBRUEsU0FBZ0Isb0JBQW9CLFNBQVMsVUFBVTtDQUNuRCxPQUFPO0VBQUUsZUFBZSx1QkFBdUIsT0FBTztFQUFHO0NBQVM7QUFDdEU7O0FBRUEsU0FBZ0IsbUJBQW1CLFFBQVEsU0FBUyxZQUFZLGlCQUFpQjtDQUM3RSxJQUFJLENBQUMsT0FBTyxjQUFjLE1BQU0sS0FBSyxTQUFTLEdBQzFDLE1BQU0sVUFBVSw0QkFBNEIsUUFBUTtDQUV4RCxNQUFNLFFBQVEsdUJBQXVCLE9BQU87Q0FDNUMsSUFBSSxTQUFTLE9BQ1QsTUFBTSxVQUFVLGlCQUFpQixPQUFPLDRCQUE0QixNQUFNLG1CQUFtQjtBQUVyRztBQUNBLFNBQVMsdUJBQXVCLFdBQVcsUUFBUSxVQUFVO0NBQ3pELElBQUksVUFBVSxTQUFTLFNBQVMsS0FBQSxLQUFhLFNBQVMsVUFBVSxTQUFTLE9BQU8sVUFDNUUsTUFBTSxJQUFJLGlCQUFpQjtBQUVuQzs7QUFFQSxlQUFzQixXQUFXLFdBQVcsUUFBUSxTQUFTLFdBQVcsVUFBVSxVQUFVLFlBQVksaUJBQWlCO0NBQ3JILG1CQUFtQixRQUFRLFNBQVMsU0FBUztDQUM3Qyx1QkFBdUIsV0FBVyxRQUFRLFFBQVE7Q0FDbEQsSUFBSSxDQUFDLHdCQUF3QixTQUFTLEtBQUssU0FBUyxlQUFlO0VBQy9ELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLEtBQUssSUFBSSxZQUFZLFFBQVEsWUFBWSxJQUFJO0dBQ3pDLE1BQU0sUUFBUSxJQUFJLFdBQVcsS0FBSyxJQUFJLFdBQVcsYUFBYSxDQUFDO0dBRS9ELElBQUksTUFEb0IsVUFBVSxXQUFXLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFDOUMsTUFBTSxRQUNwQixNQUFNLElBQUksaUJBQWlCO0dBRS9CLE9BQU8sS0FBSyxLQUFLO0dBQ2pCLGFBQWEsTUFBTTtHQUNuQixZQUFZLE1BQU07RUFDdEI7RUFDQSxNQUFNLFNBQVMsSUFBSSxXQUFXLE1BQU07RUFDcEMsSUFBSSxTQUFTO0VBQ2IsS0FBSyxNQUFNLFNBQVMsUUFBUTtHQUN4QixPQUFPLElBQUksT0FBTyxNQUFNO0dBQ3hCLFVBQVUsTUFBTTtFQUNwQjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sU0FBUyxJQUFJLFdBQVcsTUFBTTtDQUNwQyxJQUFLLE1BQU0sVUFBVSxXQUFXLFFBQVEsRUFBRSxTQUFTLENBQUMsTUFBTyxRQUN2RCxNQUFNLElBQUksaUJBQWlCO0NBRS9CLE9BQU87QUFDWDs7QUFFQSxlQUFzQixVQUFVLFdBQVcsT0FBTyxTQUFTLFdBQVcsVUFBVSxVQUFVLFlBQVksaUJBQWlCO0NBQ25ILG1CQUFtQixNQUFNLEtBQUssU0FBUyxTQUFTO0NBQ2hELHVCQUF1QixXQUFXLE1BQU0sS0FBSyxRQUFRO0NBQ3JELElBQUksTUFBTSxPQUFPLGVBQ2IsT0FBTyxVQUFVLFVBQVUsT0FBTyxRQUFRO0NBRTlDLE9BQU8sTUFBTSxJQUFJLE1BQU0sV0FBVyxXQUFXLE1BQU0sS0FBSyxTQUFTLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDNUY7O0FDdEZBLElBQWEsY0FBYixNQUF5QjtDQUNyQjtDQUNBO0NBQ0E7Ozs7Ozs7Q0FPQSxZQUFZLFVBQVUsV0FBVyxTQUFTO0VBQ3RDLHVCQUF1QixPQUFPO0VBQzlCLEtBQUssV0FBVztFQUNoQixLQUFLLFlBQVk7RUFDakIsS0FBSyxVQUFVO0NBQ25CO0NBQ0EsVUFBVSxPQUFPLFVBQVU7RUFDdkIsT0FBTyxVQUFVLEtBQUssV0FBVyxPQUFPLEtBQUssU0FBUyxRQUFRO0NBQ2xFO0FBQ0oiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMF19