import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SignUp.jsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { supabase } from "/src/lib/supabase.js";
import "/src/styles/SignUp.css";
import "/src/styles/SignUp.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignUp.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function SignUp() {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [message, setMessage] = useState("");
	const [username, setUsername] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		const { data: existing } = await supabase.from("users").select("user_name").eq("user_name", username);
		if (existing.length > 0) {
			setMessage("That username is taken.");
			return;
		}
		const { error } = await supabase.auth.signUp({
			email,
			password,
			options: { data: { user_name: username } }
		});
		if (error) {
			setMessage(error.message);
		} else {
			setMessage("Check your email to confirm your account.");
		}
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("form", {
		className: "signup-form",
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: "Create an account" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				type: "text",
				placeholder: "Username",
				value: username,
				onChange: (event) => setUsername(event.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				type: "email",
				placeholder: "Email",
				value: email,
				onChange: (event) => setEmail(event.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				type: "password",
				placeholder: "Password",
				value: password,
				onChange: (event) => setPassword(event.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				children: "Sign up"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 21
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 7
	}, this);
}
_s(SignUp, "7DUJ36wsv3Ta6KvmiztgN5LrgRw=");
_c = SignUp;
export default SignUp;
var _c;
$RefreshReg$(_c, "SignUp");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SignUp.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignUp.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignUp.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignUp.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTztBQUVQLE9BQU87Ozs7QUFFUCxTQUFTLFNBQVM7O0NBQ2QsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FFM0MsZUFBZSxhQUFhLE9BQU87RUFDL0IsTUFBTSxlQUFlO0VBRXJCLE1BQU0sRUFBRSxNQUFNLGFBQWEsTUFBTSxTQUNoQyxLQUFLLE9BQU8sQ0FBQyxDQUNiLE9BQU8sV0FBVyxDQUFDLENBQ25CLEdBQUcsYUFBYSxRQUFRO0VBRXpCLElBQUksU0FBUyxTQUFTLEdBQUc7R0FDekIsV0FBVyx5QkFBeUI7R0FDcEM7RUFDQTtFQUVBLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FBUyxLQUFLLE9BQU87R0FDekM7R0FDQTtHQUNBLFNBQVMsRUFBRSxNQUFPLEVBQUMsV0FBVyxTQUFTLEVBQUU7RUFDN0MsQ0FBQztFQUVMLElBQUksT0FBTztHQUNULFdBQVcsTUFBTSxPQUFPO0VBQzFCLE9BQU87R0FDTCxXQUFXLDJDQUEyQztFQUN4RDtDQUNGO0NBRUUsT0FDRSwrQ0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLFVBQVU7WUFBeEM7R0FDSSx3QkFBQyxNQUFELFlBQUksb0JBQXFCOzs7OztHQUU3Qix3QkFBQyxTQUFEO0lBQ0ksTUFBSztJQUNMLGFBQVk7SUFDWixPQUFPO0lBQ1AsV0FBVyxVQUFVLFlBQVksTUFBTSxPQUFPLEtBQUs7SUFDbkQ7R0FDSDs7Ozs7R0FFRCx3QkFBQyxTQUFEO0lBQ0UsTUFBSztJQUNMLGFBQVk7SUFDWixPQUFPO0lBQ1AsV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDaEQ7R0FDRDs7Ozs7R0FFRCx3QkFBQyxTQUFEO0lBQ0UsTUFBSztJQUNMLGFBQVk7SUFDWixPQUFPO0lBQ1AsV0FBVyxVQUFVLFlBQVksTUFBTSxPQUFPLEtBQUs7SUFDbkQ7R0FDRDs7Ozs7R0FFRCx3QkFBQyxVQUFEO0lBQVEsTUFBSztjQUFTO0dBQWU7Ozs7O0dBRXBDLFdBQVcsd0JBQUMsS0FBRCxZQUFJLFFBQVc7Ozs7O0VBQ3ZCOzs7OztVQUNOOzs7OztBQUVOOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZ25VcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiLi4vbGliL3N1cGFiYXNlXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9TaWduVXAuY3NzXCI7XHJcblxyXG5pbXBvcnQgXCIuLi9zdHlsZXMvU2lnblVwLmNzc1wiXHJcblxyXG5mdW5jdGlvbiBTaWduVXAoKSB7XHJcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZXZlbnQpIHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgICAgLmZyb20oXCJ1c2Vyc1wiKVxyXG4gICAgICAgIC5zZWxlY3QoXCJ1c2VyX25hbWVcIilcclxuICAgICAgICAuZXEoXCJ1c2VyX25hbWVcIiwgdXNlcm5hbWUpO1xyXG5cclxuICAgICAgICBpZiAoZXhpc3RpbmcubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldE1lc3NhZ2UoXCJUaGF0IHVzZXJuYW1lIGlzIHRha2VuLlwiKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcCh7XHJcbiAgICAgICAgICAgIGVtYWlsLFxyXG4gICAgICAgICAgICBwYXNzd29yZCxcclxuICAgICAgICAgICAgb3B0aW9uczogeyBkYXRhIDoge3VzZXJfbmFtZTogdXNlcm5hbWUgfSB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgIGlmIChlcnJvcikge1xyXG4gICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TWVzc2FnZShcIkNoZWNrIHlvdXIgZW1haWwgdG8gY29uZmlybSB5b3VyIGFjY291bnQuXCIpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNpZ251cC1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgIDxoMj5DcmVhdGUgYW4gYWNjb3VudDwvaDI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVXNlcm5hbWVcIlxyXG4gICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFVzZXJuYW1lKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbWFpbFwiXHJcbiAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFbWFpbChldmVudC50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBhc3N3b3JkXCJcclxuICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPlNpZ24gdXA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAge21lc3NhZ2UgJiYgPHA+e21lc3NhZ2V9PC9wPn1cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2lnblVwO1xyXG4iXX0=