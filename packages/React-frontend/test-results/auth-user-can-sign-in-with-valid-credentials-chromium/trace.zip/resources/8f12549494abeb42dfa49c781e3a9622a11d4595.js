import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MusicPlayer.jsx");const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=beb472b4";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import MusicControls from "/src/components/MusicControls.jsx";
import UploadProgress from "/src/components/UploadProgress.jsx";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicPlayer.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function MusicPlayer({ currentQueue, playOrder, playPosition, onFileUpload, uploadProgress, savedTracks, signedIn }) {
	_s();
	const audioRef = useRef(null);
	const [isPlaying, setIsPlaying] = useState(false);
	const [currentTime, setCurrentTime] = useState(0);
	const [duration, setDuration] = useState(0);
	const currentTrackIndex = playOrder[playPosition];
	const currentSong = currentQueue[currentTrackIndex];
	// useEffect(() => {
	//     setCurrentTime(0);
	//     setIsPlaying(false);
	// }, [selectedSong]);
	// function togglePlay() {
	//     if (!audioRef.current || !selectedSong) return;
	//     if (audioRef.current.paused) {
	//         audioRef.current.play();
	//     } else {
	//         audioRef.current.pause();
	//     }
	// }
	// function handlePlay() {
	//     if (selectedSong) {
	//         console.log(`Playing ${selectedSong.title}`);
	//     }
	// }
	// function seekSong(event) {
	//     const newTime = Number(event.target.value);
	//     if (!audioRef.current) return;
	//     audioRef.current.currentTime = newTime;
	//     setCurrentTime(newTime);
	// }
	function loadSavedTracks() {}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "player",
		children: currentSong && signedIn ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: currentSong.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("audio", {
				ref: audioRef,
				src: currentSong.audioUrl,
				onPlay: () => setIsPlaying(true),
				onPause: () => setIsPlaying(false),
				onTimeUpdate: () => setCurrentTime(audioRef.current.currentTime),
				onLoadedMetadata: () => setDuration(audioRef.current.duration)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: savedTracks }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 11
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
			/* @__PURE__ */ _jsxDEV("input", {
				type: "file",
				multiple: true,
				accept: "audio/*",
				onChange: onFileUpload,
				disabled: Boolean(uploadProgress)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 11
			}, this),
			uploadProgress && /* @__PURE__ */ _jsxDEV(UploadProgress, { ...uploadProgress }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 30
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "No song selected yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 11
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
}
_s(MusicPlayer, "UP11N+CbypWWBimLg1l474weVCA=");
_c = MusicPlayer;
export default MusicPlayer;
var _c;
$RefreshReg$(_c, "MusicPlayer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MusicPlayer.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicPlayer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicPlayer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicPlayer.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsUUFBUSxVQUFVLGlCQUFpQjtBQUM1QyxPQUFPLG1CQUFtQjtBQUMxQixPQUFPLG9CQUFvQjs7OztBQUUzQixTQUFTLFlBQVksRUFDbkIsY0FDQSxXQUNBLGNBQ0EsY0FDQSxnQkFDQSxhQUNBLFlBQ0M7O0NBQ0QsTUFBTSxXQUFXLE9BQU8sSUFBSTtDQUM1QixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUM7Q0FFMUMsTUFBTSxvQkFBb0IsVUFBVTtDQUNwQyxNQUFNLGNBQWMsYUFBYTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NqQyxTQUFTLGtCQUFrQixDQUFDO0NBRTVCLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDYixlQUFlLFdBQ2Q7R0FDRSx3QkFBQyxNQUFELFlBQUssWUFBWSxNQUFVOzs7OztHQUUzQix3QkFBQyxTQUFEO0lBQ0UsS0FBSztJQUNMLEtBQUssWUFBWTtJQUNqQixjQUFjLGFBQWEsSUFBSTtJQUMvQixlQUFlLGFBQWEsS0FBSztJQUNqQyxvQkFDRSxlQUFlLFNBQVMsUUFBUSxXQUFXO0lBRTdDLHdCQUNFLFlBQVksU0FBUyxRQUFRLFFBQVE7R0FFeEM7Ozs7O0dBRUQsd0JBQUMsT0FBRCxZQUFNLFlBQWlCOzs7OztFQUN2Qjs7OzthQUVGO0dBQ0Usd0JBQUMsU0FBRDtJQUNFLE1BQUs7SUFDTDtJQUNBLFFBQU87SUFDUCxVQUFVO0lBQ1YsVUFBVSxRQUFRLGNBQWM7R0FDakM7Ozs7O0dBQ0Esa0JBQWtCLHdCQUFDLGdCQUFELEVBQWdCLEdBQUksZUFBaUI7Ozs7O0dBQ3hELHdCQUFDLEtBQUQsWUFBRyx3QkFBd0I7Ozs7O0VBQzNCOzs7OztDQVVBOzs7OztBQUVWOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk11c2ljUGxheWVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE11c2ljQ29udHJvbHMgZnJvbSBcIi4vTXVzaWNDb250cm9sc1wiO1xyXG5pbXBvcnQgVXBsb2FkUHJvZ3Jlc3MgZnJvbSBcIi4vVXBsb2FkUHJvZ3Jlc3NcIjtcclxuXHJcbmZ1bmN0aW9uIE11c2ljUGxheWVyKHtcclxuICBjdXJyZW50UXVldWUsXHJcbiAgcGxheU9yZGVyLFxyXG4gIHBsYXlQb3NpdGlvbixcclxuICBvbkZpbGVVcGxvYWQsXHJcbiAgdXBsb2FkUHJvZ3Jlc3MsXHJcbiAgc2F2ZWRUcmFja3MsXHJcbiAgc2lnbmVkSW5cclxufSkge1xyXG4gIGNvbnN0IGF1ZGlvUmVmID0gdXNlUmVmKG51bGwpO1xyXG4gIGNvbnN0IFtpc1BsYXlpbmcsIHNldElzUGxheWluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRUaW1lLCBzZXRDdXJyZW50VGltZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbZHVyYXRpb24sIHNldER1cmF0aW9uXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBjdXJyZW50VHJhY2tJbmRleCA9IHBsYXlPcmRlcltwbGF5UG9zaXRpb25dO1xyXG4gIGNvbnN0IGN1cnJlbnRTb25nID0gY3VycmVudFF1ZXVlW2N1cnJlbnRUcmFja0luZGV4XTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgICAgc2V0Q3VycmVudFRpbWUoMCk7XHJcbiAgLy8gICAgIHNldElzUGxheWluZyhmYWxzZSk7XHJcbiAgLy8gfSwgW3NlbGVjdGVkU29uZ10pO1xyXG5cclxuICAvLyBmdW5jdGlvbiB0b2dnbGVQbGF5KCkge1xyXG4gIC8vICAgICBpZiAoIWF1ZGlvUmVmLmN1cnJlbnQgfHwgIXNlbGVjdGVkU29uZykgcmV0dXJuO1xyXG5cclxuICAvLyAgICAgaWYgKGF1ZGlvUmVmLmN1cnJlbnQucGF1c2VkKSB7XHJcbiAgLy8gICAgICAgICBhdWRpb1JlZi5jdXJyZW50LnBsYXkoKTtcclxuICAvLyAgICAgfSBlbHNlIHtcclxuICAvLyAgICAgICAgIGF1ZGlvUmVmLmN1cnJlbnQucGF1c2UoKTtcclxuICAvLyAgICAgfVxyXG4gIC8vIH1cclxuXHJcbiAgLy8gZnVuY3Rpb24gaGFuZGxlUGxheSgpIHtcclxuICAvLyAgICAgaWYgKHNlbGVjdGVkU29uZykge1xyXG4gIC8vICAgICAgICAgY29uc29sZS5sb2coYFBsYXlpbmcgJHtzZWxlY3RlZFNvbmcudGl0bGV9YCk7XHJcbiAgLy8gICAgIH1cclxuICAvLyB9XHJcblxyXG4gIC8vIGZ1bmN0aW9uIHNlZWtTb25nKGV2ZW50KSB7XHJcbiAgLy8gICAgIGNvbnN0IG5ld1RpbWUgPSBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuXHJcbiAgLy8gICAgIGlmICghYXVkaW9SZWYuY3VycmVudCkgcmV0dXJuO1xyXG5cclxuICAvLyAgICAgYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IG5ld1RpbWU7XHJcbiAgLy8gICAgIHNldEN1cnJlbnRUaW1lKG5ld1RpbWUpO1xyXG4gIC8vIH1cclxuXHJcbiAgZnVuY3Rpb24gbG9hZFNhdmVkVHJhY2tzKCkge31cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cInBsYXllclwiPlxyXG4gICAgICB7Y3VycmVudFNvbmcgJiYgc2lnbmVkSW4gPyAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxoMT57Y3VycmVudFNvbmcudGl0bGV9PC9oMT5cclxuXHJcbiAgICAgICAgICA8YXVkaW9cclxuICAgICAgICAgICAgcmVmPXthdWRpb1JlZn1cclxuICAgICAgICAgICAgc3JjPXtjdXJyZW50U29uZy5hdWRpb1VybH1cclxuICAgICAgICAgICAgb25QbGF5PXsoKSA9PiBzZXRJc1BsYXlpbmcodHJ1ZSl9XHJcbiAgICAgICAgICAgIG9uUGF1c2U9eygpID0+IHNldElzUGxheWluZyhmYWxzZSl9XHJcbiAgICAgICAgICAgIG9uVGltZVVwZGF0ZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRDdXJyZW50VGltZShhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9uTG9hZGVkTWV0YWRhdGE9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0RHVyYXRpb24oYXVkaW9SZWYuY3VycmVudC5kdXJhdGlvbilcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2PntzYXZlZFRyYWNrc308L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgbXVsdGlwbGVcclxuICAgICAgICAgICAgYWNjZXB0PVwiYXVkaW8vKlwiXHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkZpbGVVcGxvYWR9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtCb29sZWFuKHVwbG9hZFByb2dyZXNzKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7dXBsb2FkUHJvZ3Jlc3MgJiYgPFVwbG9hZFByb2dyZXNzIHsuLi51cGxvYWRQcm9ncmVzc30gLz59XHJcbiAgICAgICAgICA8cD5ObyBzb25nIHNlbGVjdGVkIHlldC48L3A+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPE11c2ljQ29udHJvbHNcclxuICAgICAgICAgICAgICAgIGlzUGxheWluZz17aXNQbGF5aW5nfVxyXG4gICAgICAgICAgICAgICAgY3VycmVudFRpbWU9e2N1cnJlbnRUaW1lfVxyXG4gICAgICAgICAgICAgICAgZHVyYXRpb249e2R1cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgb25Ub2dnbGVQbGF5PXt0b2dnbGVQbGF5fVxyXG4gICAgICAgICAgICAgICAgb25TZWVrPXtzZWVrU29uZ31cclxuICAgICAgICAgICAgLz4gKi99XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTXVzaWNQbGF5ZXI7XHJcbiJdfQ==