import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Avatar.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import "/src/styles/Socials.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Avatar.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
// Mid-tone colours that keep white initials readable in light and dark mode
const PALETTE = [
	"#e5484d",
	"#d6409f",
	"#8e4ec6",
	"#3e63dd",
	"#0d74ce",
	"#12a594",
	"#30a46c",
	"#dc6b19"
];
// Same user id always hashes to the same palette entry
function colourFor(userId) {
	let hash = 0;
	for (const char of userId ?? "") {
		hash = hash * 31 + char.charCodeAt(0) | 0;
	}
	return PALETTE[Math.abs(hash) % PALETTE.length];
}
function Avatar({ userName, userId }) {
	const initial = (userName ?? "?").charAt(0).toUpperCase();
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "avatar",
		style: { background: colourFor(userId) },
		"aria-hidden": "true",
		children: initial
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = Avatar;
export default Avatar;
var _c;
$RefreshReg$(_c, "Avatar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Avatar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Avatar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Avatar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Avatar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTzs7OztBQUdQLE1BQU0sVUFBVTtDQUNkO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjs7QUFHQSxTQUFTLFVBQVUsUUFBUTtDQUN6QixJQUFJLE9BQU87Q0FDWCxLQUFLLE1BQU0sUUFBUSxVQUFVLElBQUk7RUFDL0IsT0FBUSxPQUFPLEtBQUssS0FBSyxXQUFXLENBQUMsSUFBSztDQUM1QztDQUNBLE9BQU8sUUFBUSxLQUFLLElBQUksSUFBSSxJQUFJLFFBQVE7QUFDMUM7QUFFQSxTQUFTLE9BQU8sRUFBRSxVQUFVLFVBQVU7Q0FDcEMsTUFBTSxXQUFXLFlBQVksSUFBRyxDQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWTtDQUV4RCxPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFVO0VBQ1YsT0FBTyxFQUFFLFlBQVksVUFBVSxNQUFNLEVBQUU7RUFDdkMsZUFBWTtZQUNYO0NBQ0c7Ozs7O0FBRVY7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdmF0YXIuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9Tb2NpYWxzLmNzc1wiO1xyXG5cclxuLy8gTWlkLXRvbmUgY29sb3VycyB0aGF0IGtlZXAgd2hpdGUgaW5pdGlhbHMgcmVhZGFibGUgaW4gbGlnaHQgYW5kIGRhcmsgbW9kZVxyXG5jb25zdCBQQUxFVFRFID0gW1xyXG4gIFwiI2U1NDg0ZFwiLFxyXG4gIFwiI2Q2NDA5ZlwiLFxyXG4gIFwiIzhlNGVjNlwiLFxyXG4gIFwiIzNlNjNkZFwiLFxyXG4gIFwiIzBkNzRjZVwiLFxyXG4gIFwiIzEyYTU5NFwiLFxyXG4gIFwiIzMwYTQ2Y1wiLFxyXG4gIFwiI2RjNmIxOVwiXHJcbl07XHJcblxyXG4vLyBTYW1lIHVzZXIgaWQgYWx3YXlzIGhhc2hlcyB0byB0aGUgc2FtZSBwYWxldHRlIGVudHJ5XHJcbmZ1bmN0aW9uIGNvbG91ckZvcih1c2VySWQpIHtcclxuICBsZXQgaGFzaCA9IDA7XHJcbiAgZm9yIChjb25zdCBjaGFyIG9mIHVzZXJJZCA/PyBcIlwiKSB7XHJcbiAgICBoYXNoID0gKGhhc2ggKiAzMSArIGNoYXIuY2hhckNvZGVBdCgwKSkgfCAwO1xyXG4gIH1cclxuICByZXR1cm4gUEFMRVRURVtNYXRoLmFicyhoYXNoKSAlIFBBTEVUVEUubGVuZ3RoXTtcclxufVxyXG5cclxuZnVuY3Rpb24gQXZhdGFyKHsgdXNlck5hbWUsIHVzZXJJZCB9KSB7XHJcbiAgY29uc3QgaW5pdGlhbCA9ICh1c2VyTmFtZSA/PyBcIj9cIikuY2hhckF0KDApLnRvVXBwZXJDYXNlKCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9XCJhdmF0YXJcIlxyXG4gICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBjb2xvdXJGb3IodXNlcklkKSB9fVxyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAge2luaXRpYWx9XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXZhdGFyO1xyXG4iXX0=