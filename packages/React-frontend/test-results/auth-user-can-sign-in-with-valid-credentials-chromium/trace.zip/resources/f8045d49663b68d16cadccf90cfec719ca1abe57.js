import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PlaylistDetail.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { supabase } from "/src/lib/supabase.js";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/PlaylistDetail.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function PlaylistDetail({ playlist, onBack, onDeleted }) {
	_s();
	const [message, setMessage] = useState("");
	async function handleDelete() {
		if (!window.confirm(`Delete "${playlist.playlist_name}"?`)) return;
		const { error } = await supabase.from("playlists").delete().eq("playlist_id", playlist.playlist_id);
		if (error) {
			setMessage(error.message);
			return;
		}
		onDeleted(playlist.playlist_id);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: onBack,
			children: "Back"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: playlist.playlist_name }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", { children: [playlist.is_public ? "Public" : "Private", " playlist"] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", { children: "No songs yet." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: handleDelete,
			children: "Delete playlist"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this),
		message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 19
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_s(PlaylistDetail, "EiOGSxO4GWQlH0sM782nQ9JwuAs=");
_c = PlaylistDetail;
export default PlaylistDetail;
var _c;
$RefreshReg$(_c, "PlaylistDetail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PlaylistDetail.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/PlaylistDetail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/PlaylistDetail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/PlaylistDetail.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsU0FBUyxlQUFlLEVBQUUsVUFBVSxRQUFRLGFBQWE7O0NBQ3ZELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBRXpDLGVBQWUsZUFBZTtFQUM1QixJQUFJLENBQUMsT0FBTyxRQUFRLFdBQVcsU0FBUyxjQUFjLEdBQUcsR0FBRztFQUU1RCxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssV0FBVyxDQUFDLENBQ2pCLE9BQU8sQ0FBQyxDQUNSLEdBQUcsZUFBZSxTQUFTLFdBQVc7RUFFekMsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLFVBQVUsU0FBUyxXQUFXO0NBQ2hDO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsVUFBRDtHQUFRLFNBQVM7YUFBUTtFQUFZOzs7OztFQUVyQyx3QkFBQyxNQUFELFlBQUssU0FBUyxjQUFrQjs7Ozs7RUFDaEMsd0JBQUMsS0FBRCxhQUFJLFNBQVMsWUFBWSxXQUFXLFdBQVUsV0FBWTs7Ozs7RUFHMUQsd0JBQUMsS0FBRCxZQUFHLGdCQUFnQjs7Ozs7RUFFbkIsd0JBQUMsVUFBRDtHQUFRLFNBQVM7YUFBYztFQUF1Qjs7Ozs7RUFFckQsV0FBVyx3QkFBQyxLQUFELFlBQUksUUFBVzs7Ozs7Q0FDeEI7Ozs7O0FBRVQ7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUGxheWxpc3REZXRhaWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSBcIi4uL2xpYi9zdXBhYmFzZVwiO1xyXG5cclxuZnVuY3Rpb24gUGxheWxpc3REZXRhaWwoeyBwbGF5bGlzdCwgb25CYWNrLCBvbkRlbGV0ZWQgfSkge1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZWxldGUoKSB7XHJcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKGBEZWxldGUgXCIke3BsYXlsaXN0LnBsYXlsaXN0X25hbWV9XCI/YCkpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxyXG4gICAgICAuZnJvbShcInBsYXlsaXN0c1wiKVxyXG4gICAgICAuZGVsZXRlKClcclxuICAgICAgLmVxKFwicGxheWxpc3RfaWRcIiwgcGxheWxpc3QucGxheWxpc3RfaWQpO1xyXG5cclxuICAgIGlmIChlcnJvcikge1xyXG4gICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgb25EZWxldGVkKHBsYXlsaXN0LnBsYXlsaXN0X2lkKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQmFja30+QmFjazwvYnV0dG9uPlxyXG5cclxuICAgICAgPGgyPntwbGF5bGlzdC5wbGF5bGlzdF9uYW1lfTwvaDI+XHJcbiAgICAgIDxwPntwbGF5bGlzdC5pc19wdWJsaWMgPyBcIlB1YmxpY1wiIDogXCJQcml2YXRlXCJ9IHBsYXlsaXN0PC9wPlxyXG5cclxuICAgICAgey8qIFRPRE86IGxpc3QgdGhpcyBwbGF5bGlzdCdzIHNvbmdzIG9uY2UgdGhlIHNvbmdzIHRhYmxlIGlzIHNldCB1cCAqL31cclxuICAgICAgPHA+Tm8gc29uZ3MgeWV0LjwvcD5cclxuXHJcbiAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlRGVsZXRlfT5EZWxldGUgcGxheWxpc3Q8L2J1dHRvbj5cclxuXHJcbiAgICAgIHttZXNzYWdlICYmIDxwPnttZXNzYWdlfTwvcD59XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQbGF5bGlzdERldGFpbDtcclxuIl19