import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Socials.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { supabase } from "/src/lib/supabase.js";
import { fetchIncoming, fetchFriends, fetchBlocked, searchUsers, fetchSharedWithMe, saveToLibrary, dismissShare } from "/src/lib/socials.js";
import Avatar from "/src/components/Avatar.jsx";
import Chats from "/src/components/Chats.jsx";
import "/src/styles/Socials.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Socials.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
const SEARCH_DELAY_MS = 300;
// Postgres unique-violation code, e.g. a track already in user_tracks
const DUPLICATE_KEY = "23505";
function SectionHeading({ title, count, attention }) {
	return /* @__PURE__ */ _jsxDEV("h2", {
		className: "socials-heading",
		children: [title, /* @__PURE__ */ _jsxDEV("span", {
			className: attention ? "socials-count socials-count--attention" : "socials-count",
			children: count
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
}
_c = SectionHeading;
function Socials({ session: sessionProp }) {
	_s();
	// App.jsx doesn't pass session to this screen, so fall back to the client
	const [fetchedSession, setFetchedSession] = useState(null);
	const [query, setQuery] = useState("");
	const [results, setResults] = useState([]);
	const [searching, setSearching] = useState(false);
	const [incoming, setIncoming] = useState([]);
	const [friends, setFriends] = useState([]);
	const [blocked, setBlocked] = useState([]);
	const [shared, setShared] = useState([]);
	const [message, setMessage] = useState("");
	const [tab, setTab] = useState("friends");
	const session = sessionProp ?? fetchedSession;
	const userId = session?.user.id;
	useEffect(() => {
		if (sessionProp) return;
		supabase.auth.getSession().then(({ data }) => setFetchedSession(data.session));
	}, [sessionProp]);
	useEffect(() => {
		if (!userId) return;
		loadIncoming();
		loadFriends();
		loadBlocked();
		loadShared();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [userId]);
	// Debounced search: waits for typing to pause before querying
	useEffect(() => {
		const trimmed = query.trim();
		if (!userId || !trimmed) return;
		let cancelled = false;
		const timer = setTimeout(async () => {
			const { data, error } = await searchUsers(trimmed, userId);
			if (cancelled) return;
			setSearching(false);
			if (error) setMessage(error.message);
			else setResults(data);
		}, SEARCH_DELAY_MS);
		return () => {
			cancelled = true;
			clearTimeout(timer);
		};
	}, [query, userId]);
	// Loading starts on the keystroke; the effect above sends the query
	function handleQueryChange(value) {
		setQuery(value);
		if (value.trim()) {
			setSearching(true);
		} else {
			setResults([]);
			setSearching(false);
		}
	}
	async function loadIncoming() {
		const { data, error } = await fetchIncoming(userId);
		if (error) setMessage(error.message);
		else setIncoming(data);
	}
	async function loadFriends() {
		const { data, error } = await fetchFriends(userId);
		if (error) setMessage(error.message);
		else setFriends(data);
	}
	async function loadBlocked() {
		const { data, error } = await fetchBlocked(userId);
		if (error) setMessage(error.message);
		else setBlocked(data);
	}
	async function loadShared() {
		const { data, error } = await fetchSharedWithMe(userId);
		if (error) setMessage(error.message);
		else setShared(data);
	}
	async function handleSave(share) {
		const { error } = await saveToLibrary(userId, share.tracks.id);
		if (error?.code === DUPLICATE_KEY) {
			setMessage(`"${share.tracks.title}" is already saved.`);
			return;
		}
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage(`Saved "${share.tracks.title}" to your library.`);
	}
	async function handleDismiss(shareId) {
		const { error } = await dismissShare(shareId);
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadShared();
	}
	async function handleAdd(user) {
		const { error } = await supabase.from("friend").insert({
			user_id: userId,
			friend_id: user.user_id,
			status: "pending"
		});
		if (error) {
			setMessage(`Couldn't send a request to ${user.user_name}: ${error.message}`);
			return;
		}
		setMessage(`Friend request sent to ${user.user_name}.`);
	}
	async function handleAccept(requesterId) {
		const { error } = await supabase.rpc("accept_friend_request", { requester: requesterId });
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadIncoming();
		loadFriends();
	}
	async function handleDeny(requesterId) {
		const { error } = await supabase.rpc("deny_friend_request", { requester: requesterId });
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadIncoming();
	}
	async function handleRemove(friend) {
		const name = friend.users?.user_name;
		if (!window.confirm(`Remove ${name} from your friends?`)) return;
		const { error } = await supabase.rpc("remove_friend", { other: friend.friend_id });
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadFriends();
	}
	async function handleBlock(friend) {
		const name = friend.users?.user_name;
		if (!window.confirm(`Block ${name}?`)) return;
		const { error } = await supabase.rpc("block_user", { target: friend.friend_id });
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadFriends();
		loadIncoming();
		loadBlocked();
	}
	async function handleUnblock(blockedId) {
		const { error } = await supabase.from("blocked").delete().eq("user_id", userId).eq("blocked_id", blockedId);
		if (error) {
			setMessage(error.message);
			return;
		}
		setMessage("");
		loadBlocked();
	}
	if (!session) return /* @__PURE__ */ _jsxDEV("p", { children: "Loading…" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 262,
		columnNumber: 24
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "socials",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: "Socials" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "socials-tabs",
				role: "tablist",
				children: [["friends", "Friends"], ["chats", "Chats"]].map(([value, label]) => /* @__PURE__ */ _jsxDEV("button", {
					role: "tab",
					"aria-selected": tab === value,
					className: tab === value ? "socials-tab socials-tab--active" : "socials-tab",
					onClick: () => setTab(value),
					children: label
				}, value, false, {
					fileName: _jsxFileName,
					lineNumber: 273,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 268,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "socials-message",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 288,
				columnNumber: 19
			}, this),
			tab === "chats" ? /* @__PURE__ */ _jsxDEV(Chats, {
				userId,
				friends
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 291,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("section", {
					className: "socials-section",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "socials-heading",
							children: "Find people"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							className: "socials-search",
							type: "text",
							placeholder: "Search by username",
							value: query,
							onChange: (event) => handleQueryChange(event.target.value)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 296,
							columnNumber: 13
						}, this),
						searching && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: "Searching…"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 15
						}, this),
						!searching && query.trim() && results.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: [
								"No users match \"",
								query.trim(),
								"\""
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 17
						}, this),
						!searching && results.length > 0 && /* @__PURE__ */ _jsxDEV("ul", {
							className: "socials-list",
							children: results.map((user) => /* @__PURE__ */ _jsxDEV("li", {
								className: "socials-card",
								children: [
									/* @__PURE__ */ _jsxDEV(Avatar, {
										userName: user.user_name,
										userId: user.user_id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "socials-name",
										children: user.user_name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-actions",
										children: /* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button socials-button--primary",
											onClick: () => handleAdd(user),
											children: "Add friend"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 331,
										columnNumber: 21
									}, this)
								]
							}, user.user_id, true, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 319,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 294,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: incoming.length > 0 ? "socials-section socials-section--attention" : "socials-section",
					children: [
						/* @__PURE__ */ _jsxDEV(SectionHeading, {
							title: "Requests",
							count: incoming.length,
							attention: incoming.length > 0
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 350,
							columnNumber: 13
						}, this),
						incoming.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: "No pending requests"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "socials-list",
							children: incoming.map((request) => /* @__PURE__ */ _jsxDEV("li", {
								className: "socials-card",
								children: [
									/* @__PURE__ */ _jsxDEV(Avatar, {
										userName: request.users?.user_name,
										userId: request.user_id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 367,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "socials-name",
										children: [
											/* @__PURE__ */ _jsxDEV("strong", { children: request.users?.user_name }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 21
											}, this),
											" ",
											"wants to connect"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-actions",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button socials-button--primary",
											onClick: () => handleAccept(request.user_id),
											children: "Accept"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 376,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button",
											onClick: () => handleDeny(request.user_id),
											children: "Deny"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 383,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 375,
										columnNumber: 19
									}, this)
								]
							}, request.user_id, true, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 362,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 344,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "socials-section",
					children: [
						/* @__PURE__ */ _jsxDEV(SectionHeading, {
							title: "Shared with you",
							count: shared.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 397,
							columnNumber: 13
						}, this),
						shared.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: "Nothing shared with you yet"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 403,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "socials-list",
							children: shared.map((share) => /* @__PURE__ */ _jsxDEV("li", {
								className: "socials-card socials-card--share",
								children: [
									/* @__PURE__ */ _jsxDEV(Avatar, {
										userName: share.users?.user_name,
										userId: share.from_user
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-name share-details",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: [
											/* @__PURE__ */ _jsxDEV("strong", { children: share.users?.user_name }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 23
											}, this),
											" ",
											"shared ",
											share.tracks?.title,
											share.tracks?.artists && ` — ${share.tracks.artists}`
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 418,
											columnNumber: 21
										}, this), share.note && /* @__PURE__ */ _jsxDEV("span", {
											className: "share-note-text",
											children: [
												"\"",
												share.note,
												"\""
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 417,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-actions",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button socials-button--primary",
											onClick: () => handleSave(share),
											disabled: !share.tracks,
											children: "Save to library"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 431,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button",
											onClick: () => handleDismiss(share.id),
											children: "Dismiss"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 437,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 430,
										columnNumber: 19
									}, this)
								]
							}, share.id, true, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 408,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 396,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "socials-section",
					children: [
						/* @__PURE__ */ _jsxDEV(SectionHeading, {
							title: "Friends",
							count: friends.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 449,
							columnNumber: 13
						}, this),
						friends.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: "No friends yet — search for someone above"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 455,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "socials-list",
							children: friends.map((friend) => /* @__PURE__ */ _jsxDEV("li", {
								className: "socials-card",
								children: [
									/* @__PURE__ */ _jsxDEV(Avatar, {
										userName: friend.users?.user_name,
										userId: friend.friend_id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 465,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "socials-name",
										children: friend.users?.user_name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 469,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-actions",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button",
											onClick: () => handleRemove(friend),
											children: "Remove"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 473,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button socials-button--danger",
											onClick: () => handleBlock(friend),
											children: "Block"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 478,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 472,
										columnNumber: 19
									}, this)
								]
							}, friend.friend_id, true, {
								fileName: _jsxFileName,
								lineNumber: 462,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 460,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 448,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("section", {
					className: "socials-section",
					children: [
						/* @__PURE__ */ _jsxDEV(SectionHeading, {
							title: "Blocked",
							count: blocked.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 490,
							columnNumber: 13
						}, this),
						blocked.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "socials-empty",
							children: "You haven't blocked anyone"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 496,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "socials-list",
							children: blocked.map((entry) => /* @__PURE__ */ _jsxDEV("li", {
								className: "socials-card",
								children: [
									/* @__PURE__ */ _jsxDEV(Avatar, {
										userName: entry.users?.user_name,
										userId: entry.blocked_id
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 506,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "socials-name",
										children: entry.users?.user_name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 510,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "socials-actions",
										children: /* @__PURE__ */ _jsxDEV("button", {
											className: "socials-button",
											onClick: () => handleUnblock(entry.blocked_id),
											children: "Unblock"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 514,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 513,
										columnNumber: 19
									}, this)
								]
							}, entry.blocked_id, true, {
								fileName: _jsxFileName,
								lineNumber: 503,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 501,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 489,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 293,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 265,
		columnNumber: 5
	}, this);
}
_s(Socials, "lnwd105iRuq6+rXhOTRosZGxvLQ=");
_c2 = Socials;
export default Socials;
var _c, _c2;
$RefreshReg$(_c, "SectionHeading");
$RefreshReg$(_c2, "Socials");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Socials.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Socials.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Socials.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Socials.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLGdCQUFnQjtBQUN6QixTQUNFLGVBQ0EsY0FDQSxjQUNBLGFBQ0EsbUJBQ0EsZUFDQSxvQkFDSztBQUNQLE9BQU8sWUFBWTtBQUNuQixPQUFPLFdBQVc7QUFDbEIsT0FBTzs7OztBQUVQLE1BQU0sa0JBQWtCOztBQUd4QixNQUFNLGdCQUFnQjtBQUV0QixTQUFTLGVBQWUsRUFBRSxPQUFPLE9BQU8sYUFBYTtDQUNuRCxPQUNFLHdCQUFDLE1BQUQ7RUFBSSxXQUFVO1lBQWQsQ0FDRyxPQUNELHdCQUFDLFFBQUQ7R0FDRSxXQUNFLFlBQ0ksMkNBQ0E7YUFFTDtFQUNHOzs7O1VBQ0o7Ozs7OztBQUVSOztBQUVBLFNBQVMsUUFBUSxFQUFFLFNBQVMsZUFBZTs7O0NBRXpDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsSUFBSTtDQUN6RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0NBQ3pDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUMsQ0FBQztDQUMzQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0NBQ3pDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDLENBQUM7Q0FDekMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLENBQUMsQ0FBQztDQUN2QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsU0FBUztDQUV4QyxNQUFNLFVBQVUsZUFBZTtDQUMvQixNQUFNLFNBQVMsU0FBUyxLQUFLO0NBRTdCLGdCQUFnQjtFQUNkLElBQUksYUFBYTtFQUNqQixTQUFTLEtBQ04sV0FBVyxDQUFDLENBQ1osTUFBTSxFQUFFLFdBQVcsa0JBQWtCLEtBQUssT0FBTyxDQUFDO0NBQ3ZELEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFFBQVE7RUFDYixhQUFhO0VBQ2IsWUFBWTtFQUNaLFlBQVk7RUFDWixXQUFXOztDQUViLEdBQUcsQ0FBQyxNQUFNLENBQUM7O0NBR1gsZ0JBQWdCO0VBQ2QsTUFBTSxVQUFVLE1BQU0sS0FBSztFQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVM7RUFFekIsSUFBSSxZQUFZO0VBQ2hCLE1BQU0sUUFBUSxXQUFXLFlBQVk7R0FDbkMsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFlBQzVCLFNBQ0EsTUFDRjtHQUNBLElBQUksV0FBVztHQUNmLGFBQWEsS0FBSztHQUNsQixJQUFJLE9BQU8sV0FBVyxNQUFNLE9BQU87UUFDOUIsV0FBVyxJQUFJO0VBQ3RCLEdBQUcsZUFBZTtFQUVsQixhQUFhO0dBQ1gsWUFBWTtHQUNaLGFBQWEsS0FBSztFQUNwQjtDQUNGLEdBQUcsQ0FBQyxPQUFPLE1BQU0sQ0FBQzs7Q0FHbEIsU0FBUyxrQkFBa0IsT0FBTztFQUNoQyxTQUFTLEtBQUs7RUFDZCxJQUFJLE1BQU0sS0FBSyxHQUFHO0dBQ2hCLGFBQWEsSUFBSTtFQUNuQixPQUFPO0dBQ0wsV0FBVyxDQUFDLENBQUM7R0FDYixhQUFhLEtBQUs7RUFDcEI7Q0FDRjtDQUVBLGVBQWUsZUFBZTtFQUM1QixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sY0FBYyxNQUFNO0VBQ2xELElBQUksT0FBTyxXQUFXLE1BQU0sT0FBTztPQUM5QixZQUFZLElBQUk7Q0FDdkI7Q0FFQSxlQUFlLGNBQWM7RUFDM0IsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLGFBQWEsTUFBTTtFQUNqRCxJQUFJLE9BQU8sV0FBVyxNQUFNLE9BQU87T0FDOUIsV0FBVyxJQUFJO0NBQ3RCO0NBRUEsZUFBZSxjQUFjO0VBQzNCLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxhQUFhLE1BQU07RUFDakQsSUFBSSxPQUFPLFdBQVcsTUFBTSxPQUFPO09BQzlCLFdBQVcsSUFBSTtDQUN0QjtDQUVBLGVBQWUsYUFBYTtFQUMxQixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sa0JBQWtCLE1BQU07RUFDdEQsSUFBSSxPQUFPLFdBQVcsTUFBTSxPQUFPO09BQzlCLFVBQVUsSUFBSTtDQUNyQjtDQUVBLGVBQWUsV0FBVyxPQUFPO0VBQy9CLE1BQU0sRUFBRSxVQUFVLE1BQU0sY0FDdEIsUUFDQSxNQUFNLE9BQU8sRUFDZjtFQUVBLElBQUksT0FBTyxTQUFTLGVBQWU7R0FDakMsV0FBVyxJQUFJLE1BQU0sT0FBTyxNQUFNLG9CQUFvQjtHQUN0RDtFQUNGO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLFdBQ0UsVUFBVSxNQUFNLE9BQU8sTUFBTSxtQkFDL0I7Q0FDRjtDQUVBLGVBQWUsY0FBYyxTQUFTO0VBQ3BDLE1BQU0sRUFBRSxVQUFVLE1BQU0sYUFBYSxPQUFPO0VBRTVDLElBQUksT0FBTztHQUNULFdBQVcsTUFBTSxPQUFPO0dBQ3hCO0VBQ0Y7RUFFQSxXQUFXLEVBQUU7RUFDYixXQUFXO0NBQ2I7Q0FFQSxlQUFlLFVBQVUsTUFBTTtFQUM3QixNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQVMsS0FBSyxRQUFRLENBQUMsQ0FBQyxPQUFPO0dBQ3JELFNBQVM7R0FDVCxXQUFXLEtBQUs7R0FDaEIsUUFBUTtFQUNWLENBQUM7RUFFRCxJQUFJLE9BQU87R0FDVCxXQUNFLDhCQUE4QixLQUFLLFVBQVUsSUFBSSxNQUFNLFNBQ3pEO0dBQ0E7RUFDRjtFQUVBLFdBQVcsMEJBQTBCLEtBQUssVUFBVSxFQUFFO0NBQ3hEO0NBRUEsZUFBZSxhQUFhLGFBQWE7RUFDdkMsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUFTLElBQy9CLHlCQUNBLEVBQUUsV0FBVyxZQUFZLENBQzNCO0VBRUEsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLFdBQVcsRUFBRTtFQUNiLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FFQSxlQUFlLFdBQVcsYUFBYTtFQUNyQyxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQVMsSUFDL0IsdUJBQ0EsRUFDRSxXQUFXLFlBQ2IsQ0FDRjtFQUVBLElBQUksT0FBTztHQUNULFdBQVcsTUFBTSxPQUFPO0dBQ3hCO0VBQ0Y7RUFFQSxXQUFXLEVBQUU7RUFDYixhQUFhO0NBQ2Y7Q0FFQSxlQUFlLGFBQWEsUUFBUTtFQUNsQyxNQUFNLE9BQU8sT0FBTyxPQUFPO0VBQzNCLElBQUksQ0FBQyxPQUFPLFFBQVEsVUFBVSxLQUFLLG9CQUFvQixHQUNyRDtFQUVGLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FBUyxJQUFJLGlCQUFpQixFQUNwRCxPQUFPLE9BQU8sVUFDaEIsQ0FBQztFQUVELElBQUksT0FBTztHQUNULFdBQVcsTUFBTSxPQUFPO0dBQ3hCO0VBQ0Y7RUFFQSxXQUFXLEVBQUU7RUFDYixZQUFZO0NBQ2Q7Q0FFQSxlQUFlLFlBQVksUUFBUTtFQUNqQyxNQUFNLE9BQU8sT0FBTyxPQUFPO0VBQzNCLElBQUksQ0FBQyxPQUFPLFFBQVEsU0FBUyxLQUFLLEVBQUUsR0FBRztFQUV2QyxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQVMsSUFBSSxjQUFjLEVBQ2pELFFBQVEsT0FBTyxVQUNqQixDQUFDO0VBRUQsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLFdBQVcsRUFBRTtFQUNiLFlBQVk7RUFDWixhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBRUEsZUFBZSxjQUFjLFdBQVc7RUFDdEMsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUNyQixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU8sQ0FBQyxDQUNSLEdBQUcsV0FBVyxNQUFNLENBQUMsQ0FDckIsR0FBRyxjQUFjLFNBQVM7RUFFN0IsSUFBSSxPQUFPO0dBQ1QsV0FBVyxNQUFNLE9BQU87R0FDeEI7RUFDRjtFQUVBLFdBQVcsRUFBRTtFQUNiLFlBQVk7Q0FDZDtDQUVBLElBQUksQ0FBQyxTQUFTLE9BQU8sd0JBQUMsS0FBRCxZQUFHLFdBQVc7Ozs7O0NBRW5DLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7OztHQUVmLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWUsTUFBSztjQUNoQyxDQUNDLENBQUMsV0FBVyxTQUFTLEdBQ3JCLENBQUMsU0FBUyxPQUFPLENBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxXQUNiLHdCQUFDLFVBQUQ7S0FFRSxNQUFLO0tBQ0wsaUJBQWUsUUFBUTtLQUN2QixXQUNFLFFBQVEsUUFDSixvQ0FDQTtLQUVOLGVBQWUsT0FBTyxLQUFLO2VBQzFCO0lBQ0ssR0FWRDs7OztXQVVDLENBQ1Q7R0FDRTs7Ozs7R0FFSixXQUFXLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW1CO0dBQVc7Ozs7O0dBRXRELFFBQVEsVUFDUCx3QkFBQyxPQUFEO0lBQWU7SUFBaUI7R0FBVTs7OztjQUUxQztJQUNFLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWtCO01BQWU7Ozs7O01BQy9DLHdCQUFDLFNBQUQ7T0FDRSxXQUFVO09BQ1YsTUFBSztPQUNMLGFBQVk7T0FDWixPQUFPO09BQ1AsV0FBVyxVQUNULGtCQUFrQixNQUFNLE9BQU8sS0FBSztNQUV2Qzs7Ozs7TUFFQSxhQUNDLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQjtNQUFhOzs7OztNQUczQyxDQUFDLGFBQ0EsTUFBTSxLQUFLLEtBQ1gsUUFBUSxXQUFXLEtBQ2pCLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTZCO1FBQ1YsTUFBTSxLQUFLO1FBQUU7T0FDN0I7Ozs7OztNQUdOLENBQUMsYUFBYSxRQUFRLFNBQVMsS0FDOUIsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsUUFBUSxLQUFLLFNBQ1osd0JBQUMsTUFBRDtRQUNFLFdBQVU7a0JBRFo7U0FHRSx3QkFBQyxRQUFEO1VBQ0UsVUFBVSxLQUFLO1VBQ2YsUUFBUSxLQUFLO1NBQ2Q7Ozs7O1NBQ0Qsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsS0FBSztTQUNGOzs7OztTQUNOLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFVBQUQ7V0FDRSxXQUFVO1dBQ1YsZUFBZSxVQUFVLElBQUk7cUJBQUc7VUFFMUI7Ozs7O1NBQ0w7Ozs7O1FBQ0g7VUFmRyxLQUFLOzs7O2NBZVIsQ0FDTDtNQUNDOzs7OztLQUVDOzs7Ozs7SUFFVCx3QkFBQyxXQUFEO0tBQ0UsV0FDRSxTQUFTLFNBQVMsSUFDZCwrQ0FDQTtlQUpSO01BTUUsd0JBQUMsZ0JBQUQ7T0FDRSxPQUFNO09BQ04sT0FBTyxTQUFTO09BQ2hCLFdBQVcsU0FBUyxTQUFTO01BQzlCOzs7OztNQUVBLFNBQVMsV0FBVyxLQUNuQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBZ0I7TUFFMUI7Ozs7O01BR0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsU0FBUyxLQUFLLFlBQ2Isd0JBQUMsTUFBRDtRQUNFLFdBQVU7a0JBRFo7U0FHRSx3QkFBQyxRQUFEO1VBQ0UsVUFBVSxRQUFRLE9BQU87VUFDekIsUUFBUSxRQUFRO1NBQ2pCOzs7OztTQUNELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUNFLHdCQUFDLFVBQUQsWUFBUyxRQUFRLE9BQU8sVUFBa0I7Ozs7O1dBQUU7V0FBSTtVQUU1Qzs7Ozs7O1NBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsV0FBVTtXQUNWLGVBQ0UsYUFBYSxRQUFRLE9BQU87cUJBQzVCO1VBRUk7Ozs7b0JBQ1Isd0JBQUMsVUFBRDtXQUNFLFdBQVU7V0FDVixlQUNFLFdBQVcsUUFBUSxPQUFPO3FCQUMxQjtVQUVJOzs7O2tCQUNMOzs7Ozs7UUFDSDtVQXpCRyxRQUFROzs7O2NBeUJYLENBQ0w7TUFDQzs7Ozs7S0FDRzs7Ozs7O0lBRVQsd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBbkI7TUFDRSx3QkFBQyxnQkFBRDtPQUNFLE9BQU07T0FDTixPQUFPLE9BQU87TUFDZjs7Ozs7TUFFQSxPQUFPLFdBQVcsS0FDakIsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWdCO01BRTFCOzs7OztNQUdMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLE9BQU8sS0FBSyxVQUNYLHdCQUFDLE1BQUQ7UUFDRSxXQUFVO2tCQURaO1NBR0Usd0JBQUMsUUFBRDtVQUNFLFVBQVUsTUFBTSxPQUFPO1VBQ3ZCLFFBQVEsTUFBTTtTQUNmOzs7OztTQUNELHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUNFLHdCQUFDLFVBQUQsWUFBUyxNQUFNLE9BQU8sVUFBa0I7Ozs7O1dBQUU7V0FBSTtXQUN0QyxNQUFNLFFBQVE7V0FDckIsTUFBTSxRQUFRLFdBQ2IsTUFBTSxNQUFNLE9BQU87VUFDakI7Ozs7b0JBQ0wsTUFBTSxRQUNMLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUFrQztZQUM5QixNQUFNO1lBQUs7V0FDVDs7Ozs7a0JBRUw7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsVUFBRDtXQUNFLFdBQVU7V0FDVixlQUFlLFdBQVcsS0FBSztXQUMvQixVQUFVLENBQUMsTUFBTTtxQkFBUTtVQUVuQjs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsV0FBVTtXQUNWLGVBQWUsY0FBYyxNQUFNLEVBQUU7cUJBQUc7VUFFbEM7Ozs7a0JBQ0w7Ozs7OztRQUNIO1VBL0JHLE1BQU07Ozs7Y0ErQlQsQ0FDTDtNQUNDOzs7OztLQUNHOzs7Ozs7SUFFVCx3QkFBQyxXQUFEO0tBQVMsV0FBVTtlQUFuQjtNQUNFLHdCQUFDLGdCQUFEO09BQ0UsT0FBTTtPQUNOLE9BQU8sUUFBUTtNQUNoQjs7Ozs7TUFFQSxRQUFRLFdBQVcsS0FDbEIsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWdCO01BRTFCOzs7OztNQUdMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFFBQVEsS0FBSyxXQUNaLHdCQUFDLE1BQUQ7UUFDRSxXQUFVO2tCQURaO1NBR0Usd0JBQUMsUUFBRDtVQUNFLFVBQVUsT0FBTyxPQUFPO1VBQ3hCLFFBQVEsT0FBTztTQUNoQjs7Ozs7U0FDRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixPQUFPLE9BQU87U0FDWDs7Ozs7U0FDTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxXQUFVO1dBQ1YsZUFBZSxhQUFhLE1BQU07cUJBQUc7VUFFL0I7Ozs7b0JBQ1Isd0JBQUMsVUFBRDtXQUNFLFdBQVU7V0FDVixlQUFlLFlBQVksTUFBTTtxQkFBRztVQUU5Qjs7OztrQkFDTDs7Ozs7O1FBQ0g7VUFwQkcsT0FBTzs7OztjQW9CVixDQUNMO01BQ0M7Ozs7O0tBQ0c7Ozs7OztJQUVULHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQ0Usd0JBQUMsZ0JBQUQ7T0FDRSxPQUFNO09BQ04sT0FBTyxRQUFRO01BQ2hCOzs7OztNQUVBLFFBQVEsV0FBVyxLQUNsQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBZ0I7TUFFMUI7Ozs7O01BR0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsUUFBUSxLQUFLLFVBQ1osd0JBQUMsTUFBRDtRQUNFLFdBQVU7a0JBRFo7U0FHRSx3QkFBQyxRQUFEO1VBQ0UsVUFBVSxNQUFNLE9BQU87VUFDdkIsUUFBUSxNQUFNO1NBQ2Y7Ozs7O1NBQ0Qsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsTUFBTSxPQUFPO1NBQ1Y7Ozs7O1NBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsVUFBRDtXQUNFLFdBQVU7V0FDVixlQUNFLGNBQWMsTUFBTSxVQUFVO3FCQUM5QjtVQUVJOzs7OztTQUNMOzs7OztRQUNIO1VBakJHLE1BQU07Ozs7Y0FpQlQsQ0FDTDtNQUNDOzs7OztLQUNHOzs7Ozs7R0FDVDs7Ozs7RUFFRDs7Ozs7O0FBRVQ7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU29jaWFscy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCIuLi9saWIvc3VwYWJhc2VcIjtcclxuaW1wb3J0IHtcclxuICBmZXRjaEluY29taW5nLFxyXG4gIGZldGNoRnJpZW5kcyxcclxuICBmZXRjaEJsb2NrZWQsXHJcbiAgc2VhcmNoVXNlcnMsXHJcbiAgZmV0Y2hTaGFyZWRXaXRoTWUsXHJcbiAgc2F2ZVRvTGlicmFyeSxcclxuICBkaXNtaXNzU2hhcmVcclxufSBmcm9tIFwiLi4vbGliL3NvY2lhbHNcIjtcclxuaW1wb3J0IEF2YXRhciBmcm9tIFwiLi9BdmF0YXJcIjtcclxuaW1wb3J0IENoYXRzIGZyb20gXCIuL0NoYXRzXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9Tb2NpYWxzLmNzc1wiO1xyXG5cclxuY29uc3QgU0VBUkNIX0RFTEFZX01TID0gMzAwO1xyXG5cclxuLy8gUG9zdGdyZXMgdW5pcXVlLXZpb2xhdGlvbiBjb2RlLCBlLmcuIGEgdHJhY2sgYWxyZWFkeSBpbiB1c2VyX3RyYWNrc1xyXG5jb25zdCBEVVBMSUNBVEVfS0VZID0gXCIyMzUwNVwiO1xyXG5cclxuZnVuY3Rpb24gU2VjdGlvbkhlYWRpbmcoeyB0aXRsZSwgY291bnQsIGF0dGVudGlvbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxoMiBjbGFzc05hbWU9XCJzb2NpYWxzLWhlYWRpbmdcIj5cclxuICAgICAge3RpdGxlfVxyXG4gICAgICA8c3BhblxyXG4gICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICBhdHRlbnRpb25cclxuICAgICAgICAgICAgPyBcInNvY2lhbHMtY291bnQgc29jaWFscy1jb3VudC0tYXR0ZW50aW9uXCJcclxuICAgICAgICAgICAgOiBcInNvY2lhbHMtY291bnRcIlxyXG4gICAgICAgIH0+XHJcbiAgICAgICAge2NvdW50fVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L2gyPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFNvY2lhbHMoeyBzZXNzaW9uOiBzZXNzaW9uUHJvcCB9KSB7XHJcbiAgLy8gQXBwLmpzeCBkb2Vzbid0IHBhc3Mgc2Vzc2lvbiB0byB0aGlzIHNjcmVlbiwgc28gZmFsbCBiYWNrIHRvIHRoZSBjbGllbnRcclxuICBjb25zdCBbZmV0Y2hlZFNlc3Npb24sIHNldEZldGNoZWRTZXNzaW9uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Jlc3VsdHMsIHNldFJlc3VsdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hpbmcsIHNldFNlYXJjaGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2luY29taW5nLCBzZXRJbmNvbWluZ10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZyaWVuZHMsIHNldEZyaWVuZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtibG9ja2VkLCBzZXRCbG9ja2VkXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hhcmVkLCBzZXRTaGFyZWRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZShcImZyaWVuZHNcIik7XHJcblxyXG4gIGNvbnN0IHNlc3Npb24gPSBzZXNzaW9uUHJvcCA/PyBmZXRjaGVkU2Vzc2lvbjtcclxuICBjb25zdCB1c2VySWQgPSBzZXNzaW9uPy51c2VyLmlkO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlc3Npb25Qcm9wKSByZXR1cm47XHJcbiAgICBzdXBhYmFzZS5hdXRoXHJcbiAgICAgIC5nZXRTZXNzaW9uKClcclxuICAgICAgLnRoZW4oKHsgZGF0YSB9KSA9PiBzZXRGZXRjaGVkU2Vzc2lvbihkYXRhLnNlc3Npb24pKTtcclxuICB9LCBbc2Vzc2lvblByb3BdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghdXNlcklkKSByZXR1cm47XHJcbiAgICBsb2FkSW5jb21pbmcoKTtcclxuICAgIGxvYWRGcmllbmRzKCk7XHJcbiAgICBsb2FkQmxvY2tlZCgpO1xyXG4gICAgbG9hZFNoYXJlZCgpO1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFt1c2VySWRdKTtcclxuXHJcbiAgLy8gRGVib3VuY2VkIHNlYXJjaDogd2FpdHMgZm9yIHR5cGluZyB0byBwYXVzZSBiZWZvcmUgcXVlcnlpbmdcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdHJpbW1lZCA9IHF1ZXJ5LnRyaW0oKTtcclxuICAgIGlmICghdXNlcklkIHx8ICF0cmltbWVkKSByZXR1cm47XHJcblxyXG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xyXG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc2VhcmNoVXNlcnMoXHJcbiAgICAgICAgdHJpbW1lZCxcclxuICAgICAgICB1c2VySWRcclxuICAgICAgKTtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xyXG4gICAgICBzZXRTZWFyY2hpbmcoZmFsc2UpO1xyXG4gICAgICBpZiAoZXJyb3IpIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIGVsc2Ugc2V0UmVzdWx0cyhkYXRhKTtcclxuICAgIH0sIFNFQVJDSF9ERUxBWV9NUyk7XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcclxuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH07XHJcbiAgfSwgW3F1ZXJ5LCB1c2VySWRdKTtcclxuXHJcbiAgLy8gTG9hZGluZyBzdGFydHMgb24gdGhlIGtleXN0cm9rZTsgdGhlIGVmZmVjdCBhYm92ZSBzZW5kcyB0aGUgcXVlcnlcclxuICBmdW5jdGlvbiBoYW5kbGVRdWVyeUNoYW5nZSh2YWx1ZSkge1xyXG4gICAgc2V0UXVlcnkodmFsdWUpO1xyXG4gICAgaWYgKHZhbHVlLnRyaW0oKSkge1xyXG4gICAgICBzZXRTZWFyY2hpbmcodHJ1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRSZXN1bHRzKFtdKTtcclxuICAgICAgc2V0U2VhcmNoaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRJbmNvbWluZygpIHtcclxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGZldGNoSW5jb21pbmcodXNlcklkKTtcclxuICAgIGlmIChlcnJvcikgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgIGVsc2Ugc2V0SW5jb21pbmcoZGF0YSk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBsb2FkRnJpZW5kcygpIHtcclxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGZldGNoRnJpZW5kcyh1c2VySWQpO1xyXG4gICAgaWYgKGVycm9yKSBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgZWxzZSBzZXRGcmllbmRzKGRhdGEpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gbG9hZEJsb2NrZWQoKSB7XHJcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBmZXRjaEJsb2NrZWQodXNlcklkKTtcclxuICAgIGlmIChlcnJvcikgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgIGVsc2Ugc2V0QmxvY2tlZChkYXRhKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRTaGFyZWQoKSB7XHJcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBmZXRjaFNoYXJlZFdpdGhNZSh1c2VySWQpO1xyXG4gICAgaWYgKGVycm9yKSBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgZWxzZSBzZXRTaGFyZWQoZGF0YSk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTYXZlKHNoYXJlKSB7XHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzYXZlVG9MaWJyYXJ5KFxyXG4gICAgICB1c2VySWQsXHJcbiAgICAgIHNoYXJlLnRyYWNrcy5pZFxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoZXJyb3I/LmNvZGUgPT09IERVUExJQ0FURV9LRVkpIHtcclxuICAgICAgc2V0TWVzc2FnZShgXCIke3NoYXJlLnRyYWNrcy50aXRsZX1cIiBpcyBhbHJlYWR5IHNhdmVkLmApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1lc3NhZ2UoXHJcbiAgICAgIGBTYXZlZCBcIiR7c2hhcmUudHJhY2tzLnRpdGxlfVwiIHRvIHlvdXIgbGlicmFyeS5gXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRGlzbWlzcyhzaGFyZUlkKSB7XHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBkaXNtaXNzU2hhcmUoc2hhcmVJZCk7XHJcblxyXG4gICAgaWYgKGVycm9yKSB7XHJcbiAgICAgIHNldE1lc3NhZ2UoZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRNZXNzYWdlKFwiXCIpO1xyXG4gICAgbG9hZFNoYXJlZCgpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWRkKHVzZXIpIHtcclxuICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJmcmllbmRcIikuaW5zZXJ0KHtcclxuICAgICAgdXNlcl9pZDogdXNlcklkLFxyXG4gICAgICBmcmllbmRfaWQ6IHVzZXIudXNlcl9pZCxcclxuICAgICAgc3RhdHVzOiBcInBlbmRpbmdcIlxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKGVycm9yKSB7XHJcbiAgICAgIHNldE1lc3NhZ2UoXHJcbiAgICAgICAgYENvdWxkbid0IHNlbmQgYSByZXF1ZXN0IHRvICR7dXNlci51c2VyX25hbWV9OiAke2Vycm9yLm1lc3NhZ2V9YFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TWVzc2FnZShgRnJpZW5kIHJlcXVlc3Qgc2VudCB0byAke3VzZXIudXNlcl9uYW1lfS5gKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFjY2VwdChyZXF1ZXN0ZXJJZCkge1xyXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKFxyXG4gICAgICBcImFjY2VwdF9mcmllbmRfcmVxdWVzdFwiLFxyXG4gICAgICB7IHJlcXVlc3RlcjogcmVxdWVzdGVySWQgfVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcbiAgICBsb2FkSW5jb21pbmcoKTtcclxuICAgIGxvYWRGcmllbmRzKCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEZW55KHJlcXVlc3RlcklkKSB7XHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoXHJcbiAgICAgIFwiZGVueV9mcmllbmRfcmVxdWVzdFwiLFxyXG4gICAgICB7XHJcbiAgICAgICAgcmVxdWVzdGVyOiByZXF1ZXN0ZXJJZFxyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGlmIChlcnJvcikge1xyXG4gICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIGxvYWRJbmNvbWluZygpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlUmVtb3ZlKGZyaWVuZCkge1xyXG4gICAgY29uc3QgbmFtZSA9IGZyaWVuZC51c2Vycz8udXNlcl9uYW1lO1xyXG4gICAgaWYgKCF3aW5kb3cuY29uZmlybShgUmVtb3ZlICR7bmFtZX0gZnJvbSB5b3VyIGZyaWVuZHM/YCkpXHJcbiAgICAgIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoXCJyZW1vdmVfZnJpZW5kXCIsIHtcclxuICAgICAgb3RoZXI6IGZyaWVuZC5mcmllbmRfaWRcclxuICAgIH0pO1xyXG5cclxuICAgIGlmIChlcnJvcikge1xyXG4gICAgICBzZXRNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIGxvYWRGcmllbmRzKCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVCbG9jayhmcmllbmQpIHtcclxuICAgIGNvbnN0IG5hbWUgPSBmcmllbmQudXNlcnM/LnVzZXJfbmFtZTtcclxuICAgIGlmICghd2luZG93LmNvbmZpcm0oYEJsb2NrICR7bmFtZX0/YCkpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5ycGMoXCJibG9ja191c2VyXCIsIHtcclxuICAgICAgdGFyZ2V0OiBmcmllbmQuZnJpZW5kX2lkXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcbiAgICBsb2FkRnJpZW5kcygpO1xyXG4gICAgbG9hZEluY29taW5nKCk7XHJcbiAgICBsb2FkQmxvY2tlZCgpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlVW5ibG9jayhibG9ja2VkSWQpIHtcclxuICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXHJcbiAgICAgIC5mcm9tKFwiYmxvY2tlZFwiKVxyXG4gICAgICAuZGVsZXRlKClcclxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXHJcbiAgICAgIC5lcShcImJsb2NrZWRfaWRcIiwgYmxvY2tlZElkKTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcbiAgICBsb2FkQmxvY2tlZCgpO1xyXG4gIH1cclxuXHJcbiAgaWYgKCFzZXNzaW9uKSByZXR1cm4gPHA+TG9hZGluZ+KApjwvcD47XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbHNcIj5cclxuICAgICAgPGgyPlNvY2lhbHM8L2gyPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb2NpYWxzLXRhYnNcIiByb2xlPVwidGFibGlzdFwiPlxyXG4gICAgICAgIHtbXHJcbiAgICAgICAgICBbXCJmcmllbmRzXCIsIFwiRnJpZW5kc1wiXSxcclxuICAgICAgICAgIFtcImNoYXRzXCIsIFwiQ2hhdHNcIl1cclxuICAgICAgICBdLm1hcCgoW3ZhbHVlLCBsYWJlbF0pID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXt2YWx1ZX1cclxuICAgICAgICAgICAgcm9sZT1cInRhYlwiXHJcbiAgICAgICAgICAgIGFyaWEtc2VsZWN0ZWQ9e3RhYiA9PT0gdmFsdWV9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgdGFiID09PSB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgPyBcInNvY2lhbHMtdGFiIHNvY2lhbHMtdGFiLS1hY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgOiBcInNvY2lhbHMtdGFiXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWIodmFsdWUpfT5cclxuICAgICAgICAgICAge2xhYmVsfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge21lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwic29jaWFscy1tZXNzYWdlXCI+e21lc3NhZ2V9PC9wPn1cclxuXHJcbiAgICAgIHt0YWIgPT09IFwiY2hhdHNcIiA/IChcclxuICAgICAgICA8Q2hhdHMgdXNlcklkPXt1c2VySWR9IGZyaWVuZHM9e2ZyaWVuZHN9IC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNvY2lhbHMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwic29jaWFscy1oZWFkaW5nXCI+RmluZCBwZW9wbGU8L2gyPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLXNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IHVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cXVlcnl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgIGhhbmRsZVF1ZXJ5Q2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICB7c2VhcmNoaW5nICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLWVtcHR5XCI+U2VhcmNoaW5n4oCmPC9wPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgeyFzZWFyY2hpbmcgJiZcclxuICAgICAgICAgICAgICBxdWVyeS50cmltKCkgJiZcclxuICAgICAgICAgICAgICByZXN1bHRzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzb2NpYWxzLWVtcHR5XCI+XHJcbiAgICAgICAgICAgICAgICAgIE5vIHVzZXJzIG1hdGNoIFwie3F1ZXJ5LnRyaW0oKX1cIlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7IXNlYXJjaGluZyAmJiByZXN1bHRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzb2NpYWxzLWxpc3RcIj5cclxuICAgICAgICAgICAgICAgIHtyZXN1bHRzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17dXNlci51c2VyX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICA8QXZhdGFyXHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZT17dXNlci51c2VyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VySWQ9e3VzZXIudXNlcl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNvY2lhbHMtbmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIudXNlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbHMtYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvbiBzb2NpYWxzLWJ1dHRvbi0tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZCh1c2VyKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBmcmllbmRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgICA8c2VjdGlvblxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgIGluY29taW5nLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgID8gXCJzb2NpYWxzLXNlY3Rpb24gc29jaWFscy1zZWN0aW9uLS1hdHRlbnRpb25cIlxyXG4gICAgICAgICAgICAgICAgOiBcInNvY2lhbHMtc2VjdGlvblwiXHJcbiAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgIDxTZWN0aW9uSGVhZGluZ1xyXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVxdWVzdHNcIlxyXG4gICAgICAgICAgICAgIGNvdW50PXtpbmNvbWluZy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgYXR0ZW50aW9uPXtpbmNvbWluZy5sZW5ndGggPiAwfVxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAge2luY29taW5nLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic29jaWFscy1lbXB0eVwiPlxyXG4gICAgICAgICAgICAgICAgTm8gcGVuZGluZyByZXF1ZXN0c1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzb2NpYWxzLWxpc3RcIj5cclxuICAgICAgICAgICAgICB7aW5jb21pbmcubWFwKChyZXF1ZXN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic29jaWFscy1jYXJkXCJcclxuICAgICAgICAgICAgICAgICAga2V5PXtyZXF1ZXN0LnVzZXJfaWR9PlxyXG4gICAgICAgICAgICAgICAgICA8QXZhdGFyXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU9e3JlcXVlc3QudXNlcnM/LnVzZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICB1c2VySWQ9e3JlcXVlc3QudXNlcl9pZH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic29jaWFscy1uYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57cmVxdWVzdC51c2Vycz8udXNlcl9uYW1lfTwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB3YW50cyB0byBjb25uZWN0XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb2NpYWxzLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvbiBzb2NpYWxzLWJ1dHRvbi0tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBY2NlcHQocmVxdWVzdC51c2VyX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICAgICAgICAgIEFjY2VwdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbnkocmVxdWVzdC51c2VyX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICAgICAgICAgIERlbnlcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNvY2lhbHMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8U2VjdGlvbkhlYWRpbmdcclxuICAgICAgICAgICAgICB0aXRsZT1cIlNoYXJlZCB3aXRoIHlvdVwiXHJcbiAgICAgICAgICAgICAgY291bnQ9e3NoYXJlZC5sZW5ndGh9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICB7c2hhcmVkLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic29jaWFscy1lbXB0eVwiPlxyXG4gICAgICAgICAgICAgICAgTm90aGluZyBzaGFyZWQgd2l0aCB5b3UgeWV0XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNvY2lhbHMtbGlzdFwiPlxyXG4gICAgICAgICAgICAgIHtzaGFyZWQubWFwKChzaGFyZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtY2FyZCBzb2NpYWxzLWNhcmQtLXNoYXJlXCJcclxuICAgICAgICAgICAgICAgICAga2V5PXtzaGFyZS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZT17c2hhcmUudXNlcnM/LnVzZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICB1c2VySWQ9e3NoYXJlLmZyb21fdXNlcn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb2NpYWxzLW5hbWUgc2hhcmUtZGV0YWlsc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57c2hhcmUudXNlcnM/LnVzZXJfbmFtZX08L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaGFyZWQge3NoYXJlLnRyYWNrcz8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2hhcmUudHJhY2tzPy5hcnRpc3RzICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGAg4oCUICR7c2hhcmUudHJhY2tzLmFydGlzdHN9YH1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge3NoYXJlLm5vdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hhcmUtbm90ZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwie3NoYXJlLm5vdGV9XCJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb2NpYWxzLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvbiBzb2NpYWxzLWJ1dHRvbi0tcHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTYXZlKHNoYXJlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2hhcmUudHJhY2tzfT5cclxuICAgICAgICAgICAgICAgICAgICAgIFNhdmUgdG8gbGlicmFyeVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURpc21pc3Moc2hhcmUuaWQpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIERpc21pc3NcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNvY2lhbHMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8U2VjdGlvbkhlYWRpbmdcclxuICAgICAgICAgICAgICB0aXRsZT1cIkZyaWVuZHNcIlxyXG4gICAgICAgICAgICAgIGNvdW50PXtmcmllbmRzLmxlbmd0aH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIHtmcmllbmRzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic29jaWFscy1lbXB0eVwiPlxyXG4gICAgICAgICAgICAgICAgTm8gZnJpZW5kcyB5ZXQg4oCUIHNlYXJjaCBmb3Igc29tZW9uZSBhYm92ZVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzb2NpYWxzLWxpc3RcIj5cclxuICAgICAgICAgICAgICB7ZnJpZW5kcy5tYXAoKGZyaWVuZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgIGtleT17ZnJpZW5kLmZyaWVuZF9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZT17ZnJpZW5kLnVzZXJzPy51c2VyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcklkPXtmcmllbmQuZnJpZW5kX2lkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzb2NpYWxzLW5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZnJpZW5kLnVzZXJzPy51c2VyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb2NpYWxzLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmUoZnJpZW5kKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzb2NpYWxzLWJ1dHRvbiBzb2NpYWxzLWJ1dHRvbi0tZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJsb2NrKGZyaWVuZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmxvY2tcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNvY2lhbHMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8U2VjdGlvbkhlYWRpbmdcclxuICAgICAgICAgICAgICB0aXRsZT1cIkJsb2NrZWRcIlxyXG4gICAgICAgICAgICAgIGNvdW50PXtibG9ja2VkLmxlbmd0aH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIHtibG9ja2VkLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic29jaWFscy1lbXB0eVwiPlxyXG4gICAgICAgICAgICAgICAgWW91IGhhdmVuJ3QgYmxvY2tlZCBhbnlvbmVcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic29jaWFscy1saXN0XCI+XHJcbiAgICAgICAgICAgICAge2Jsb2NrZWQubWFwKChlbnRyeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNvY2lhbHMtY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgIGtleT17ZW50cnkuYmxvY2tlZF9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZT17ZW50cnkudXNlcnM/LnVzZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICB1c2VySWQ9e2VudHJ5LmJsb2NrZWRfaWR9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNvY2lhbHMtbmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbnRyeS51c2Vycz8udXNlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic29jaWFscy1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic29jaWFscy1idXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVW5ibG9jayhlbnRyeS5ibG9ja2VkX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICAgICAgICAgIFVuYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU29jaWFscztcclxuIl19