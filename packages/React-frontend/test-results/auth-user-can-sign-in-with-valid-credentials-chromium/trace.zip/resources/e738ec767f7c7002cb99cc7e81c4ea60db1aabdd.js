import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SignIn.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { supabase } from "/src/lib/supabase.js";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignIn.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function SignIn() {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [message, setMessage] = useState("");
	const [identifier, setIdentifier] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		let loginEmail = identifier;
		if (!identifier.includes("@")) {
			const { data, error: lookupError } = await supabase.rpc("email_for_username", { lookup_name: identifier });
			if (lookupError || !data) {
				setMessage("Invalid Login Credentials");
				return;
			}
			loginEmail = data;
		}
		const { error } = await supabase.auth.signInWithPassword({
			email: loginEmail,
			password
		});
		if (error) {
			setMessage(error.message);
		}
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "sign-in-page",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "sign-in-background",
			"aria-hidden": "true",
			children: /* @__PURE__ */ _jsxDEV("svg", {
				className: "background-svg",
				viewBox: "0 0 1000 600",
				children: [/* @__PURE__ */ _jsxDEV("defs", { children: /* @__PURE__ */ _jsxDEV("linearGradient", {
					id: "purple-blue-pink",
					children: [
						/* @__PURE__ */ _jsxDEV("stop", { stopColor: "#a855f7" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("stop", {
							offset: "0.5",
							stopColor: "#38bdf8"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("stop", {
							offset: "1",
							stopColor: "#ec4899"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 13
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("path", {
					className: "background-path",
					d: "M -100 300 C 150 80, 260 520, 500, 300 S 800 80, 1100 300"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "sign-in-card",
			children: /* @__PURE__ */ _jsxDEV("form", {
				className: "signup-form",
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: "Sign in" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Email/Username",
						value: identifier,
						onChange: (event) => setIdentifier(event.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "password",
						placeholder: "Password",
						value: password,
						onChange: (event) => setPassword(event.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						children: "Sign In"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this),
					message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 23
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
}
_s(SignIn, "YQPTy+RewEqxUUeD3sCxs3DGQTs=");
_c = SignIn;
export default SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SignIn.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignIn.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignIn.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/SignIn.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsU0FBUyxTQUFTOztDQUNoQixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBRS9DLGVBQWUsYUFBYSxPQUFPO0VBQ2pDLE1BQU0sZUFBZTtFQUVyQixJQUFJLGFBQWE7RUFFakIsSUFBSSxDQUFDLFdBQVcsU0FBUyxHQUFHLEdBQUc7R0FDN0IsTUFBTSxFQUFFLE1BQU0sT0FBTyxnQkFBZ0IsTUFBTSxTQUFTLElBQ2xELHNCQUNBLEVBQ0UsYUFBYSxXQUNmLENBQ0Y7R0FFQSxJQUFJLGVBQWUsQ0FBQyxNQUFNO0lBQ3hCLFdBQVcsMkJBQTJCO0lBQ3RDO0dBQ0Y7R0FFQSxhQUFhO0VBQ2Y7RUFFQSxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQVMsS0FBSyxtQkFBbUI7R0FDdkQsT0FBTztHQUNQO0VBQ0YsQ0FBQztFQUVELElBQUksT0FBTztHQUNULFdBQVcsTUFBTSxPQUFPO0VBQzFCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBcUIsZUFBWTthQUM5Qyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFpQixTQUFRO2NBQXhDLENBQ0Usd0JBQUMsUUFBRCxZQUNFLHdCQUFDLGtCQUFEO0tBQWdCLElBQUc7ZUFBbkI7TUFDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxVQUFXOzs7OztNQUMzQix3QkFBQyxRQUFEO09BQU0sUUFBTztPQUFNLFdBQVU7TUFBVzs7Ozs7TUFDeEMsd0JBQUMsUUFBRDtPQUFNLFFBQU87T0FBSSxXQUFVO01BQVc7Ozs7O0tBQ3hCOzs7OzthQUNaOzs7O2NBRU4sd0JBQUMsUUFBRDtLQUNFLFdBQVU7S0FDVixHQUFFO0lBQ0g7Ozs7WUFDRTs7Ozs7O0VBQ0Y7Ozs7WUFFTCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUNqQix3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFjLFVBQVU7Y0FBeEM7S0FDRSx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7S0FFZix3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVyxVQUNULGNBQWMsTUFBTSxPQUFPLEtBQUs7TUFFbEM7S0FDRDs7Ozs7S0FFRCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVyxVQUNULFlBQVksTUFBTSxPQUFPLEtBQUs7TUFFaEM7S0FDRDs7Ozs7S0FFRCx3QkFBQyxVQUFEO01BQVEsTUFBSztnQkFBUztLQUFlOzs7OztLQUVwQyxXQUFXLHdCQUFDLEtBQUQsWUFBSSxRQUFXOzs7OztJQUN2Qjs7Ozs7O0VBQ0M7Ozs7VUFDTDs7Ozs7O0FBRVY7OztBQUNBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2lnbkluLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCIuLi9saWIvc3VwYWJhc2VcIjtcclxuXHJcbmZ1bmN0aW9uIFNpZ25JbigpIHtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lkZW50aWZpZXIsIHNldElkZW50aWZpZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBsZXQgbG9naW5FbWFpbCA9IGlkZW50aWZpZXI7XHJcblxyXG4gICAgaWYgKCFpZGVudGlmaWVyLmluY2x1ZGVzKFwiQFwiKSkge1xyXG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yOiBsb29rdXBFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UucnBjKFxyXG4gICAgICAgIFwiZW1haWxfZm9yX3VzZXJuYW1lXCIsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbG9va3VwX25hbWU6IGlkZW50aWZpZXJcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcblxyXG4gICAgICBpZiAobG9va3VwRXJyb3IgfHwgIWRhdGEpIHtcclxuICAgICAgICBzZXRNZXNzYWdlKFwiSW52YWxpZCBMb2dpbiBDcmVkZW50aWFsc1wiKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxvZ2luRW1haWwgPSBkYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluV2l0aFBhc3N3b3JkKHtcclxuICAgICAgZW1haWw6IGxvZ2luRW1haWwsXHJcbiAgICAgIHBhc3N3b3JkXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgc2V0TWVzc2FnZShlcnJvci5tZXNzYWdlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJzaWduLWluLXBhZ2VcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWduLWluLWJhY2tncm91bmRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImJhY2tncm91bmQtc3ZnXCIgdmlld0JveD1cIjAgMCAxMDAwIDYwMFwiPlxyXG4gICAgICAgICAgPGRlZnM+XHJcbiAgICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cInB1cnBsZS1ibHVlLXBpbmtcIj5cclxuICAgICAgICAgICAgICA8c3RvcCBzdG9wQ29sb3I9XCIjYTg1NWY3XCIgLz5cclxuICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwLjVcIiBzdG9wQ29sb3I9XCIjMzhiZGY4XCIgLz5cclxuICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxXCIgc3RvcENvbG9yPVwiI2VjNDg5OVwiIC8+XHJcbiAgICAgICAgICAgIDwvbGluZWFyR3JhZGllbnQ+XHJcbiAgICAgICAgICA8L2RlZnM+XHJcblxyXG4gICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmFja2dyb3VuZC1wYXRoXCJcclxuICAgICAgICAgICAgZD1cIk0gLTEwMCAzMDAgQyAxNTAgODAsIDI2MCA1MjAsIDUwMCwgMzAwIFMgODAwIDgwLCAxMTAwIDMwMFwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInNpZ24taW4tY2FyZFwiPlxyXG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNpZ251cC1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICA8aDI+U2lnbiBpbjwvaDI+XHJcblxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbWFpbC9Vc2VybmFtZVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtpZGVudGlmaWVyfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgIHNldElkZW50aWZpZXIoZXZlbnQudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBhc3N3b3JkXCJcclxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5TaWduIEluPC9idXR0b24+XHJcblxyXG4gICAgICAgICAge21lc3NhZ2UgJiYgPHA+e21lc3NhZ2V9PC9wPn1cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcbmV4cG9ydCBkZWZhdWx0IFNpZ25JbjtcclxuIl19