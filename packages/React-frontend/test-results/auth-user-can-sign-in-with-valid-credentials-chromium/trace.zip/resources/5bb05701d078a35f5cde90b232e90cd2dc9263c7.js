import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MusicControls.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { ShuffleIcon, SkipBackIcon, RewindIcon, PlayIcon, PauseIcon, FastForwardIcon, SkipForwardIcon, RepeatIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import "/src/styles/MusicControls.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicControls.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
function MusicControls({ isPlaying, isShuffle, isRepeating, currentTime, duration, onTogglePlay, onSeek, onToggleSeekRight, onToggleSeekLeft, onToggleNext, onTogglePrevious, onToggleRepeat, onToggleShuffle }) {
	function formatTime(time) {
		if (!Number.isFinite(time)) return "0:00";
		const minutes = Math.floor(time / 60);
		const seconds = Math.floor(time % 60);
		return `${minutes}:${String(seconds).padStart(2, "0")}`;
	}
	// Percent of the song played, used by the CSS to fill the seek bar purple
	const progress = duration ? currentTime / duration * 100 : 0;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "mini-player",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "progress-row",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: formatTime(currentTime) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					className: "seek-bar",
					type: "range",
					min: "0",
					max: duration || 0,
					value: currentTime,
					onChange: onSeek,
					style: { "--progress": `${progress}%` }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: formatTime(duration) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "music-controls",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleShuffle,
					className: "shuffle-button",
					title: "Shuffle",
					children: /* @__PURE__ */ _jsxDEV(ShuffleIcon, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onTogglePrevious,
					title: "Previous",
					children: /* @__PURE__ */ _jsxDEV(SkipBackIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleSeekLeft,
					title: "Seek back",
					children: /* @__PURE__ */ _jsxDEV(RewindIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onTogglePlay,
					className: "play-button",
					title: isPlaying ? "Pause" : "Play",
					children: isPlaying ? /* @__PURE__ */ _jsxDEV(PauseIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 34
					}, this) : /* @__PURE__ */ _jsxDEV(PlayIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 74
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleSeekRight,
					title: "Seek forward",
					children: /* @__PURE__ */ _jsxDEV(FastForwardIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleNext,
					title: "Next",
					children: /* @__PURE__ */ _jsxDEV(SkipForwardIcon, {
						size: 22,
						weight: "fill"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleRepeat,
					className: "repeat-button",
					title: "Repeat",
					children: /* @__PURE__ */ _jsxDEV(RepeatIcon, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 9
	}, this);
}
_c = MusicControls;
export default MusicControls;
var _c;
$RefreshReg$(_c, "MusicControls");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MusicControls.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicControls.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicControls.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/MusicControls.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDSSxhQUNBLGNBQ0EsWUFDQSxVQUNBLFdBQ0EsaUJBQ0EsaUJBQ0Esa0JBQ0c7QUFDUCxPQUFPOzs7QUFFUCxTQUFTLGNBQWMsRUFDbkIsV0FDQSxXQUNBLGFBQ0EsYUFDQSxVQUNBLGNBQ0EsUUFDQSxtQkFDQSxrQkFDQSxjQUNBLGtCQUNBLGdCQUNBLG1CQUNEO0NBRUMsU0FBUyxXQUFXLE1BQU07RUFDdEIsSUFBSSxDQUFDLE9BQU8sU0FBUyxJQUFJLEdBQUcsT0FBTztFQUVuQyxNQUFNLFVBQVUsS0FBSyxNQUFNLE9BQU8sRUFBRTtFQUNwQyxNQUFNLFVBQVUsS0FBSyxNQUFNLE9BQU8sRUFBRTtFQUVwQyxPQUFPLEdBQUcsUUFBUSxHQUFHLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDeEQ7O0NBR0EsTUFBTSxXQUFXLFdBQVksY0FBYyxXQUFZLE1BQU07Q0FFN0QsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0ksd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLE9BQUQsWUFBTSxXQUFXLFdBQVcsRUFBTzs7Ozs7SUFDbkMsd0JBQUMsU0FBRDtLQUNJLFdBQVU7S0FDVixNQUFLO0tBQ0wsS0FBSTtLQUNKLEtBQUssWUFBWTtLQUNqQixPQUFPO0tBQ1AsVUFBVTtLQUNWLE9BQU8sRUFBRSxjQUFjLEdBQUcsU0FBUyxHQUFHO0lBQ3pDOzs7OztJQUNELHdCQUFDLE9BQUQsWUFBTSxXQUFXLFFBQVEsRUFBTzs7Ozs7R0FDL0I7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLFVBQUQ7S0FBUSxTQUFTO0tBQWlCLFdBQVU7S0FBaUIsT0FBTTtlQUMvRCx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztJQUNwQjs7Ozs7SUFDUix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFrQixPQUFNO2VBQ3JDLHdCQUFDLGNBQUQ7TUFBYyxNQUFNO01BQUksUUFBTztLQUFROzs7OztJQUNuQzs7Ozs7SUFDUix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFrQixPQUFNO2VBQ3JDLHdCQUFDLFlBQUQ7TUFBWSxNQUFNO01BQUksUUFBTztLQUFROzs7OztJQUNqQzs7Ozs7SUFDUix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFjLFdBQVU7S0FBYyxPQUFPLFlBQVksVUFBVTtlQUMvRSxZQUFZLHdCQUFDLFdBQUQ7TUFBVyxNQUFNO01BQUksUUFBTztLQUFROzs7O2dCQUFJLHdCQUFDLFVBQUQ7TUFBVSxNQUFNO01BQUksUUFBTztLQUFROzs7OztJQUNwRjs7Ozs7SUFDUix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFtQixPQUFNO2VBQ3RDLHdCQUFDLGlCQUFEO01BQWlCLE1BQU07TUFBSSxRQUFPO0tBQVE7Ozs7O0lBQ3RDOzs7OztJQUNSLHdCQUFDLFVBQUQ7S0FBUSxTQUFTO0tBQWMsT0FBTTtlQUNqQyx3QkFBQyxpQkFBRDtNQUFpQixNQUFNO01BQUksUUFBTztLQUFROzs7OztJQUN0Qzs7Ozs7SUFDUix3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFnQixXQUFVO0tBQWdCLE9BQU07ZUFDN0Qsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7Ozs7SUFDbkI7Ozs7O0dBQ1A7Ozs7O1VBQ0o7Ozs7OztBQUdiOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTXVzaWNDb250cm9scy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIFNodWZmbGVJY29uLFxyXG4gICAgU2tpcEJhY2tJY29uLFxyXG4gICAgUmV3aW5kSWNvbixcclxuICAgIFBsYXlJY29uLFxyXG4gICAgUGF1c2VJY29uLFxyXG4gICAgRmFzdEZvcndhcmRJY29uLFxyXG4gICAgU2tpcEZvcndhcmRJY29uLFxyXG4gICAgUmVwZWF0SWNvbixcclxufSBmcm9tIFwiQHBob3NwaG9yLWljb25zL3JlYWN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9NdXNpY0NvbnRyb2xzLmNzc1wiO1xyXG5cclxuZnVuY3Rpb24gTXVzaWNDb250cm9scyh7XHJcbiAgICBpc1BsYXlpbmcsXHJcbiAgICBpc1NodWZmbGUsXHJcbiAgICBpc1JlcGVhdGluZyxcclxuICAgIGN1cnJlbnRUaW1lLFxyXG4gICAgZHVyYXRpb24sXHJcbiAgICBvblRvZ2dsZVBsYXksXHJcbiAgICBvblNlZWssXHJcbiAgICBvblRvZ2dsZVNlZWtSaWdodCxcclxuICAgIG9uVG9nZ2xlU2Vla0xlZnQsXHJcbiAgICBvblRvZ2dsZU5leHQsXHJcbiAgICBvblRvZ2dsZVByZXZpb3VzLFxyXG4gICAgb25Ub2dnbGVSZXBlYXQsXHJcbiAgICBvblRvZ2dsZVNodWZmbGUsXHJcbn0pIHtcclxuXHJcbiAgICBmdW5jdGlvbiBmb3JtYXRUaW1lKHRpbWUpIHtcclxuICAgICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh0aW1lKSkgcmV0dXJuIFwiMDowMFwiO1xyXG5cclxuICAgICAgICBjb25zdCBtaW51dGVzID0gTWF0aC5mbG9vcih0aW1lIC8gNjApO1xyXG4gICAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLmZsb29yKHRpbWUgJSA2MCk7XHJcblxyXG4gICAgICAgIHJldHVybiBgJHttaW51dGVzfToke1N0cmluZyhzZWNvbmRzKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBQZXJjZW50IG9mIHRoZSBzb25nIHBsYXllZCwgdXNlZCBieSB0aGUgQ1NTIHRvIGZpbGwgdGhlIHNlZWsgYmFyIHB1cnBsZVxyXG4gICAgY29uc3QgcHJvZ3Jlc3MgPSBkdXJhdGlvbiA/IChjdXJyZW50VGltZSAvIGR1cmF0aW9uKSAqIDEwMCA6IDA7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbmktcGxheWVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3Mtcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2Pntmb3JtYXRUaW1lKGN1cnJlbnRUaW1lKX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNlZWstYmFyXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1heD17ZHVyYXRpb24gfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFRpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e29uU2Vla31cclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBcIi0tcHJvZ3Jlc3NcIjogYCR7cHJvZ3Jlc3N9JWAgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2Pntmb3JtYXRUaW1lKGR1cmF0aW9uKX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdXNpYy1jb250cm9sc1wiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvblRvZ2dsZVNodWZmbGV9IGNsYXNzTmFtZT1cInNodWZmbGUtYnV0dG9uXCIgdGl0bGU9XCJTaHVmZmxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNodWZmbGVJY29uIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uVG9nZ2xlUHJldmlvdXN9IHRpdGxlPVwiUHJldmlvdXNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2tpcEJhY2tJY29uIHNpemU9ezIyfSB3ZWlnaHQ9XCJmaWxsXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvblRvZ2dsZVNlZWtMZWZ0fSB0aXRsZT1cIlNlZWsgYmFja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSZXdpbmRJY29uIHNpemU9ezIyfSB3ZWlnaHQ9XCJmaWxsXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvblRvZ2dsZVBsYXl9IGNsYXNzTmFtZT1cInBsYXktYnV0dG9uXCIgdGl0bGU9e2lzUGxheWluZyA/IFwiUGF1c2VcIiA6IFwiUGxheVwifT5cclxuICAgICAgICAgICAgICAgICAgICB7aXNQbGF5aW5nID8gPFBhdXNlSWNvbiBzaXplPXsyMn0gd2VpZ2h0PVwiZmlsbFwiIC8+IDogPFBsYXlJY29uIHNpemU9ezIyfSB3ZWlnaHQ9XCJmaWxsXCIgLz59XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25Ub2dnbGVTZWVrUmlnaHR9IHRpdGxlPVwiU2VlayBmb3J3YXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhc3RGb3J3YXJkSWNvbiBzaXplPXsyMn0gd2VpZ2h0PVwiZmlsbFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25Ub2dnbGVOZXh0fSB0aXRsZT1cIk5leHRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2tpcEZvcndhcmRJY29uIHNpemU9ezIyfSB3ZWlnaHQ9XCJmaWxsXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvblRvZ2dsZVJlcGVhdH0gY2xhc3NOYW1lPVwicmVwZWF0LWJ1dHRvblwiIHRpdGxlPVwiUmVwZWF0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJlcGVhdEljb24gc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNdXNpY0NvbnRyb2xzOyJdfQ==