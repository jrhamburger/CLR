import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Home.jsx");const useState = __vite__cjsImport2_react["useState"]; const useEffect = __vite__cjsImport2_react["useEffect"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { getUserTracks } from "/@fs/C:/Users/resen/cs-3100-stuff/CLR/packages/Express-backend/src/api/library.js";
import { supabase } from "/src/lib/supabase.js";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=45fd8ac1";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=beb472b4";
import { ShareNetworkIcon } from "/node_modules/.vite/deps/@phosphor-icons_react.js?v=880a9414";
import ShareTrackDialog from "/src/components/ShareTrackDialog.jsx";
import "/src/styles/Home.css";
var _jsxFileName = "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Home.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=45fd8ac1";
var _s = $RefreshSig$();
function Home({ session, onStartQueue }) {
	_s();
	const [username, setUsername] = useState("");
	const [tracks, setTracks] = useState([]);
	const [trackMessage, setTrackMessage] = useState("");
	const [rotations, setRotations] = useState({});
	const [sharing, setSharing] = useState(null);
	//Fetching the Username from personal.users.username
	useEffect(() => {
		supabase.from("users").select("user_name").eq("user_id", session.user.id).single().then(({ data }) => setUsername(data?.user_name ?? ""));
	}, [session]);
	// Fetches the tracks that the user owns
	useEffect(() => {
		async function loadTracks() {
			try {
				const userTracks = await getUserTracks(session.access_token);
				setTracks(userTracks);
			} catch (error) {
				setTrackMessage(error.message);
			}
		}
		loadTracks();
	}, [session]);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: ["Welcome, ", username] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: "Home" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", { children: [
			/* @__PURE__ */ _jsxDEV("h3", { children: "Your Music" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 9
			}, this),
			tracks.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "You have not uploaded any tracks yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "track-grid",
				children: tracks.map((track, index) => /* @__PURE__ */ _jsxDEV(
					"div",
					// Share sits beside the card because buttons can't nest
					{
						className: "track-card-wrapper",
						children: [/* @__PURE__ */ _jsxDEV(motion.button, {
							className: "track-card",
							type: "button",
							initial: {
								opacity: 0,
								y: 30
							},
							animate: {
								opacity: 1,
								y: 0,
								rotateY: rotations[track.id] || 0
							},
							transition: {
								type: "spring",
								stiffness: 100,
								damping: 15
							},
							whileHover: {
								y: -10,
								scale: 1.04,
								rotateY: 360
							},
							whileTap: {
								scale: .95,
								y: 4,
								transition: {
									type: "spring",
									duration: .1,
									bounce: 0
								}
							},
							onClick: () => onStartQueue(tracks, index),
							children: [
								/* @__PURE__ */ _jsxDEV("img", {
									src: track.coverArtUrl,
									alt: `${track.title} cover art`,
									className: "user-track-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 89,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: track.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: track.artists }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "track-share",
							type: "button",
							title: "Share with a friend",
							onClick: () => setSharing(track),
							children: /* @__PURE__ */ _jsxDEV(ShareNetworkIcon, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 15
						}, this)]
					},
					track.id,
					true,
					{
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					},
					this
				))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 9
			}, this),
			trackMessage && /* @__PURE__ */ _jsxDEV("p", { children: trackMessage }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 26
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this),
		sharing && /* @__PURE__ */ _jsxDEV(ShareTrackDialog, {
			session,
			track: sharing,
			onClose: (shared) => {
				if (shared) setTrackMessage(`Shared "${sharing.title}".`);
				setSharing(null);
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_s(Home, "Bc3imveWv1cSGPTgybYIcARtnvM=");
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Home.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/resen/cs-3100-stuff/CLR/packages/React-frontend/src/components/Home.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyx3QkFBd0I7QUFDakMsT0FBTyxzQkFBc0I7QUFFN0IsT0FBTzs7OztBQUVQLFNBQVMsS0FBSyxFQUFFLFNBQVMsZ0JBQWdCOztDQUN2QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJOztDQUczQyxnQkFBZ0I7RUFDZCxTQUNHLEtBQUssT0FBTyxDQUFDLENBQ2IsT0FBTyxXQUFXLENBQUMsQ0FDbkIsR0FBRyxXQUFXLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FDOUIsT0FBTyxDQUFDLENBQ1IsTUFBTSxFQUFFLFdBQVcsWUFBWSxNQUFNLGFBQWEsRUFBRSxDQUFDO0NBQzFELEdBQUcsQ0FBQyxPQUFPLENBQUM7O0NBR1osZ0JBQWdCO0VBQ2QsZUFBZSxhQUFhO0dBQzFCLElBQUk7SUFDRixNQUFNLGFBQWEsTUFBTSxjQUN2QixRQUFRLFlBQ1Y7SUFDQSxVQUFVLFVBQVU7R0FDdEIsU0FBUyxPQUFPO0lBQ2QsZ0JBQWdCLE1BQU0sT0FBTztHQUMvQjtFQUNGO0VBRUEsV0FBVztDQUNiLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FFWixPQUNFLHdCQUFDLE9BQUQ7RUFDRSx3QkFBQyxNQUFELGFBQUksYUFBVSxRQUFhOzs7OztFQUMzQix3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7RUFFWix3QkFBQyxXQUFEO0dBQ0Usd0JBQUMsTUFBRCxZQUFJLGFBQWM7Ozs7O0dBRWpCLE9BQU8sV0FBVyxLQUNqQix3QkFBQyxLQUFELFlBQUcsd0NBQXdDOzs7OztHQUc3Qyx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNoQixPQUFPLEtBQUssT0FBTyxVQUVsQjtLQUFDOztLQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQU8sUUFBUjtPQUNFLFdBQVU7T0FDVixNQUFLO09BQ0wsU0FBUztRQUFFLFNBQVM7UUFBRyxHQUFHO09BQUc7T0FDN0IsU0FBUztRQUNQLFNBQVM7UUFDVCxHQUFHO1FBQ0gsU0FBUyxVQUFVLE1BQU0sT0FBTztPQUNsQztPQUNBLFlBQVk7UUFDVixNQUFNO1FBQ04sV0FBVztRQUNYLFNBQVM7T0FDWDtPQUNBLFlBQVk7UUFDVixHQUFHLENBQUM7UUFDSixPQUFPO1FBQ1AsU0FBUztPQUNYO09BQ0EsVUFBVTtRQUNSLE9BQU87UUFDUCxHQUFHO1FBQ0gsWUFBWTtTQUNWLE1BQU07U0FDTixVQUFVO1NBQ1YsUUFBUTtRQUNWO09BQ0Y7T0FDQSxlQUFlLGFBQWEsUUFBUSxLQUFLO2lCQTVCM0M7UUE4QkUsd0JBQUMsT0FBRDtTQUNFLEtBQUssTUFBTTtTQUNYLEtBQUssR0FBRyxNQUFNLE1BQU07U0FDcEIsV0FBVTtRQUNYOzs7OztRQUNELHdCQUFDLEtBQUQsWUFBSSxNQUFNLE1BQVM7Ozs7O1FBQ25CLHdCQUFDLEtBQUQsWUFBSSxNQUFNLFFBQVc7Ozs7O09BQ1I7Ozs7O2dCQUVmLHdCQUFDLFVBQUQ7T0FDRSxXQUFVO09BQ1YsTUFBSztPQUNMLE9BQU07T0FDTixlQUFlLFdBQVcsS0FBSztpQkFFL0Isd0JBQUMsa0JBQUQsRUFBa0IsTUFBTSxHQUFLOzs7OztNQUN2Qjs7OztjQUNMOztLQWhEb0MsTUFBTTs7Ozs7Ozs7SUFnRDFDLENBQ047R0FDTTs7Ozs7R0FFUixnQkFBZ0Isd0JBQUMsS0FBRCxZQUFJLGFBQWdCOzs7OztFQUM5Qjs7Ozs7RUFFUixXQUNDLHdCQUFDLGtCQUFEO0dBQ1c7R0FDVCxPQUFPO0dBQ1AsVUFBVSxXQUFXO0lBQ25CLElBQUksUUFBUSxnQkFBZ0IsV0FBVyxRQUFRLE1BQU0sR0FBRztJQUN4RCxXQUFXLElBQUk7R0FDakI7RUFDRDs7Ozs7Q0FFQTs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIb21lLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRVc2VyVHJhY2tzIH0gZnJvbSBcIi4uLy4uLy4uL0V4cHJlc3MtYmFja2VuZC9zcmMvYXBpL2xpYnJhcnlcIjtcclxuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiLi4vbGliL3N1cGFiYXNlXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSBcImZyYW1lci1tb3Rpb25cIjtcclxuaW1wb3J0IHsgU2hhcmVOZXR3b3JrSWNvbiB9IGZyb20gXCJAcGhvc3Bob3ItaWNvbnMvcmVhY3RcIjtcclxuaW1wb3J0IFNoYXJlVHJhY2tEaWFsb2cgZnJvbSBcIi4vU2hhcmVUcmFja0RpYWxvZ1wiO1xyXG5cclxuaW1wb3J0IFwiLi4vc3R5bGVzL0hvbWUuY3NzXCI7XHJcblxyXG5mdW5jdGlvbiBIb21lKHsgc2Vzc2lvbiwgb25TdGFydFF1ZXVlIH0pIHtcclxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0cmFja3MsIHNldFRyYWNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RyYWNrTWVzc2FnZSwgc2V0VHJhY2tNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyb3RhdGlvbnMsIHNldFJvdGF0aW9uc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3NoYXJpbmcsIHNldFNoYXJpbmddID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIC8vRmV0Y2hpbmcgdGhlIFVzZXJuYW1lIGZyb20gcGVyc29uYWwudXNlcnMudXNlcm5hbWVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc3VwYWJhc2VcclxuICAgICAgLmZyb20oXCJ1c2Vyc1wiKVxyXG4gICAgICAuc2VsZWN0KFwidXNlcl9uYW1lXCIpXHJcbiAgICAgIC5lcShcInVzZXJfaWRcIiwgc2Vzc2lvbi51c2VyLmlkKVxyXG4gICAgICAuc2luZ2xlKClcclxuICAgICAgLnRoZW4oKHsgZGF0YSB9KSA9PiBzZXRVc2VybmFtZShkYXRhPy51c2VyX25hbWUgPz8gXCJcIikpO1xyXG4gIH0sIFtzZXNzaW9uXSk7XHJcblxyXG4gIC8vIEZldGNoZXMgdGhlIHRyYWNrcyB0aGF0IHRoZSB1c2VyIG93bnNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZFRyYWNrcygpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB1c2VyVHJhY2tzID0gYXdhaXQgZ2V0VXNlclRyYWNrcyhcclxuICAgICAgICAgIHNlc3Npb24uYWNjZXNzX3Rva2VuXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRUcmFja3ModXNlclRyYWNrcyk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2V0VHJhY2tNZXNzYWdlKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZFRyYWNrcygpO1xyXG4gIH0sIFtzZXNzaW9uXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+V2VsY29tZSwge3VzZXJuYW1lfTwvaDI+XHJcbiAgICAgIDxoMj5Ib21lPC9oMj5cclxuXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxoMz5Zb3VyIE11c2ljPC9oMz5cclxuXHJcbiAgICAgICAge3RyYWNrcy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgPHA+WW91IGhhdmUgbm90IHVwbG9hZGVkIGFueSB0cmFja3MgeWV0LjwvcD5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0cmFjay1ncmlkXCI+XHJcbiAgICAgICAgICB7dHJhY2tzLm1hcCgodHJhY2ssIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgIC8vIFNoYXJlIHNpdHMgYmVzaWRlIHRoZSBjYXJkIGJlY2F1c2UgYnV0dG9ucyBjYW4ndCBuZXN0XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJhY2stY2FyZC13cmFwcGVyXCIga2V5PXt0cmFjay5pZH0+XHJcbiAgICAgICAgICAgICAgPG1vdGlvbi5idXR0b25cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRyYWNrLWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDMwIH19XHJcbiAgICAgICAgICAgICAgICBhbmltYXRlPXt7XHJcbiAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDEsXHJcbiAgICAgICAgICAgICAgICAgIHk6IDAsXHJcbiAgICAgICAgICAgICAgICAgIHJvdGF0ZVk6IHJvdGF0aW9uc1t0cmFjay5pZF0gfHwgMCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3ByaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgIHN0aWZmbmVzczogMTAwLFxyXG4gICAgICAgICAgICAgICAgICBkYW1waW5nOiAxNSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICB3aGlsZUhvdmVyPXt7XHJcbiAgICAgICAgICAgICAgICAgIHk6IC0xMCxcclxuICAgICAgICAgICAgICAgICAgc2NhbGU6IDEuMDQsXHJcbiAgICAgICAgICAgICAgICAgIHJvdGF0ZVk6IDM2MCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICB3aGlsZVRhcD17e1xyXG4gICAgICAgICAgICAgICAgICBzY2FsZTogMC45NSxcclxuICAgICAgICAgICAgICAgICAgeTogNCxcclxuICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwic3ByaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDAuMSxcclxuICAgICAgICAgICAgICAgICAgICBib3VuY2U6IDAsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TdGFydFF1ZXVlKHRyYWNrcywgaW5kZXgpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgc3JjPXt0cmFjay5jb3ZlckFydFVybH1cclxuICAgICAgICAgICAgICAgICAgYWx0PXtgJHt0cmFjay50aXRsZX0gY292ZXIgYXJ0YH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidXNlci10cmFjay1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHA+e3RyYWNrLnRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgIDxwPnt0cmFjay5hcnRpc3RzfTwvcD5cclxuICAgICAgICAgICAgICA8L21vdGlvbi5idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRyYWNrLXNoYXJlXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJTaGFyZSB3aXRoIGEgZnJpZW5kXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNoYXJpbmcodHJhY2spfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTaGFyZU5ldHdvcmtJY29uIHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAge3RyYWNrTWVzc2FnZSAmJiA8cD57dHJhY2tNZXNzYWdlfTwvcD59XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIHtzaGFyaW5nICYmIChcclxuICAgICAgICA8U2hhcmVUcmFja0RpYWxvZ1xyXG4gICAgICAgICAgc2Vzc2lvbj17c2Vzc2lvbn1cclxuICAgICAgICAgIHRyYWNrPXtzaGFyaW5nfVxyXG4gICAgICAgICAgb25DbG9zZT17KHNoYXJlZCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoc2hhcmVkKSBzZXRUcmFja01lc3NhZ2UoYFNoYXJlZCBcIiR7c2hhcmluZy50aXRsZX1cIi5gKTtcclxuICAgICAgICAgICAgc2V0U2hhcmluZyhudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhvbWU7XHJcbiJdfQ==